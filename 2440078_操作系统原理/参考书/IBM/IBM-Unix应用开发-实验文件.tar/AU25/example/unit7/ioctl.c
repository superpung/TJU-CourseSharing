/* ioctl.c */
#include <termio.h> /* terminal character, i/o control */ 
#include <stdio.h>  
struct termio origchar, newchar; /*struct to hold term char*/ 
main() 
{ 
   ioctl(0,TCGETA,&origchar); /* get the current EOF char */ 
   newchar = origchar;    /* Make a copy in newchar */ 
   newchar.c_cc[4]='\001'; /* change the EOF char*/ 
   ioctl(0,TCSETA, &newchar); /*it is now set to <Ctrl>A */ 
   printf("Executing cat > afile \n"); 
   printf("<Ctrl>A terminates...\n"); 
   system("cat > afile"); 
   ioctl(0,TCSETA,&origchar); /* resets original EOF char */ 
   printf("All done...\n"); 
} 
