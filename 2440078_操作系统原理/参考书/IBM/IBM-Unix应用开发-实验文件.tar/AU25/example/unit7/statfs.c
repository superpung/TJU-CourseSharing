/* statfs.c */
#include <sys/types.h>  
#include <sys/statfs.h>  
main(int argc, char *argv[]) 
{ 
	struct statfs mystatfs; 
 
	if (argc < 2) { 
		printf("Usage: %s filename\n", argv[0]); exit(1); 
	} 
	if ((statfs(argv[1], &mystatfs)) < 0) { 
		perror("Problems with statfs"); exit(1); 
	} 
	printf("Name of the file system for %s is %s\n", argv[1], 
	mystatfs.f_fname); 
	printf("Name of the vfstype for %s is %d\n", argv[1], 
	mystatfs.f_vfstype); 
	printf("Number of free blocks for %s is %d\n", argv[1], 
	mystatfs.f_bavail); 
	printf("Number of free blocks for superuser for %s is %d\n", 
		argv[1], mystatfs.f_bfree); 
	printf("File system pack name for %s is %s\n", 
		argv[1], mystatfs.f_fpack); 
	printf("File system name for %s is %s\n", 
		argv[1], mystatfs.f_fname); 
} 
