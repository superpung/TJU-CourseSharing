/* filesystem.c */
#include <stdio.h>  
#include <sys/types.h>  
#include <sys/stat.h>  
struct stat *statp; 
main() 
{ 
  statp=(struct stat*)malloc(sizeof(struct stat)); 
  chdir("/home/dave/workshop"); 
  sync(); 
  stat("newlist",statp); 
  printf("The number of links for newlist is %d.\n" 
             ,statp->st_nlink); 
  printf("Linking newlist to altlist...\n"); 
  link("newlist","/home/dave/altlist"); 
  stat("newlist",statp); 
  printf("Now the no. of links for newlist is %d.\n", 
             statp->st_nlink); 
  printf("Unlinking...\n"); 
  unlink("/home/dave/altlist"); 
  stat("newlist",statp); 
  printf("The number of links is back to %d.\n", 
                    statp->st_nlink); 
} 
