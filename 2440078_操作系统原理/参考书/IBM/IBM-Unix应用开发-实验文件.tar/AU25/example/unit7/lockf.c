/* lockf.c */
#include <sys/lockf.h>
#include <fcntl.h> /* file attributes */ 
#include <unistd.h> /*lseek constants */ 
#define RECSIZE 31 /* line length plus <CR> */ 
main() 
{ 
      int fd; 
      fd=open("mylist",O_RDWR); 
      /* lock first two records (lines) */ 
      lockf(fd,F_LOCK,(2 * RECSIZE)); 
      printf("Parent has locked first two records.\n"); 
      /* create a child process */ 
      if(fork()==0)  /* we are the child */ 
      { 
            /* lock record 5 */ 
            lseek(fd,(4 * RECSIZE),SEEK_SET); 
            lockf(fd,F_LOCK,RECSIZE); 
            printf("Child has locked fifth record.\n"); 
            /* try locking record 2 */ 
            lseek(fd,RECSIZE,SEEK_SET); 
            printf("Child trying to lock second record.\n"); 
            lockf(fd,F_LOCK,RECSIZE); 
            printf("Child has locked second record.\n"); 
            exit(0); /* implicitly releases locks */ 
      } 
      sleep(10); /* parent sleeps holding a lock */ 
      /* parent unlocks first two records */ 
      printf("Parent is unlocking first two records.\n"); 
      lseek(fd,0,SEEK_SET); 
      lockf(fd,F_ULOCK,(2 * RECSIZE)); 
} 
