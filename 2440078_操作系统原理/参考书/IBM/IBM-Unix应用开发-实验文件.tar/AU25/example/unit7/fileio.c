/* fileio.c */
#include <stdio.h> /*standard IO */ 
#include <fcntl.h> /*file attributes */ 
#include <sys/stat.h> /*file status values */ 
#include <sys/types.h> /*common typedefs */ 
#include <unistd.h> /*lseek constants */ 
main() 
{ 
   int fdr, fdw; 
   short i; 
   char line[44]; 
   /* open file "mylist" in read mode */ 
   fdr=open("mylist",O_RDONLY); 
   /* create new file "newlist" with read/write access */ 
   fdw=open("newlist",O_CREAT|O_WRONLY,0666); 
   /* skip first five entries in "mylist" */ 
   lseek(fdr,(5*sizeof(line)),SEEK_SET); 
   /* read the next five entries in "mylist" and 
      write them to "newlist" */ 
   for(i=0;i<5;i++) 
   { 
      read(fdr,line,sizeof(line)); 
      write(fdw,line,sizeof(line)); 
   } 
   /* close both files */ 
   close(fdr); 
   close(fdw); 
} 
