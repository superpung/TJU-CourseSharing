/* filelock.c */
#include <fcntl.h>  
#include <sys/flock.h>  
#include <unistd.h>  
#include <errno.h>  
main() 
{ 
int lock; 
int rc; 
struct flock myflock; 
char buffer[256]; 

lock = open("mylockfile", O_CREAT|O_RDWR,0666); 
printf("lock is %d\n", lock); 
myflock.l_type = F_WRLCK; /* write lock on whole file */ 
myflock.l_whence = SEEK_SET; 
myflock.l_start = 0; 
myflock.l_len = 0; 
 
 if (fcntl(lock,F_SETLKW,&myflock) < 0) {    /* locking */ 
     perror("problems with lockfile"); exit(1); 
 } 
 read(lock,buffer,sizeof(buffer)); 
 printf("Lockf: The buffer says - %s\n", buffer); 
 sleep(5); 
 myflock.l_type = F_UNLCK;        /* unlocking */ 
 if (fcntl(lock,F_SETLKW,&myflock) < 0) { 
     perror("problems with unlockfile"); exit(1); 
 } 
} 
