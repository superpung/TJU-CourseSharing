/* filetest.c */ 
#include <stdio.h>  
#include <fcntl.h>  
#include <sys/types.h>  
#include <unistd.h>  
main() 
{ 
       int fdr, fdw; 
       char line[31]; 
       chdir("/home/dave/workshop"); 
       fdr=open("mylist",O_RDWR); 
       umask(S_IROTH); /* sets new umask value */ 
       fdw=creat("newlist",0644); 
       /* copy the third record from mylist to newlist */ 
       lseek(fdr,(2 * sizeof(line)),SEEK_SET); 
       read(fdr,line,sizeof(line)); 
       write(fdw,line,sizeof(line)); 
       /* close all files */ 
       close(fdr); 
       close(fdw); 
       /* change permissions on "mylist" file */ 
       chmod("mylist",S_IRUSR|S_IWUSR|S_IRGRP|S_IWGRP); 
}
