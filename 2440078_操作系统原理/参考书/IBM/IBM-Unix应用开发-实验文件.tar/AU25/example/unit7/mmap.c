 /* mmap.c */
 #include <sys/types.h>  
 #include <fcntl.h>  
 #include <stdio.h>  
 #include <sys/mman.h>  
 #include <errno.h>  

 main() 
 { 
 	int fd, i; 
	 caddr_t ptr, beg_ptr; 
 
 	if ((fd = open("mmapfile",O_RDWR)) < 0) { 
	     perror("problems with open"); exit(1); 
	 } 
	 ptr = mmap((caddr_t)NULL,256, 
	 PROT_READ|PROT_WRITE, MAP_FILE|MAP_VARIABLE|MAP_SHARED, 
	   fd,(off_t)0); 
	 if (ptr == (caddr_t)-1) { 
	 perror("problems with mmap"); exit(1); 
	 } 
	 beg_ptr = ptr; 
 
	 for (i=0;i<100;i++) 
		 *ptr++='A'; 
	 if (munmap(beg_ptr,256) < 0 ) { 
	     perror("problems with munmap"); exit(1); 
	 } 
	 ftruncate(fd,100); 
	 if (close(fd) < 0 ) { 
	     perror("problems with close"); exit(1); 
	 } 
	 printf("done\n"); 
	 exit(0); 
 } 
