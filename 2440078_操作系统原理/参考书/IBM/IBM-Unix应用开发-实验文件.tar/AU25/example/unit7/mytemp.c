#include <stdio.h>
#include <stdlib.h>

main()
{
	FILE *temp;
	char buffer[50];

	if ((temp=tmpfile()) == NULL) {
		printf ("error creating file\n"); exit(1);
	}

	fputs("I wrote some data to the file\n", temp);
	rewind(temp);
	fgets(buffer, sizeof(buffer), temp);
	fputs(buffer, stdout);
	exit(0);
}
