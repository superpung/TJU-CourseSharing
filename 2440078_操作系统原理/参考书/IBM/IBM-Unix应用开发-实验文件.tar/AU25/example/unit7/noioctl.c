/* noioctl.c */
#include <termios.h>  
#include <termio.h>  
#include <stdio.h>  
main() 
{ 
	struct termios origtermios, newtermios; 
 
	tcgetattr(0, &origtermios);  
	newtermios = origtermios; 
 
	newtermios.c_cc[4] = '\001'; 
	tcsetattr(0,0,&newtermios); 
 
	printf("Executing cat > afile \n"); 
	printf("<Ctrl>A terminates...\n"); 
	system("cat > afile"); 
 
	tcsetattr(0,0,&origtermios); 
	printf("All done...\n"); 
} 
