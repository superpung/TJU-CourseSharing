/* chkfile.c */ 
#include <stdio.h>  
#include <sys/access.h> /*file access constants */ 
main(argc,argv) 
int argc; 
char *argv[]; 
{ 
   if(argc<2) { 
      printf("A file name must be specified.\n"); exit(1); 
   } 
   if(access(argv[1],F_OK)!=0) 
      printf("The named file does not exist.\n"); 
   if(access(argv[1],R_OK)==0) 
      printf("You have read access to the named file.\n"); 
   if(access(argv[1],W_OK)==0) 
      printf("You have write access to the named file.\n"); 
   if(access(argv[1],X_OK)==0) 
      printf("You can execute the named file.\n"); 
}
