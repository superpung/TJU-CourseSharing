# include<stdio.h>

int global = 100;

main()
{
	int x = 20;
	int y = 5;
	int z;
	printf("\n\n This is a sample program that does basic arithmetic oprations on two integer variables\n\n");
	printf("Global = %d\n",global);
	printf("Value of x = %d\n",x);
	printf("Value of y = %d\n",y);
	z = add_int(x,y);
	printf("\nAddition	: x + y = %d\n",z);
	z = sub_int(x,y);
	printf("\nSubtraction	: x - y = %d\n",z);
	z = mul_int(x,y);
	printf("\nMultiplication	: x * y = %d\n",z);
	z = div_int(x,y);
	printf("\nDivision	: x / y = %d\n",z);
}
