# include<stdio.h>

struct dummy {
	int i;
	char c;
	int * iptr;
};

main()
{
	int j = 50;
	struct dummy d;
	d.i = 75;
	d.c = 'V';
	d.iptr = &j;
	printf("i = %d, c = %c, iptr = %x\n",d.i, d.c, d.iptr);
	printf("Address of j = %x\n",&j);
}
