# include<stdio.h>

int add_int(int,int);
int sub_int(int,int);
int mul_int(int,int);
int div_int(int,int);

int add_int(int num1, int num2)
{
	int i;
	i = num1 + num2;
	return(i);
}

int sub_int(int num1, int num2)
{
        int i;
        i = num1 - num2;
        return(i);
}

int mul_int(int num1, int num2)
{
        int i;
        i = num1 * num2;
        return(i);
}

int div_int(int num1, int num2)
{
        int i;
        i = num1 / num2;
        return(i);
}
