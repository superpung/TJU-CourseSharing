# include<stdio.h>

struct node {
	char value[4];
	char *depth;
};

void format_node(struct node n)
{
	printf("value is %s, depth is %s\n",n.depth);
}

void doit()
{
	struct node n;
	sprintf(n.value,"%d",4*1024*1024);
	format_node(n);
}

main()
{
	printf("here we go...\n");
	doit();
	exit(0);
}
