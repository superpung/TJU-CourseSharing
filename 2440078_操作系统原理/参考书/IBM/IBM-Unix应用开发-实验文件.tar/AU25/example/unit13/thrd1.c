#include <pthread.h> /* for pthread defns and calls */ 
#include <stdio.h>   /* for printf */ 
 
void * funca(void * arg) /* Thread thd1 = T2 */ 
{  
	printf("Thread says: %s\n", (char *) arg); 
	pthread_exit(NULL); 
}  
 
main()  /* main thread  - T1 */ 
{  
	pthread_t thd1; 
	int rc; 
	char buffer[] = "Hi there!"; 
 
	rc=pthread_create(&thd1, NULL, funca, (void *) buffer); 
 
	if (rc) 
	{  
		/* error processing */ 
	}  
	pthread_exit(NULL); 
}  
