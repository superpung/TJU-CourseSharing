#include <sys/ipc.h>  
#include <sys/shm.h>  
#define SHMKEY 5555555L 
 
main()
{
	int shmid; 
	char *shmr_p, *shm_start_p; 
	int i; 
 
	if((shmid=shmget(SHMKEY,10,0))<0) { 
      		perror("Could not get shmid...");
		exit(1); 
	} 
	if((shm_start_p=shmat(shmid,0,0))<=0) { 
      		perror("Could not shmat...");
		exit(2); 
	} 
	shmr_p=shm_start_p; 
	for(i=1;i<=10;i++) 
      		printf("%c",*shmr_p++); 
	if(shmdt(shm_start_p) != 0) { 
      		perror("Could not detach...");
		exit(1); 
	} 
	if(shmctl(shmid,IPC_RMID,NULL !=0)) { 
      		perror("Could not remove segment...");
		exit(1); 
	} 
}
