#include <sys/types.h>  
#include <sys/ipc.h>  
#include <sys/sem.h>  
#define   SEMKEY 888888L 

int semid; 

extern int locker(int num); 
extern int unlocker(int num); 

main( ) 
{ 
 
 	semid=semget(SEMKEY,1,IPC_CREAT|0660); 
 	if  (locker(0)  != 0) 
        	perror("Problems locking semaphore"); 
 	else 
        	printf("Locked semaphore and pid is %d\n", getpid()); 
 
 	sleep(10); 
 	if (unlocker(0)  !=0) 
        	perror("Problems unlocking semaphore"); 
 	else 
        	printf("Unlocked semaphore and pid is %d\n", getpid()); 
 
 	semctl(semid,0,IPC_RMID,NULL); 
}
