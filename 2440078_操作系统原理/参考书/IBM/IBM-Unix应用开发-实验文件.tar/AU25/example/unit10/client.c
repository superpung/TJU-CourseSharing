#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>

main()
{
	int rc;
	int sd,sessionsd;
	char buffer[80];
	struct sockaddr_in toname;
	memset(&toname, 0, sizeof(toname));
	toname.sin_family = AF_INET;
	toname.sin_port = htons((u_short )5001);
	toname.sin_addr.s_addr = inet_addr("10.1.1.1");

	/*obtain a socket descriptor*/
	sd=socket(AF_INET,SOCK_STREAM,0);
	if ( sd == -1) {
      		perror("client:socket");
		exit(1);
	}
	/*connect with a server process*/
	rc = connect(sd, &toname, sizeof(toname));
	if (rc == -1) {
      		perror("client:connect");
		exit(2);
	}

	/*read a message from server*/
	rc = read(sd, buffer, sizeof(buffer));
	if (rc == -1) {
      		perror("client:read");
		exit(3);
	}
	printf("%s",buffer);
	close(sd);
}
