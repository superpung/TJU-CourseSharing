/*  msg queue example -- Server    */
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include "bbmsg.h"

main()
{
	bbmsg_t msgout, msgin;
	int msgid;
	if((msgid=msgget(MSGKEY,IPC_CREAT|0660))<0) {
        	perror("Could not create queue...");
		exit(1);
	}
	msgrcv(msgid,&msgin,sizeof(msgin),1,0);
	msgout.mtype=msgin.mpid;
	msgout.mpid=0;
	strcpy(msgout.mcity,msgin.mcity);
	strcpy(msgout.mcity,"San Antonio");
	if(msgsnd(msgid,&msgout,sizeof(msgout),IPC_NOWAIT)<0)
        	perror("Could not send message...");
}
