#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
extern int semid;

locker(int num)
{
      static struct sembuf lock_it[2] = {
                   0,0,0,
                   0,1,0
      };
      lock_it[0].sem_num = num; /* sem number to test*/
      lock_it[1].sem_num = num; /* sem number to lock*/

      if (semop(semid,&lock_it[0],2) < 0)
                   return 1;
      else
                   return 0;
}

unlocker(int num)
{
      static struct sembuf unlock_it[1] = {
                   0,-1,0
      };
      unlock_it[0].sem_num = num; /* sem number to unlock*/
      if(semop(semid,&unlock_it[0],1) < 0)
                   return 1;
      else
                   return 0;
}
