#include <sys/types.h>  
#include <stdio.h>  
#include <fcntl.h>  
main() 
{  
int p[2]; 
int fd; 
char buf[80]; 
pid_t pid; 
if (pipe(p) !=0) 
   {   perror("pipe failed"); 
       exit(1); 
   } 
if ((pid=fork()) == 0) 
{ 
close(p[0]); 
sprintf(buf,"%d",getpid()); 
write(p[1], buf,strlen(buf)+1); 
close(p[1]); 
exit (0); 
} 
 
/* Parent continues...*/ 
 
close(p[1]); 
read(p[0],buf,sizeof(buf)); 
printf("Child process said: %s\n", buf); 
close(p[0]); 
exit(0); 
} 
