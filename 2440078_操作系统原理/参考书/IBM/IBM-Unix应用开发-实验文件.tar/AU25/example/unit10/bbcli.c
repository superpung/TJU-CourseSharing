/*  msg queue example -- Client    */
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include "bbmsg.h"

main()
{
	bbmsg_t msgout, msgin;
	int msgid;
	msgout.mtype=1;
	msgout.mpid=getpid();
	if((msgid=msgget(MSGKEY,0))<0) {
        	perror("Could not get queue...");
	exit(1);
	}

	printf("Enter city name: ");
	scanf(&msgout.mcity);
	if(msgsnd(msgid,&msgout,sizeof (msgout),IPC_NOWAIT)<0) {
        	perror("Could not send message...");
		exit(1);
	}

	msgrcv(msgid,&msgin,sizeof (msgin),getpid(),0);
	printf("Team : %s\n",msgin.mteam);
}
