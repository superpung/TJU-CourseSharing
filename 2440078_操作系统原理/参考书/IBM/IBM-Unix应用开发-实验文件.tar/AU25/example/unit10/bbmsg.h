/*  bbmsg.h defines message format for example   */

typedef  struct my_msgbuf {
	long mtype;       /*  message type, must be > 0  */
	int mpid;         /*  PID of sender  */
	char mcity[32];   /*  client's city request  */
	char mteam[32];   /*  message data  */
} bbmsg_t;

#define MSGKEY 4429087L
