#include <sys/types.h>  
#include <stdio.h>  
#include <fcntl.h>  
 
main() 
{
	int fd,fd2,rc; 
	char buf[80]; 
	pid_t pid; 
 
	rc = mkfifo("myfifo", 0620); 
	if (rc < 0) { 
     		perror("problems with making the pipe"); 
		exit(1); 
	}   
	if ((pid=fork()) == 0) 
	{ 
		sleep(1); 
		fd = open("myfifo", O_WRONLY); 
		if (fd < 0) { 
     			perror("problems with open on pipe - child"); 
			exit(1); 
		} 
		sprintf(buf,"%d",getpid()); 
		rc = write(fd,buf,strlen(buf)+1); 
		if (rc < 0) { 
     			perror("problems with write on pipe"); exit(1); 
		} 
		close(fd); 
		exit (0); 
	} 

	fd2 = open("myfifo", O_RDWR); 
	if (fd2 < 0) { 
     		perror("problems: pipe open - parent"); 
		exit(1); 
	} 
	rc = read(fd2,buf,sizeof(buf)); 
	if (rc < 0) { 
     		perror("problems with read on pipe"); exit(1); 
	} 
	printf("Child process said: %s\n", buf); 
	close(fd2); 
	remove("myfifo"); 
	exit (0); 
} 
