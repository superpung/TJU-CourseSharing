#include <sys/signal.h>  
#include <stdlib.h>  
#include <fcntl.h>  
#include <sys/mode.h>  
 
#define PERMS 0620 
 
char *whoami; 
int fdread; 
 
int main(void) 
{ 
   int read_count; 
   int pid; 
   int fdwrite; 
   int rc; 
   char parentbuf[25]; 
   char childbuf[25]; 
 
   struct sigaction mysig; 
   sigset_t mymask; 
 
   void end_pgm(int signo); 
 
   memset(&mysig,0,sizeof(mysig)); 
   mysig.sa_handler = end_pgm; 
   sigfillset(&mymask); 
   mysig.sa_mask = mymask; 
   sigaction(SIGINT, &mysig, NULL); 
   sigaction(SIGQUIT, &mysig, NULL); 
   sigaction(SIGTERM, &mysig, NULL); 
 
   umask(0); 
   rc = mkfifo("myfifo", PERMS); 
   if (rc < 0) { 
     perror("parent: problems with create of myfifo"); exit(1); 
	} 
   pid = fork(); 
   if (pid == -1) { 
     perror("parent: problems with fork"); exit(3); 
} 
 
 
 
   if (pid == 0) 
    { 
    whoami = "child"; 
    fdwrite = open("myfifo", O_WRONLY); 
    if (fdwrite < 0) 
        perror("child: problems with open of myfifo"); exit(4); 
    strcpy(childbuf, "Hi there from child!\n"); 
    if ((write(fdwrite, childbuf, sizeof(childbuf))) < 0) 
        perror("child: problems with writing to pipe"); exit(5); 
    close(fdwrite); 
    exit(EXIT_SUCCESS); 
    } 
 
  whoami = "parent"; 
  fdread = open("myfifo", O_RDONLY); 
  if (fdread < 0) { 
     perror("parent: problems with open of myfifo"); exit(2);
  } 
   for(;;) 
  { 
  read_count = read(fdread, parentbuf, sizeof(parentbuf)); 
  if (read_count > 0) 
      { 
      printf("processing request\n"); 
      printf("request is: %s\n", parentbuf); 
      } 
 
    else 
     { 
    sleep(1); 
    } 
  } 
} 
 
void end_pgm(int signo) 
{ 
   remove("myfifo"); 
   printf("%s dying off... Signal %d received.\n",whoami,signo); 
   exit(EXIT_SUCCESS); 
} 
