#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <signal.h>

main()
{
	int rc, pid, i, clientlen, sessionsd,sd;
	char buffer[80];
	char str[20];
	struct sockaddr_in sockname, client;
/*	signal(SIGUSR1,cleanup);*/
	signal(SIGCHLD, SIG_IGN);
	strcpy(buffer,"This is the message from the server\n");

	memset(&sockname, 0, sizeof(sockname));
	sockname.sin_family = AF_INET;
	sockname.sin_port = htons((u_short )5001);
	sockname.sin_addr.s_addr = htonl(INADDR_ANY);

	sd=socket(AF_INET,SOCK_STREAM,0);
	if ( sd == -1) {
      		perror("server:socket");
		exit(1);
	}
	printf("Server socket is %d\n", sd);

	rc = bind(sd,&sockname,sizeof(sockname));
	if (rc == -1) {
      		perror("server:bind");
		exit(2);
	}
	if (listen(sd,3)== -1) {
      		perror("server:listen");
		exit(3);
	}
	/*wait for a connection*/
	for(;;) {
      		clientlen = sizeof(&client);
      		sessionsd = accept(sd,&client,&clientlen);
     	 	if (sessionsd == -1) {
         		perror("server:accept");
			exit(4);
      		}
      		/*fork child to perform rest of actions*/

      		pid=fork();
      		if(pid == -1) {
           		perror("server:fork");
			exit(6);
      		}
      		if(pid == 0)  {
           	/*write a message to the session socket descriptor*/
              		printf("Server sending....\n");
              		rc = write(sessionsd,buffer,sizeof(buffer));
              		if (rc == -1) {
                  		perror("server:send");
				exit(5);
              		}
          		exit(0);
       		}
		close(sessionsd);
	}
}
