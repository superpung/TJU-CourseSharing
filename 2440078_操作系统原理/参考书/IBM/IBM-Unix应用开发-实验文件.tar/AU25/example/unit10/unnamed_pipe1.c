#include <sys/signal.h>  
#include <stdlib.h>  
#include <fcntl.h>  
 
int p[2]; 
char *whoami; 
 
 
int main(void) 
{ 
   int read_count; 
   int pid; 
   char parentbuf[25]; 
   char childbuf[25]; 
 
   struct sigaction mysig; 
   sigset_t mymask; 
 
   void end_pgm(int signo); 
 
   memset(&mysig,0,sizeof(mysig)); 
   mysig.sa_handler = end_pgm; 
   sigfillset(&mymask); 
   mysig.sa_mask = mymask; 
   sigaction(SIGINT, &mysig, NULL); 
   sigaction(SIGQUIT, &mysig, NULL); 
   sigaction(SIGTERM, &mysig, NULL); 
 
   pipe(p); 
   pid = fork(); 
   if (pid == -1) { 
    perror("parent: problems with fork"); exit(1); 
    } 
   if (pid == 0) 
    { 
    whoami = "child"; 
    close(p[0]); 
    strcpy(childbuf, "Hi there from child!\n"); 
    if ((write(p[1], childbuf, sizeof(childbuf))) < 0) { 
        perror("child: problems with writing to pipe"); exit(2); 
    } 
    close(p[1]); 
    exit(EXIT_SUCCESS); 
    } 
 
 
 
   whoami = "parent"; 
   close (p[1]); 
   for(;;) 
    { 
    read_count = read(p[0], parentbuf, sizeof(parentbuf)); 
    if (read_count > 0) 
        { 
        printf("processing request\n"); 
        printf("request is: %s\n", parentbuf); 
        } 
 
    else 
    { 
    sleep(1); 
    } 
  } 
} 
 
void end_pgm(int signo) 
{ 
   printf("%s dying off... Signal %d received.\n",whoami,signo); 
   exit(EXIT_SUCCESS); 
} 
 
