#include <sys/ipc.h>  
#include <sys/shm.h>  
#define SHMKEY 5555555L 
 
main()
{
	int shmid; 
	char  *shmw_p, *shm_start_p; 
	int i; 
 
	if((shmid=shmget(SHMKEY,10,IPC_CREAT|0660))<0) { 
      		perror("Could not get shmid...");
		exit(1); 
	} 
	if((shm_start_p=shmat(shmid,0,0))<=0) { 
      		perror("Could not shmat...");
		exit(2); 
	} 
	shmw_p=shm_start_p; 
	for(i=1;i<=10;i++) 
      		*shmw_p++='A'; 
 
	if(shmdt(shm_start_p) != 0) { 
      		perror("Could not detach...");
		exit(1); 
	}
} 
