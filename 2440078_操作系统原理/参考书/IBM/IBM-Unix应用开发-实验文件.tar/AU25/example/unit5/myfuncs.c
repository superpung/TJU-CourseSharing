funcA()
{
printf("This is funcA\n");
}

funcB()
{
printf("This is funcB\n");
}

funcC()
{
printf("This is funcC\n");
}

funcXYZ()
{
printf("This is funcXYZ\n");
}
