funcB()
{
printf("This is funcB\n");
}
