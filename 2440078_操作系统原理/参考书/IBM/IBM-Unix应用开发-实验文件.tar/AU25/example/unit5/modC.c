funcC()
{
printf("This is funcC\n");
}
