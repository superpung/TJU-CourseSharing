main()
{
	printf("Staring main...\n");
	printf("Calling funcC...\n");
	funcC();
	printf("Back in main...\n");
	printf("Calling funcB...\n");
	funcB();
	printf("Back in main...\n");
	printf("Ending program...\n");
}
