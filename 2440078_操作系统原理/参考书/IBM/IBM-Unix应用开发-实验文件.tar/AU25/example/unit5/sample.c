main()
{
printf("This is main\n");
funcA();
funcB();
funcC();
}
