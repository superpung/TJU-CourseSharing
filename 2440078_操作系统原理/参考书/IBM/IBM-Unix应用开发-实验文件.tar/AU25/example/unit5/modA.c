funcA()
{
printf("This is funcA\n");
}
