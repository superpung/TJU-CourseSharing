#include <stdio.h>  
#include <signal.h>  
#include <limits.h>  

main() 
{ 
	int fd; 
 
	signal(SIGTTOU,SIG_IGN); 
	signal(SIGTTIN,SIG_IGN); 
	signal(SIGTSTP,SIG_IGN); 
	signal (SIGHUP,SIG_IGN); 
	if (fork()!=0) /* parent */ 
		exit(0); 
 
	setsid(); 	/* detach from process group and 
			   relinquish controlling terminal  */ 
 
	for (fd=0;fd < OPEN_MAX;fd++) 
		close(fd); 
 
	chdir("/"); 
	umask(0); 
 
	/* do the daemon's work */ 
} 
