/* sigaction.c */
#include <stdio.h>  
#include <signal.h>  
#include <memory.h>  
void handle_it(); 

main() 
{ 
	struct sigaction mysig; 
	memset (&mysig,0,sizeof(mysig)); 
	mysig.sa_handler = handle_it; 
	mysig.sa_flags = SA_RESTART; 
sigfillset(&mysig.sa_mask);
	/* register signals using mysig structure */ 
	sigaction(SIGINT,&mysig,NULL); 
	sigaction(SIGTERM,&mysig,NULL);

	while(1) { 
		printf("My pid is %d.\n",getpid()); 
		sleep(1); 
	}
} 

void handle_it(int signo) 
{ 
	printf("Received signal %d...Quitting\n", signo); 
	exit(0); 
}
