 /* condwait.c */
 #include <signal.h>  
 #include <stdio.h>  
 #include <pthread.h>  
 
 int Ready=0; 
 pthread_mutex_t m; 
 pthread_cond_t cv; 
 
 void  * slave(void * threadID) 
 { 
 int threadNum = *(int *) threadID; 
 	pthread_mutex_lock(&m); 
    while(Ready != 1) 
       pthread_cond_wait(&cv, &m);  
 	pthread_mutex_unlock(&m); 
 	printf("Thread %d continuing.... \n",threadNum); 
 		*(int *)threadID = 0; 
 	pthread_exit(NULL); 
 } 
 
 main() 
 { 
 	pthread_t thd1; 
 	pthread_t thd2; 
 	pthread_t thd3; 
 
 	int j1=1, j2=2, j3=3; 
 
 	pthread_mutex_init(&m,NULL);
 	pthread_cond_init(&cv,NULL); 
 
 	pthread_create(&thd1, NULL, slave, (void * )&j1); 
 	pthread_create(&thd2, NULL, slave, (void * )&j2); 
 	pthread_create(&thd3, NULL, slave, (void * )&j3); 
 	printf("Main doing work....\n"); 
 	sleep(5);      /* Simulate work */ 
 	pthread_mutex_lock(&m); 
 	Ready=1; 
 	pthread_cond_broadcast(&cv); 
 pthread_mutex_unlock(&m);
 printf("Main ready for others and continuing on.... \n"); 
 sleep(5); 
 
 /* Wait for children to terminate 
  * (using pthread_join with undetached 
  * children would be better) 
  */ 
 
 while ( j1 != 0 || j2 != 0 || j3 != 0 ) 
     sleep(1); 
 pthread_mutex_destroy(&m); 
 pthread_cond_destroy(&cv); 
 pthread_exit((void *) 0); 
 } 
