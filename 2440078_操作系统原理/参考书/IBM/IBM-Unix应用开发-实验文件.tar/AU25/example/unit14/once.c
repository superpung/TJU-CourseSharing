/* once.c */
#include <pthread.h>  
#include <unistd.h>  
 
pthread_t thd[2]; 
static pthread_once_t once = PTHREAD_ONCE_INIT; 
 
void init() 
{ 
       pthread_t self; 
       /* Do your initializations here */

       /* Check which thread is here */
       self = pthread_self(); 
       if(pthread_equal(self,thd[0]))
              printf("init() - invoked by Thread 1\n"); 
       if(pthread_equal(self,thd[1]))
              printf("init() - invoked by Thread 2\n"); 
} 
void * func(void *arg) 
{ 
       pthread_t self; 

       /* init() should be called only once */
       (void)pthread_once(&once, init); 
 
       self = pthread_self(); 
       if(pthread_equal(self,thd[0]))
              printf("In Thread 1\n");
       if(pthread_equal(self,thd[1]))
              printf("In Thread 2\n"); 
       pthread_exit((void *)1); 
} 
 
main() 
{ 
       pthread_create(&thd[0], NULL, func, 0);
       pthread_create(&thd[1], NULL, func, 0);
       pthread_exit( (void **)1);
}
