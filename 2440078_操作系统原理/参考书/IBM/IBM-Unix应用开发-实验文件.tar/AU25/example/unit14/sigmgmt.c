/* sigmgmt.c */
#include <pthread.h>  
#include <signal.h>  
 
void *threadfunc(void * notused) 
{ 
struct sigset_t set, oset; 
 
sigemptyset(&set); 
sigaddset(&set, SIGQUIT); 
sigthreadmask(SIG_BLOCK,  &set, NULL); 
 
for(;;); /* simulate action */ 
} 
 
void * sigwaiter_thread(void *notused) 
{ 
int sig; 
int ret; 
struct sigset_t set, oset; 
sigemptyset(&set); 
sigaddset(&set, SIGQUIT); 
sigthreadmask(SIG_BLOCK,  &set, NULL); 
 
for(;;) 
{ 
sigwait(&set,&sig); 
printf("sigwait() returned signal = %d\n", sig); 
} 
}
main() 
{ 
pthread_t waiterthd, thd; 
int status; 
struct sigset_t set, oset; 
struct sigaction mysig; 
pthread_attr_t attr; 
 
/* Block the signals. */ 
sigemptyset(&set); 
sigaddset(&set, SIGQUIT); 
sigthreadmask(SIG_BLOCK,  &set, NULL); 
 
pthread_attr_init(&attr); 
pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_UNDETACHED); 
 
pthread_create(&waiterthd, &attr, sigwaiter_thread, NULL); 
pthread_create(&thd, &attr,  threadfunc, NULL); 
 
sleep(2); 
 
pthread_join(thd, (void **)&status); 
printf("Main- check-\n"); 
} 
