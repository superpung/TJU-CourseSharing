 /* global.c */
 #include <stdio.h>  
 #include <stdlib.h>  
 #include <pthread.h>  
 
 int g_count; 
 int g_done; 
 pthread_mutex_t g_count_mutex; 
 
 void *  callFunc(void * notused) 
 { 
 int i; 
 
 printf("I'm in the child thread now....\n"); 
 for(i=0;i<10;i++) 
   { 
  		pthread_mutex_lock(&g_count_mutex); 
   		g_count++; 
   		pthread_mutex_unlock(&g_count_mutex); 
   		printf("Count in CHILD is %d\n", g_count); 
   		sleep(1); 
   } 
 g_done = 1; /* Child is done with the mutex */ 
 pthread_exit(NULL); 
 } 
main() 
{ 
 pthread_t callThd; 
 int ret; 
 int i; 
 
 g_count=0; 
 g_done=0; 
 pthread_mutex_init(&g_count_mutex,NULL); 
 ret=pthread_create(&callThd, NULL, callFunc, NULL); 
 if(ret) { 
 	printf("problems on creating thread\n"); 
 exit(EXIT_FAILURE); 
 } 
 for(i=0;i<10;i++) 
 { 
    pthread_mutex_lock(&g_count_mutex); 
    g_count++; 
    pthread_mutex_unlock(&g_count_mutex); 
    printf("Count in PARENT is %d\n", g_count); 
    sleep(1); 
 } 
 while (!g_done) 
      sleep(1); 
 pthread_mutex_destroy(&g_count_mutex); 
 pthread_exit(NULL); 
} 
