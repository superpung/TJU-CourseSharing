 /* master.c */
 #include <signal.h>  
 #include <stdio.h>  
 #include <pthread.h>  
 
 int jobInfo[25];               /* job data passed to thread */ 
 int jobAvail = 0;               /* boolean - # jobs available*/ 
 int jobPtr=0;                   /* job index for slave thread */ 
 
 pthread_mutex_t m;              /* used to protect cv */ 
 pthread_cond_t cv;              /* causes slave to wait for new job */ 
 pthread_key_t key;              /* provides  TSD data for global jobInfo*/ 
 
 void  * slave(void * threadID) 
 { 
 int threadNum=*(int *) threadID; 
 int  * local_job;               /* will store jobInfo data */ 
 for(;;) 
 { 
    pthread_mutex_lock(&m);
    while(jobAvail < 1 && jobPtr < 25) 
       pthread_cond_wait(&cv, &m);  
 
    if (jobPtr == 25) { 
       pthread_mutex_unlock(&m);  /* We're done */ 
       break; 
    } 
    local_job = (int *)malloc(sizeof(int));      /* allocate room for jobInfo*/ 
    pthread_setspecific(key, (void *)local_job); 
    *local_job = jobInfo[jobPtr];      /*global to TSD*/ 
    jobPtr++;                          /* job handled count goes up */ 
    jobAvail--;                        /* one less job left */ 
    pthread_mutex_unlock(&m);          /* Ready for others to continue*/ 
 
    printf("Thread %d handling job  with local_job info of %d\n", 
          threadNum, *local_job); 
 } 
 *(int *)threadID = 0; 
 pthread_exit(NULL); 
 } 
 main() 
 { 
 pthread_t thd1; 
 pthread_t thd2; 
 pthread_t thd3; 
 int j1=1,j2=2,j3=3;           /* thread IDs passed to threads */ 
 int i;                        /* job index for master thread */ 
 
 pthread_mutex_init(&m,NULL); 
 pthread_cond_init(&cv,NULL); 
 
 pthread_create(&thd1, NULL, slave, (void * )&j1); 
 pthread_create(&thd2, NULL, slave, (void * )&j2);
 pthread_create(&thd3, NULL, slave, (void * )&j3); 
 
 for(i=0;i< 25;i++) /* create 25 jobs */ 
 { 
 printf("Getting a new job\n");      /*simulates a new job created */ 
 jobInfo[i] = i + 100;               /* simulates making data */ 
 
 pthread_mutex_lock(&m); 
 jobAvail++;                         /* new job available */ 
 pthread_cond_signal(&cv); 
 pthread_mutex_unlock(&m); 
 } 
 
 
 /* Help others finish */ 
 /* (some might be blocked on the pthread_cond_wait call) */ 
 
 while ( j1 != 0 || j2 != 0 || j3 != 0 ) { 
 pthread_mutex_lock(&m); 
 pthread_cond_signal(&cv); 
 pthread_mutex_unlock(&m); 
 sleep(1); 
 } 
 
 pthread_mutex_destroy(&m); 
 pthread_cond_destroy(&cv); 
 exit(0); 
 }
