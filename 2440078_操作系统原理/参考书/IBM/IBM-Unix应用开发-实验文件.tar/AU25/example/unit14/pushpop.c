/* cancel.c */
#include <pthread.h>  
pthread_mutex_t m; 
 
void cleanup_m(void * m) 
{ 
printf("In cleanup_m handler.\n"); 
pthread_mutex_unlock((pthread_mutex_t *)m); 
} 
 
void * thread_starter(void * notused) 
{ 
printf("In thd1.\n"); 
pthread_mutex_lock(&m); 
pthread_cleanup_push(cleanup_m, (void *)&m); 
sleep(1); 
pthread_testcancel(); /* Cancelation point */ 
printf("If I reached here, I didn't get canceled.\n"); 
pthread_mutex_unlock(&m); 
pthread_cleanup_pop(0); 
pthread_exit(NULL); 
} 
main() 
{ 
pthread_t thd1; 

pthread_mutex_init(&m, NULL); 
pthread_create(&thd1, NULL, thread_starter, NULL); 
 
pthread_cancel(thd1); 
 
pthread_mutex_destroy(&m); 
pthread_exit(NULL); 
} 
