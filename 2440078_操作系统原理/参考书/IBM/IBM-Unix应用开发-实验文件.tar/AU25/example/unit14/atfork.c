/* atfork.c */
#include <pthread.h>                                 
#include <sys/types.h>                               
pthread_mutex_t m;                                   
                                                     
void prefork_prepare(void)                           
{                                                    
printf("prepare\n");                                
pthread_mutex_lock(&m);                             
}                                                    
void postfork_parent(void)                           
{                                                    
printf("parent\n");                                 
pthread_mutex_unlock(&m);                           
}                                                    
void postfork_child(void)                            
{                                                    
printf("Child\n");      
pthread_mutex_unlock(&m);                 
}                                          
void * func(void * arg)                    
{                                          
pthread_mutex_lock(&m);                   
sleep(1);                                 
printf("In func before unlock\n");        
pthread_mutex_unlock(&m);                 
pthread_exit(NULL);                       
}                                                                      
main()                                  
{                                       
pthread_t thd;                          
int status;                             
                                        
pthread_mutex_init(&m, NULL);           
                                       
pthread_create(&thd, NULL, func, (void *)func);
                                        
pthread_atfork(prefork_prepare, postfork_parent, postfork_child);
                                        
if(fork()== 0){                        
printf("Child  Process - Do lock\n");   
pthread_mutex_lock(&m);                
sleep(2);                              
printf("Child is exiting\n");          
exit(0);               
}                             
wait(&status);                 
pthread_exit(NULL);            
}                                              
