/* thrdsched.c */
#include  <pthread.h>  
 
void * func1( void *notused) 
{ 
 int priority; 
 struct sched_param sched; 

 pthread_getschedparam(pthread_self(), &priority, &sched);  
 printf("Child thread policy is %d and priority is %d\n", 
        sched.sched_policy, sched.sched_priority); 
} 

main() 
{ 
 struct sched_param sched; 
 
 pthread_attr_t attr; 
 pthread_t thd; 

 printf("Legend:\nPolicy 0 is SCHED_OTHER.\n"); 
 printf("Policy 1 is SCHED_FIFO.\n"); 
 printf("Policy 2 is SCHED_RR.\n\n");  

 pthread_create( &thd, NULL, func1, NULL); 
 sleep(1);

 printf("Changing policy of child thread to RR\n");
 printf("Changing priority of child thread to 80\n");

 pthread_attr_init(&attr);
 sched.sched_policy = SCHED_RR; 
 sched.sched_priority= 80; 
 pthread_attr_setschedparam(&attr, &sched);  
 pthread_attr_setinheritsched(&attr, PTHREAD_EXPLICIT_SCHED); 
 
 pthread_create( &thd, &attr, func1, NULL); 
 
 pthread_exit(NULL); 
} 
