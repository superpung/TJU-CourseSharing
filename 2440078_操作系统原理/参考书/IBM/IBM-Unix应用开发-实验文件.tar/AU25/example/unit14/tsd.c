 /* tsd.c */
 #include <pthread.h>  
 pthread_key_t count_key; 
 
 void * thread_starter(void * TID) 
 { 
 	int * ptr; 
  	int ThreadID; 
  	ThreadID=*(int *)TID; 
 
 	ptr=(int *) malloc(sizeof(int)); 
  	pthread_setspecific(count_key, ptr); 
  	*ptr=0; 
 
  	(*ptr)++; 
 	subfunc(); 
 	(*ptr)++; 
 	printf("Thread %d's count should be 3 now. The pointer says: %d\n", 
 		ThreadID, *ptr); 
 	*(int *)TID = 0; 
 } 
 
 subfunc(void) 
 { 
 	int * local_p; 
 	local_p=pthread_getspecific(count_key); 
 	(*local_p)++; 
 } 
 
 void count_key_destructor(void * Data) 
 { 
 		free(Data); 
 } 
 main() 
 { 
 	pthread_t thd1; 
 	pthread_t thd2; 
 	int tid1=1, tid2=2; 
 
 	pthread_key_create(&count_key, count_key_destructor); 
 
 	pthread_create(&thd1, NULL, thread_starter, (void *)&tid1); 
 	pthread_create(&thd2, NULL, thread_starter, (void *)&tid2); 
 	while (tid1 != 0 || tid2 != 0) 
   		sleep(1); 
 	while(pthread_key_delete(count_key) != 0) 
   		sleep(1); 
 
 	pthread_exit(NULL); 
 } 
