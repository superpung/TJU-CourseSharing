#include <stdio.h>  
main() 
{  
  printf("My pid is %d.\n",getpid() ); 
  printf("My parent's pid is %d.\n",getppid() ); 
  printf("My process group id is %d.\n",getpgrp() ); 
  printf("My real user id is %d.\n", getuid()); 
  printf("My effective user id is %d\n", geteuid()); 
  if (getpid() == getpgrp() ) 
  {  
       printf("This group leader process is ending now...\n");
	exit(0); 
  }  
  printf("Starting my own process group now...\n"); 
  setpgid(0,0); 
  printf("My process group id is now %d.\n", getpgrp() ); 
  printf("ending...\n"); 
}
