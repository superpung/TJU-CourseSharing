#include <stdio.h> 
 
main() 
{  
 int i, oldpri; 
 printf("My pid is %d.\n",getpid() ); 
 printf("My current priority is %d.\n",getpri(0) ); 
 printf("Looping for a while...\n"); 
 oldpri = getpri(0); 
while ( oldpri == getpri(0) ); 
 printf("Now my priority is %d.\n",getpri(0) ); 
 printf("The priority of my parent is %d.\n",getpri(getppid())); 
 printf("Attempting to set my priority...\n"); 
 if ( getuid()==0 || geteuid()==0 ) 
 {  
           setpri(0,30); 
           printf("My priority is now %d.\n",getpri(0)); 
           for(i=1;i<=1000;i++); 
           printf("My priority is still %d.\n",getpri(0)); 
           exit(); 
 }  
 printf("You do not have authority to set your priority!\n"); 
 exit(1); 
}
