#include <stdio.h>  
#include <signal.h>  
#include <sys/wait.h>  

void handle_it();

int status;
 
main() 
{ 
   int i = 2; 
   signal(SIGCHLD,handle_it); 
   while(i>0) {
   if(fork()==0)     /*We are the child... */ 
   {  
            execl("/usr/bin/ls", "ls",NULL); 
            perror("exec failed"); 
            exit(1); 
   }
   	i--; 
   } 
   while(1); 
}  
  
void handle_it() 
{
   int rv = 1;
   signal(SIGCHLD,handle_it);
   printf("signal handler\n");
   while(rv > 0) 
   	rv = waitpid(0,0,WNOHANG);
   printf("status = %d\n",status);
}
