#include <stdio.h>  
#include <string.h>  
#include <rpc/rpc.h>  
#include "baseball.h" 
 
reply * 
getcity_1(city_pp) 
char **city_pp; 
{ 
	char *cityname = *city_pp; 
	static reply r; 
 
	/* pretend that all cities have a team called the Mud Hens */ 
 
	r.city = cityname; 
	r.team = "Mud Hens"; 
	r.founded = 1997; 
	return(&r); 
} 

reply * 
champion_1(year_p) 
int *year_p; 
{ 
	int year = *year_p; 
	static reply r; 
 
	/* 
	 * The Sherwood Park Mud Hens won in 1997. 
	 * Nobody won in any other year. 
	 */ 
 
	if ( year == 1997 ) { 
		r.city = "Sherwood Park"; 
		r.team = "Mud Hens"; 
		r.founded = 1997; 
		return(&r); 
	} else { 
		r.city = NULL; 
		r.team = NULL; 
		r.founded = 0; 
		return(&r); 
	} 
} 

