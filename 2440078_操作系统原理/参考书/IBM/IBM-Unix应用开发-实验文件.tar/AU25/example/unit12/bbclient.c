#include <stdio.h>  
#include <rpc/rpc.h>  
#include "baseball.h" 
 
main(int argc, char **argv) 
{ 
	CLIENT *cl; 
	reply *rp; 
 
	if ( argc != 3 ) { 
		fprintf(stderr,"Usage:  bbclient server_host parm\n"); 
		fprintf(stderr,"\tserver_host : which host the server is running on\n");
		fprintf(stderr,"\tparm : either a year or a city name\n"); 
		exit(1); 
	} 
 
	/* Create the client record */ 
 
	cl = clnt_create(argv[1], TEAMDB, V1, "udp"); 
	if ( cl == NULL ) { 
		/* Can't find the server */ 
		clnt_pcreateerror(argv[1]); 
		exit(1); 
	} 
 
	if ( isdigit(argv[2][0]) ) { 
		int year; 
 
		year = atoi(argv[2]); 
		rp = champion_1(&year,cl); 
		if ( rp->city == NULL || strlen(rp->city) == 0 ) { 
			printf("Nobody won in %d.\n",year); 
		} else { 
			printf("The %s %s won in %d.\n",rp->city,rp->team,year);
		} 
	xdr_free(xdr_reply, rp); 
	} else { 
		rp = getcity_1(&argv[2],cl);
		if ( rp->city == NULL || strlen(rp->city) == 0) {
			printf("There is no team in %s.\n",argv[2]);
		} else {
			printf("The %s team is called the %s and was founded in %d.\n", rp->city,rp->team,rp->founded);
		}
		xdr_free(xdr_reply, rp);
	}
	exit(0);
}
