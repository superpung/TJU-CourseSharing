#include <rpc/rpc.h>
#include <sys/time.h>
#include "baseball.h"

/* Default timeout can be changed using clnt_control() */
static struct timeval TIMEOUT = { 25, 0 };

reply *
getcity_1(argp, clnt)
	char **argp;
	CLIENT *clnt;
{
	static reply res;

	bzero((char *)&res, sizeof(res));
	if (clnt_call(clnt, GETCITY, xdr_wrapstring, argp, xdr_reply, &res, TIMEOUT) != RPC_SUCCESS) {
		return (NULL);
	}
	return (&res);
}


reply *
champion_1(argp, clnt)
	int *argp;
	CLIENT *clnt;
{
	static reply res;

	bzero((char *)&res, sizeof(res));
	if (clnt_call(clnt, CHAMPION, xdr_int, argp, xdr_reply, &res, TIMEOUT) != RPC_SUCCESS) {
		return (NULL);
	}
	return (&res);
}

