#include <rpc/rpc.h>
#include "baseball.h"


bool_t
xdr_reply(xdrs, objp)
	XDR *xdrs;
	reply *objp;
{
	if (!xdr_string(xdrs, &objp->city, MAX_STR)) {
		return (FALSE);
	}
	if (!xdr_string(xdrs, &objp->team, MAX_STR)) {
		return (FALSE);
	}
	if (!xdr_int(xdrs, &objp->founded)) {
		return (FALSE);
	}
	return (TRUE);
}


