#define MAX_STR 32

struct reply {
	char *city;
	char *team;
	int founded;
};
typedef struct reply reply;
bool_t xdr_reply();


#define TEAMDB ((u_long)0x1234)
#define V1 ((u_long)1)
#define GETCITY ((u_long)1)
extern reply *getcity_1();
#define CHAMPION ((u_long)2)
extern reply *champion_1();

