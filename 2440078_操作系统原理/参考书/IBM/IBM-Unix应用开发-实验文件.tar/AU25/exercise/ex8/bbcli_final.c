
/* Program name - bbcli.c */ 

/* This program asks the user for a city, then sends 
a message across a message queue to a server.  The 
server looks the city up in the bball.db database and 
returns the name of the baseball team in that city.   */ 

#include <sys/mode.h> 
#include <sys/types.h> 
#include <sys/ipc.h> 
#include "bball.h" 

main() 
{ 
	struct msgout { 
		int mtype; /* Outgoing message */ 
        	int mpid; 
        	char mtext[20];
	} mymsgout; 

	struct msgin { 
		int mtype; /* Incoming message */ 
            	char mtext[20];
	} mymsgin; 

	char response[20]; 
	key_t mykey; 
	int msgid; 

	mykey=7654321L; 

	if ((msgid=msgget(mykey,0))<0) 
	{ 
		printf("Message queue is %d.\n",msgid); 
		perror("Could not get message queue..."); 
		perror("Check to see if the server is running..."); 
		exit(1); 
	} 


	while (1) 
	{ 
		printf("\nEnter a city:  "); 
   		gets(response); 
   		if (!(strcmp("quit",response))) 
      		{ 
			printf("Exiting...\n"); 
			exit(0); 
      		} 
 
  		mymsgout.mpid=getpid(); 
  		strcpy(mymsgout.mtext,response); 
 
  		mymsgout.mtype=1; 
  		if ((msgsnd(msgid,&mymsgout,sizeof(mymsgout),0)) < 0 ) 
      		{ 
			perror("Could not send message..."); 
			exit(1); 
      		} 
 
  		printf("\nWaiting for server to answer...\n"); 
  		if((msgrcv(msgid,&mymsgin,sizeof(mymsgin),getpid(),0)) <= 0) 
      		{ 
			perror("Could not receive message..."); 
			exit(1); 
      		} 
 
  		printf("\nThe team name is:  %s\n",mymsgin.mtext); 
 
      	}    /*  closes while loop   */ 
 
}   /*  End of Program    */ 

