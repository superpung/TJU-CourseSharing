
/* Program name - bbsvr.c   */ 
 
/*  This program takes requests for database lookups 
    from a client via message queues. The server 
    creates the message queue. Ther server looks 
    up the city in the bball.db file and returns the 
    discovered team name to the client via the message 
    queue. The outgoing message type is equal to the 
    client's PID, which the client sent in the request. 
    The structure of the client's request message is: 
 
                 int mpid; 
                 char city[20]; 
 
  The bball.db record structure is defined in bball.h */ 
 
#include <stdio.h>  
#include <sys/mode.h>  
#include <sys/types.h>  
#include <sys/ipc.h>  
#include <sys/file.h>  
#include "bball.h" 
 
main() 
{ 
	struct msgin {
		int mtype; /* Incoming message */ 
          	int mpid; 
                char mtext[20];
	} mymsgin; 
 
   	struct msgout {
		int mtype; /* Outgoing message */ 
                char mtext[20];
	} mymsgout; 
 
 
   	struct bbrec mybbrec; 
   	key_t mykey; 
   	int msgid; 
   	int fd; 
   	int i,n; 
   	char city[20]; 
 
   	mykey=7654321L; 
 
   	if ((msgid=msgget(mykey,IPC_CREAT|S_IRUSR|S_IWUSR))<0) 
	{ 
		printf("Message queue ID is %d.\n",msgid); 
		perror("Could not create message queue..."); 
		exit(1); 
	} 
 
   	printf("Message queue ID is %d.\n",msgid); 
 
   	if ((fd=open("./bball.db",O_RDONLY,0)) < 0 ) 
	{ 
		perror("Could not open data base file..."); 
		exit(1); 
	} 
 
	while (1) 
	{ 
   		printf("Waiting for requests...\n"); 
   		if (msgrcv(msgid,&mymsgin,256,1,0) <= 0) 
        	{ 
        		perror("Could not receive messages..."); 
        		exit(1); 
        	} 
 
		strcpy(city,mymsgin.mtext); 
		mymsgout.mtype=mymsgin.mpid; 
 
		printf("Lookup for city:  %s\n",city); 
 
		lseek(fd,0,SEEK_SET); 
		while(read(fd,&mybbrec,sizeof(mybbrec))) 
  		{        
			printf("Found city: %s   ---   team:  %s\n", mybbrec.city,mybbrec.team);        
			if (!strcmp(mybbrec.city,city) || !strcmp(mybbrec.city,"END"))                
  			{
				strcpy(mymsgout.mtext,mybbrec.team);
				printf("Returns: %s\n",mymsgout.mtext); 
				if (msgsnd(msgid,&mymsgout,sizeof(mymsgout),IPC_NOWAIT) < 0) 
  				{
  					perror("Could not send team name...");
					exit(1);           
  				}                
  				printf("Message sent.\n");        
				break;                
  			} 
		}
	}   /*  Closes while loop   */ 
}   
/*   End of Program   */  

