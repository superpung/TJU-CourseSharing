/* Program name - sem2.c */ 

#include <sys/types.h> 
#include <sys/ipc.h> 
#include <sys/sem.h> 
#include <sys/signal.h> 
#define SEMKEY 888888L 

int semid; 
extern int locker(int num); 
extern int unlocker(int num); 
static void handler(int signo); 


/* Be sure to include lockit.c when creating this mod.*/ 
/* cc -c sem2.c;cc -c lockit.c */
/* cc -o sem2 sem2.o lockit.o */
main() 
{
	sigset_t mymask; 
	struct sigaction mysig; 

	sigfillset( &mymask);
	mysig.sa_handler = handler; 
	mysig.sa_flags = 0; 
	mysig.sa_mask = mymask; 
	sigaction(SIGUSR1,&mysig,NULL);
 	/* prepare for SIGUSR1 before semctl done */ 
   	semid=semget(SEMKEY,1,IPC_CREAT|0660); 
   	if (locker(0)  !=  0) { 
   		perror("Problems locking semaphore");
		exit(1); 
	}  
	else
      		printf("Locked semaphore and pid is %d\n",getpid()); 
 
   	sleep(10);  /* simulate interim activity  */ 
 
   	if (unlocker(0)  != 0) { 
      		perror("Problems unlocking semaphore");
		exit(1); 
	}  
	else 
   		printf("Unlocked semaphore and pid is %d\n",getpid()); 
 
   	printf("Exiting....\n"); 
   	exit(0); 
} 
 
void handler(int signo) 
{ 
   	printf("Doing cleanup activity and exiting....\n"); 
   	exit(1); 
} 

