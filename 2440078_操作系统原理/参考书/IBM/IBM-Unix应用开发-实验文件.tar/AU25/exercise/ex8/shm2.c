
/* Program name - shm2.c */ 
 
#include <sys/types.h>  
#include <sys/shm.h>  
#define SHMKEY 333333L 
#define INFOSIZE 256000 
 
main() 
{ 
	int shmid; 
	struct shmid_ds mystat; 
	
	struct info { 
		int type; 
		int length; 
		char msg [256]; 
	} *shmptr, *shmptr_beg; 
 
	if ((shmid= shmget(SHMKEY,INFOSIZE,0)) <0) { 
		perror("problems with shmget"); 
		exit(1);
	} 
	if ((shmptr = (struct info *)shmat(shmid,0,0)) < 0) {
		perror("probs with shmat");
		exit(1);
	} 
	shmptr_beg= shmptr; 
 
	printf("The message says:  \n\n%s\n", shmptr->msg); 
 
	/* If we wanted, we could use the length field */ 
	/* to figure out how much to read.*/ 
 
	/* Note that if we would advance the pointer */ 
	/* (shmptr++), we would be going ahead one full */ 
	/* structure */ 
 
	/* We could also have used another field  */ 
	/* or separate control record to */ 
	/* figure out how many structures to read...OR */ 
	/* we could use semaphores....CONT. ON NEXT SCREEN */ 

	mystat.shm_nattch = 2; 
	while(mystat.shm_nattch > 1) 
	/* Make sure no messages on queue before it's */ 
	/* removed.... Remember, you have to be the   */ 
	/* owner to remove it.  You can set it from   */ 
	/* the original application with -            */ 
 
	/* shmctl(shmid,IPC_STAT,&mystat)              */ 
	/* mystat.shm_perm.uid = xxx;                  */ 
	/* shmctl(shmid,IPC_SET,&mystat)               */ 
 
	{ 
		sleep(1); 
		shmctl(shmid,IPC_STAT,&mystat); 
	} 
 
	if ((shmdt(shmptr_beg)) < 0) {
		perror("problems in detaching memory"); 
		exit(1);
	} 
	if ((shmctl(shmid, IPC_RMID, NULL)) <0) {
		perror("problems in removing shmid"); 
		exit(1);
	} 
} 

