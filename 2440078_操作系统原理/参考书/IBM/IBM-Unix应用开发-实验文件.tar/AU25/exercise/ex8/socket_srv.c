/* Program name - socket_srv.c */ 

#include <sys/types.h> 
#include <sys/socket.h> 
#include <netinet/in.h> 
#include <sys/signal.h> 
int sd; 

void cleanup(int i) 
{ 
	close(sd); 
	exit(0); 
} 

main() 
{ 
	int sessionsd; 
	int rc, pid, i; 
	socklen_t clientlen; 
	char buffer[80]; 
	char str[20]; 
	struct sockaddr_in sockname, client; 

	signal(SIGUSR1,cleanup); 
	strcpy(buffer,"This is the message from the server\n"); 

	memset( &sockname, 0, sizeof(sockname)); 
	sockname.sin_family = AF_INET; 
	sockname.sin_port = htons((u_short )7001); 
	sockname.sin_addr.s_addr = htonl(INADDR_ANY); 

	/*obtain a socket descriptor and bind a name to it*/ 
	sd=socket(AF_INET,SOCK_STREAM,0); 
	if ( sd == -1) { 
		perror("server:socket");
		exit(1); 
	} 
	printf("Server socket is %d\n", sd); 

	rc = bind(sd, (struct sockaddr *)&sockname,sizeof(sockname));
	if (rc == -1) { 
		perror("server:bind");
		exit(2); 
	} 


	/*specify the number of connections requests that can be queued*/ 
	if (listen(sd,3)== -1) { 
		perror("sever:listen");
		exit(3); 
	} 

	/*wait for a connection*/ 
	clientlen = sizeof(&client);
 	for(;;) { 
		sessionsd = accept(sd, (struct sockaddr *)&client,&clientlen);
		if (sessionsd == -1) { 
			perror("server:accept");
			exit(4); 
		} 
		/*fork child to perform rest of actions*/ 

		pid=fork(); 
		if(pid == -1) { 
			perror("server:fork");
			exit(6); 
		} 
		if(pid == 0)  { 
		/*write a message to the session socket descriptor*/ 
     			printf("Server sending....\n"); 
     			rc = write(sessionsd,buffer,sizeof(buffer)); 
     			if (rc == -1) { 
          			perror("server:send");
				exit(5); 
     			} 
			close(sessionsd); 
			exit(0); 
		}
	} 
}  

