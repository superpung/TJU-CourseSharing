/*     Header file for baseball database record definition    */

struct bbrec {
	char  city[20];
	char  team[20];
	char  newline;
};

