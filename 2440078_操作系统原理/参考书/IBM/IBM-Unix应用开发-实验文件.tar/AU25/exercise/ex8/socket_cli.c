/* socket_cli.c */ 
#include <sys/types.h>  
#include <sys/socket.h>  
#include <netinet/in.h>  

main() 
{ 
	int rc; 
	int sd,sessionsd; 
	char buffer[80]; 
	struct sockaddr_in toname; 
	memset(&toname, 0, sizeof(toname)); 
	toname.sin_family = AF_INET; 
	toname.sin_port = htons((u_short )(7001)); 
	toname.sin_addr.s_addr = inet_addr("10.1.1.1"); 
	/* The IP address must be that on which the server is running */
	/* Obtain a socket descriptor*/ 

	sd=socket(AF_INET,SOCK_STREAM,0); 
	if ( sd == -1) { 
		perror("client:socket");
		exit(1); 
	} 

	/*connect with a server process*/ 

	rc = connect(sd,(struct sockaddr *)&toname,sizeof(toname)); 
	if (rc == -1) { 
		perror("client:connect");
		exit(2); 
	} 

	/*sleep to allow server to send a message*/ 

	printf("Client ready to read from server...\n"); 
	sleep(2); 

	/*read a message from server*/ 

	rc = read(sd, buffer, sizeof(buffer)); 
	if (rc == -1) { 
		perror("client:read");
		exit(3); 
	} 
	printf("%s",buffer); 

	close(sd); 
} 

