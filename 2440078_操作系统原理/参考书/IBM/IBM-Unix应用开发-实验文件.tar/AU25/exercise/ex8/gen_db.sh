#!/usr/bin/ksh

echo "Pittsburgh\0         Pirates\0            " > bball.db
echo "Boston\0             Red Sox\0            " >> bball.db
echo "Chicago\0            Cubs\0               " >> bball.db
echo "Atlanta\0            Braves\0             " >> bball.db
echo "Los Angeles\0        Dogders\0            " >> bball.db
echo "Toronto\0            Blue Jays\0          " >> bball.db
echo "Houston\0            Astros\0             " >> bball.db
echo "END\0                No Team\0            " >> bball.db
