
/* Program name - sem1.c */

#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <sys/signal.h>
#define SEMKEY 888888L

int semid;
extern int locker(int num);
extern int unlocker(int num);

/* Be sure to include lockit.c when creating this mod */
/* cc -c sem1.c;cc -c lockit.c */
/* cc -o sem1 sem1.0 lockit.o */

main()
{
	sigset_t mymask;
	struct sigaction mysig;

	sigemptyset (&mymask);
	mysig.sa_handler = SIG_IGN;
	/* I dont care about cleanup since Im the */
	/* one issuing the SIGUSR1 at the end */
	mysig.sa_flags = 0;
	mysig.sa_mask = mymask;
	sigaction (SIGUSR1,&mysig,NULL);
	/* prepare for SIGUSR1 before semctl done */
	semid=semget(SEMKEY,1,IPC_CREAT|0660); 
	if (locker(0)  !=  0) { 
     		perror("Problems locking semaphore"); 
		exit(1); 
	}
	else 
  		printf("Locked semaphore and pid is %d\n",getpid()); 

	if (fork() == 0) /* start up competing child in*/ 
   	execl("./sem2","sem2",0);/* same process group */ 

	sleep(10);  /* simulate interim activity  */ 

	if (unlocker(0)  != 0) { 
   		perror("Problems unlocking semaphore"); 
		exit(1); 
	}
	else 
		printf("Unlocked semaphore and pid is %d\n",getpid()); 

	sleep(4); /* Let sem2 get started in the lock process */ 

	killpg(getpid(), SIGUSR1); /* warn that you're coming */ 
	/* down to all procs in current process group */ 

	sleep(5); 

	printf("Bringing down semaphore set....\n"); 

	if ((semctl(semid,0,IPC_RMID,NULL)) <0) { 
		perror("problems removing semaphore"); 
		exit(1); 
	} 
	/* repeat for all semaphores in set */ 

	exit(0); 
} 

