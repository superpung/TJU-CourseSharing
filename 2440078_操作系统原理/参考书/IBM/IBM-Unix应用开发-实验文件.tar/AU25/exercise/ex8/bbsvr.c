#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
...
	bbmsg_t msgout, msgin;
	int msgid;
	if((msgid=msgget(MSGKEY,IPC_CREAT|0660))<0) {
		perror("Could not create queue...");
		exit(1);
	}
	msgrcv(msgid,&msgin,sizeof(msgin),1,0);
	msgout.mtype=msgin.mpid;
	msgout.mpid=0;
	strcpy(msgout.mcity,msgin.mcity);
	/*  Lookup the baseball team for msgin.mcity and assign the
	    results to msgout.mteam  */
	if(msgsnd(msgid,&msgout,sizeof(msgout),IPC_NOWAIT)<0)
		perror("Could not send message...");
...
