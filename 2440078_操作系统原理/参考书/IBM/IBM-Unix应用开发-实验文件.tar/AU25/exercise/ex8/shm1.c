
/* Program name - shm1.c */ 
 
#include <sys/types.h>  
#include <sys/shm.h>  
#define SHMKEY 333333L 
#define INFOSIZE 256000 
 
main() 
{ 
	int shmid; 
	char mymsg[] = "Hi!!  Here's your message....\n"; 
 
	struct info { 
		int type; 
		int length; 
		char msg [256]; 
	} *shmptr, *shmptr_beg; 
 
	shmid = shmget(SHMKEY,INFOSIZE,IPC_CREAT|0660); 
	if ((shmptr = (struct info *)shmat(shmid,0,0)) < 0) 
		perror("probs with shmat"); 
	shmptr_beg= shmptr; 
 
	shmptr->type = 1; 
	shmptr->length = strlen(mymsg) + 1 + sizeof(shmptr->type) + sizeof(shmptr->length); 
	strcpy(shmptr->msg,mymsg); 
 
	shmdt(shmptr_beg); 
	/* let shm2 delete the shared memory    */ 
} 

