func1(){ 
	printf("This is function 1.\n"); 
} 
 
func2(){ 
	printf("This is function 2.\n"); 
} 
 
func3(){ 
	printf("This is function 3.\n"); 
} 
