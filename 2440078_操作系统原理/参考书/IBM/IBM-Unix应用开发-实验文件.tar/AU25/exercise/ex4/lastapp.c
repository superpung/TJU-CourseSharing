#include <dlfcn.h>
#include <stdio.h>

main()
{
	void *lib_handle;
	int (*funcp)();
	char *error;

	lib_handle = dlopen("./loadmod", RTLD_NOW);
	if(error = dlerror())
	{ 
		fprintf(stderr, "Error:%s \n",error);
		exit(1);
	} 
	printf("Load was successful.\n"); 

	funcp = (int (*)()) dlsym(lib_handle, "func3");
        if(error = dlerror())
        {
                fprintf(stderr, "Error:%s \n",error);
                exit(1);
        }
	(*funcp)(); 
	printf("\nUnloading loadmod.\n"); 
	
	dlclose(lib_handle);
        if(error = dlerror())
        {
                fprintf(stderr, "Error:%s \n",error);
                exit(1);
        }
}
