main() 
{ 
           printf("This is main calling foo...\n"); 
           foo(); 
           printf("Back to main.\n"); 
} 
