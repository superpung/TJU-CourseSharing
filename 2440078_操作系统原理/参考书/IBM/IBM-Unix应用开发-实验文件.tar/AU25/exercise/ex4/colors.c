red() 
{ 
	printf("This is the red function.\n"); 
} 
 
blue() 
{ 
	printf("This is the blue function.\n"); 
} 
 
green() 
{ 
	printf("This is the green function.\n"); 
} 
