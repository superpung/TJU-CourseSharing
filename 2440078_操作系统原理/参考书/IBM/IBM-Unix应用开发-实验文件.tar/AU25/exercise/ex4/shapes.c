
round() 
{ 
	printf("This is the round function.\n"); 
} 
 
square() 
{ 
	printf("This is the square function.\n"); 
} 
