main() 
{ 
	printf("This is main.\n"); 
	red(); 
	square(); 
	area(); 
	printf("Back in main.\n"); 
} 
