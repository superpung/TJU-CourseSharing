area() 
{ 
	printf("This is the area function.\n"); 
} 
 
vol() 
{ 
	printf("This is the vol function.\n"); 
}
