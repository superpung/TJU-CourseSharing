foo() 
{ 
	printf("This is the foo function\n"); 
} 
