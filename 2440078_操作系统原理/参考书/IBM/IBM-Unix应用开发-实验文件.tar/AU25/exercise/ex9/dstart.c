
/* Program name - dstart.c */ 

#include <stdio.h>  
#include <signal.h>  
#define NUMFILEDES 2000 

main() 
{ 
	int fd; 
 
	signal(SIGTTOU,SIG_IGN); 
	signal(SIGTTIN,SIG_IGN); 
	signal(SIGTSTP,SIG_IGN); 
 
	if (fork() != 0)   /* Parent  */ 
	{ 
		sleep(10); 
		exit(0); 
	} 
 
	setsid();  /* detach from process group and 
	relinquish controlling terminal   */ 
 
	for (fd=0; fd<NUMFILEDES; fd++) 
	close(fd); 
 
	chdir("/"); 
	umask(0); 
 
	execl("/exercises/ex9/mydaemon","mydaemon",0); 
	/* Set to appropriate dir  */ 
} 

