main() 
{  
	while (1) 
	{  
		system("/usr/bin/date >> /home/teamxx/dmonlab/dtest"); 
		sleep(10); 
	}  
}
