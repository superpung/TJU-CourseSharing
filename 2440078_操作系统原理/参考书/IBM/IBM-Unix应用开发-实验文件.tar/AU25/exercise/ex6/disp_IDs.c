/* disp_IDs.c */
/* This program displays its PID, PPID, RUID, EUID, and GID */

#include <stdio.h>

main()
{
        printf("My PID is %d\n",getpid());
        printf("My PPID is %d\n",getppid());
        printf("My UID is %d\n",getuid());
        printf("My EUID is %d\n",geteuid());
        printf("My GID is %d\n",getgid());
}
