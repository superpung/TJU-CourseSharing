/* set_child_PGID.c */
/* This program displays its PID, PPID, RUID, EUID, GID, and PGID */

#include <stdio.h>

main()
{
	printf("My PID is %d\n",getpid());
	printf("My PPID is %d\n",getppid());
	printf("My UID is %d\n",getuid());
	printf("My EUID is %d\n",geteuid());
	printf("My GID is %d\n",getgid());
	printf("My PGID is %d\n",getpgrp());
	
	if(fork() == 0)
	{
		printf("The child PGID is currently %d\n",getpgrp());
		printf("Changing the child process group ID\n");
		setpgid(0,0);
		printf("The child PGID is now %d\n",getpgrp());
	}
}
