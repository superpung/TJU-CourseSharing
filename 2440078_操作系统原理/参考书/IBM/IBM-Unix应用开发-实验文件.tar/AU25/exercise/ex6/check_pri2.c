/* check_pri2.c */
/* This program reports its priority every 100,000 microseconds, */
/* then attempts to change the priority */

#include <stdio.h>  

main() 
{ 
	int i; 
	for (i=1;i<=10;i++) 
	{
		printf("My priority is %d.\n", getpri(0)); 
		usleep(100000); 
	} 
	printf("Attempting to change the priority...\n"); 
	if (getuid()==0 || geteuid()==0) 
   	{ 
        	setpri(0,40); 
        	printf("My priority is now %d.\n", getpri(0)); 
   	} 
	else 
		printf("You do not have authority to change the priority.\n"); 
	printf("My priority is still %d.\n", getpri(0)); 
}
