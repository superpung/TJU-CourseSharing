/* demo_exec.c */
/* This program displays its PID and PPID, */
/* then forks a new process and waits */

#include <stdio.h>  

main() 
{ 
	printf("My PID is %d.\n", getpid()); 
	printf("My PPID is %d.\n", getppid()); 
	if (fork()==0) 
   	{ 
   		printf ("Executing program disp_IDs...\n"); 
   		execl("/home/team01/procmgmtlab/disp_IDs","disp_IDs",0); 
		printf("Error executing program disp_IDs\n");
		exit(1);
   	} 
	wait (NULL); 
	printf ("Returned to parent...\n"); 
}
