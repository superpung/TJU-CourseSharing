/* check_pri1.c */
/* This program reports its priority every 10,000 microseconds */

#include <stdio.h>  

main() 
{ 
	while(1) 
   	{ 
   		printf("My priority is %d.\n", getpri(0)); 
   		usleep(10000); 
   	} 
}
