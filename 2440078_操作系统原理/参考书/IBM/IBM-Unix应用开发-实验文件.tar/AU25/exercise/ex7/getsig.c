/* getsig.c */
/* This program reports its PID. */ 
/* It also catches SIGINT and SIGTERM signals. */ 
#include <signal.h> /* Automatically includes <sys/signal.h> */ 

void deal_with_it(int dummy) 
{ 
	printf("I received a SIGUSR1 signal\n"); 
	exit(0);
} 
 
main() 
{ 
	struct sigaction mysig; 

	mysig.sa_handler = deal_with_it; 
	mysig.sa_flags = 0; 
	sigemptyset(&mysig.sa_mask); 
	sigaction(SIGUSR1, &mysig,NULL);
	printf("My PID is %d.\n", getpid()); 

	/* infinite loop */
	while (1) ; 
} 
