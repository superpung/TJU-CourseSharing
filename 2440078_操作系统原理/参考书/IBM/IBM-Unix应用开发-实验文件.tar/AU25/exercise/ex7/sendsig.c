/* sendsig.c */
/* This program sends a SIGUSR1 signal to */ 
/* the PID provided as arg 1 by */ 
/* the user. It first verifies the existence */ 
/* of the process. */ 
#include <signal.h>  
 
main(int argc, char *argv[]) 
{ 
	int rv; 
	int target_pid; 

	if ( argc < 2 ) 
	{ 
		printf("Usage: %s target_pid\n", argv[0]); 
		exit(1); 
	} 

	target_pid = atoi(argv[1]); 
 
	rv = kill(target_pid, 0);   /*  test existence  */ 
	if ( rv < 0 )               /*  PID doesn't exist  */ 
	{ 
		printf("PID %d does not exist.\n", target_pid); 
		exit(2); 
	} 
 
	rv = kill(target_pid, SIGUSR1); 
	if ( rv < 0 ) 
	{ 
		printf("Unable to send signal.\n"); 
		printf("Check UID for permission.\n"); 
		exit(3); 
	} 
} 
