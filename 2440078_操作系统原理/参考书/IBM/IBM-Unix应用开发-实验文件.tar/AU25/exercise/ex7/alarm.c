/* alarm.c */
/* This program emulates an alarm clock */ 
 
#include <signal.h>  
#include <stdio.h>  
#include <stdlib.h>  
 
void catch_alrm (int signo) 
{ 
	printf("Just got a SIGALRM signal.\n");
	return; 
} 

main() 
{ 
	struct sigaction mysig; 
	mysig.sa_handler = catch_alrm; 
	mysig.sa_flags = 0; 
	sigemptyset(&mysig.sa_mask); 
	sigaction(SIGALRM, &mysig, NULL);/* reg. alarm signal */ 
	system("date"); 
	printf("Setting our alarm clock...\n"); 
	alarm (10);   /*schedule alarm for 10 sec. from now*/ 
	pause ();    /* pause until signal received */ 
	system("date"); 
	return 0;
} 
