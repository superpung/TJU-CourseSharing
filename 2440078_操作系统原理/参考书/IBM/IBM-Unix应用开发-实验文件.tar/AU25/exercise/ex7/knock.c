/* knock.c */
/* This program reports its PID every second */ 
/* It also catches SIGINT and SIGTERM signals. */ 
#include <signal.h> 

void deal_with_it(int dummy) 
{ 
	printf("I hear you knocking but you can't come in!\n"); 
} 

main() 
{
	struct sigaction mysig; 
	mysig.sa_handler = deal_with_it; 
	mysig.sa_flags = 0; 
	sigemptyset(&mysig.sa_mask); 
 
	sigaction(SIGINT, &mysig,NULL);
	sigaction(SIGTERM, &mysig,NULL);
	while (1) 
	{ 
		printf("My PID is %d.\n", getpid()); 
		sleep(1); 
	} 
} 
