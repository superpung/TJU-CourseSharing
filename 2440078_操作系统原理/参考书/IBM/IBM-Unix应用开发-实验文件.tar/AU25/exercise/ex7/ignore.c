/* ignore.c */
/* This program reports its PID every second */ 
/* It also ignores SIGINT and SIGTERM signals */ 
#include <signal.h>

main() 
{ 
	struct sigaction mysig; 
	mysig.sa_handler = SIG_IGN; 
	sigemptyset(&mysig.sa_mask); 
	mysig.sa_flags = 0; 
	sigaction(SIGINT, &mysig,NULL);
	sigaction(SIGTERM, &mysig,NULL);
	while (1) 
	{ 
		printf("My PID is %d.\n", getpid()); 
		sleep(1); 
	} 
} 
