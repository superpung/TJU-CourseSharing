h47004
s 00001/00000/00019
d D 1.2 02/03/26 16:00:51 root 2 1
c I made small changes.
e
s 00019/00000/00000
d D 1.1 02/03/26 15:55:03 root 1 0
c date and time created 02/03/26 15:55:03 by root
e
u
U
t
T
I 1
/*   mod1.c  Contains main processing */
I 2
static const char* SCCSID="%M% %I%";
E 2
#include <stdio.h>
#include "mydefs.h" /* assumes local */
#define MAX 15

main()
{
int a;
factor=5;
incnum=3;
#ifdef DEBUG
   printf("This is a test run.\n\n");
#endif
for (a=1;a<=MAX;a+=incnum)
   printf("a is %d, result is %d \n",a,a*factor);
printf("\nPassing to myfunc\n");
myfunc(a,factor,incnum);
printf("\nEnding program.HaHaHoHo\n");
}
E 1
