/* The remote procedures - funcs.c */

#include <stdio.h>
#include <string.h>
#include <time.h>
#include <rpc/rpc.h>
#include "rpcmail.h"

#define MAX_USERS	25		/* Support maximum of 25 users */
#define MAX_MSGS	10		/* Each user gets 10 messages */

struct user {
    char *name;
    struct {
	char *body;
	char *sender;
	char *subject;
	long timestamp;
    } msgs[MAX_MSGS];
};

struct user udb[MAX_USERS];

/*
 * The V1 routines
 */

static char *tmpmsg;

char **
next_1(char **username_pp)
{
    int i, j;
    char *username = *username_pp;

    if ( tmpmsg != NULL ) {
	free(tmpmsg);
	tmpmsg = NULL;
    }

    for ( i = 0; i < MAX_USERS; i += 1 ) {
	if ( udb[i].name != NULL && strcmp(udb[i].name,username) == 0 ) {
	    tmpmsg = udb[i].msgs[0].body;
	    free(udb[i].msgs[0].sender);
	    free(udb[i].msgs[0].subject);
	    for ( j = 1; j < MAX_MSGS; j += 1 ) {
		udb[i].msgs[j-1] = udb[i].msgs[j];
	    }
	    udb[i].msgs[MAX_MSGS-1].body = NULL;
	    if ( udb[i].msgs[0].body == NULL ) {
		/* No more messages - recycle this slot */
		free(udb[i].name);
		udb[i].name = NULL;
	    }
	    return(&tmpmsg);
	}
    }
    tmpmsg = strdup("");
    return(&tmpmsg);

}

int *
count_1(char **username_pp)
{
    int i;
    static int j;
    char *username = *username_pp;

    for ( i = 0; i < MAX_USERS; i += 1 ) {
	if ( udb[i].name != NULL && strcmp(udb[i].name,username) == 0 ) {
	    for ( j = 0; j < MAX_MSGS; j += 1 ) {
		if ( udb[i].msgs[j].body == NULL ) {
		    break;
		}
	    }
	    return(&j);
	}
    }
    j = 0;
    return(&j);
}

int *
send_1(struct msg *mp)
{
    char *username = mp->recipient;
    struct user *empty = NULL;
    int i, j;
    static int rval;

    for ( i = 0; i < MAX_USERS; i += 1 ) {
	if ( udb[i].name == NULL ) {
	    empty = &udb[i];
	} else if ( strcmp(udb[i].name,username) == 0 ) {
	    for ( j = 0; j < MAX_MSGS; j += 1 ) {
		if ( udb[i].msgs[j].body == NULL ) {
		    udb[i].msgs[j].body = strdup(mp->body);
		    udb[i].msgs[j].subject = strdup("");
		    udb[i].msgs[j].sender = strdup("<unknown>");
		    rval = 0;
		    return(&rval);
		}
	    }
	    rval = -1;
	    return(&rval);
	}
    }

    /* Didn't find the recipient - is there an empty slot? */

    if ( empty == NULL ) {
	rval = -1;
	return(&rval);
    }
    memset(empty,0,sizeof(*empty));
    empty->name = strdup(username);
    empty->msgs[0].body = strdup(mp->body);
    empty->msgs[0].subject = strdup("");
    empty->msgs[0].sender = strdup("<unknown>");
    rval = 0;
    return(&rval);
}

/*
 * The V2 routines
 */

struct msgv2 tmpv2;

struct msgv2 *
next_2(char **username_pp)
{
    int i, j;
    char *username = *username_pp;

    if ( tmpv2.recipient != NULL ) {
	xdr_free(xdr_msgv2,&tmpv2);
	memset(&tmpv2,0,sizeof(tmpv2));
    }

    for ( i = 0; i < MAX_USERS; i += 1 ) {
	if ( udb[i].name != NULL && strcmp(udb[i].name,username) == 0 ) {
	    tmpv2.body = udb[i].msgs[0].body;
	    tmpv2.subject = udb[i].msgs[0].subject;
	    tmpv2.sender = udb[i].msgs[0].sender;
	    tmpv2.recipient = strdup(username);
	    tmpv2.timestamp = udb[i].msgs[0].timestamp;
	    for ( j = 1; j < MAX_MSGS; j += 1 ) {
		udb[i].msgs[j-1] = udb[i].msgs[j];
	    }
	    udb[i].msgs[MAX_MSGS-1].body = NULL;
	    if ( udb[i].msgs[0].body == NULL ) {
		/* No more messages - recycle this slot */
		free(udb[i].name);
		udb[i].name = NULL;
	    }
	    return(&tmpv2);
	}
    }
    tmpv2.body = strdup("");
    tmpv2.subject = strdup("");
    tmpv2.sender = strdup("");
    tmpv2.recipient = strdup("");
    return(&tmpv2);

}

int *
count_2(char **username_pp)
{
    /* Identical to the V1 count routine */

    return( count_1(username_pp) );
}

int *
send_2(struct msgv2 *mp)
{
    char *username = mp->recipient;
    struct user *empty = NULL;
    int i, j;
    static int rval;
    struct timeval tv;

    gettimeofday(&tv,NULL);

    for ( i = 0; i < MAX_USERS; i += 1 ) {
	if ( udb[i].name == NULL ) {
	    empty = &udb[i];
	} else if ( strcmp(udb[i].name,username) == 0 ) {
	    for ( j = 0; j < MAX_MSGS; j += 1 ) {
		if ( udb[i].msgs[j].body == NULL ) {
		    udb[i].msgs[j].body = strdup(mp->body);
		    udb[i].msgs[j].subject = strdup(mp->subject);
		    udb[i].msgs[j].sender = strdup(mp->sender);
		    udb[i].msgs[j].timestamp = tv.tv_sec;
		    rval = 0;
		    return(&rval);
		}
	    }
	    rval = -1;
	    return(&rval);
	}
    }

    /* Didn't find the recipient - is there an empty slot? */

    if ( empty == NULL ) {
	rval = -1;
	return(&rval);
    }
    memset(empty,0,sizeof(*empty));
    empty->name = strdup(username);
    empty->msgs[0].body = strdup(mp->body);
    empty->msgs[0].subject = strdup(mp->subject);
    empty->msgs[0].sender = strdup(mp->sender);
    empty->msgs[0].timestamp = tv.tv_sec;
    rval = 0;
    return(&rval);
}
