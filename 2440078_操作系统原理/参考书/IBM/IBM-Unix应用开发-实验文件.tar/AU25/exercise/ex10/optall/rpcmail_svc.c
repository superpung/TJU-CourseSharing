#include <stdio.h>
#include <rpc/rpc.h>
#include "rpcmail.h"

static void rpcmail_1();
static void rpcmail_2();

main()
{
	SVCXPRT *transp;

	(void)pmap_unset(RPCMAIL, V1);
	(void)pmap_unset(RPCMAIL, V2);

	transp = svcudp_create(RPC_ANYSOCK);
	if (transp == NULL) {
		(void)fprintf(stderr, "cannot create udp service.\n");
		exit(1);
	}
	if (!svc_register(transp, RPCMAIL, V1, rpcmail_1, IPPROTO_UDP)) {
		(void)fprintf(stderr, "unable to register (RPCMAIL, V1, udp).\n");
		exit(1);
	}
	if (!svc_register(transp, RPCMAIL, V2, rpcmail_2, IPPROTO_UDP)) {
		(void)fprintf(stderr, "unable to register (RPCMAIL, V2, udp).\n");
		exit(1);
	}

	transp = svctcp_create(RPC_ANYSOCK, 0, 0);
	if (transp == NULL) {
		(void)fprintf(stderr, "cannot create tcp service.\n");
		exit(1);
	}
	if (!svc_register(transp, RPCMAIL, V1, rpcmail_1, IPPROTO_TCP)) {
		(void)fprintf(stderr, "unable to register (RPCMAIL, V1, tcp).\n");
		exit(1);
	}
	if (!svc_register(transp, RPCMAIL, V2, rpcmail_2, IPPROTO_TCP)) {
		(void)fprintf(stderr, "unable to register (RPCMAIL, V2, tcp).\n");
		exit(1);
	}
	svc_run();
	(void)fprintf(stderr, "svc_run returned\n");
	exit(1);
}

static void
rpcmail_1(rqstp, transp)
	struct svc_req *rqstp;
	SVCXPRT *transp;
{
	union {
		char *next_1_arg;
		msg send_1_arg;
		char *count_1_arg;
	} argument;
	char *result;
	bool_t (*xdr_argument)(), (*xdr_result)();
	char *(*local)();

	switch (rqstp->rq_proc) {
	case NULLPROC:
		(void)svc_sendreply(transp, xdr_void, (char *)NULL);
		return;

	case NEXT:
		xdr_argument = xdr_wrapstring;
		xdr_result = xdr_wrapstring;
		local = (char *(*)()) next_1;
		break;

	case SEND:
		xdr_argument = xdr_msg;
		xdr_result = xdr_int;
		local = (char *(*)()) send_1;
		break;

	case COUNT:
		xdr_argument = xdr_wrapstring;
		xdr_result = xdr_int;
		local = (char *(*)()) count_1;
		break;

	default:
		svcerr_noproc(transp);
		return;
	}
	bzero((char *)&argument, sizeof(argument));
	if (!svc_getargs(transp, xdr_argument, &argument)) {
		svcerr_decode(transp);
		return;
	}
	result = (*local)(&argument, rqstp);
	if (result != NULL && !svc_sendreply(transp, xdr_result, result)) {
		svcerr_systemerr(transp);
	}
	if (!svc_freeargs(transp, xdr_argument, &argument)) {
		(void)fprintf(stderr, "unable to free arguments\n");
		exit(1);
	}
}


static void
rpcmail_2(rqstp, transp)
	struct svc_req *rqstp;
	SVCXPRT *transp;
{
	union {
		char *next_2_arg;
		msgv2 send_2_arg;
		char *count_2_arg;
	} argument;
	char *result;
	bool_t (*xdr_argument)(), (*xdr_result)();
	char *(*local)();

	switch (rqstp->rq_proc) {
	case NULLPROC:
		(void)svc_sendreply(transp, xdr_void, (char *)NULL);
		return;

	case NEXT:
		xdr_argument = xdr_wrapstring;
		xdr_result = xdr_msgv2;
		local = (char *(*)()) next_2;
		break;

	case SEND:
		xdr_argument = xdr_msgv2;
		xdr_result = xdr_int;
		local = (char *(*)()) send_2;
		break;

	case COUNT:
		xdr_argument = xdr_wrapstring;
		xdr_result = xdr_int;
		local = (char *(*)()) count_2;
		break;

	default:
		svcerr_noproc(transp);
		return;
	}
	bzero((char *)&argument, sizeof(argument));
	if (!svc_getargs(transp, xdr_argument, &argument)) {
		svcerr_decode(transp);
		return;
	}
	result = (*local)(&argument, rqstp);
	if (result != NULL && !svc_sendreply(transp, xdr_result, result)) {
		svcerr_systemerr(transp);
	}
	if (!svc_freeargs(transp, xdr_argument, &argument)) {
		(void)fprintf(stderr, "unable to free arguments\n");
		exit(1);
	}
}

