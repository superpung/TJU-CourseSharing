#include <rpc/rpc.h>
#include "rpcmail.h"


bool_t
xdr_msg(xdrs, objp)
	XDR *xdrs;
	msg *objp;
{
	if (!xdr_string(xdrs, &objp->recipient, MAX_USERNAME)) {
		return (FALSE);
	}
	if (!xdr_string(xdrs, &objp->body, MAX_BODY)) {
		return (FALSE);
	}
	return (TRUE);
}




bool_t
xdr_msgv2(xdrs, objp)
	XDR *xdrs;
	msgv2 *objp;
{
	if (!xdr_string(xdrs, &objp->recipient, MAX_USERNAME)) {
		return (FALSE);
	}
	if (!xdr_string(xdrs, &objp->sender, MAX_USERNAME)) {
		return (FALSE);
	}
	if (!xdr_string(xdrs, &objp->body, MAX_BODY)) {
		return (FALSE);
	}
	if (!xdr_string(xdrs, &objp->subject, MAX_SUBJECT)) {
		return (FALSE);
	}
	if (!xdr_long(xdrs, &objp->timestamp)) {
		return (FALSE);
	}
	return (TRUE);
}


