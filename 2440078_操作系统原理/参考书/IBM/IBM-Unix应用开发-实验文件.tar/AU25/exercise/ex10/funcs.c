/* The remote procedures - funcs.c */

#include <stdio.h>
#include <string.h>
#include <rpc/rpc.h>
#include "rpcmail.h"

#define MAX_USERS	25		/* Support maximum of 25 users */
#define MAX_MSGS	10		/* Each user gets 10 messages */

struct user {
	char *name;
	char *msgs[MAX_MSGS];
};

struct user udb[MAX_USERS];

static char *tmpmsg;

char **
next_1(char **username_pp)
{
	int i, j;
	char *username = *username_pp;

	if ( tmpmsg != NULL ) {
		free(tmpmsg);
		tmpmsg = NULL;
	}

	for ( i = 0; i < MAX_USERS; i += 1 ) {
		if ( udb[i].name != NULL && strcmp(udb[i].name,username) == 0 ){
			tmpmsg = udb[i].msgs[0];
			for ( j = 1; j < MAX_MSGS; j += 1 ) {
				udb[i].msgs[j-1] = udb[i].msgs[j];
			}
			udb[i].msgs[MAX_MSGS-1] = NULL;
			if ( udb[i].msgs[0] == NULL ) {
				/* No more messages - recycle this slot */
				free(udb[i].name);
				udb[i].name = NULL;
			}
			return(&tmpmsg);
		}
    	}
	tmpmsg = strdup("");
	return(&tmpmsg);
}

int *
send_1(struct msg *mp)
{
	char *username = mp->recipient;
	struct user *empty = NULL;
	int i, j;
	static int rval;

	for ( i = 0; i < MAX_USERS; i += 1 ) {
		if ( udb[i].name == NULL ) {
			empty = &udb[i];
		} else if ( strcmp(udb[i].name,username) == 0 ) {
			for ( j = 0; j < MAX_MSGS; j += 1 ) {
				if ( udb[i].msgs[j] == NULL ) {
					udb[i].msgs[j] = strdup(mp->body);
					rval = 0;
					return(&rval);
				}
			}
			rval = -1;
			return(&rval);
		}
	}

	/* Didn't find the recipient - is there an empty slot? */

	if ( empty == NULL ) {
		rval = -1;
		return(&rval);
	}
	memset(empty,0,sizeof(*empty));
	empty->name = strdup(username);
	empty->msgs[0] = strdup(mp->body);
	rval = 0;
	return(&rval);
}
