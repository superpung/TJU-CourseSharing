#define MAX_USERNAME 20
#define MAX_BODY 1001

struct msg {
	char *recipient;
	char *body;
};
typedef struct msg msg;
bool_t xdr_msg();


#define RPCMAIL ((u_long)12345)
#define V1 ((u_long)1)
#define NEXT ((u_long)1)
extern char **next_1();
#define SEND ((u_long)2)
extern int *send_1();
#define COUNT ((u_long)3)
extern int *count_1();

