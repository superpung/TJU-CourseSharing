#include <rpc/rpc.h>
#include "rpcmail.h"


bool_t
xdr_msg(xdrs, objp)
	XDR *xdrs;
	msg *objp;
{
	if (!xdr_string(xdrs, &objp->recipient, MAX_USERNAME)) {
		return (FALSE);
	}
	if (!xdr_string(xdrs, &objp->body, MAX_BODY)) {
		return (FALSE);
	}
	return (TRUE);
}


