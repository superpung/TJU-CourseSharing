
/* The mail client main program - mc.c */ 
/* This file is in /home/workshop/q1125/solutions/rpclbasic/mc.c */
 
#include <stdio.h>  
#include <stdlib.h>  
#include <unistd.h>  
#include <rpc/rpc.h>  
#include "rpcmail.h" 
 
CLIENT *cl; 
char *username; 
 
void 
show_usage() 
{ 
	fprintf(stderr,"Usage:\n"); 
	fprintf(stderr,"\tmc send _recipient_ < msg\n"); 
	fprintf(stderr,"\tmc next\n"); 
} 
 
void 
donext() 
{ 
	char **msgp; 
	char *msg; 
 
	msgp = next_1(&username,cl);
	msg = *msgp; 
	if ( strlen(msg) == 0 ) { 
		fprintf(stderr,"no more messages\n"); 
	} else { 
		printf("%s\n",msg); 
	} 
} 

void 
dosend(char *recipient) 
{ 
	struct msg m; 
	char **msgp; 
	char *msg; 
	char buffer[MAX_BODY]; 
	char *nextp; 
	int left; 

	m.recipient = recipient; 
	m.body = &buffer[0];
	nextp = &buffer[0];
	left = sizeof(buffer)-1;
	while (1) {
		if ( fgets(nextp,left,stdin) == NULL ) {
			if ( nextp == &buffer[0] ) {
				fprintf(stderr,"no message body - request ignored\n");
			} else {
				send_1(&m,cl);
				printf("%d byte message sent to %s\n", strlen(buffer),recipient);
				return;
			}
		}
		left -= strlen(nextp);
		nextp += strlen(nextp);
	}
}

main(int argc, char **argv)
{
	char *servername;

	if ( argc < 2 ) {
		show_usage();
		exit(1);
	}

	servername = getenv("RPCMAIL");
	if ( servername == NULL ) {
		fprintf(stderr,"Please set RPCMAIL environment variable to the name\n");
		fprintf(stderr,"of the machine that the rpcmail server is running on.\n");
		exit(1);
	}

	username = getlogin();
	if ( username == NULL ) {
		fprintf(stderr,"can't get your username - bye!\n");
		exit(1);
	}

	/* Create the client record */

	cl = clnt_create(servername, RPCMAIL, V1, "udp");
	if ( cl == NULL ) {
		/* Can't contact the server */
		clnt_pcreateerror(servername);
		exit(1);
	}

	if ( strcmp(argv[1],"next") == 0 ) {
		if ( argv[2] != NULL ) {
			fprintf(stderr,"unexpected parameter after \"next\" command\n");
			show_usage();
                           exit(1);
		}
		donext();
	} else if ( strcmp(argv[1],"send") == 0 ) {
		if ( argv[2] == NULL ) {
			fprintf(stderr,"missing recipient after \"send\" command\n");
			show_usage();
			exit(1);
		}
		if ( argv[3] != NULL ) {
			fprintf(stderr, "unexpected parameter after \"send\" command's recipient \"%s\"\n", argv[2]);
			show_usage();
			exit(1);
		}
		dosend(argv[2]);
	} else {
		fprintf(stderr,"\"%s\" is an invalid command\n",argv[1]);
		show_usage();
		exit(1);
	}
	exit(0);
}
