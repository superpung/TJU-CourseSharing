/* exitstatus.c */
#include <pthread.h>  
#include <stdio.h>  
#include <stdlib.h>  
 
void *  callFunc(void * myarg) 
{ 
   printf("Arg from main is: %s\n", (char *)myarg); 
   pthread_exit((void *) 2); 
} 
 
main() 
{ 
   pthread_t callThd; 
   pthread_attr_t attr; 
   char myparm[] = "Main Thread Arg.\n"; 
   int status; 
 
   pthread_attr_init(&attr);
   pthread_attr_setdetachstate(&attr,PTHREAD_CREATE_UNDETACHED);
   pthread_create(&callThd, &attr, callFunc, (void *)myparm); 
 
   pthread_join(callThd,(void * *) &status); 
   printf("status from callThd is %d\n", status); 
 
   pthread_exit(NULL); 
} 
