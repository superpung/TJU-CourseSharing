/* multi.c */
#include <pthread.h>  
#include <stdio.h>  
#include <stdlib.h>  
 
void *  callFunc(void * myarg) 
{ 
   printf("Arg from main is: %s\n", (char *)myarg); 
   pthread_exit(NULL); 
} 
 
main() 
{ 
   pthread_t callThd; 
   char myparm[] = "Main Thread Arg.\n"; 
 
   pthread_create(&callThd, NULL, callFunc, (void *)myparm); 
   pthread_exit(NULL); 
} 
