/*   mod1.c  Contains main processing */
#include <stdio.h>
#include "mydefs.h" /* assumes local */
#define MAX 15

main()
{
int a;
factor=5;
incnum=3;
#ifdef DEBUG
   printf("This is a test run.\n\n");
#endif
for (a=1;a<=MAX;a+=incnum)
   printf("a is %d, result is %d \n",a,a*factor);
printf("\nPassing to myfunc\n");
myfunc(a,factor,incnum);
printf("\nEnding program\n");
}
