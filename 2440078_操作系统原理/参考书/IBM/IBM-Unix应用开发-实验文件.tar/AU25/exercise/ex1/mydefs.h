/* mydefs.h    typical header file */
int factor;
int incnum;
int sad;
int myfunc(int, int, int);
