/*   mod2.c  Contains myfunc() code */
#define MIN 0
myfunc(int x, int newfactor, int decnum)
{
	printf("Now in myfunc in mod2.c\n");
	for (x;x>=MIN;x-=decnum)
   		printf("x is %d, result is %d\n",x,x*newfactor);
	printf("Returning to main now\n");
}
