/*   count.c */
/*   This program opens the file specified on the command line and counts   */
/*   the number of characters in the file.  The results are printed to      */
/*   standard out.                                                          */
#include <fcntl.h>

main(int argc, char *argv[])
{
	int fd;
	int count=0;
	char c;

	if (argc != 2)
	{
		printf("Usage -- %s filename\n",argv[0]);
		exit(1);
	}
	if ((fd=open(argv[1],O_RDONLY)) < 0 )
	{
		perror("Could not open file - See Instructor.\n");
		exit(1);
	}
	while (read(fd,&c,1))
		count++ ;
	printf("The character count is %d.\n", count);
	close(fd);
}
