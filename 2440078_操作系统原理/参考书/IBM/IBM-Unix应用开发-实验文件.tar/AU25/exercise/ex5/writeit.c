/* writeit.c */
#include <fcntl.h>
#include <sys/types.h>
main()
{
	int i,fdw;
	char c='A';
	fdw=open("wfile",O_CREAT|O_RDWR, 0666);
	for (i=0;i<1000000;i++)
		write(fdw,&c,1);
	close(fdw);
	exit(0);
}
