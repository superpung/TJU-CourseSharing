/* dirperms.c */
/* This program creates a directory */ 
/* and changes its permission to rwx------ */ 
#include <fcntl.h>  
 
main(int argc, char *argv[]) 
{ 
	int fd, count; 
	char c; 

	if (argc != 3) 
	{ 
		printf("Usage -- %s dirname linkname\n",argv[0]); 
		exit(1); 
	} 
	if (mkdir(argv[1], 0700) == -1) 
	{ 
		perror("Can't create directory.\n"); 
		exit(1); 
	} 
	if (symlink(argv[1], argv[2]) == -1)
	{ 
		perror("Can't create link.\n"); 
		exit(2); 
	} 
} 
