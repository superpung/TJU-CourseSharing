/* mapit.c */
#include <fcntl.h>
#include <sys/shm.h>
main()
{
	int i,fdw;
	char *ptr, *beg_ptr;
	
	fdw=open("mfile",O_CREAT|O_RDWR, 0666);
	ptr=shmat(fdw, 0, SHM_MAP);
	beg_ptr=ptr;
	for(i=0;i<1000000;i++)
		*ptr++='A';
	shmdt(beg_ptr);
	ftruncate(fdw,1000000);
	close(fdw);
	exit(0);
}
