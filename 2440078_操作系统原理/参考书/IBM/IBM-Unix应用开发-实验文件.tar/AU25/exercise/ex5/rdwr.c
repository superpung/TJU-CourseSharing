/*   rdwr.c */
/*   This program asks the user for five words and stores them in the file   */
/*   named "mydata".  New lines are added.                                   */
#include <fcntl.h>

main()
{
	int i, fd, rc;
	char word[32];

	if ((fd=open("./mydata",O_RDWR|O_CREAT,0666)) < 0 )
	{
		perror("Could not open - See Instructor.\n");
		exit(1);
	}
	for(i=1; i<=5; i++)
	{
		printf("\n\nEnter a word: ");
		rc=read(0,word,sizeof(word));
		write(fd,word,rc);
	}
	close(fd);
}
