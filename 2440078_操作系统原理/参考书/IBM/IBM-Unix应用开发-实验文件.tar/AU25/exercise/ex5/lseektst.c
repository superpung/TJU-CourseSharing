/*   lseektst.c */
/*   This program opens the "mydata" file created in the previous step  */
/*   and copies characters 4 through 10 to a file called "mydata2".     */
#include <fcntl.h>
#include <unistd.h>

main()
{
	int i, fd1, fd2;
	char c;

	if ((fd1=open("./mydata",O_RDONLY)) < 0 )
	{
		perror("Could not open mydata - See Instructor.\n");
		exit(1);
	}
	if ((fd2=open("./mydata2",O_WRONLY|O_CREAT,0666)) < 0)
	{
		perror("Could not open mydata2 - See Instructor.\n");
		exit(2);
	}
	lseek(fd1,3,SEEK_SET);
	for(i=4; i<=10; i++)
	{
		read(fd1,&c,1);
		write(fd2,&c,1);
	}
	close(fd1);
	close(fd2);
}
