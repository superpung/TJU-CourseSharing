/* lockdata.c */
#include <pthread.h>  
#include <stdio.h>  
#include <stdlib.h>  
 
int count=0; 
pthread_mutex_t m; 
 
void *  callFunc(void * myarg) 
{ 
   printf("Arg from main is: %s\n", (char *)myarg); 
 
   pthread_mutex_lock(&m) ;
   count++; 
   printf("callThd says count is %d\n", count); 
   pthread_mutex_unlock( &m);
 
   pthread_exit((void *) 2); 
} 
 
main() 
{ 
   pthread_t callThd; 
   pthread_attr_t attr; 
   char myparm[] = "Main Thread Arg.\n"; 
   int status; 
 
   pthread_mutex_init(&m,NULL); 
   pthread_attr_init(&attr); 
   pthread_attr_setdetachstate(&attr,PTHREAD_CREATE_UNDETACHED); 
   pthread_create(&callThd, &attr, callFunc, (void *)myparm); 
 
   pthread_mutex_lock(&m);
   count++; 
   printf("Parent says count is %d\n", count); 
   pthread_mutex_unlock(&m); 
 
   pthread_join(callThd,(void * *) &status); 
   printf("status from callThd is %d\n", status); 
 
   pthread_mutex_destroy(&m); 
   pthread_exit(NULL); 
} 
