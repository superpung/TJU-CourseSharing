/* condvar.c */
#include <pthread.h>  
#include <stdio.h>  
#include <stdlib.h>  
 
int Ready=0; 
pthread_cond_t cv; 
pthread_mutex_t m; 
 
void *  callFunc(void * myarg) 
{ 
   printf("Arg from main is: %s\n", (char *)myarg); 
 
   pthread_mutex_lock(&m); 
   while(Ready != 1) 
       pthread_cond_wait(&cv, &m);  
   pthread_mutex_unlock(&m); 
   printf("second thread is continuing on....\n"); 
 
   pthread_exit((void *) 2); 
} 
 
main() 
{ 
   pthread_t callThd; 
   pthread_attr_t attr; 
   char myparm[] = "Main Thread Arg.\n"; 
   int status; 
 
   pthread_mutex_init(&m, NULL); 
   pthread_cond_init(&cv, NULL);
 
   pthread_attr_init(&attr); 
   pthread_attr_setdetachstate(&attr,PTHREAD_CREATE_UNDETACHED); 
   pthread_create(&callThd, &attr, callFunc, (void *)myparm); 
 
   sleep(3); /* simulate work */ 
 
   pthread_mutex_lock(&m); 
   pthread_cond_broadcast(&cv); 
   Ready=1; 
   pthread_mutex_unlock(&m); 
 
   pthread_join(callThd,(void * *) &status); 
   printf("status from callThd is %d\n", status); 
 
   pthread_mutex_destroy(&m); 
   pthread_cond_destroy(&cv); 
 
   pthread_exit(NULL); 
} 
