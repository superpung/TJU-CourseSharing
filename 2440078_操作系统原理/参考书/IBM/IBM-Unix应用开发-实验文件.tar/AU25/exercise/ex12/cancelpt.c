/* cancelpt.c */
#include <pthread.h>  
#include <stdio.h>  
#include <stdlib.h>  
 
void *  callFunc(void * myarg) 
{ 
   int i; 
 
   printf("Arg from main is: %s\n", (char *)myarg); 
 
   for(i=0;i<1000000;i++); 
   printf("Before testcancel\n"); 
   pthread_testcancel(); 
   printf("I should never reach this statement.\n"); 
 
   pthread_exit(NULL); 
} 
 
main() 
{ 
   pthread_t callThd; 
   char myparm[] = "Main Thread Arg.\n"; 
 
   pthread_create(&callThd, NULL, callFunc, (void *)myparm); 
   usleep(10000); 
 
   pthread_cancel(callThd); 
 
   pthread_exit(NULL); 
} 
