/* buggy.c */

main()
{
	int x=10;
	int y;
	printf("Starting...\n");
	for(y;y<=10;y++)
	{
		printf("The value of y is %d.\n",y);
		printf("x divided by y is %d.\n",x/y);
	}

	printf("Now on to Part 2...\n");
	for(x;x<=1;x--)
	{
		printf("The value of x is %d.\n");
		printf("y divided by x is %d.\n",y/x);
	}

	printf("Starting Part 3...\n");
	for(x;x<=10;x++);
		printf("The value of x is 5D.\n",x);

}   /*   End of Program   */
