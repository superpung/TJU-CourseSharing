#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define MAX_INPUT 4096

static void url_decode(char *dst, const char *src, size_t dst_size) {
    char a, b;
    size_t di = 0;
    while (*src && di < dst_size - 1) {
        if (*src == '+') {
            dst[di++] = ' ';
            src++;
        } else if (*src == '%' && src[1] && src[2]) {
            a = src[1];
            b = src[2];
            if (((a >= '0' && a <= '9') || (a >= 'A' && a <= 'F') || (a >= 'a' && a <= 'f')) &&
                ((b >= '0' && b <= '9') || (b >= 'A' && b <= 'F') || (b >= 'a' && b <= 'f'))) {
                unsigned int hex;
                sscanf(src + 1, "%2x", &hex);
                dst[di++] = (char)hex;
                src += 3;
            } else {
                dst[di++] = *src++;
            }
        } else {
            dst[di++] = *src++;
        }
    }
    dst[di] = '\0';
}

static void parse_field(const char *data, const char *field_name, char *value, size_t value_size) {
    const char *pos;
    const char *end;
    size_t field_len;
    size_t val_len;
    char encoded[4096];

    value[0] = '\0';
    field_len = strlen(field_name);
    pos = data;

    while (*pos) {
        while (*pos == '&') pos++;
        if (strncmp(pos, field_name, field_len) == 0 && pos[field_len] == '=') {
            pos += field_len + 1;
            end = pos;
            while (*end && *end != '&') end++;
            val_len = end - pos;
            if (val_len >= sizeof(encoded)) val_len = sizeof(encoded) - 1;
            memcpy(encoded, pos, val_len);
            encoded[val_len] = '\0';
            url_decode(value, encoded, value_size);
            return;
        }
        pos = strchr(pos, '&');
        if (!pos) break;
    }
}

int main(void) {
    char *method;
    char *content_length_str;
    char *query_string;
    char input[MAX_INPUT];
    int content_length;
    int i;
    char username[256];
    char password[256];

    method = getenv("REQUEST_METHOD");
    content_length_str = getenv("CONTENT_LENGTH");
    query_string = getenv("QUERY_STRING");

    memset(input, 0, sizeof(input));

    if (method && strcmp(method, "POST") == 0 && content_length_str) {
        content_length = atoi(content_length_str);
        if (content_length > 0 && content_length < MAX_INPUT) {
            i = 0;
            while (i < content_length && i < MAX_INPUT - 1) {
                if (read(STDIN_FILENO, input + i, 1) != 1) break;
                i++;
            }
            input[i] = '\0';
        }
    } else if (query_string) {
        strncpy(input, query_string, sizeof(input) - 1);
    }

    memset(username, 0, sizeof(username));
    memset(password, 0, sizeof(password));
    parse_field(input, "username", username, sizeof(username));
    parse_field(input, "password", password, sizeof(password));

    printf("Content-Type: text/html\r\n");
    printf("\r\n");
    printf("<!DOCTYPE html>\n");
    printf("<html>\n");
    printf("<head><meta charset=\"UTF-8\"><title>Login Result</title></head>\n");
    printf("<body style=\"font-family: Arial; max-width: 500px; margin: 50px auto; padding: 20px;\">\n");
    printf("<h1 style=\"color: #333;\">Login Information</h1>\n");
    printf("<table border=\"1\" cellpadding=\"10\" style=\"border-collapse: collapse; width: 100%%;\">\n");
    printf("<tr><td><b>Username</b></td><td>%s</td></tr>\n", username[0] ? username : "(empty)");
    printf("<tr><td><b>Password</b></td><td>%s</td></tr>\n", password[0] ? password : "(empty)");
    printf("</table>\n");
    printf("<p><a href=\"/login.html\">Go back</a></p>\n");
    printf("</body>\n");
    printf("</html>\n");

    return 0;
}