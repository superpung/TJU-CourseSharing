#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <signal.h>
#include <string.h>
#include <strings.h>
#include <ctype.h>
#include <time.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/select.h>
#include <sys/wait.h>
#include <errno.h>
#include "parse.h"

#define MAX_CLIENTS 1024

typedef struct {
    fd_set all_set;
    fd_set read_fds;
    int max_fd;
    int ready_num;
    int max_idx;
    int client_fds[MAX_CLIENTS];
    char *client_bufs[MAX_CLIENTS];
    ssize_t client_buf_lens[MAX_CLIENTS];
    int client_ignore_after_error[MAX_CLIENTS];
} client_pool;

#define ECHO_PORT 9999
#define BUF_SIZE 4096
#define MAX_HEADER_SIZE 8192
#define RESPONSE_BUF_SIZE 8192
#define CLIENT_BUF_SIZE 65536

FILE *log_file = NULL;

const char* server_name = "liso/1.0";
const char* http_version = "HTTP/1.1";
const char* default_index_file = "index.html";
const char* static_site_path = "./static_site";

int classify_http_request(const char *recv_buf, ssize_t readret, char *method_out, size_t method_out_size, char *uri_out, size_t uri_out_size, char *version_out, size_t version_out_size);
int client_should_close(Request *request, int status_code);
int send_nbytes(int sock, const void *p, int nbytes);
void Send_nbytes(int sock, const void *ptr, int nbytes);
void response400(int client_sock);
void response404(int client_sock);
void response501(int client_sock);
void response505(int client_sock);
void response500(int client_sock);
const char* get_mime_type(const char* filename);
void format_http_date(time_t t, char* buf, size_t buf_size);
int is_dir(const char* path);
int response_post(int client_sock, const char *recv_buf, ssize_t readret);
int send_response_headers(int client_sock, const char* content_type, off_t content_length, time_t last_modified, int keep_alive);
int response_get(int client_sock, Request* request);
int response_head(int client_sock, Request* request);
void process_client_buffer(int client_sock, int idx, client_pool *pool, struct sockaddr_in* client_addr);
void log_request(const char *client_ip, int port, const char *method, const char *uri, int status_code);
int handle_request(int client_sock, ssize_t readret, char* recv_buf, struct sockaddr_in* client_addr, int *should_close);
int str_contains_case_insensitive(const char* haystack, const char* needle);
int is_cgi_uri(const char *uri);
int handle_cgi(int client_sock, Request *request, char *recv_buf, ssize_t readret, struct sockaddr_in *client_addr);
char *get_header_value(Request *request, const char *header_name);
ssize_t find_header_end(const char *buf, ssize_t len);
ssize_t get_content_length_from_request(const char *buf, ssize_t header_len);
int resolve_static_path(const char *uri, char *fullpath, size_t fullpath_size);
void init_pool(int listen_fd, client_pool *pool);
void add_client_to_pool(int new_fd, client_pool *pool);
void drain_socket_input(int client_sock);
void handle_clients(client_pool *pool);

int classify_http_request(const char *recv_buf, ssize_t readret, char *method_out, size_t method_out_size, char *uri_out, size_t uri_out_size, char *version_out, size_t version_out_size) {
    ssize_t i;
    ssize_t line_end;
    ssize_t first_sp;
    ssize_t second_sp;
    ssize_t method_len;
    ssize_t uri_len;
    ssize_t version_len;
    ssize_t header_len;
    ssize_t content_length;
    char *host_hdr;
    Request *request;

    if (method_out_size == 0 || uri_out_size == 0 || version_out_size == 0) {
        return 400;
    }

    method_out[0] = '\0';
    uri_out[0] = '\0';
    version_out[0] = '\0';

    header_len = find_header_end(recv_buf, readret);
    if (header_len < 0 || header_len > MAX_HEADER_SIZE) {
        return 400;
    }

    content_length = get_content_length_from_request(recv_buf, header_len);
    if (content_length < 0) {
        return 400;
    }

    line_end = -1;
    for (i = 0; i + 1 < header_len; i++) {
        if (recv_buf[i] == '\r' && recv_buf[i + 1] == '\n') {
            line_end = i;
            break;
        }
    }
    if (line_end < 0) {
        return 400;
    }

    first_sp = -1;
    second_sp = -1;
    for (i = 0; i < line_end; i++) {
        if (recv_buf[i] == ' ') {
            if (first_sp < 0) {
                first_sp = i;
            } else {
                second_sp = i;
                break;
            }
        }
    }

    if (first_sp <= 0 || second_sp <= first_sp + 1 || second_sp >= line_end - 1) {
        return 400;
    }

    method_len = first_sp;
    uri_len = second_sp - first_sp - 1;
    version_len = line_end - second_sp - 1;

    if ((size_t)method_len >= method_out_size || (size_t)uri_len >= uri_out_size || (size_t)version_len >= version_out_size) {
        return 400;
    }

    memcpy(method_out, recv_buf, (size_t)method_len);
    method_out[method_len] = '\0';
    memcpy(uri_out, recv_buf + first_sp + 1, (size_t)uri_len);
    uri_out[uri_len] = '\0';
    memcpy(version_out, recv_buf + second_sp + 1, (size_t)version_len);
    version_out[version_len] = '\0';

    if (method_out[0] == '\0' || uri_out[0] == '\0' || version_out[0] == '\0') {
        return 400;
    }

    if (strcmp(version_out, "HTTP/1.1") != 0) {
        return 505;
    }

    if (strcmp(method_out, "GET") != 0 && strcmp(method_out, "HEAD") != 0 && strcmp(method_out, "POST") != 0) {
        return 501;
    }

    request = parse(recv_buf, readret, -1);
    if (request == NULL) {
        return 400;
    }

    host_hdr = get_header_value(request, "Host");
    if (host_hdr == NULL || host_hdr[0] == '\0') {
        free(request->headers);
        free(request);
        return 400;
    }

    free(request->headers);
    free(request);
    return 200;
}

int client_should_close(Request *request, int status_code) {
    char *connection_header;

    (void)status_code;

    connection_header = get_header_value(request, "Connection");
    if (connection_header != NULL && str_contains_case_insensitive(connection_header, "close")) {
        return 1;
    }

    return 0;
}

int send_nbytes(int sock, const void *p, int nbytes) {
    size_t left_bytes = nbytes;
    ssize_t sent_bytes = 0;
    const char *ptr = p;
    while (left_bytes > 0) {
        sent_bytes = send(sock, ptr, left_bytes, 0);
        if (sent_bytes < 0) {
            perror("send");
            return -1;
        }
        left_bytes -= sent_bytes;
        ptr += sent_bytes;
    }
    return nbytes;
}

void Send_nbytes(int sock, const void *ptr, int nbytes) {
    if (send_nbytes(sock, ptr, nbytes) != nbytes)
        printf("send_bytes error\n");
}

void response400(int client_sock) {
    const char* resp = "HTTP/1.1 400 Bad request\r\n\r\n";
    size_t len = strlen(resp);
    size_t sent = 0;
    while (sent < len) {
        ssize_t s = write(client_sock, resp + sent, len - sent);
        if (s < 0) {
            break;
        }
        sent += s;
    }
}

void response404(int client_sock) {
    const char* resp = "HTTP/1.1 404 Not Found\r\n\r\n";
    size_t len = strlen(resp);
    size_t sent = 0;
    while (sent < len) {
        ssize_t s = write(client_sock, resp + sent, len - sent);
        if (s < 0) {
            break;
        }
        sent += s;
    }
}

void response501(int client_sock) {
    const char* resp = "HTTP/1.1 501 Not Implemented\r\n\r\n";
    size_t len = strlen(resp);
    size_t sent = 0;
    while (sent < len) {
        ssize_t s = write(client_sock, resp + sent, len - sent);
        if (s < 0) {
            break;
        }
        sent += s;
    }
}

void response505(int client_sock) {
    const char* resp = "HTTP/1.1 505 HTTP Version not supported\r\n\r\n";
    size_t len = strlen(resp);
    size_t sent = 0;
    while (sent < len) {
        ssize_t s = write(client_sock, resp + sent, len - sent);
        if (s < 0) {
            break;
        }
        sent += s;
    }
}

void response500(int client_sock) {
    const char* resp = "HTTP/1.1 500 Internal Server Error\r\n\r\n";
    size_t len = strlen(resp);
    size_t sent = 0;
    while (sent < len) {
        ssize_t s = write(client_sock, resp + sent, len - sent);
        if (s < 0) {
            break;
        }
        sent += s;
    }
}

const char* get_mime_type(const char* filename) {
    const char* dot = strrchr(filename, '.');
    if (dot == NULL) {
        return "application/octet-stream";
    }
    if (strcmp(dot, ".html") == 0 || strcmp(dot, ".htm") == 0) {
        return "text/html";
    } else if (strcmp(dot, ".css") == 0) {
        return "text/css";
    } else if (strcmp(dot, ".png") == 0) {
        return "image/png";
    } else if (strcmp(dot, ".jpg") == 0 || strcmp(dot, ".jpeg") == 0) {
        return "image/jpeg";
    } else if (strcmp(dot, ".gif") == 0) {
        return "image/gif";
    }
    return "application/octet-stream";
}

void format_http_date(time_t t, char* buf, size_t buf_size) {
    struct tm* gm = gmtime(&t);
    strftime(buf, buf_size, "%a, %d %b %Y %H:%M:%S GMT", gm);
}

int is_dir(const char* path) {
    struct stat stat_buf;
    if (stat(path, &stat_buf) != 0) {
        return 0;
    }
    return S_ISDIR(stat_buf.st_mode);
}

int str_contains_case_insensitive(const char* haystack, const char* needle) {
    size_t needle_len;
    size_t haystack_len;
    size_t i;
    size_t j;
    int match;
    
    if (!haystack || !needle) {
        return 0;
    }
    needle_len = strlen(needle);
    haystack_len = strlen(haystack);
    if (needle_len == 0 || needle_len > haystack_len) {
        return 0;
    }
    for (i = 0; i <= haystack_len - needle_len; i++) {
        match = 1;
        for (j = 0; j < needle_len; j++) {
            if (tolower((unsigned char)haystack[i + j]) != tolower((unsigned char)needle[j])) {
                match = 0;
                break;
            }
        }
        if (match) {
            return 1;
        }
    }
    return 0;
}

char *get_header_value(Request *request, const char *header_name) {
    int i;
    for (i = 0; i < request->header_count; i++) {
        if (strcasecmp(request->headers[i].header_name, header_name) == 0) {
            return request->headers[i].header_value;
        }
    }
    return NULL;
}

ssize_t find_header_end(const char *buf, ssize_t len) {
    ssize_t i;

    for (i = 0; i + 3 < len; i++) {
        if (buf[i] == '\r' && buf[i + 1] == '\n' &&
            buf[i + 2] == '\r' && buf[i + 3] == '\n') {
            return i + 4;
        }
    }

    return -1;
}

ssize_t get_content_length_from_request(const char *buf, ssize_t header_len) {
    char header_copy[MAX_HEADER_SIZE + 1];
    char *line;
    char *save;
    char *colon;
    char *value;
    char *endptr;
    long parsed_length;
    size_t copy_len;

    if (header_len <= 0 || header_len > MAX_HEADER_SIZE) {
        return -1;
    }

    copy_len = (size_t)header_len;
    memcpy(header_copy, buf, copy_len);
    header_copy[copy_len] = '\0';

    line = strtok_r(header_copy, "\r\n", &save);
    while (line != NULL) {
        colon = strchr(line, ':');
        if (colon != NULL) {
            *colon = '\0';
            value = colon + 1;
            while (*value == ' ' || *value == '\t') {
                value++;
            }
            if (strcasecmp(line, "Content-Length") == 0) {
                errno = 0;
                parsed_length = strtol(value, &endptr, 10);
                if (errno != 0 || endptr == value || parsed_length < 0) {
                    return -1;
                }
                while (*endptr == ' ' || *endptr == '\t') {
                    endptr++;
                }
                if (*endptr != '\0') {
                    return -1;
                }
                return (ssize_t)parsed_length;
            }
        }
        line = strtok_r(NULL, "\r\n", &save);
    }

    return 0;
}

int resolve_static_path(const char *uri, char *fullpath, size_t fullpath_size) {
    char uri_path[4096];
    const char *query_start;
    size_t uri_len;

    if (uri == NULL || fullpath == NULL || fullpath_size == 0 || uri[0] != '/') {
        return -1;
    }

    query_start = strchr(uri, '?');
    uri_len = query_start ? (size_t)(query_start - uri) : strlen(uri);
    if (uri_len == 0 || uri_len >= sizeof(uri_path)) {
        return -1;
    }

    memcpy(uri_path, uri, uri_len);
    uri_path[uri_len] = '\0';

    if (strstr(uri_path, "..") != NULL) {
        return -1;
    }

    if ((size_t)snprintf(fullpath, fullpath_size, "%s%s", static_site_path, uri_path) >= fullpath_size) {
        return -1;
    }

    if (is_dir(fullpath)) {
        if (fullpath[strlen(fullpath) - 1] != '/') {
            if (strlen(fullpath) + 1 >= fullpath_size) {
                return -1;
            }
            strcat(fullpath, "/");
        }
        if (strlen(fullpath) + strlen(default_index_file) >= fullpath_size) {
            return -1;
        }
        strcat(fullpath, default_index_file);
    }

    return 0;
}

int is_cgi_uri(const char *uri) {
    if (uri == NULL) {
        return 0;
    }
    if (strncmp(uri, "/cgi-bin/", 9) == 0) {
        return 1;
    }
    if (strncmp(uri, "/cgi/", 5) == 0) {
        return 1;
    }
    return 0;
}

static void set_cgi_env(Request *request, struct sockaddr_in *client_addr,
                         const char *script_name, const char *path_info,
                         const char *query_string) {
    char port_str[16];
    char *content_length;
    char *content_type;
    int i;
    char env_name[256];
    char *hdr_val;
    int j;
    int k;

    content_length = get_header_value(request, "Content-Length");
    content_type = get_header_value(request, "Content-Type");

    if (content_length) {
        setenv("CONTENT_LENGTH", content_length, 1);
    }
    if (content_type) {
        setenv("CONTENT_TYPE", content_type, 1);
    }

    setenv("GATEWAY_INTERFACE", "CGI/1.1", 1);
    setenv("PATH_INFO", path_info ? path_info : "", 1);
    setenv("QUERY_STRING", query_string ? query_string : "", 1);
    setenv("REMOTE_ADDR", inet_ntoa(client_addr->sin_addr), 1);
    setenv("REQUEST_METHOD", request->http_method, 1);
    setenv("REQUEST_URI", request->http_uri, 1);
    setenv("SCRIPT_NAME", script_name, 1);

    snprintf(port_str, sizeof(port_str), "%d", ECHO_PORT);
    setenv("SERVER_PORT", port_str, 1);
    setenv("SERVER_PROTOCOL", "HTTP/1.1", 1);
    setenv("SERVER_SOFTWARE", "Liso/1.0", 1);

    for (i = 0; i < request->header_count; i++) {
        memset(env_name, 0, sizeof(env_name));
        strcpy(env_name, "HTTP_");
        k = (int)strlen("HTTP_");
        for (j = 0; request->headers[i].header_name[j] != '\0' && k < (int)(sizeof(env_name) - 1); j++) {
            if (request->headers[i].header_name[j] == '-') {
                env_name[k++] = '_';
            } else {
                env_name[k++] = (char)toupper((unsigned char)request->headers[i].header_name[j]);
            }
        }
        env_name[k] = '\0';
        hdr_val = request->headers[i].header_value;
        if (hdr_val && strlen(hdr_val) > 0) {
            setenv(env_name, hdr_val, 1);
        }
    }
}

int response_post(int client_sock, const char *recv_buf, ssize_t readret) {
    Send_nbytes(client_sock, recv_buf, (int)readret);
    return 200;
}

int handle_cgi(int client_sock, Request *request, char *recv_buf, ssize_t readret, struct sockaddr_in *client_addr) {
    char script_path[4096];
    char script_name[4096];
    char path_info[4096];
    char query_string[4096];
    char *uri;
    char *qmark;
    char *body;
    ssize_t body_len;
    int stdin_pipe[2];
    int stdout_pipe[2];
    pid_t pid;
    int status;
    char cgi_output[65536];
    ssize_t total_read;
    ssize_t n;
    char *header_end;
    char date_str[128];
    time_t now;
    int content_len;
    char response_header[4096];
    char *hdr_buf;
    char *line;
    char *save;
    char *colon;
    int hdr_line;
    char *body_start;
    ssize_t hdr_len;
    ssize_t remaining;
    ssize_t bi;
    ssize_t written;
    ssize_t w;

    uri = request->http_uri;

    memset(script_path, 0, sizeof(script_path));
    memset(script_name, 0, sizeof(script_name));
    memset(path_info, 0, sizeof(path_info));
    memset(query_string, 0, sizeof(query_string));

    qmark = strchr(uri, '?');
    if (qmark != NULL) {
        strncpy(query_string, qmark + 1, sizeof(query_string) - 1);
        strncpy(script_name, uri, (size_t)(qmark - uri) < sizeof(script_name) - 1 ? (size_t)(qmark - uri) : sizeof(script_name) - 1);
    } else {
        strncpy(script_name, uri, sizeof(script_name) - 1);
    }

    snprintf(script_path, sizeof(script_path), ".%s", script_name);

    if (access(script_path, F_OK) != 0) {
        response404(client_sock);
        return 404;
    }

    body = NULL;
    body_len = 0;
    for (bi = 0; bi + 4 <= readret; bi++) {
        if (recv_buf[bi] == '\r' && recv_buf[bi+1] == '\n' && 
            recv_buf[bi+2] == '\r' && recv_buf[bi+3] == '\n') {
            body = recv_buf + bi + 4;
            body_len = readret - (bi + 4);
            break;
        }
    }

    if (pipe(stdin_pipe) < 0 || pipe(stdout_pipe) < 0) {
        response500(client_sock);
        return 500;
    }

    pid = fork();
    if (pid < 0) {
        close(stdin_pipe[0]);
        close(stdin_pipe[1]);
        close(stdout_pipe[0]);
        close(stdout_pipe[1]);
        response500(client_sock);
        return 500;
    }

    if (pid == 0) {
        close(stdin_pipe[1]);
        close(stdout_pipe[0]);

        dup2(stdin_pipe[0], STDIN_FILENO);
        dup2(stdout_pipe[1], STDOUT_FILENO);

        close(stdin_pipe[0]);
        close(stdout_pipe[1]);

        set_cgi_env(request, client_addr, script_name, path_info, query_string);

        execl(script_path, script_path, (char *)NULL);
        exit(1);
    }

    close(stdin_pipe[0]);
    close(stdout_pipe[1]);

    written = 0;
    if (body != NULL && body_len > 0) {
        while (written < body_len) {
            w = write(stdin_pipe[1], body + written, body_len - written);
            if (w <= 0) {
                break;
            }
            written += w;
        }
    }
    close(stdin_pipe[1]);

    memset(cgi_output, 0, sizeof(cgi_output));
    total_read = 0;
    while (total_read < (ssize_t)(sizeof(cgi_output) - 1)) {
        n = read(stdout_pipe[0], cgi_output + total_read, sizeof(cgi_output) - 1 - total_read);
        if (n <= 0) {
            break;
        }
        total_read += n;
    }
    close(stdout_pipe[0]);

    waitpid(pid, &status, 0);
    if (WIFEXITED(status) && WEXITSTATUS(status) != 0) {
        response500(client_sock);
        return 500;
    }
    if (WIFSIGNALED(status)) {
        response500(client_sock);
        return 500;
    }

    header_end = strstr(cgi_output, "\r\n\r\n");
    if (header_end == NULL) {
        response500(client_sock);
        return 500;
    }

    content_len = -1;
    hdr_buf = strdup(cgi_output);
    if (hdr_buf != NULL) {
        line = strtok_r(hdr_buf, "\r\n", &save);
        hdr_line = 0;
        while (line != NULL && hdr_line < 50) {
            colon = strchr(line, ':');
            if (colon != NULL) {
                *colon = '\0';
                if (strcasecmp(line, "Content-Length") == 0) {
                    content_len = atoi(colon + 1);
                }
            }
            hdr_line++;
            line = strtok_r(NULL, "\r\n", &save);
        }
        free(hdr_buf);
    }

    now = time(NULL);
    format_http_date(now, date_str, sizeof(date_str));

    snprintf(response_header, sizeof(response_header),
             "HTTP/1.1 200 OK\r\n"
             "Server: %s\r\n"
             "Date: %s\r\n"
             "Connection: close\r\n",
             server_name, date_str);
    Send_nbytes(client_sock, response_header, strlen(response_header));

    hdr_len = header_end - cgi_output + 4;
    body_start = cgi_output + hdr_len;

    Send_nbytes(client_sock, cgi_output, hdr_len);

    if (content_len > 0) {
        Send_nbytes(client_sock, body_start, content_len);
    } else {
        remaining = total_read - hdr_len;
        if (remaining > 0) {
            Send_nbytes(client_sock, body_start, remaining);
        }
    }

    return 200;
}

int send_response_headers(int client_sock, const char* content_type, off_t content_length, time_t last_modified, int keep_alive) {
    char response[RESPONSE_BUF_SIZE] = {0};
    char date_str[128] = {0};
    char last_mod_str[128] = {0};
    time_t now = time(NULL);
    
    format_http_date(now, date_str, sizeof(date_str));
    format_http_date(last_modified, last_mod_str, sizeof(last_mod_str));
    
    snprintf(response, sizeof(response), 
             "%s 200 OK\r\n"
             "Server: %s\r\n"
             "Date: %s\r\n"
             "Content-Type: %s\r\n"
             "Content-Length: %lld\r\n"
             "Last-Modified: %s\r\n",
             http_version, server_name, date_str, content_type, 
             (long long)content_length, last_mod_str);
    
    if (keep_alive) {
        strcat(response, "Connection: keep-alive\r\n");
    }
    
    strcat(response, "\r\n");
    Send_nbytes(client_sock, response, strlen(response));
    return 0;
}

int response_get(int client_sock, Request *request) {
    char fullpath[4096];
    struct stat stat_buf;
    const char *mime_type;
    int keep_alive;
    int i;
    int fd;
    char file_buf[4096];
    ssize_t bytes_read;

    memset(fullpath, 0, sizeof(fullpath));
    if (resolve_static_path(request->http_uri, fullpath, sizeof(fullpath)) != 0) {
        response404(client_sock);
        return 404;
    }

    if (access(fullpath, F_OK) < 0) {
        response404(client_sock);
        return 404;
    }

    if (stat(fullpath, &stat_buf) < 0) {
        response404(client_sock);
        return 404;
    }

    fd = open(fullpath, O_RDONLY);
    if (fd < 0) {
        response500(client_sock);
        return 500;
    }

    mime_type = get_mime_type(fullpath);

    keep_alive = 0;
    for (i = 0; i < request->header_count; i++) {
        if (strcasecmp(request->headers[i].header_name, "Connection") == 0) {
            if (str_contains_case_insensitive(request->headers[i].header_value, "keep-alive")) {
                keep_alive = 1;
            }
        }
    }

    send_response_headers(client_sock, mime_type, stat_buf.st_size, stat_buf.st_mtime, keep_alive);

    while ((bytes_read = read(fd, file_buf, sizeof(file_buf))) > 0) {
        Send_nbytes(client_sock, file_buf, bytes_read);
    }

    close(fd);
    return 200;
}

int response_head(int client_sock, Request* request) {
    char fullpath[4096];
    struct stat stat_buf;
    const char* mime_type;
    int keep_alive;
    int i;
    int fd;

    memset(fullpath, 0, sizeof(fullpath));
    if (resolve_static_path(request->http_uri, fullpath, sizeof(fullpath)) != 0) {
        response404(client_sock);
        return 404;
    }

    if (access(fullpath, F_OK) < 0) {
        response404(client_sock);
        return 404;
    }

    if (stat(fullpath, &stat_buf) < 0) {
        response404(client_sock);
        return 404;
    }

    fd = open(fullpath, O_RDONLY);
    if (fd < 0) {
        response500(client_sock);
        return 500;
    }
    close(fd);

    mime_type = get_mime_type(fullpath);

    keep_alive = 0;
    for (i = 0; i < request->header_count; i++) {
        if (strcasecmp(request->headers[i].header_name, "Connection") == 0) {
            if (str_contains_case_insensitive(request->headers[i].header_value, "keep-alive")) {
                keep_alive = 1;
            }
        }
    }

    send_response_headers(client_sock, mime_type, stat_buf.st_size, stat_buf.st_mtime, keep_alive);
    return 200;
}

void process_client_buffer(int client_sock, int idx, client_pool *pool, struct sockaddr_in* client_addr) {
    ssize_t header_len;
    ssize_t content_length;
    ssize_t request_len;
    char *client_buf;
    ssize_t client_len;
    char request_buf[CLIENT_BUF_SIZE];
    int should_close;

    client_buf = pool->client_bufs[idx];
    client_len = pool->client_buf_lens[idx];

    while (1) {
        header_len = find_header_end(client_buf, client_len);
        if (header_len < 0) {
            if (client_len > MAX_HEADER_SIZE) {
                response400(client_sock);
                log_request(inet_ntoa(client_addr->sin_addr), ntohs(client_addr->sin_port), "UNKNOWN", "UNKNOWN", 400);
                pool->client_buf_lens[idx] = 0;
            }
            return;
        }

        if (header_len > MAX_HEADER_SIZE) {
            response400(client_sock);
            log_request(inet_ntoa(client_addr->sin_addr), ntohs(client_addr->sin_port), "UNKNOWN", "UNKNOWN", 400);
            pool->client_buf_lens[idx] = 0;
            return;
        }

        content_length = get_content_length_from_request(client_buf, header_len);
        if (content_length < 0) {
            response400(client_sock);
            log_request(inet_ntoa(client_addr->sin_addr), ntohs(client_addr->sin_port), "UNKNOWN", "UNKNOWN", 400);
            pool->client_buf_lens[idx] = 0;
            return;
        }

        request_len = header_len + content_length;
        if (request_len > CLIENT_BUF_SIZE) {
            response400(client_sock);
            log_request(inet_ntoa(client_addr->sin_addr), ntohs(client_addr->sin_port), "UNKNOWN", "UNKNOWN", 400);
            pool->client_buf_lens[idx] = 0;
            return;
        }

        if (client_len < request_len) {
            return;
        }

        memcpy(request_buf, client_buf, (size_t)request_len);
        should_close = 0;
        handle_request(client_sock, request_len, request_buf, client_addr, &should_close);

        client_len -= request_len;
        if (client_len > 0) {
            memmove(client_buf, client_buf + request_len, (size_t)client_len);
        }
        pool->client_buf_lens[idx] = client_len;

        if (should_close) {
            clear_client(client_sock, idx, pool);
            return;
        }
    }
}



void log_request(const char *client_ip, int port, const char *method, const char *uri, int status_code) {
    time_t now;
    char time_str[64];
    
    if (log_file == NULL) {
        log_file = fopen("server.log", "a");
        if (log_file == NULL) {
            return;
        }
    }
    now = time(NULL);
    strftime(time_str, sizeof(time_str), "%d/%b/%Y:%H:%M:%S %z", localtime(&now));
    fprintf(log_file, "%s:%d - - [%s] \"%s %s HTTP/1.1\" %d\n", 
            client_ip, port, time_str, method, uri, status_code);
    fflush(log_file);
}

int handle_request(int client_sock, ssize_t readret, char* recv_buf, struct sockaddr_in* client_addr, int *should_close) {
    Request *request;
    int status_code;
    int classified_status;
    char method[64];
    char uri[4096];
    char version[64];

    classified_status = classify_http_request(recv_buf, readret, method, sizeof(method), uri, sizeof(uri), version, sizeof(version));
    if (classified_status == 400) {
        response400(client_sock);
        log_request(inet_ntoa(client_addr->sin_addr), ntohs(client_addr->sin_port), method[0] ? method : "UNKNOWN", uri[0] ? uri : "UNKNOWN", 400);
        if (should_close != NULL) {
            *should_close = 0;
        }
        return 400;
    }
    if (classified_status == 501) {
        response501(client_sock);
        log_request(inet_ntoa(client_addr->sin_addr), ntohs(client_addr->sin_port), method, uri[0] ? uri : "UNKNOWN", 501);
        if (should_close != NULL) {
            *should_close = 0;
        }
        return 501;
    }
    if (classified_status == 505) {
        response505(client_sock);
        log_request(inet_ntoa(client_addr->sin_addr), ntohs(client_addr->sin_port), method[0] ? method : "UNKNOWN", uri[0] ? uri : "UNKNOWN", 505);
        if (should_close != NULL) {
            *should_close = 0;
        }
        return 505;
    }

    request = parse(recv_buf, readret, client_sock);
    if (request == NULL) {
        response400(client_sock);
        log_request(inet_ntoa(client_addr->sin_addr), ntohs(client_addr->sin_port), method[0] ? method : "UNKNOWN", uri[0] ? uri : "UNKNOWN", 400);
        if (should_close != NULL) {
            *should_close = 0;
        }
        return 400;
    }

    status_code = 200;

    if (!strcmp(request->http_method, "GET")) {
        if (is_cgi_uri(request->http_uri)) {
            status_code = handle_cgi(client_sock, request, recv_buf, readret, client_addr);
        } else {
            status_code = response_get(client_sock, request);
        }
    } else if (!strcmp(request->http_method, "HEAD")) {
        status_code = response_head(client_sock, request);
    } else if (!strcmp(request->http_method, "POST")) {
        if (is_cgi_uri(request->http_uri)) {
            status_code = handle_cgi(client_sock, request, recv_buf, readret, client_addr);
        } else {
            status_code = response_post(client_sock, recv_buf, readret);
        }
    } else {
        response501(client_sock);
        status_code = 501;
    }

    if (should_close != NULL) {
        *should_close = client_should_close(request, status_code);
    }

    log_request(inet_ntoa(client_addr->sin_addr), ntohs(client_addr->sin_port),
                request->http_method, request->http_uri, status_code);

    free(request->headers);
    free(request);
    return status_code;
}

void init_pool(int listen_fd, client_pool *pool) {
    int i;
    pool->max_fd = listen_fd;
    pool->max_idx = -1;
    for (i = 0; i < MAX_CLIENTS; i++) {
        pool->client_fds[i] = -1;
        pool->client_bufs[i] = NULL;
        pool->client_buf_lens[i] = 0;
        pool->client_ignore_after_error[i] = 0;
    }
    FD_ZERO(&pool->all_set);
    FD_SET(listen_fd, &pool->all_set);
}

void add_client_to_pool(int new_fd, client_pool *pool) {
    int i;
    for (i = 0; i < MAX_CLIENTS; i++) {
        if (pool->client_fds[i] < 0) {
            pool->client_fds[i] = new_fd;
            pool->client_bufs[i] = (char *)malloc(CLIENT_BUF_SIZE);
            pool->client_buf_lens[i] = 0;
            pool->client_ignore_after_error[i] = 0;
            if (pool->client_bufs[i] == NULL) {
                fprintf(stderr, "Failed allocating client buffer\n");
                pool->client_fds[i] = -1;
                close(new_fd);
                return;
            }
            break;
        }
    }
    if (i == MAX_CLIENTS) {
        fprintf(stderr, "Too many clients\n");
        close(new_fd);
        return;
    }
    FD_SET(new_fd, &pool->all_set);
    if (new_fd > pool->max_fd) {
        pool->max_fd = new_fd;
    }
    if (i > pool->max_idx) {
        pool->max_idx = i;
    }
}

void clear_client(int client_fd, int idx, client_pool *pool) {
    close(client_fd);
    FD_CLR(client_fd, &pool->all_set);
    pool->client_fds[idx] = -1;
    if (pool->client_bufs[idx] != NULL) {
        free(pool->client_bufs[idx]);
        pool->client_bufs[idx] = NULL;
    }
    pool->client_buf_lens[idx] = 0;
    pool->client_ignore_after_error[idx] = 0;
}

void drain_socket_input(int client_sock) {
    char drain_buf[BUF_SIZE];

    while (recv(client_sock, drain_buf, sizeof(drain_buf), MSG_DONTWAIT) > 0) {
    }
}

void handle_clients(client_pool *pool) {
    int i;
    char buf[BUF_SIZE];
    ssize_t n;
    struct sockaddr_in cli_addr;
    socklen_t cli_size;
    int current_fd;
    char *client_buf;
    ssize_t client_len;

    for (i = 0; i <= pool->max_idx; i++) {
        if (pool->client_fds[i] < 0) {
            continue;
        }
        current_fd = pool->client_fds[i];
        if (FD_ISSET(current_fd, &pool->read_fds)) {
            memset(buf, 0, BUF_SIZE);
            n = recv(current_fd, buf, BUF_SIZE, 0);
            if (n < 0) {
                perror("recv error");
                clear_client(current_fd, i, pool);
            } else if (n == 0) {
                fprintf(stdout, "Client closed connection\n");
                clear_client(current_fd, i, pool);
            } else {
                if (pool->client_ignore_after_error[i]) {
                    pool->client_ignore_after_error[i] = 0;
                    pool->client_buf_lens[i] = 0;
                    drain_socket_input(current_fd);
                    if (--pool->ready_num <= 0) {
                        break;
                    }
                    continue;
                }
                client_buf = pool->client_bufs[i];
                client_len = pool->client_buf_lens[i];
                if (client_buf == NULL || client_len + n > CLIENT_BUF_SIZE) {
                    response400(current_fd);
                    pool->client_buf_lens[i] = 0;
                    pool->client_ignore_after_error[i] = 1;
                } else {
                    memcpy(client_buf + client_len, buf, (size_t)n);
                    pool->client_buf_lens[i] = client_len + n;
                    fprintf(stdout, "Received (total %d bytes): %s\n", (int)n, buf);
                    cli_size = sizeof(cli_addr);
                    getpeername(current_fd, (struct sockaddr *)&cli_addr, &cli_size);
                    process_client_buffer(current_fd, i, pool, &cli_addr);
                }
            }
            if (--pool->ready_num <= 0) {
                break;
            }
        }
    }
}

int sock = -1;
char buf[BUF_SIZE];

int close_socket(int sock) {
    if (close(sock)) {
        fprintf(stderr, "Failed closing socket.\n");
        return 1;
    }
    return 0;
}
void handle_signal(const int sig) {
    if (sock != -1) {
        fprintf(stderr, "\nReceived signal %d. Closing socket.\n", sig);
        close_socket(sock);
    }
    exit(0);
}
void handle_sigpipe(const int sig) 
{
    if (sock != -1) {
        return;
    }
    exit(0);
}
int main(int argc, char *argv[]) {
    socklen_t cli_size;
    struct sockaddr_in addr, cli_addr;
    client_pool pool;
    int connfd;
    int opt;
    int fd;
    
    /* register signal handler */
    /* process termination signals */
    signal(SIGTERM, handle_signal);
    signal(SIGINT, handle_signal);
    signal(SIGSEGV, handle_signal);
    signal(SIGABRT, handle_signal);
    signal(SIGQUIT, handle_signal);
    signal(SIGTSTP, handle_signal);
    signal(SIGFPE, handle_signal);
    signal(SIGHUP, handle_signal);
    /* normal I/O event */
    signal(SIGPIPE, handle_sigpipe);

    fprintf(stdout, "----- Echo Server -----\n");

    /* all networked programs must create a socket */
    if ((sock = socket(PF_INET, SOCK_STREAM, 0)) == -1) {
        fprintf(stderr, "Failed creating socket.\n");
        return EXIT_FAILURE;
    }
    /* set socket SO_REUSEADDR */
    opt = 1;
    if (setsockopt(sock, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt))) {
        fprintf(stderr, "Failed setting socket options.\n");
        return EXIT_FAILURE;
    }

    addr.sin_family = AF_INET; /* ipv4 */
    addr.sin_port = htons(ECHO_PORT);
    addr.sin_addr.s_addr = INADDR_ANY;

    /* servers bind sockets to ports---notify the OS they accept connections */
    if (bind(sock, (struct sockaddr *) &addr, sizeof(addr))) {
        close_socket(sock);
        fprintf(stderr, "Failed binding socket.\n");
        return EXIT_FAILURE;
    }

    if (listen(sock, 5)) {
        close_socket(sock);
        fprintf(stderr, "Error listening on socket.\n");
        return EXIT_FAILURE;
    }

    init_pool(sock, &pool);

    /* finally, loop waiting for input and then write it back */
    while (1) {
        FD_ZERO(&pool.read_fds);
        for (fd = 0; fd <= pool.max_fd; fd++) {
            if (FD_ISSET(fd, &pool.all_set)) {
                FD_SET(fd, &pool.read_fds);
            }
        }
        pool.ready_num = select(pool.max_fd + 1, &pool.read_fds, NULL, NULL, NULL);
        
        if (pool.ready_num < 0) {
            perror("select error");
            break;
        }
        
        if (FD_ISSET(sock, &pool.read_fds)) {
            cli_size = sizeof(cli_addr);
            connfd = accept(sock, (struct sockaddr *)&cli_addr, &cli_size);
            if (connfd == -1) {
                perror("accept error");
            } else {
                fprintf(stdout, "New connection from %s:%d\n", 
                        inet_ntoa(cli_addr.sin_addr), ntohs(cli_addr.sin_port));
                add_client_to_pool(connfd, &pool);
            }
            if (--pool.ready_num <= 0) {
                continue;
            }
        }
        
        handle_clients(&pool);
    }

    close_socket(sock);
    return EXIT_SUCCESS;
}
