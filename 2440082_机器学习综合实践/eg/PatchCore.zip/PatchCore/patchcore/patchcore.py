"""PatchCore and PatchCore detection methods."""
import logging
import os
import pickle

import numpy as np
import torch
import torch.nn.functional as F
import tqdm

import patchcore
import patchcore.backbones
import patchcore.common
import patchcore.sampler

LOGGER = logging.getLogger(__name__)


class PatchCore(torch.nn.Module):
    def __init__(self, device):
        """PatchCore anomaly detection class."""
        super(PatchCore, self).__init__()
        self.device = device

    def load(
        self,
        backbone,
        layers_to_extract_from,
        device,
        input_shape,
        pretrain_embed_dimension,
        target_embed_dimension,
        patchsize=3,
        patchstride=1,
        anomaly_score_num_nn=1,
        featuresampler=patchcore.sampler.IdentitySampler(),
        nn_method=patchcore.common.FaissNN(False, 4),
        **kwargs,
    ):
        self.backbone = backbone.to(device)
        self.layers_to_extract_from = layers_to_extract_from
        self.input_shape = input_shape

        self.device = device
        self.patch_maker = PatchMaker(patchsize, stride=patchstride)

        self.forward_modules = torch.nn.ModuleDict({})

        # 初始化特征提取器
        feature_aggregator = patchcore.common.NetworkFeatureAggregator(
            self.backbone, self.layers_to_extract_from, self.device
        )

        feature_dimensions = feature_aggregator.feature_dimensions(input_shape)
        self.forward_modules["feature_aggregator"] = feature_aggregator

        preprocessing = patchcore.common.Preprocessing(
            feature_dimensions, pretrain_embed_dimension
        )
        self.forward_modules["preprocessing"] = preprocessing

        self.target_embed_dimension = target_embed_dimension
        preadapt_aggregator = patchcore.common.Aggregator(
            target_dim=target_embed_dimension
        )

        _ = preadapt_aggregator.to(self.device)

        self.forward_modules["preadapt_aggregator"] = preadapt_aggregator

        self.anomaly_scorer = patchcore.common.NearestNeighbourScorer(
            n_nearest_neighbours=anomaly_score_num_nn, nn_method=nn_method
        )

        self.anomaly_segmentor = patchcore.common.RescaleSegmentor(
            device=self.device, target_size=input_shape[-2:]
        )

        self.featuresampler = featuresampler

    def embed(self, data):
        if isinstance(data, torch.utils.data.DataLoader):
            features = []
            for image in data:
                if isinstance(image, dict):
                    image = image["image"]
                with torch.no_grad():
                    input_image = image.to(torch.float).to(self.device)
                    features.append(self._embed(input_image))
            return features
        return self._embed(data)

    def _embed(self, images, detach=True, provide_patch_shapes=False):
        """返回图像的特征嵌入"""

        def _detach(features):
            # 若detach为True，将特征从计算图分离并转为numpy数组（减少GPU占用，便于后续处理）
            if detach:
                return [x.detach().cpu().numpy() for x in features]
            return features

        # 特征提取器设为评估模式（无需微调预训练骨干网络）
        _ = self.forward_modules["feature_aggregator"].eval()
        # 关闭梯度计算（非训练阶段，提升效率）
        with torch.no_grad():
            # 用预训练骨干网络（如WideResNet50）提取图像特征
            features = self.forward_modules["feature_aggregator"](images)

        # 仅保留指定的中间层特征（如ResNet的2、3层，避免高层特征的ImageNet偏置）
        features = [features[layer] for layer in self.layers_to_extract_from]

        # 对每个层级的特征图进行patch化处理，同时返回patch的空间尺寸信息
        features = [
            self.patch_maker.patchify(x, return_spatial_info=True) for x in features
        ]
        # 提取各层级特征对应的patch空间尺寸（如(h_patches, w_patches)）
        patch_shapes = [x[1] for x in features]
        # 提取patch化后的特征（剥离空间尺寸信息）
        features = [x[0] for x in features]
        # 以第一个层级的patch尺寸为参考标准（用于后续对齐不同层级特征）
        ref_num_patches = patch_shapes[0]

        # 对齐不同层级特征的patch尺寸（因不同层特征图分辨率不同）
        for i in range(1, len(features)):
            _features = features[i]  # 当前层级的patch特征
            patch_dims = patch_shapes[i]  # 当前层级的patch空间尺寸

            # 重塑特征形状：适配后续插值操作，将patch维度与空间维度分离
            _features = _features.reshape(
                _features.shape[0], patch_dims[0], patch_dims[1], *_features.shape[2:]
            )
            # 调整维度顺序：将空间维度后置，便于插值
            _features = _features.permute(0, -3, -2, -1, 1, 2)
            perm_base_shape = _features.shape  # 记录当前维度结构（用于后续恢复）
            # 展平特征：适配双线性插值的输入格式
            _features = _features.reshape(-1, *_features.shape[-2:])
            # 双线性插值：将当前层级patch尺寸对齐到参考尺寸
            _features = F.interpolate(
                _features.unsqueeze(1),  # 增加通道维度（插值函数要求输入为4D）
                size=(ref_num_patches[0], ref_num_patches[1]),  # 目标尺寸（参考层级的patch尺寸）
                mode="bilinear",  # 双线性插值模式
                align_corners=False,
            )
            # 移除多余的通道维度
            _features = _features.squeeze(1)
            # 恢复特征维度结构：将插值后的特征还原为原始的patch特征格式
            _features = _features.reshape(
                *perm_base_shape[:-2], ref_num_patches[0], ref_num_patches[1]
            )
            # 调整维度顺序：恢复为“样本数×patch数×通道×patch高×patch宽”格式
            _features = _features.permute(0, -2, -1, 1, 2, 3)
            _features = _features.reshape(len(_features), -1, *_features.shape[-3:])
            features[i] = _features  # 更新对齐后的特征
        # 展平特征：将“样本数×patch数×通道×patch高×patch宽”转为“(样本数×patch数)×通道×patch高×patch宽”
        features = [x.reshape(-1, *x.shape[-3:]) for x in features]

        # 预处理：统一不同层级特征的维度
        features = self.forward_modules["preprocessing"](features)
        # 聚合多层级特征（如拼接2层和3层特征）
        features = self.forward_modules["preadapt_aggregator"](features)

        # 若需要，返回patch特征和patch空间尺寸；否则仅返回patch特征
        if provide_patch_shapes:
            return _detach(features), patch_shapes
        return _detach(features)


    def fit(self, training_data):
        """PatchCore training.

        This function computes the embeddings of the training data and fills the
        memory bank of SPADE.
        """
        self._fill_memory_bank(training_data)

    def _fill_memory_bank(self, input_data):
        """计算并设置支持特征，用于构建记忆库"""
        # 将前向传播模块设为评估模式（无需训练，仅用于特征提取）
        _ = self.forward_modules.eval()

        def _image_to_features(input_image):
            # 关闭梯度计算，避免不必要的资源消耗（特征提取阶段无参数更新）
            with torch.no_grad():
                # 将输入图像转为浮点型并迁移到指定设备（如GPU）
                input_image = input_image.to(torch.float).to(self.device)
                # 调用_embed方法提取图像的patch特征（返回预处理后的特征嵌入）
                return self._embed(input_image)

        # 初始化列表用于存储所有输入数据的特征
        features = []
        # 使用tqdm创建进度条，显示特征计算进度（位置1，不保留进度条痕迹）
        with tqdm.tqdm(
            input_data, desc="Computing support features...", position=1, leave=False
        ) as data_iterator:
            # 遍历输入数据中的每张图像
            for image in data_iterator:
                # 若图像以字典形式存储，提取"image"字段对应的图像数据
                if isinstance(image, dict):
                    image = image["image"]
                # 计算当前图像的特征并添加到列表中
                features.append(_image_to_features(image))

        # 将所有图像的特征在第0维（样本维度）拼接，形成完整的特征集合
        features = np.concatenate(features, axis=0)
        # 对特征集合进行采样（如核心集采样），减少冗余并优化记忆库规模
        features = self.featuresampler.run(features)

        # 将采样后的特征作为检测特征传入异常评分器，完成评分器的初始化
        self.anomaly_scorer.fit(detection_features=[features])

    def predict(self, data):
        """异常检测推理入口：根据输入数据类型分发推理任务"""
        # 若输入为DataLoader（批量数据集），调用批量推理方法
        if isinstance(data, torch.utils.data.DataLoader):
            return self._predict_dataloader(data)
        # 若输入为单批次图像，直接调用单批次推理方法
        return self._predict(data)

    def _predict_dataloader(self, dataloader):
        """为整个DataLoader提供异常分数和异常掩码（大规模数据推理）"""
        # 将前向传播模块设为评估模式（推理阶段不训练）
        _ = self.forward_modules.eval()

        scores = []  # 存储所有图像的图像级异常分数
        masks = []   # 存储所有图像的像素级异常掩码
        labels_gt = []  # 存储数据集中的真实异常标签（1=异常，0=正常）
        masks_gt = []   # 存储数据集中的真实异常掩码（像素级标注）
        # 使用tqdm创建推理进度条，desc为进度条描述，leave=False不保留完成后的进度条
        with tqdm.tqdm(dataloader, desc="Inferring...", leave=False) as data_iterator:
            for image in data_iterator:
                # 若输入是字典（含图像、标签、掩码等结构化数据）
                if isinstance(image, dict):
                    # 提取真实异常标签并转为列表添加到labels_gt
                    labels_gt.extend(image["is_anomaly"].numpy().tolist())
                    # 提取真实异常掩码并转为列表添加到masks_gt
                    masks_gt.extend(image["mask"].numpy().tolist())
                    # 仅保留图像数据用于推理
                    image = image["image"]
                # 对当前批次图像执行推理，得到异常分数和掩码
                _scores, _masks = self._predict(image)
                # 逐样本将结果添加到总列表
                for score, mask in zip(_scores, _masks):
                    scores.append(score)
                    masks.append(mask)
        # 返回推理结果：预测分数、预测掩码、真实标签、真实掩码
        return scores, masks, labels_gt, masks_gt

    def _predict(self, images):
        """对单批次图像推理，输出图像级异常分数和像素级异常掩码"""
        # 将图像转为浮点型并迁移到指定计算设备（GPU/CPU）
        images = images.to(torch.float).to(self.device)
        # 前向传播模块设为评估模式
        _ = self.forward_modules.eval()

        batchsize = images.shape[0]  # 获取当前批次的图像数量
        # 关闭梯度计算，减少内存占用并提升推理速度
        with torch.no_grad():
            # 提取图像的补丁特征和补丁空间尺寸（调用_embed方法，provide_patch_shapes=True返回尺寸信息）
            features, patch_shapes = self._embed(images, provide_patch_shapes=True)
            features = np.asarray(features)  # 转为numpy数组，适配后续评分器

            # 调用异常评分器计算补丁级异常分数（初始与图像级分数共用变量，后续分别处理）
            patch_scores = image_scores = self.anomaly_scorer.predict([features])[0]
            
            # ---------------------- 图像级异常分数计算 ----------------------
            # 将扁平的补丁分数恢复为批次结构（[批次×补丁数]）
            image_scores = self.patch_maker.unpatch_scores(
                image_scores, batchsize=batchsize
            )
            # 展平特征维度，统一为[批次×补丁数×特征维度]格式
            image_scores = image_scores.reshape(*image_scores.shape[:2], -1)
            # 聚合补丁分数为图像级分数（递归取最大值，符合"单补丁异常即图像异常"逻辑）
            image_scores = self.patch_maker.score(image_scores)

            # ---------------------- 像素级异常掩码生成 ----------------------
            # 将扁平的补丁分数恢复为批次结构
            patch_scores = self.patch_maker.unpatch_scores(
                patch_scores, batchsize=batchsize
            )
            scales = patch_shapes[0]  # 取第一个层级的补丁空间尺寸（如[56,56]）
            # 将补丁分数重塑为[批次×补丁高×补丁宽]，与特征图的补丁分布对齐
            patch_scores = patch_scores.reshape(batchsize, scales[0], scales[1])
            # 将补丁级分数转换为像素级异常掩码（通过插值匹配原始图像分辨率）
            masks = self.anomaly_segmentor.convert_to_segmentation(patch_scores)

        # 以列表形式返回逐样本的图像级分数和异常掩码
        return [score for score in image_scores], [mask for mask in masks]
    @staticmethod
    def _params_file(filepath, prepend=""):
        return os.path.join(filepath, prepend + "patchcore_params.pkl")

    def save_to_path(self, save_path: str, prepend: str = "") -> None:
        LOGGER.info("Saving PatchCore data.")
        self.anomaly_scorer.save(
            save_path, save_features_separately=False, prepend=prepend
        )
        patchcore_params = {
            "backbone.name": self.backbone.name,
            "layers_to_extract_from": self.layers_to_extract_from,
            "input_shape": self.input_shape,
            "pretrain_embed_dimension": self.forward_modules[
                "preprocessing"
            ].output_dim,
            "target_embed_dimension": self.forward_modules[
                "preadapt_aggregator"
            ].target_dim,
            "patchsize": self.patch_maker.patchsize,
            "patchstride": self.patch_maker.stride,
            "anomaly_scorer_num_nn": self.anomaly_scorer.n_nearest_neighbours,
        }
        with open(self._params_file(save_path, prepend), "wb") as save_file:
            pickle.dump(patchcore_params, save_file, pickle.HIGHEST_PROTOCOL)

    def load_from_path(
        self,
        load_path: str,
        device: torch.device,
        nn_method: patchcore.common.FaissNN(False, 4),
        prepend: str = "",
    ) -> None:
        LOGGER.info("Loading and initializing PatchCore.")
        with open(self._params_file(load_path, prepend), "rb") as load_file:
            patchcore_params = pickle.load(load_file)
        patchcore_params["backbone"] = patchcore.backbones.load(
            patchcore_params["backbone.name"]
        )
        patchcore_params["backbone"].name = patchcore_params["backbone.name"]
        del patchcore_params["backbone.name"]
        self.load(**patchcore_params, device=device, nn_method=nn_method)

        self.anomaly_scorer.load(load_path, prepend)


# Image handling classes.
class PatchMaker:
    """patch工具类：实现特征图的patch化与分数反patch化"""
    def __init__(self, patchsize, stride=None):
        self.patchsize = patchsize  # patch大小（默认3，即3×3 patch）
        self.stride = stride  # patch滑动步长（默认1，密集重叠patch）

    def patchify(self, features, return_spatial_info=False):
        """
        将特征图转换为patch张量
        Args:
            features: 输入特征图，shape为[批量大小×通道数×高×宽]
            return_spatial_info: 是否返回patch的空间尺寸信息
        Returns:
            patch特征（shape：[批量×patch总数×通道×patch高×patch宽]）+ 可选的空间尺寸
        """
        # 计算填充大小：保证patch中心与特征图像素对齐（patch大小为奇数时，填充为(patchsize-1)/2）
        padding = int((self.patchsize - 1) / 2)
        # 定义滑动窗口展开器：按指定patch大小、步长、填充切分特征图
        unfolder = torch.nn.Unfold(
            kernel_size=self.patchsize, stride=self.stride, padding=padding, dilation=1
        )
        # 展开特征图：shape转为[批量×(通道×patch高×patch宽)×patch总数]
        unfolded_features = unfolder(features)
        # 计算每个维度的patch数量（高方向和宽方向）
        number_of_total_patches = []
        for s in features.shape[-2:]:  # 遍历特征图的高和宽
            # patch数量计算公式：(特征尺寸 + 2×填充 - patch大小) / 步长 + 1
            n_patches = (
                s + 2 * padding - 1 * (self.patchsize - 1) - 1
            ) / self.stride + 1
            number_of_total_patches.append(int(n_patches))
        # 重塑patch特征：转为[批量×通道×patch高×patch宽×patch总数]
        unfolded_features = unfolded_features.reshape(
            *features.shape[:2], self.patchsize, self.patchsize, -1
        )
        # 调整维度顺序：转为[批量×patch总数×通道×patch高×patch宽]（符合后续处理习惯）
        unfolded_features = unfolded_features.permute(0, 4, 1, 2, 3)

        # 若需要，返回patch特征和空间尺寸；否则仅返回patch特征
        if return_spatial_info:
            return unfolded_features, number_of_total_patches
        return unfolded_features

    def unpatch_scores(self, x, batchsize):
        """将扁平化的patch分数重塑为带批量维度的形状（用于后续定位映射）"""
        return x.reshape(batchsize, -1, *x.shape[1:])

    def score(self, x):
        """
        计算patch的异常分数：递归取最大值压缩维度
        Args:
            x: patch特征分数（可为numpy数组或torch张量）
        Returns:
            单个patch的异常分数（标量）
        """
        was_numpy = False
        # 若输入为numpy数组，转为torch张量处理
        if isinstance(x, np.ndarray):
            was_numpy = True
            x = torch.from_numpy(x)
        # 递归取最后一维的最大值，直到维度为1（压缩patch内的分数为单值）
        while x.ndim > 1:
            x = torch.max(x, dim=-1).values
        # 若原始为numpy数组，转回numpy格式
        if was_numpy:
            return x.numpy()
        return x