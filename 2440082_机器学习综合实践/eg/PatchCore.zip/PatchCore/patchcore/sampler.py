import abc
from typing import Union

import numpy as np
import torch
import tqdm


class IdentitySampler:
    def run(
        self, features: Union[torch.Tensor, np.ndarray]
    ) -> Union[torch.Tensor, np.ndarray]:
        return features


class BaseSampler(abc.ABC):
    def __init__(self, percentage: float):
        if not 0 < percentage < 1:
            raise ValueError("Percentage value not in (0, 1).")
        self.percentage = percentage

    @abc.abstractmethod
    def run(
        self, features: Union[torch.Tensor, np.ndarray]
    ) -> Union[torch.Tensor, np.ndarray]:
        pass

    def _store_type(self, features: Union[torch.Tensor, np.ndarray]) -> None:
        self.features_is_numpy = isinstance(features, np.ndarray)
        if not self.features_is_numpy:
            self.features_device = features.device

    def _restore_type(self, features: torch.Tensor) -> Union[torch.Tensor, np.ndarray]:
        if self.features_is_numpy:
            return features.cpu().numpy()
        return features.to(self.features_device)

class GreedyCoresetSampler(BaseSampler):  # 基于贪心算法的核心集采样器
    def __init__(
        self,
        percentage: float,  # 采样比例
        device: torch.device,  # 计算设备（GPU/CPU）
        dimension_to_project_features_to=128,  # 特征降维后的目标维度，默认128
    ):
        """贪心核心集采样的基类"""
        super().__init__(percentage)  # 调用父类构造函数，传入采样比例

        self.device = device  # 保存计算设备
        # 保存特征降维的目标维度
        self.dimension_to_project_features_to = dimension_to_project_features_to

    def _reduce_features(self, features):
        """对特征进行降维处理，降低后续距离计算复杂度"""
        # 若特征已满足目标维度，直接返回无需降维
        if features.shape[1] == self.dimension_to_project_features_to:
            return features
        # 定义线性投影层（无偏置），实现特征维度转换
        mapper = torch.nn.Linear(
            features.shape[1], self.dimension_to_project_features_to, bias=False
        )
        mapper.to(self.device)  # 将投影层迁移到指定设备
        features = features.to(self.device)  # 将特征迁移到指定设备
        return mapper(features)  # 执行降维并返回结果

    def run(
        self, features: Union[torch.Tensor, np.ndarray]
    ) -> Union[torch.Tensor, np.ndarray]:
        """
        执行贪心核心集采样
        Args:
            features: 输入特征集合，shape为[N x D]（N=特征总数，D=特征维度）
        Returns:
            采样后的特征集合，保持与输入相同的数据类型
        """
        # 若采样比例为1，直接返回原始特征
        if self.percentage == 1:
            return features
        self._store_type(features)  # 记录输入特征的数据类型（numpy/torch）
        # 若输入为numpy数组，转换为torch张量便于计算
        if isinstance(features, np.ndarray):
            features = torch.from_numpy(features)
        # 对特征进行降维优化
        reduced_features = self._reduce_features(features)
        # 计算贪心核心集的采样索引
        sample_indices = self._compute_greedy_coreset_indices(reduced_features)
        # 根据索引筛选特征，并恢复为原始数据类型
        features = features[sample_indices]
        return self._restore_type(features)

    @staticmethod
    def _compute_batchwise_differences(
        matrix_a: torch.Tensor, matrix_b: torch.Tensor
    ) -> torch.Tensor:
        """
        基于PyTorch批量计算欧氏距离
        Args:
            matrix_a: 特征矩阵A，shape为[N x D]
            matrix_b: 特征矩阵B，shape为[M x D]
        Returns:
            距离矩阵，shape为[N x M]，元素(i,j)表示A[i]与B[j]的欧氏距离
        """
        # 计算matrix_a中每个向量的L2范数平方，shape转为[N, 1]
        a_times_a = matrix_a.unsqueeze(1).bmm(matrix_a.unsqueeze(2)).reshape(-1, 1)
        # 计算matrix_b中每个向量的L2范数平方，shape转为[1, M]
        b_times_b = matrix_b.unsqueeze(1).bmm(matrix_b.unsqueeze(2)).reshape(1, -1)
        # 计算matrix_a与matrix_b的点积，shape为[N, M]
        a_times_b = matrix_a.mm(matrix_b.T)

        # 欧氏距离公式：sqrt(||a||² + ||b||² - 2ab)，clamp(0, None)确保非负（数值稳定性）
        return (-2 * a_times_b + a_times_a + b_times_b).clamp(0, None).sqrt()

    def _compute_greedy_coreset_indices(self, features: torch.Tensor) -> np.ndarray:
        """
        执行迭代式贪心核心集选择，获取采样索引
        Args:
            features: 输入特征库，shape为[NxD]
        Returns:
            采样索引数组，shape为[K]（K=采样后特征数）
        """
        # 计算全量特征的距离矩阵（N x N）
        distance_matrix = self._compute_batchwise_differences(features, features)
        # 初始化锚点距离：每个特征到所有特征的L2范数（衡量特征"孤立程度"）
        coreset_anchor_distances = torch.norm(distance_matrix, dim=1)

        coreset_indices = []  # 存储核心集采样索引
        # 计算需要采样的核心集大小（总特征数×采样比例）
        num_coreset_samples = int(len(features) * self.percentage)

        # 迭代选择核心集特征
        for _ in range(num_coreset_samples):
            # 选择锚点距离最大的特征（最孤立，最具代表性）
            select_idx = torch.argmax(coreset_anchor_distances).item()
            coreset_indices.append(select_idx)

            # 取出所有特征到当前选中特征的距离（N x 1）
            coreset_select_distance = distance_matrix[
                :, select_idx : select_idx + 1  # noqa E203
            ]
            # 合并原锚点距离与新选中特征的距离
            coreset_anchor_distances = torch.cat(
                [coreset_anchor_distances.unsqueeze(-1), coreset_select_distance], dim=1
            )
            # 更新锚点距离：取每个特征到已选核心集的最小距离
            coreset_anchor_distances = torch.min(coreset_anchor_distances, dim=1).values

        return np.array(coreset_indices)


class ApproximateGreedyCoresetSampler(GreedyCoresetSampler):
    # 近似贪心核心集采样器（优化内存占用，避免计算全量距离矩阵）
    def __init__(
        self,
        percentage: float,  # 采样比例
        device: torch.device,  # 计算设备
        number_of_starting_points: int = 10,  # 初始随机参考点数量，默认10
        dimension_to_project_features_to: int = 128,  # 特征降维目标维度
    ):
        """近似贪心核心集采样的基类"""
        self.number_of_starting_points = number_of_starting_points  # 保存初始参考点数量
        # 调用父类构造函数，初始化采样比例、设备和降维参数
        super().__init__(percentage, device, dimension_to_project_features_to)

    def _compute_greedy_coreset_indices(self, features: torch.Tensor) -> np.ndarray:
        """
        执行近似迭代式贪心核心集选择
        无需计算全量N×N距离矩阵，内存占用显著降低，但采样时间略有增加
        Args:
            features: 输入特征库，shape为[NxD]
        Returns:
            采样索引数组，shape为[K]（K=采样后特征数）
        """
        # 限制初始参考点数量不超过特征总数
        number_of_starting_points = np.clip(
            self.number_of_starting_points, None, len(features)
        )
        # 随机选择一批初始参考点（无放回抽样）
        start_points = np.random.choice(
            len(features), number_of_starting_points, replace=False
        ).tolist()

        # 计算所有特征到初始参考点的距离矩阵（N x K，K=初始参考点数量）
        approximate_distance_matrix = self._compute_batchwise_differences(
            features, features[start_points]
        )
        # 初始化近似锚点距离：取每个特征到所有初始参考点的平均距离
        approximate_coreset_anchor_distances = torch.mean(
            approximate_distance_matrix, axis=-1
        ).reshape(-1, 1)
        coreset_indices = []  # 存储核心集采样索引
        # 计算需要采样的核心集大小
        num_coreset_samples = int(len(features) * self.percentage)

        # 关闭梯度计算，提升效率
        with torch.no_grad():
            # 迭代选择核心集特征（带进度条）
            for _ in tqdm.tqdm(range(num_coreset_samples), desc="Subsampling..."):
                # 选择近似锚点距离最大的特征
                select_idx = torch.argmax(approximate_coreset_anchor_distances).item()
                coreset_indices.append(select_idx)
                # 计算所有特征到当前选中特征的距离
                coreset_select_distance = self._compute_batchwise_differences(
                    features, features[select_idx : select_idx + 1]  # noqa: E203
                )
                # 合并原近似锚点距离与新选中特征的距离
                approximate_coreset_anchor_distances = torch.cat(
                    [approximate_coreset_anchor_distances, coreset_select_distance],
                    dim=-1,
                )
                # 更新近似锚点距离：取每个特征到已选核心集的最小距离
                approximate_coreset_anchor_distances = torch.min(
                    approximate_coreset_anchor_distances, dim=1
                ).values.reshape(-1, 1)

        return np.array(coreset_indices)

class RandomSampler(BaseSampler):
    def __init__(self, percentage: float):
        super().__init__(percentage)

    def run(
        self, features: Union[torch.Tensor, np.ndarray]
    ) -> Union[torch.Tensor, np.ndarray]:
        """Randomly samples input feature collection.

        Args:
            features: [N x D]
        """
        num_random_samples = int(len(features) * self.percentage)
        subset_indices = np.random.choice(
            len(features), num_random_samples, replace=False
        )
        subset_indices = np.array(subset_indices)
        return features[subset_indices]
