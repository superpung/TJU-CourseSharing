import copy
import os
import pickle
from typing import List
from typing import Union

import faiss
import numpy as np
import scipy.ndimage as ndimage
import torch
import torch.nn.functional as F


class FaissNN(object):
    def __init__(self, on_gpu: bool = False, num_workers: int = 4) -> None:
        """FAISS Nearest neighbourhood search.

        Args:
            on_gpu: If set true, nearest neighbour searches are done on GPU.
            num_workers: Number of workers to use with FAISS for similarity search.
        """
        faiss.omp_set_num_threads(num_workers)
        self.on_gpu = on_gpu
        self.search_index = None

    def _gpu_cloner_options(self):
        return faiss.GpuClonerOptions()

    def _index_to_gpu(self, index):
        if self.on_gpu:
            # For the non-gpu faiss python package, there is no GpuClonerOptions
            # so we can not make a default in the function header.
            return faiss.index_cpu_to_gpu(
                faiss.StandardGpuResources(), 0, index, self._gpu_cloner_options()
            )
        return index

    def _index_to_cpu(self, index):
        if self.on_gpu:
            return faiss.index_gpu_to_cpu(index)
        return index

    def _create_index(self, dimension):
        if self.on_gpu:
            return faiss.GpuIndexFlatL2(
                faiss.StandardGpuResources(), dimension, faiss.GpuIndexFlatConfig()
            )
        return faiss.IndexFlatL2(dimension)

    def fit(self, features: np.ndarray) -> None:
        """
        Adds features to the FAISS search index.

        Args:
            features: Array of size NxD.
        """
        if self.search_index:
            self.reset_index()
        self.search_index = self._create_index(features.shape[-1])
        self._train(self.search_index, features)
        self.search_index.add(features)

    def _train(self, _index, _features):
        pass

    def run(
        self,
        n_nearest_neighbours,
        query_features: np.ndarray,
        index_features: np.ndarray = None,
    ) -> Union[np.ndarray, np.ndarray, np.ndarray]:
        """
        Returns distances and indices of nearest neighbour search.

        Args:
            query_features: Features to retrieve.
            index_features: [optional] Index features to search in.
        """
        if index_features is None:
            return self.search_index.search(query_features, n_nearest_neighbours)

        # Build a search index just for this search.
        search_index = self._create_index(index_features.shape[-1])
        self._train(search_index, index_features)
        search_index.add(index_features)
        return search_index.search(query_features, n_nearest_neighbours)

    def save(self, filename: str) -> None:
        faiss.write_index(self._index_to_cpu(self.search_index), filename)

    def load(self, filename: str) -> None:
        self.search_index = self._index_to_gpu(faiss.read_index(filename))

    def reset_index(self):
        if self.search_index:
            self.search_index.reset()
            self.search_index = None


class ApproximateFaissNN(FaissNN):
    def _train(self, index, features):
        index.train(features)

    def _gpu_cloner_options(self):
        cloner = faiss.GpuClonerOptions()
        cloner.useFloat16 = True
        return cloner

    def _create_index(self, dimension):
        index = faiss.IndexIVFPQ(
            faiss.IndexFlatL2(dimension),
            dimension,
            512,  # n_centroids
            64,  # sub-quantizers
            8,
        )  # nbits per code
        return self._index_to_gpu(index)


class _BaseMerger:
    def __init__(self):
        """Merges feature embedding by name."""

    def merge(self, features: list):
        features = [self._reduce(feature) for feature in features]
        return np.concatenate(features, axis=1)


class AverageMerger(_BaseMerger):
    @staticmethod
    def _reduce(features):
        # NxCxWxH -> NxC
        return features.reshape([features.shape[0], features.shape[1], -1]).mean(
            axis=-1
        )


class ConcatMerger(_BaseMerger):
    @staticmethod
    def _reduce(features):
        # NxCxWxH -> NxCWH
        return features.reshape(len(features), -1)


class Preprocessing(torch.nn.Module):
    """特征预处理模块：统一不同层级特征的维度"""
    def __init__(self, input_dims, output_dim):
        super(Preprocessing, self).__init__()
        self.input_dims = input_dims  # 各层级特征的原始通道数（如ResNet2层512维、3层1024维）
        self.output_dim = output_dim  # 目标统一通道数

        # 为每个层级特征创建独立的预处理模块（如维度映射器）
        self.preprocessing_modules = torch.nn.ModuleList()
        for input_dim in input_dims:
            module = MeanMapper(output_dim)  # MeanMapper：将输入维度映射到output_dim的工具
            self.preprocessing_modules.append(module)

    def forward(self, features):
        _features = []
        # 对每个层级的特征应用对应的预处理（统一维度）
        for module, feature in zip(self.preprocessing_modules, features):
            _features.append(module(feature))
        # 沿维度1堆叠多层级特征（shape：(样本数×patch数) × 层级数 × 目标维度）
        return torch.stack(_features, dim=1)
    
    
class MeanMapper(torch.nn.Module):
    def __init__(self, preprocessing_dim):
        super(MeanMapper, self).__init__()
        self.preprocessing_dim = preprocessing_dim

    def forward(self, features):
        features = features.reshape(len(features), 1, -1)
        return F.adaptive_avg_pool1d(features, self.preprocessing_dim).squeeze(1)


class Aggregator(torch.nn.Module):
    def __init__(self, target_dim):
        super(Aggregator, self).__init__()
        self.target_dim = target_dim

    def forward(self, features):
        """Returns reshaped and average pooled features."""
        # batchsize x number_of_layers x input_dim -> batchsize x target_dim
        features = features.reshape(len(features), 1, -1)
        features = F.adaptive_avg_pool1d(features, self.target_dim)
        return features.reshape(len(features), -1)


class RescaleSegmentor:
    def __init__(self, device, target_size=224):
        self.device = device
        self.target_size = target_size
        self.smoothing = 4

    def convert_to_segmentation(self, patch_scores):

        with torch.no_grad():
            if isinstance(patch_scores, np.ndarray):
                patch_scores = torch.from_numpy(patch_scores)
            _scores = patch_scores.to(self.device)
            _scores = _scores.unsqueeze(1)
            _scores = F.interpolate(
                _scores, size=self.target_size, mode="bilinear", align_corners=False
            )
            _scores = _scores.squeeze(1)
            patch_scores = _scores.cpu().numpy()

        return [
            ndimage.gaussian_filter(patch_score, sigma=self.smoothing)
            for patch_score in patch_scores
        ]


class NetworkFeatureAggregator(torch.nn.Module):
    """高效提取网络特征的模块。"""

    def __init__(self, backbone, layers_to_extract_from, device):
        super(NetworkFeatureAggregator, self).__init__()
        """网络特征提取初始化方法。

        仅运行网络至需要提取特征的最后一层（即 layers_to_extract_from 列表的最后一个元素），
        避免冗余的后续层计算。

        参数:
            backbone: torchvision.model
                预训练的主干网络（如 ResNet、WideResNet 等）
            layers_to_extract_from: [list of str]
                需要提取特征的网络层名称列表（如 ["layer2", "layer3"]）
            device: torch.device
                计算设备（CPU 或 GPU）
        """
        self.layers_to_extract_from = layers_to_extract_from  # 待提取特征的层列表
        self.backbone = backbone  # 主干网络
        self.device = device  # 计算设备
        # 若主干网络无 hook_handles 属性，初始化为空列表（用于管理钩子句柄）
        if not hasattr(backbone, "hook_handles"):
            self.backbone.hook_handles = []
        # 移除已存在的钩子，避免重复注册
        for handle in self.backbone.hook_handles:
            handle.remove()
        self.outputs = {}  # 用于存储各层提取的特征

        # 为每个待提取特征的层注册前向钩子
        for extract_layer in layers_to_extract_from:
            # 实例化钩子：传入特征存储字典、当前提取层名称、最后一个提取层名称
            forward_hook = ForwardHook(
                self.outputs, extract_layer, layers_to_extract_from[-1]
            )
            # 处理含层级结构的层名称（如 "layer2.3"，表示 layer2 的第 3 个子层）
            if "." in extract_layer:
                extract_block, extract_idx = extract_layer.split(".")
                # 获取主干网络中的对应块（如 backbone.layer2）
                network_layer = backbone.__dict__["_modules"][extract_block]
                # 若索引为数字，获取块中的序列层（如 layer2[3]）
                if extract_idx.isnumeric():
                    extract_idx = int(extract_idx)
                    network_layer = network_layer[extract_idx]
                # 若索引为字符串，获取块中的子模块（如 layer2.conv1）
                else:
                    network_layer = network_layer.__dict__["_modules"][extract_idx]
            # 处理直接命名的层（如 "layer3"）
            else:
                network_layer = backbone.__dict__["_modules"][extract_layer]

            # 若目标层是 Sequential 序列，为序列的最后一个子层注册钩子
            if isinstance(network_layer, torch.nn.Sequential):
                self.backbone.hook_handles.append(
                    network_layer[-1].register_forward_hook(forward_hook)
                )
            # 若目标层是单个模块，直接为该层注册钩子
            else:
                self.backbone.hook_handles.append(
                    network_layer.register_forward_hook(forward_hook)
                )
        # 将模块移动到指定设备
        self.to(self.device)

    def forward(self, images):
        """前向传播：提取并返回指定层的特征。

        参数:
            images: torch.Tensor
                输入图像张量，形状通常为 [batch_size, channels, height, width]
        
        返回:
            self.outputs: dict
                键为层名称，值为对应层的特征张量
        """
        self.outputs.clear()  # 清空上一轮的特征存储
        with torch.no_grad():  # 推理模式，禁用梯度计算
            # 主干网络前向传播，当到达最后一个提取层时会抛出异常以终止后续计算
            try:
                _ = self.backbone(images)
            except LastLayerToExtractReachedException:
                pass  # 捕获异常，不执行额外操作
        return self.outputs  # 返回提取的所有层特征

    def feature_dimensions(self, input_shape):
        """计算给定输入形状下，各提取层的特征维度。

        参数:
            input_shape: tuple
                输入图像的形状（不含 batch 维度），如 (3, 224, 224)
        
        返回:
            list of int
                各提取层的特征通道数（如 [512, 1024] 对应 layer2 和 layer3 的通道数）
        """
        # 构造符合输入形状的虚拟张量（batch_size=1）
        _input = torch.ones([1] + list(input_shape)).to(self.device)
        # 前向传播获取特征
        _output = self(_input)
        # 提取各层特征的通道数（特征张量形状通常为 [1, c, h, w]，取索引 1 即通道数 c）
        return [_output[layer].shape[1] for layer in self.layers_to_extract_from]

class ForwardHook:
    def __init__(self, hook_dict, layer_name: str, last_layer_to_extract: str):
        self.hook_dict = hook_dict
        self.layer_name = layer_name
        self.raise_exception_to_break = copy.deepcopy(
            layer_name == last_layer_to_extract
        )

    def __call__(self, module, input, output):
        self.hook_dict[self.layer_name] = output
        if self.raise_exception_to_break:
            raise LastLayerToExtractReachedException()
        return None


class LastLayerToExtractReachedException(Exception):
    pass


class NearestNeighbourScorer(object):
    """基于最近邻（k-NN）的异常评分器，核心用于计算补丁与记忆库的距离"""
    def __init__(self, n_nearest_neighbours: int, nn_method=FaissNN(False, 4)) -> None:
        """
        初始化最近邻异常评分器
        Args:
            n_nearest_neighbours: 用于计算异常分数的近邻数量（如5个近邻）
            nn_method: 近邻搜索方法（默认FaissNN，高效大规模特征检索工具）
        """
        self.feature_merger = ConcatMerger()  # 特征合并器（用于聚合多层级特征）

        self.n_nearest_neighbours = n_nearest_neighbours  # 近邻数量
        self.nn_method = nn_method  # 近邻搜索实现

        # 图像级近邻搜索匿名函数：查询每个补丁的n个近邻
        self.imagelevel_nn = lambda query: self.nn_method.run(
            n_nearest_neighbours, query
        )
        # 像素级近邻搜索匿名函数（预留，用于更精细的像素级检索）
        self.pixelwise_nn = lambda query, index: self.nn_method.run(1, query, index)

    def fit(self, detection_features: List[np.ndarray]) -> None:
        """
        构建记忆库的近邻搜索索引
        Args:
            detection_features: 训练阶段的特征列表，格式为[[批次×特征维度]...]
                包含骨干网络输出的、用于图像级异常检测的特征向量（或特征图）
        """
        # 合并多层级特征（如ResNet的2层和3层特征）
        self.detection_features = self.feature_merger.merge(
            detection_features,
        )
        # 用合并后的训练特征（记忆库）训练近邻搜索方法，构建检索索引
        self.nn_method.fit(self.detection_features)

    def predict(
        self, query_features: List[np.ndarray]
    ) -> Union[np.ndarray, np.ndarray, np.ndarray]:
        """
        预测异常分数：在训练记忆库中搜索测试特征的近邻并计算距离
        Args:
            query_features: 测试图像的特征列表，格式与训练特征一致
        Returns:
            anomaly_scores: 补丁级异常分数（每个补丁的平均近邻距离）
            query_distances: 每个补丁到n个近邻的距离矩阵
            query_nns: 每个补丁的n个近邻在记忆库中的索引
        """
        # 合并测试图像的多层级特征
        query_features = self.feature_merger.merge(
            query_features,
        )
        # 执行近邻搜索，得到每个测试补丁的n个近邻距离和索引
        query_distances, query_nns = self.imagelevel_nn(query_features)
        # 计算异常分数：取每个补丁到n个近邻的平均距离
        anomaly_scores = np.mean(query_distances, axis=-1)
        return anomaly_scores, query_distances, query_nns

    @staticmethod
    def _detection_file(folder, prepend=""):
        """返回特征库的保存路径"""
        return os.path.join(folder, prepend + "nnscorer_features.pkl")

    @staticmethod
    def _index_file(folder, prepend=""):
        """返回近邻搜索索引的保存路径"""
        return os.path.join(folder, prepend + "nnscorer_search_index.faiss")

    @staticmethod
    def _save(filename, features):
        """将特征数据保存为pkl文件"""
        if features is None:
            return
        with open(filename, "wb") as save_file:
            # 使用最高协议保存pickle文件，提升兼容性和压缩率
            pickle.dump(features, save_file, pickle.HIGHEST_PROTOCOL)

    @staticmethod
    def _load(filename: str):
        """从pkl文件加载特征数据"""
        with open(filename, "rb") as load_file:
            return pickle.load(load_file)

    def save(
        self,
        save_folder: str,
        save_features_separately: bool = False,
        prepend: str = "",
    ) -> None:
        """
        保存近邻搜索索引和特征库
        Args:
            save_folder: 保存文件夹路径
            save_features_separately: 是否单独保存特征库（默认不保存）
            prepend: 文件名前缀（用于区分不同版本的保存文件）
        """
        # 保存近邻搜索索引
        self.nn_method.save(self._index_file(save_folder, prepend))
        # 若需要单独保存特征库，调用_save方法保存
        if save_features_separately:
            self._save(
                self._detection_file(save_folder, prepend), self.detection_features
            )

    def save_and_reset(self, save_folder: str) -> None:
        """保存数据后重置近邻索引（释放内存）"""
        self.save(save_folder)
        self.nn_method.reset_index()

    def load(self, load_folder: str, prepend: str = "") -> None:
        """
        加载保存的近邻搜索索引和特征库
        Args:
            load_folder: 加载文件夹路径
            prepend: 文件名前缀（与保存时一致）
        """
        # 加载近邻搜索索引
        self.nn_method.load(self._index_file(load_folder, prepend))
        # 若特征库文件存在，加载特征库
        if os.path.exists(self._detection_file(load_folder, prepend)):
            self.detection_features = self._load(
                self._detection_file(load_folder, prepend)
            )