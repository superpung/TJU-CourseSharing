# 基于 PatchCore 的工业图像异常检测

## 项目简介

本项目实现了基于**PatchCore**的无监督工业图像异常检测方法，针对工业场景中异常样本稀缺、传统检测方法适应性差的问题，通过预训练骨干网络提取特征、核心集采样优化记忆库、近邻搜索计算异常分数，实现高精度的图像级异常检测与像素级异常定位。

项目基于 MVTec-AD 子集数据集（包含 cable、capsule、metal_nut、screw、transistor 五类工业产品），以AUROC（受试者工作特征曲线下面积） 为评估指标，最终在图像级检测任务中达到 98.93% 的 AUROC 成绩，同时支持像素级异常区域可视化。

## 原理

PatchCore 算法流程为 “特征提取 - 记忆库构建 - 异常评分” 三步：

1. **特征提取**：使用 ImageNet 预训练骨干网络提取中层特征。
2. **记忆库构建**：将正常样本特征拆分为局部 Patch 特征，通过**核心集采样**剔除冗余特征。
3. **异常评分**：测试阶段计算每个测试 Patch 与记忆库核心集的欧氏距离，取最大近邻距离作为图像级异常分数，结合双线性插值与高斯滤波实现像素级异常定位。

## 环境配置

### 1. conda 环境创建

```bash
conda create --name patchcore_env python=3.11
conda activate patchcore_env
```

### 2. 依赖安装

根据 CUDA 版本选择对应的 PyTorch 安装指令，其他依赖通过 pip 安装：

```bash
# 示例：CUDA 12.8版本（其他版本请参考PyTorch官网调整）
pip3 install torch torchvision --index-url https://download.pytorch.org/whl/cu128

# 其他依赖
pip install click matplotlib pillow scikit-image scikit-learn scipy tqdm timm faiss-cpu pandas
```

## 数据集准备

### 1. 数据集下载

使用 MVTec-AD 子集数据集，包含 5 类工业产品的正常 / 异常样本，下载地址：[MVTec-AD Subset](https://www.kaggle.com/datasets/shuyulv/mvtec-ad-subset)

### 2. 数据集结构

下载后解压至项目根目录，目录结构如下：

```plaintext
./archive/MVTec-AD_subset/
├── train/                # 训练集（仅正常样本）
│   ├── cable_000.png
│   ├── capsule_000.png
│   └── ...
├── test/                 # 测试集（正常+异常样本）
│   ├── cable_069.png
│   ├── capsule_070.png
│   └── ...
├── train.csv             # 训练集标注（0=正常，1=异常）
├── test.csv              # 测试集标注
└── val.csv               # 验证集标注（可选）
```

## 代码结构

```plaintext
./
├── patchcore
|   ├── backbones.py          #骨干网络定义
|   ├── common.py             # 通用模块
|   ├── metrics.py            # 评估指标
|   ├── patchcore.py          # PatchCore核心类
|   ├── sampler.py            # 采样器
|
|
├── dataset.py            # 数据集类
├── train_per_class.py    # 训练/评估入口
└── README.md             # 说明文档
```

## 快速开始

### 1. 配置参数（train_per_class.py）

修改`train_per_class.py`中的配置参数：

| 参数名                | 说明             | 默认值                                                   |
| --------------------- | ---------------- | -------------------------------------------------------- |
| `CLASS_NAMES`         | 待训练的类别列表 | ["cable", "capsule", "metal_nut", "screw", "transistor"] |
| `BACKBONE_NAME`       | 预训练骨干网络   | "wideresnet101"                                          |
| `LAYERS_TO_EXTRACT`   | 特征提取层级     | ["layer2", "layer3"]                                     |
| `SAMPLER_NAME`        | 采样器类型       | "approx_greedy_coreset"                                  |
| `SAMPLING_PERCENTAGE` | 核心集采样比例   | 0.01                                                     |
| `PATCHSIZE`           | Patch 邻域大小   | 3                                                        |
| `IS_TRAIN`            | 模式选择         | True = 训练模式，False = 评估模式                        |
| `SAVE_DIR`            | 模型保存目录     | "./saved_dir"                                            |

### 2. 训练模型

设置`IS_TRAIN = True`，运行训练脚本：

```bash
python train_per_class.py
```

- 训练过程：为每个类别单独训练模型，构建正常样本 Patch 特征记忆库，保存模型参数与训练集统计信息（均值 / 标准差，用于后续标准化）。
- 输出文件：
  - 模型参数：`./saved_dir/{class_name}/`
  - 训练统计量：`./saved_dir/train_stats.csv`
  - 评估指标：`./saved_dir/training_metrics.csv`
  - 测试结果：`./submissionT.csv`（一边训练一边测试的结果）

### 3. 评估模型

设置`IS_TRAIN = False`，加载已训练模型并评估：

```bash
python train_per_class.py
```

- 评估过程：加载每个类别的预训练模型，对测试集进行异常预测， 并生成像素级分割图（可选）。
- 输出文件：
  - 评估结果：`./submissionE.csv`（直接测试的结果）
  - 像素级异常检测结果：`./saved_dir/segmentation_results/`（需开启`GENERATE_SEGMENTATION_IMAGES = True`）