import os
import pandas as pd
import torch
from torch.utils.data import Dataset
from PIL import Image
import torchvision.transforms as transforms

class MVTecSubsetDataset(Dataset):
    def __init__(self, data_root, split="train", class_name=None, csv_path=None, resize=256, imagesize=224, sample_limit=None):
        """
        Args:
            data_root: 数据集根目录（./archive/MVTec-AD_subset）
            split: 数据划分（train/test/val）
            class_name: 目标类别（cable/capsule/metal_nut/screw/transistor）
            csv_path: 对应split的csv标注文件路径
            resize: 预处理resize尺寸
            imagesize: 最终输入模型尺寸
        """
        self.data_root = data_root
        self.split = split
        self.class_name = class_name
        self.csv_path = csv_path
        self.resize = resize
        self.imagesize = imagesize

        # 加载csv标注，筛选当前类别的样本
        self.df = pd.read_csv(csv_path)
        if class_name is not None:
            # 按filename前缀筛选当前类别（如"cable_000.png"属于cable类）
            self.df = self.df[self.df["filename"].str.startswith(class_name)]
        
        # 训练时仅保留正常样本（label=0）
        if split == "train":
            self.df = self.df[self.df["label"] == 0].reset_index(drop=True)
            # 应用样本数量限制
            if sample_limit is not None and sample_limit > 0:
                self.df = self.df.head(sample_limit).reset_index(drop=True)
        
        # 数据预处理
        self.transform = transforms.Compose([
            transforms.Resize((self.resize, self.resize)),
            transforms.CenterCrop((self.imagesize, self.imagesize)),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
        ])

    def __len__(self):
        return len(self.df)

    def __getitem__(self, idx):
        row = self.df.iloc[idx]
        filename = row["filename"]
        label = row["label"]
        
        # 拼接图片路径（如./archive/MVTec-AD_subset/train/cable_000.png）
        img_path = os.path.join(self.data_root, self.split, filename)
        img = Image.open(img_path).convert("RGB")
        img = self.transform(img)

        return {
            "image": img,
            "filename": filename,
            "label": torch.tensor(label, dtype=torch.long),
            "is_anomaly": torch.tensor(label, dtype=torch.bool),  # 适配原SimpleNet数据格式
            "image_path": img_path  # 新增：添加image_path键，值为完整路径
        }