import os
import torch
import numpy as np
from torch.utils.data import DataLoader
import patchcore.patchcore as patchcore_model
import patchcore.backbones
import patchcore.sampler
import patchcore.common
from dataset import MVTecSubsetDataset  # 导入你提供的dataset实现
import pandas as pd
import time  # 添加时间模块用于测量推理时间
import PIL.Image
import matplotlib.pyplot as plt
import tqdm
import torchvision.transforms as transforms
import re

# ==================== 配置参数 ====================
# 数据集配置
DATA_ROOT = "./archive/MVTec-AD_subset"  # 数据集根目录 ./archive/MVTec-AD_subset
TRAIN_CSV = "./archive/MVTec-AD_subset/train.csv"  # 训练集CSV路径
TEST_CSV = "./archive/MVTec-AD_subset/test.csv"  # 测试集CSV路径
CLASS_NAMES = ["cable", "capsule", "metal_nut", "screw", "transistor"]  # 要训练的类别  "cable", "capsule", "metal_nut", "screw", "transistor"
LIMIT = None # None  # 每类训练样本数量限制，None表示不限制

# 模型配置
BACKBONE_NAME = "wideresnet101"  # 使用的backbone  wideresnet101  wideresnet50
LAYERS_TO_EXTRACT = ["layer2","layer3"]  # 从哪些层提取特征  "layer2", "layer3"  "layer4"
PRETRAIN_EMBED_DIM = 1024  # 预训练特征维度
TARGET_EMBED_DIM = 384  # 目标特征维度
PATCHSIZE = 3  # patch大小
ANOMALY_SCORER_NUM_NN = 1  # 最近邻数量

# 采样器配置
SAMPLING_PERCENTAGE = 0.01  # 采样百分比
SAMPLER_NAME = "approx_greedy_coreset"  # 采样器类型  random  approx_greedy_coreset  greedy_coreset

# 训练配置
BATCH_SIZE = 2  # 批大小
NUM_WORKERS = 0  # 减少工作进程数，避免内存问题
RESIZE = 366  # 初始resize尺寸 366
IMAGESIZE = 320  # 最终输入模型尺寸  320

# 标准化配置
NORMALIZATION_MODE = 1  # 0: 不标准化, 1: 使用训练集统计量标准化, 2: 使用自身均值和方差标准化

# 设备与随机种子
GPU_ID = 0  # 使用的GPU ID
SEED = 40  # 随机种子

# 保存配置
SAVE_DIR = "./saved_dir"  # 模型保存目录
STATS_FILE = os.path.join(SAVE_DIR, "train_stats.csv")  # 训练集统计信息保存路径（改为CSV格式）
SUBMISSION_PATH_TRAIN = "./submissionT.csv"  # 训练模式下的提交文件路径
SUBMISSION_PATH_EVAL = "./submissionE.csv"  # 评估模式下的提交文件路径
METRICS_FILE = os.path.join(SAVE_DIR, "training_metrics.csv")  # 训练指标保存文件
os.environ['TORCH_HOME'] = './torch_cache'  # Kaggle工作目录下的自定义路径

# 分割图像生成配置
GENERATE_SEGMENTATION_IMAGES = False  # 是否生成分割图像
SEGMENTATION_SAVE_FOLDER = "./saved_dir/segmentation_results"  # 分割图像保存路径
TEST_FILES_TO_GENERATE = None  # 要生成分割图像的测试集文件列表， None 表示所有文件  ["cable_069.png"]

# 模式选择
IS_TRAIN = True  # True 表示训练模式， False 表示评估模式
# ==================== 配置结束 ====================

def plot_segmentation_images(
    savefolder,
    image_paths,
    segmentations,
    anomaly_scores=None,
    image_transform=lambda x: x,
    save_depth=1,
):
    """Generate anomaly segmentation images.

    Args:
        savefolder: 保存文件夹路径
        image_paths: List[str] 图像路径列表
        segmentations: [List[np.ndarray]] 生成的分割结果
        anomaly_scores: [List[float]] 每张图像的异常分数
        image_transform: [function or lambda] 可选的图像变换
        save_depth: [int] 用于图像保存名称的路径字符串数量
    """
    if anomaly_scores is None:
        anomaly_scores = ["-1" for _ in range(len(image_paths))]

    os.makedirs(savefolder, exist_ok=True)

    for image_path, anomaly_score, segmentation in tqdm.tqdm(
        zip(image_paths, anomaly_scores, segmentations),
        total=len(image_paths),
        desc="Generating Segmentation Images...",
        leave=False,
    ):
        image = PIL.Image.open(image_path).convert("RGB")
        image = image_transform(image)
        if not isinstance(image, np.ndarray):
            image = image.numpy()
        
        min_val = image.min()
        max_val = image.max()
        if max_val > min_val:  # 避免除以零
            image = (image - min_val) / (max_val - min_val)
        else:
            image = np.zeros_like(image)  # 处理特殊情况

        # 使用正则表达式分割两种路径分隔符
        savename = re.split(r'[\\/]', image_path)
        # 过滤掉空字符串和可能的当前目录符号
        savename = [part for part in savename if part and part != '.']
        

        # 拼接最后save_depth个部分
        savename = "_".join(savename[-save_depth:])
        

        # 生成完整保存路径
        savename = os.path.join(savefolder, savename)
        


        f, axes = plt.subplots(1, 2)
        axes[0].imshow(image.transpose(1, 2, 0))
        axes[0].set_title(f"Image\nScore: {anomaly_score:.4f}")
        axes[0].axis('off')
        
        axes[1].imshow(segmentation)
        axes[1].set_title("Segmentation")
        axes[1].axis('off')
        
        f.set_size_inches(6, 3)
        f.tight_layout()
        f.savefig(savename)
        plt.close()

def setup_device_and_seed(gpu_id, seed):
    """设置设备和随机种子"""
    device = torch.device(f"cuda:{gpu_id}" if torch.cuda.is_available() and gpu_id >= 0 else "cpu")

    # 固定随机种子
    torch.manual_seed(seed)
    np.random.seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
        torch.backends.cudnn.deterministic = True
    
    print(f"使用设备: {device}")
    return device

def create_dataloaders(data_root, train_csv, test_csv, class_name, batch_size, num_workers, resize, imagesize, sample_limit=LIMIT):
    """创建训练和测试数据加载器"""
    # 训练数据加载器 - 只包含正常样本
    train_dataset = MVTecSubsetDataset(
        data_root=data_root,
        split="train",
        class_name=class_name,
        csv_path=train_csv,
        resize=resize,
        imagesize=imagesize,
        sample_limit=sample_limit  # 应用样本数量限制
    )
    train_loader = DataLoader(
        train_dataset,
        batch_size=batch_size,
        shuffle=True,
        num_workers=num_workers,
        pin_memory=False  # 禁用pin_memory以减少内存使用
    )

    # 测试数据加载器 - 包含正常和异常样本
    test_dataset = MVTecSubsetDataset(
        data_root=data_root,
        split="test",
        class_name=class_name,
        csv_path=test_csv,
        resize=resize,
        imagesize=imagesize
    )
    test_loader = DataLoader(
        test_dataset,
        batch_size=batch_size,
        shuffle=False,
        num_workers=num_workers,
        pin_memory=False  # 禁用pin_memory以减少内存使用
    )

    return train_loader, test_loader

def create_test_dataloader(data_root, test_csv, class_name, batch_size, num_workers, resize, imagesize):
    """创建测试数据加载器（仅用于评估模式）"""
    test_dataset = MVTecSubsetDataset(
        data_root=data_root,
        split="test",
        class_name=class_name,
        csv_path=test_csv,
        resize=resize,
        imagesize=imagesize
    )
    test_loader = DataLoader(
        test_dataset,
        batch_size=batch_size,
        shuffle=False,
        num_workers=num_workers,
        pin_memory=False
    )
    return test_loader

def create_patchcore_model(device, backbone_name, layers_to_extract, input_shape, 
                          pretrain_embed_dim, target_embed_dim, patchsize, 
                          sampling_percentage, sampler_name, anomaly_scorer_num_nn):
    """创建并初始化PatchCore模型"""
    # 加载backbone
    backbone = patchcore.backbones.load(backbone_name)
    backbone.name = backbone_name
    backbone.seed = SEED

    # 创建采样器
    if sampler_name == "identity":
        sampler = patchcore.sampler.IdentitySampler()
    elif sampler_name == "greedy_coreset":
        sampler = patchcore.sampler.GreedyCoresetSampler(sampling_percentage, device)
    elif sampler_name == "approx_greedy_coreset":
        sampler = patchcore.sampler.ApproximateGreedyCoresetSampler(sampling_percentage, device)
    elif sampler_name == "random":
        sampler = patchcore.sampler.RandomSampler(sampling_percentage)
    else:
        raise ValueError(f"未知的采样器类型: {sampler_name}")

    # 创建FAISS NN方法
    nn_method = patchcore.common.FaissNN(False, 4)  # 不使用GPU上的FAISS

    # 创建PatchCore模型
    model = patchcore_model.PatchCore(device)
    model.load(
        backbone=backbone,
        layers_to_extract_from=layers_to_extract,
        device=device,
        input_shape=input_shape,
        pretrain_embed_dimension=pretrain_embed_dim,
        target_embed_dimension=target_embed_dim,
        patchsize=patchsize,
        featuresampler=sampler,
        anomaly_scorer_num_nn=anomaly_scorer_num_nn,
        nn_method=nn_method
    )

    return model

def predict_image_level(model, dataloader):
    """仅进行图像级别的预测，返回图像级异常分数和真实标签"""
    model.eval()
    all_scores = []
    all_labels = []
    all_filenames = []
    all_masks = []  # 新增：存储分割掩码
    all_image_paths = []  # 新增：存储图像路径

    with torch.no_grad():
        for batch in dataloader:
            images = batch["image"].to(model.device)
            labels = batch["label"].cpu().numpy()
            filenames = batch["filename"]
            image_paths = batch["image_path"]  # 新增：获取图像路径
        
            # 使用PatchCore进行预测
            scores, masks = model.predict(images)  # 修改：获取分割掩码
        
            all_scores.extend(scores)
            all_labels.extend(labels)
            all_filenames.extend(filenames)
            all_masks.extend(masks)  # 新增：存储分割掩码
            all_image_paths.extend(image_paths)  # 新增：存储图像路径

    return np.array(all_scores), np.array(all_labels), all_filenames, all_masks, all_image_paths  # 修改：返回分割掩码和图像路径

def predict_image_level_with_time(model, dataloader):
    """进行图像级别的预测，并测量推理时间"""
    model.eval()
    all_scores = []
    all_labels = []
    all_filenames = []
    all_masks = []  # 新增：存储分割掩码
    all_image_paths = []  # 新增：存储图像路径
    inference_times = []  # 存储每个batch的推理时间

    with torch.no_grad():
        for batch in dataloader:
            images = batch["image"].to(model.device)
            labels = batch["label"].cpu().numpy()
            filenames = batch["filename"]
            image_paths = batch["image_path"]  # 新增：获取图像路径
            
            # 测量推理时间
            start_time = time.time()
            
            # 使用PatchCore进行预测
            scores, masks = model.predict(images)  # 修改：获取分割掩码
            
            # 记录结束时间
            end_time = time.time()
            batch_time = end_time - start_time
            inference_times.append(batch_time)
        
            all_scores.extend(scores)
            all_labels.extend(labels)
            all_filenames.extend(filenames)
            all_masks.extend(masks)  # 新增：存储分割掩码
            all_image_paths.extend(image_paths)  # 新增：存储图像路径

    return np.array(all_scores), np.array(all_labels), all_filenames, all_masks, all_image_paths, inference_times  # 修改：返回分割掩码和图像路径

def evaluate_model(model, test_loader):
    """评估模型性能（图像级AUROC）"""
    from sklearn.metrics import roc_auc_score

    # 获取预测分数和真实标签
    scores, labels, filenames, masks, image_paths = predict_image_level(model, test_loader)  # 修改：获取分割掩码和图像路径

    # 计算AUROC
    auroc = roc_auc_score(labels, scores)

    return auroc, scores, labels, filenames, masks, image_paths  # 修改：返回分割掩码和图像路径

def evaluate_model_with_time(model, test_loader):
    """评估模型性能（图像级AUROC）并测量推理时间"""
    from sklearn.metrics import roc_auc_score

    # 获取预测分数和真实标签，并测量时间
    scores, labels, filenames, masks, image_paths, inference_times = predict_image_level_with_time(model, test_loader)  # 修改：获取分割掩码和图像路径

    # 计算AUROC
    auroc = roc_auc_score(labels, scores)
    
    # 计算时间统计
    total_time = sum(inference_times)
    num_images = len(scores)
    avg_time_per_image = total_time / num_images if num_images > 0 else 0

    return auroc, scores, labels, filenames, masks, image_paths, total_time, avg_time_per_image  # 修改：返回分割掩码和图像路径

def get_category(filename):
    """从文件名中提取类别，支持带下划线的类别名称（如metal_nut）"""
    # 分割文件名和扩展名
    name_without_ext = filename.split('.')[0]
    # 找到最后一个下划线的位置，其前面的部分即为类别
    last_underscore_index = name_without_ext.rfind('_')
    if last_underscore_index != -1:
        return name_without_ext[:last_underscore_index]
    return name_without_ext  # 异常情况处理

def normalize_scores(scores, normalization_mode, category_stats=None):
    """根据指定的标准化模式对分数进行标准化"""
    if normalization_mode == 0:  # 不标准化
        return scores
    elif normalization_mode == 1:  # 使用训练集统计量标准化
        if category_stats is None:
            raise ValueError("需要提供category_stats参数用于训练集统计量标准化")
        mean_score, std_score = category_stats
        if std_score == 0:
            return scores - mean_score
        else:
            return (scores - mean_score) / std_score
    elif normalization_mode == 2:  # 使用自定义均值和方差标准化
        custom_mean = scores.mean()
        custom_std = scores.std()
        if custom_std == 0:
            return scores - custom_mean
        else:
            return (scores - custom_mean) / custom_std
    else:
        raise ValueError(f"未知的标准化模式: {normalization_mode}")

def train_mode():
    """训练模式：训练模型并保存"""
    # 设置设备和随机种子
    device = setup_device_and_seed(GPU_ID, SEED)

    # 确保保存目录存在
    os.makedirs(SAVE_DIR, exist_ok=True)

    # 输入形状
    input_shape = [3, IMAGESIZE, IMAGESIZE]

    all_results = []
    category_stats = {}  # 存储每个类别的均值和标准差
    metrics_data = []    # 存储每个类别的评估指标

    # 对每个类别进行训练
    for class_name in CLASS_NAMES:
        print(f"\n开始训练类别: {class_name}")
    
        # 创建数据加载器
        train_loader, test_loader = create_dataloaders(
            DATA_ROOT, TRAIN_CSV, TEST_CSV, class_name, 
            BATCH_SIZE, NUM_WORKERS, RESIZE, IMAGESIZE, LIMIT
        )
    
        # 创建模型
        model = create_patchcore_model(
            device, BACKBONE_NAME, LAYERS_TO_EXTRACT, input_shape,
            PRETRAIN_EMBED_DIM, TARGET_EMBED_DIM, PATCHSIZE,
            SAMPLING_PERCENTAGE, SAMPLER_NAME, ANOMALY_SCORER_NUM_NN
        )
    
        # 训练模型
        print(f"正在训练 {class_name}...")
        model.fit(train_loader)

        # 在训练集上预测，计算均值和标准差
        print(f"计算 {class_name} 的训练集统计量...")
        train_scores, _, _, _, _ = predict_image_level(model, train_loader)  # 修改：接收额外的返回值
        mean_score = np.mean(train_scores)
        std_score = np.std(train_scores)
        category_stats[class_name] = (mean_score, std_score)
        print(f"{class_name} 训练集分数均值: {mean_score:.6f}, 标准差: {std_score:.6f}")
    
        # 评估模型并测量时间
        print(f"评估 {class_name}...")
        auroc, scores, labels, filenames, masks, image_paths, total_time, avg_time_per_image = evaluate_model_with_time(model, test_loader)  # 修改：接收额外的返回值
        print(f"{class_name} 图像级AUROC: {auroc:.4f}")
        print(f"{class_name} 推理时间统计:")
        print(f"  总图像数: {len(scores)}")
        print(f"  总推理时间: {total_time:.4f} 秒")
        print(f"  平均每张图像推理时间: {avg_time_per_image:.4f} 秒")
        
        # 存储评估指标
        metrics_data.append({
            "class_name": class_name,
            "auroc": auroc,
            "total_images": len(scores),
            "total_time": total_time,
            "avg_time_per_image": avg_time_per_image
        })
    
        # 标准化测试集分数
        normalized_scores = normalize_scores(
            scores, NORMALIZATION_MODE, 
            category_stats.get(class_name)
        )
    
        # 存储标准化后的结果
        for filename, norm_score in zip(filenames, normalized_scores):
            all_results.append({"filename": filename, "score": norm_score})
            
        # 生成分割图像（如果启用）
        if GENERATE_SEGMENTATION_IMAGES:
            print(f"为 {class_name} 生成分割图像...")
            os.makedirs(SEGMENTATION_SAVE_FOLDER, exist_ok=True)
            
            # 筛选要生成分割图像的文件
            if TEST_FILES_TO_GENERATE is not None:
                # 只生成指定文件的分割图像
                selected_indices = [i for i, filename in enumerate(filenames) 
                                  if filename in TEST_FILES_TO_GENERATE]
                selected_image_paths = [image_paths[i] for i in selected_indices]
                selected_scores = [scores[i] for i in selected_indices]
                selected_masks = [masks[i] for i in selected_indices]
            else:
                # 生成所有文件的分割图像
                selected_image_paths = image_paths
                selected_scores = scores
                selected_masks = masks
            
            # 定义图像变换（与训练时相同）
            image_transform = transforms.Compose([
                transforms.Resize((RESIZE, RESIZE)),
                transforms.CenterCrop((IMAGESIZE, IMAGESIZE)),
                transforms.ToTensor(),
                transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
            ])
            
            # 生成分割图像
            plot_segmentation_images(
                savefolder=SEGMENTATION_SAVE_FOLDER,  # 直接使用配置的保存文件夹
                image_paths=selected_image_paths,
                segmentations=selected_masks,
                anomaly_scores=selected_scores,
                image_transform=image_transform,
                save_depth=4
            )
            print(f"{class_name} 的分割图像已保存到: {SEGMENTATION_SAVE_FOLDER}")

        # 创建类别保存目录
        class_save_dir = os.path.join(SAVE_DIR, class_name)
        os.makedirs(class_save_dir, exist_ok=True)
    
        # 保存模型
        print(f"保存 {class_name} 模型...")
        model.save_to_path(class_save_dir)
    
        # 清理内存
        del model, train_loader, test_loader
        torch.cuda.empty_cache()

    # 保存训练集统计信息为CSV文件
    stats_df = pd.DataFrame([
        {"class_name": class_name, "mean": stats[0], "std": stats[1]}
        for class_name, stats in category_stats.items()
    ])
    stats_df.to_csv(STATS_FILE, index=False)
    print(f"\n训练集统计信息已保存到: {STATS_FILE}")
    
    # 保存评估指标
    metrics_df = pd.DataFrame(metrics_data)
    metrics_df.to_csv(METRICS_FILE, index=False)
    print(f"\n评估指标已保存到: {METRICS_FILE}")

    print("\n所有类别训练完成!")

    # 创建DataFrame并排序
    submission_df = pd.DataFrame(all_results)

    # 确保按照指定的类别顺序排序
    def get_class_order(filename):
        for i, class_name in enumerate(CLASS_NAMES):
            if filename.startswith(class_name):
                return i
        return len(CLASS_NAMES)  # 不在指定类别中的放在最后

    submission_df["class_order"] = submission_df["filename"].apply(get_class_order)
    submission_df = submission_df.sort_values(["class_order", "filename"])
    submission_df = submission_df[["filename", "score"]]  # 只保留需要的列

    # 保存结果
    submission_df.to_csv(SUBMISSION_PATH_TRAIN, index=False)
    print(f"\n标准化后的预测结果已保存到: {SUBMISSION_PATH_TRAIN}")

def eval_mode():
    """评估模式：加载已训练模型并进行预测"""
    # 设置设备
    device = setup_device_and_seed(GPU_ID, SEED)
    
    # 输入形状
    input_shape = [3, IMAGESIZE, IMAGESIZE]
    
    all_results = []
    
    # 加载训练集统计信息（如果使用训练集统计量标准化）
    category_stats = {}
    if NORMALIZATION_MODE == 1 and os.path.exists(STATS_FILE):
        stats_df = pd.read_csv(STATS_FILE)
        category_stats = {
            row["class_name"]: (row["mean"], row["std"])
            for _, row in stats_df.iterrows()
        }
        print(f"已加载训练集统计信息: {STATS_FILE}")
    
    # 对每个类别进行预测
    for class_name in CLASS_NAMES:
        print(f"\n加载并预测类别: {class_name}")
        
        # 创建测试数据加载器
        test_loader = create_test_dataloader(
            DATA_ROOT, TEST_CSV, class_name, 
            BATCH_SIZE, NUM_WORKERS, RESIZE, IMAGESIZE
        )
        
        # 创建模型结构
        model = create_patchcore_model(
            device, BACKBONE_NAME, LAYERS_TO_EXTRACT, input_shape,
            PRETRAIN_EMBED_DIM, TARGET_EMBED_DIM, PATCHSIZE,
            SAMPLING_PERCENTAGE, SAMPLER_NAME, ANOMALY_SCORER_NUM_NN
        )
        nn_method = patchcore.common.FaissNN(False, 4)
        
        # 加载已训练模型
        class_save_dir = os.path.join(SAVE_DIR, class_name)
        if not os.path.exists(class_save_dir):
            print(f"警告: {class_name} 的模型目录不存在，跳过此类别")
            continue
            
        print(f"加载 {class_name} 模型...")
        model.load_from_path(class_save_dir, device, nn_method)
        
        # 进行预测
        print(f"预测 {class_name}...")
        scores, labels, filenames, masks, image_paths = predict_image_level(model, test_loader)  # 修改：接收额外的返回值
        
        # 标准化分数
        class_stats = category_stats.get(class_name, (0.0, 1.0))
        normalized_scores = normalize_scores(
            scores, NORMALIZATION_MODE, 
            class_stats
        )
        
        # 存储标准化后的分数
        for filename, score in zip(filenames, normalized_scores):
            all_results.append({"filename": filename, "score": score})
            
        # 生成分割图像（如果启用）
        if GENERATE_SEGMENTATION_IMAGES:
            print(f"为 {class_name} 生成分割图像...")
            os.makedirs(SEGMENTATION_SAVE_FOLDER, exist_ok=True)
            
            # 筛选要生成分割图像的文件
            if TEST_FILES_TO_GENERATE is not None:
                # 只生成指定文件的分割图像
                selected_indices = [i for i, filename in enumerate(filenames) 
                                  if filename in TEST_FILES_TO_GENERATE]
                selected_image_paths = [image_paths[i] for i in selected_indices]
                selected_scores = [scores[i] for i in selected_indices]
                selected_masks = [masks[i] for i in selected_indices]
            else:
                # 生成所有文件的分割图像
                selected_image_paths = image_paths
                selected_scores = scores
                selected_masks = masks
            
            # 定义图像变换（与训练时相同）
            image_transform = transforms.Compose([
                transforms.Resize((RESIZE, RESIZE)),
                transforms.CenterCrop((IMAGESIZE, IMAGESIZE)),
                transforms.ToTensor(),
                transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
            ])
            
            # 生成分割图像
            plot_segmentation_images(
                savefolder=SEGMENTATION_SAVE_FOLDER,  # 直接使用配置的保存文件夹
                image_paths=selected_image_paths,
                segmentations=selected_masks,
                anomaly_scores=selected_scores,
                image_transform=image_transform,
                save_depth=4
            )
            print(f"{class_name} 的分割图像已保存到: {SEGMENTATION_SAVE_FOLDER}")
            
        # 清理内存
        del model, test_loader
        torch.cuda.empty_cache()
    
    print("\n所有类别预测完成!")
    
    # 创建DataFrame并排序
    submission_df = pd.DataFrame(all_results)

    # 确保按照指定的类别顺序排序
    def get_class_order(filename):
        for i, class_name in enumerate(CLASS_NAMES):
            if filename.startswith(class_name):
                return i
        return len(CLASS_NAMES)  # 不在指定类别中的放在最后

    submission_df["class_order"] = submission_df["filename"].apply(get_class_order)
    submission_df = submission_df.sort_values(["class_order", "filename"])
    submission_df = submission_df[["filename", "score"]]  # 只保留需要的列

    # 保存结果
    submission_df.to_csv(SUBMISSION_PATH_EVAL, index=False)
    print(f"\n标准化后的预测结果已保存到: {SUBMISSION_PATH_EVAL}")

def main():
    """主函数，根据IS_TRAIN选择模式"""
    if IS_TRAIN:
        print("进入训练模式...")
        train_mode()
    else:
        print("进入评估模式...")
        eval_mode()

if __name__ == "__main__":
    main()
