import numpy as np

# 定义两个三维向量
vector_a = np.array([3, 4, 0])
vector_b = np.array([1, -2, 5])

# 向量加法
vector_add = vector_a + vector_b
print(f"向量加法 ({vector_a} + {vector_b}): {vector_add}")

#向量减法
vector_sub = vector_a - vector_b
print(f"向量减法 ({vector_a} - {vector_b}): {vector_sub}")

#数乘
scalar = 2.5
vector_scalar_mul = scalar * vector_a
print(f"数乘 ({scalar} * {vector_a}): {vector_scalar_mul}")

#点乘
dot_product = np.dot(vector_a, vector_b)
print(f"点乘 ({vector_a} · {vector_b}): {dot_product}")

#取模
mod_a = np.linalg.norm(vector_a)
mod_b = np.linalg.norm(vector_b)
print(f"向量 {vector_a} 的模: {mod_a:.4f}")
print(f"向量 {vector_b} 的模: {mod_b:.4f}")

#方向角 (与各坐标轴的夹角)
def direction_angles(vector):
    mod = np.linalg.norm(vector)
    angles_rad = np.arccos(vector / mod)  # 计算反余弦得到弧度
    angles_deg = np.degrees(angles_rad)   # 弧度转角度
    return angles_deg

angles_a = direction_angles(vector_a)
angles_b = direction_angles(vector_b)
print(f"向量 {vector_a} 与坐标轴的方向角 (度): α={angles_a[0]:.2f}°, β={angles_a[1]:.2f}°, γ={angles_a[2]:.2f}°")
print(f"向量 {vector_b} 与坐标轴的方向角 (度): α={angles_b[0]:.2f}°, β={angles_b[1]:.2f}°, γ={angles_b[2]:.2f}°")

#两个向量之间的夹角
def vector_angle(v1, v2):
    dot = np.dot(v1, v2)
    mod_product = np.linalg.norm(v1) * np.linalg.norm(v2)
    cos_theta = dot / mod_product
    angle_rad = np.arccos(cos_theta)
    return np.degrees(angle_rad)

angle_ab = vector_angle(vector_a, vector_b)
print(f"向量 {vector_a} 和 {vector_b} 之间的夹角: {angle_ab:.2f}°")
