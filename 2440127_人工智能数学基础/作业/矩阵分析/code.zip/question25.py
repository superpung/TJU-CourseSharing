import gensim
from gensim.models import Word2Vec
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA
from gensim import downloader


print("下载text8语料库...")
corpus = downloader.load('text8')  # 维基百科文本清洗后的语料
print("下载完成")

# 配置模型参数
model = Word2Vec(
    sentences = corpus,
    vector_size=100,    
    window=3,           
    min_count=1,        
    sg=1,               
    workers=4,          
    epochs=10           
)


# 保存和加载模型
model.save("word2vec_text8.model")
model = Word2Vec.load("word2vec_text8.model")

# 词语相似度查询
for word in ['computer', 'engine', 'language', 'sport']:
    print(f"\n与'{word}'最相似的词：")
    print(model.wv.most_similar(word, topn=5))

# 类比推理
print("\n类比推理: king - man + woman =")
result = model.wv.most_similar(positive=['woman', 'king'], negative=['man'], topn=3)
for word, score in result:
    print(f"{word}: {score:.3f}")

# 选择要可视化的词汇
categories = {
    "科技": ["computer", "internet", "software", "technology", "digital"],
    "体育": ["football", "basketball", "tennis", "sport", "olympic"],
    "国家": ["france", "germany", "china", "india", "brazil"],
    "职业": ["doctor", "engineer", "teacher", "scientist", "artist"]
}

words = []
for cat in categories.values():
    words.extend(cat)

# 提取词向量
vectors = model.wv[words]

# PCA降维
pca = PCA(n_components=2)
result = pca.fit_transform(vectors)

# 绘制可视化
plt.figure(figsize=(14, 10))
colors = {'科技': 'red', '体育': 'blue', '国家': 'green', '职业': 'purple'}
markers = {'科技': 'o', '体育': 's', '国家': '^', '职业': 'D'}


for i, word in enumerate(words):
    category = next(cat for cat, words in categories.items() if word in words)
    plt.scatter(result[i, 0], result[i, 1], 
                c=colors[category], 
                marker=markers[category],
                s=100, alpha=0.7)
    plt.annotate(word, xy=(result[i, 0], result[i, 1]), 
                 fontsize=9,
                 xytext=(5, 2), 
                 textcoords='offset points')


from matplotlib.lines import Line2D
legend_elements = [Line2D([0], [0], marker=markers[cat], color='w', label=cat,
                          markersize=10, markerfacecolor=colors[cat]) 
                   for cat in categories]
plt.legend(handles=legend_elements, loc='best', fontsize=12)
plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']  # 指定中文字体
plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示问题
plt.title('Word2Vec 词向量空间分布 (text8语料库)', fontsize=16)
plt.xlabel('PCA维度1', fontsize=12)
plt.ylabel('PCA维度2', fontsize=12)
plt.grid(alpha=0.3)
plt.tight_layout()
plt.show()