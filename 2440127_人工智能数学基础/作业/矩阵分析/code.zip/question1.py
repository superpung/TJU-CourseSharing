import numpy as np


#矩阵定义
matrix_a = np.array([[4, 2, 1, 3],
                     [0, 1, 3, 2],
                     [2, 0, 1, 4],
                     [1, 3, 2, 1]])

matrix_b = np.array([[1, 3, 2, 4],
                     [2, 1, 4, 3],
                     [3, 4, 1, 2],
                     [4, 2, 3, 1]])


print("原始矩阵A (4x4):")
print(matrix_a)
print("\n原始矩阵B (4x4):")
print(matrix_b)


#矩阵运算
add_result = matrix_a + matrix_b
print("\n矩阵加法结果 (A + B):")
print(add_result)


sub_result = matrix_a - matrix_b
print("\n矩阵减法结果 (A - B):")
print(sub_result)


s = 2
mult_result = s * matrix_a
print(f"\n矩阵数乘结果 (2 * A):")
print(mult_result)


mult_result = np.matmul(matrix_a, matrix_b)
print("\n矩阵乘积结果 (A × B):")
print(mult_result)


mult_result = np.multiply(matrix_a, matrix_b)
print("\n点乘结果 (A ⊙ B):")
print(mult_result)


inv_a = np.linalg.inv(matrix_a)
print("\n矩阵A的逆:")
print(inv_a)


transpose_a = matrix_a.T
print("\n矩阵A的转置:")
print(transpose_a)


print("\n矩阵A切片:")

row_slice = matrix_a[1, :]
print("第2行:", row_slice)


col_slice = matrix_a[:, 2]
print("第3列:", col_slice)


submatrix1 = matrix_a[:2, :2]
print("左上角2x2子矩阵:")
print(submatrix1)


submatrix2 = matrix_a[2:, 2:]
print("右下角2x2子矩阵:")
print(submatrix2)


submatrix3 = matrix_a[1:3, 1:3]
print("中间2x2子矩阵:")
print(submatrix3)


det_a = np.linalg.det(matrix_a)
det_b = np.linalg.det(matrix_b)

print("\n行列式计算:")
print(f"矩阵A的行列式: {det_a:.2f}")
print(f"矩阵B的行列式: {det_b:.2f}")

