python版本为3.11
问题1，10/18的环境只需要用到numpy库
pip install numpy
问题15/26是基于sk-learn实现SVM，需要的库有numpy，sk-learn，matplotlib
pip install numpy matplotlib scikit-learn
问题25是基于gensim包进行的Word2Vec实现，需要的库有gensim matplotlib，由于在可视化部分用到了PCA降维，所以也需要sk-learn库
pip install gensim matplotlib scikit-learn

