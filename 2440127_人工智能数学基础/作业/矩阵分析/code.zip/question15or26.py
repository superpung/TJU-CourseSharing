import numpy as np
import matplotlib.pyplot as plt
from sklearn import datasets
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score, classification_report


# 加载乳腺癌数据集
cancer = datasets.load_breast_cancer()
X = cancer.data
y = cancer.target

# 标准化
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# 划分训练测试集
X_train, X_test, y_train, y_test = train_test_split(
    X_scaled, y, test_size=0.3, random_state=42
)


# 创建SVM分类器
svm_model = SVC(kernel='rbf', C=1.0, gamma='scale', random_state=42)

# 训练模型
svm_model.fit(X_train, y_train)

# 预测与评估
y_pred = svm_model.predict(X_test)

print("准确率:", accuracy_score(y_test, y_pred))
print("\n分类报告:")
print(classification_report(y_test, y_pred))


# 选择前两个特征进行可视化
X_2d = X_scaled[:, :2]

# 重新训练模型
svm_2d = SVC(kernel='rbf', C=1.0, gamma=0.5)
svm_2d.fit(X_2d, y)

# 创建网格点
x_min, x_max = X_2d[:, 0].min() - 1, X_2d[:, 0].max() + 1
y_min, y_max = X_2d[:, 1].min() - 1, X_2d[:, 1].max() + 1
xx, yy = np.meshgrid(np.arange(x_min, x_max, 0.02),
                     np.arange(y_min, y_max, 0.02))

# 预测网格点类别
Z = svm_2d.predict(np.c_[xx.ravel(), yy.ravel()])
Z = Z.reshape(xx.shape)

# 绘制
plt.contourf(xx, yy, Z, alpha=0.8)
plt.scatter(X_2d[:, 0], X_2d[:, 1], c=y, edgecolors='k')
plt.xlabel('Feature 1 ')
plt.ylabel('Feature 2 ')
plt.title('SVM Decision Boundary with RBF Kernel')
plt.show()
