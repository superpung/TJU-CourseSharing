#include <iostream>
using namespace std;

int main()
{
  // Prompt the user to enter an integer
  cout << "Enter three integers: ";
  int n1, n2, n3;
  cin >> n1 >> n2 >> n3;

  cout << "You entered " << n1 << " " << n2 << " " << n3 << endl;

system("PAUSE");
    system("pause");
  return 0;
}

