#include <iostream>
#include "Student.h"
#include <fstream>
using namespace std;

int main()
{

  Student s;
  cout << sizeof(s) << endl;
    system("pause");
  return 0;
}
