// ShowSyntaxErrors.java: The program contains syntax errors
#include <iostream>
using namespace std;

int main()
{
  i = 30;
  cout << i + 4;
}

