#include <iostream>
#include "A.h"
using namespace std;

int main()
{
 // A a;

  cout << max(3, 4) << endl;
    system("pause");
  return 0;
}
