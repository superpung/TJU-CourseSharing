#include <iostream>

int main()
{
  std::cout << "Welcome to C++!" << std::endl;
  return 0;
}
