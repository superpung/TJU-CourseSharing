class Date
{
public:
  friend class AccessDate;

private:
  int year;
  int month;
  int day;
};
