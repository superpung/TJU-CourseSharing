#include <iostream>
using namespace std;

void t1(); // function prototype

int main()
{
   char  ch1[]={'a','b'};
   char ch2[]="ab";
   
   cout<<ch1<<endl;
   cout<<ch2<<endl;
    system("pause");
  return 0;
}

