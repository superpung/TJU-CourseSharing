#include <iostream>

int main()
{
  // Display Welcome to C++ to the console
  std::cout << "Welcome to C++!" << std::endl;
  system("pause"); 
  return 0;
}
