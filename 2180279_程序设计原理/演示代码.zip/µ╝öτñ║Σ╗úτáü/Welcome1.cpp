#include <iostream>

int main()
{
  std::cout << "Welcome to C++!" << std::endl;
  std::cout << "Welcome to C++Builder!" << std::endl;
  std::cout << "Welcome to C++ Compiler!" << std::endl;

    system("pause");
  return 0;
}
