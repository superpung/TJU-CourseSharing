class Circle
{
public:
  // The radius of this circle
  double radius;

  // Construct a circle object
  Circle();

  Circle(double);

  // Return the area of this circle
  double getArea();
};
