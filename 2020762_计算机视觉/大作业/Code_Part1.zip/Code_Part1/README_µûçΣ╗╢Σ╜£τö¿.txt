main.cpp: 主函数;
part1.cpp: 自行编写的part1的算法;

part1.h是相应的头文件。