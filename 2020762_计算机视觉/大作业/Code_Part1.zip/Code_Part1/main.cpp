#include "part1.h"
#include <ctime>

int main() {
	/*	Part 1	*/
	// Definations 
	clock_t begin = clock();
	Mat image0, gray, gauss, imp, bin;
	vector<Vec3f> circles;
	vector<vector<Point>> clusters;
	int cnt = 0;
	
	image0 = load_img("0.JPG");					// 0.JPG
	//image0 = load_img("1.JPG");						// 1.JPG
	//imp = Mat::zeros(image0.size(), CV_8UC1);		// Initialize 
	cvtColor(image0, gray, COLOR_BGR2GRAY);			// Transform into gray 
	GaussianBlur(gray, gauss, Size(5, 5), 2, 2);	// Gaussian Blur 
	
	//strength(gauss, imp);							// Image strengthening 
	threshold(gauss, bin, 80, 255, THRESH_BINARY);	// Binary
	//namedWindow("11", 0);
	//imshow("11", bin);
	//waitKey(0);
	circles = HoughTransform(bin, image0);			// Hough transform, testing circles 
	clusters = Cluster(circles, 95.0);				
	// Clusters with 8 circles are marked as a code-block 
	// Clusters without 8 circles, skip 
	for (auto i : clusters) {
		if (i.size() == 8)
			cnt++;
	}
	cout << "\nThe number of coding blocks:" << cnt << endl;
	drawClusterCenters(image0, clusters);			// Visualize the final decision 
	clock_t end = clock();
	// Timer 
	double duration = double(end - begin) / CLOCKS_PER_SEC;
	cout << "Run time: " << duration << " Second" << std::endl;
	
	return 0;
}