#pragma once

#include <iostream>
#include<opencv2/opencv.hpp>
#include <vector>
#include <queue>
#include <cmath>
#include <algorithm>

using namespace std;
using namespace cv;

cv::Mat load_img(string img_name);
void HoughTest(const Mat& image, vector<Vec3f>& circles, double dp, double minDist, double param1, double param2, int minRadius, int maxRadius);
vector<cv::Vec3f> HoughTransform(cv::Mat img, cv::Mat output);
vector<vector<Point>> Cluster(const vector<cv::Vec3f>& circles, float radius);
void drawClusterCenters(cv::Mat& image, const vector<vector<Point>>& clusters);