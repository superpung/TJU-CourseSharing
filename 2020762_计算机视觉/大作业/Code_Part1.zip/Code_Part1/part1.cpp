#include "part1.h"
#include <string>

Mat load_img(string img_name) {
	string path_ini = "G:/cpp/cv_1/Data/";	// Location
	Mat image = imread(path_ini.append(img_name));
	if (image.data == nullptr) {
		cout << "DO NOT EXIST!" << endl;	// Loading failed
		return Mat();
	}
	//namedWindow("00", 0);					// Prevent partial presentation
	//imshow("00", image);
	//waitKey(0);
	return image;
}

// Mimic HoughCircles() function in OpenCV, with the same formal parameter
void HoughTest(const Mat& image, vector<Vec3f>& circles, double dp, double minDist, double param1, double param2, int minRadius, int maxRadius) {
	// Edge detection
	Mat edges;
	Canny(image, edges, param1 / 2, param1);
	int rows = image.rows;
	int cols = image.cols;
	int rRange = maxRadius - minRadius + 1;

	// Vote accumulator in unit: (a, b, r)
	vector<vector<vector<int>>> acc(rows, vector<vector<int>>(cols, vector<int>(rRange, 0)));

	// Vote
	for (int y = 0; y < rows; ++y) {
		for (int x = 0; x < cols; ++x) {
			// Skip background
			if (edges.at<uchar>(y, x) == 0) 
				continue;
			// Vote for circle edge
			for (int r = minRadius; r <= maxRadius; ++r) {
				for (int t = 0; t < 360; t += 5) {
					// Transform the coordinate system into polar one
					double theta = t * CV_PI / 180.0;
					int a = cvRound(x - r * cos(theta));
					int b = cvRound(y - r * sin(theta));
					if (a >= 0 && a < cols && b >= 0 && b < rows) {
						acc[b][a][r - minRadius]++;			// Vote in accumulator (a, b, r)
					}
				}
			}
		}
	}
	//int maxvotes = 0;
	for (int r = 0; r < rRange; ++r) {
		for (int y = 1; y < rows - 1; ++y) {
			for (int x = 1; x < cols - 1; ++x) {
				int votes = acc[y][x][r];
				// Local maximum suppresion, preventing the disruption caused by coarse edge
				// 1 pixel for each direction
				if (votes > param2 &&
					votes > acc[y - 1][x][r] && votes > acc[y + 1][x][r] &&
					votes > acc[y][x - 1][r] && votes > acc[y][x + 1][r]) {
					/*
					if (votes > maxvotes) {
						maxvotes = votes;
					}
					*/
					// Skip, when the distance < minDist
					float cx = x, cy = y, cr = r + minRadius;
					bool tooClose = false;
					for (auto& c : circles) {
						if (norm(Point2f(c[0], c[1]) - Point2f(cx, cy)) < minDist) {
							tooClose = true;
							break;
						}
					}
					if (!tooClose)
						circles.emplace_back(cx, cy, cr);		// Push into the vector
				}
			}
		}
	}
	//cout << endl << maxvotes << endl;
}

vector<cv::Vec3f> HoughTransform(cv::Mat img, cv::Mat output) {
	vector<cv::Vec3f> circles;
	// Hough circle test with self-defined, instead of the function in OpenCV
	HoughTest(img, circles, 1, 20, 100, 20, 8, 16);		 
	for (size_t i = 0; i < circles.size(); i++) {
		// 3 channels for the variable "circles"
		// Channel 0 and 1 for the coordinate of x and y, respectively 
		Point centre(cvRound(circles[i][0]), cvRound(circles[i][1]));
		// Channel 2 for the radius 
		int radius = cvRound(circles[i][2]);
		//cout << radius << endl;
		// Marked the tested circles 
		circle(output, centre, 3, Scalar(0, 255, 0), -1, 8, 0);
		circle(output, centre, radius, Scalar(0, 0, 255), 3, 8, 0);
	}

	//namedWindow("22", 0);
	//imshow("22", output);
	//waitKey(0);
	return circles;
}

// Distance clustering based on BFS 
vector<vector<Point>> Cluster(const vector<cv::Vec3f>& circles, float radius_thresh) {
	vector<vector<Point>> clusters;	// The return value 
	vector<Point> circle_points;
	// Transform the 3D vector<Vec3f> into 2D circle points 
	for (const auto& cc : circles) {
		circle_points.emplace_back(cvRound(cc[0]), cvRound(cc[1]));
	}
	// Initialize the visiting record, preventing clustering repeatedly 
	vector<bool> visited(circle_points.size(), false);

	for (size_t i = 0; i < circle_points.size(); i++) {
		if (visited[i])				// Have been clustered, skip 
			continue;

		vector<Point> current_cluster;
		queue<int> q;				// Achieve BFS 
		q.push(i);
		visited[i] = true;

		while (!q.empty()) {
			int idx = q.front(); q.pop();		// Achieve BFS
			current_cluster.push_back(circle_points[idx]);

			for (size_t j = 0; j < circle_points.size(); j++) {
				// Add into a cluster, only when satisfied both of 2 requirements: 
				// 1. Unvisited;
				// 2. Distance < minDist. 
				// Using the 2 normal function to calculate the distance 
				if (!visited[j] && norm(circle_points[idx] - circle_points[j]) < radius_thresh) {
					visited[j] = true;			// Set visited, then push into the cluster 
					q.push(j);
				}
			}
		}

		clusters.push_back(current_cluster);
	}

	return clusters;
}

void drawClusterCenters(cv::Mat& image, const vector<vector<Point>>& clusters) {
	int cnt = 0;
	for (size_t i = 0; i < clusters.size(); i++) {
		if (clusters[i].size() != 8)
			continue;							// Cluster without 8 circles, skip 

		// With 8 circles, do calculations below 
		// Calculate the central pixel for each cluster, and visualize them 
		int sum_x = 0, sum_y = 0;
		for (const Point& p : clusters[i]) {
			sum_x += p.x;
			sum_y += p.y;
		}
		Point center(sum_x / 8, sum_y / 8);

		// Visualize with marked number, from 1-11 here 
		circle(image, center, 125, Scalar(255, 255, 0), 5);
		putText(image, to_string(++cnt), center + Point(60, -60), FONT_HERSHEY_SIMPLEX, 5, Scalar(0, 255, 255), 5);
	}

	imwrite("G:/cpp/cv_1/Data/0_cppmarked.jpg", image);
	//imwrite("G:/cpp/cv_1/Data/1_cppmarked.jpg", image);
	
	//namedWindow("33", 0);
	//imshow("33", image);
	//waitKey(0);
}