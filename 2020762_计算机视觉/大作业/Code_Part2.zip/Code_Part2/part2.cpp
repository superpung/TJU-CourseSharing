#include "part2.h"

Mat normalize(vector<Point2d>& fig) {
	double sumX,sumY, cenX, cenY;
	double sumRMS, RMS, s;
	double tx, ty;
	sumX = sumY = sumRMS = 0;
	Mat T;

	for (int i = 0; i < 8; i++) {
		sumX += fig[i].x;
		sumY += fig[i].y;
	}
	// New centre
	cenX = sumX / 8;
	cenY = sumY / 8;
	
	// Made RMS = sqrt(2)
	for (int i = 0; i < 8; i++) {
		sumRMS += norm(Point2d(fig[i].x, fig[i].y) - Point2d(cenX, cenY));
	}
	RMS = sumRMS / 8;
	s = sqrt(2) / RMS;
	tx = -s * cenX;
	ty = -s * cenY;
	T = (Mat_<double>(3, 3) << s, 0, tx, 0, s, ty, 0, 0, 1);
	// Normalize coordinates 
	for (int i = 0; i < 8; i++){
		fig[i].x = s * fig[i].x + tx;
		fig[i].y = s * fig[i].y + ty;
		//std::cout << "Normalized: (" << Point2d(fig[i].x, fig[i].y) << ")\n";
	}

	return T;
}

Mat calF(const Point2d fig0[], const Point2d fig1[]) {
	// Definations 
	vector<Point2d> img0_8points, img1_8points;
	Mat T1, T2;
	Mat W(8, 9, CV_64FC1);
	double matW[8][9];
	double x1, x2, y1, y2;
	Mat u, s, vt, F, Fq, f;
	
	// Push const-type 8 points into vector
	for (int i = 0; i < 8; i++) {
		img0_8points.push_back(fig0[i]);
		img1_8points.push_back(fig1[i]);
	}

	// Normalize, calculating for T and T' 
	T1 = normalize(img0_8points);
	T2 = normalize(img1_8points);
	
	//for (int i = 0; i < 8; i++) {
	//	std::cout << "Normalized0: (" << Point2d(img0_8points[i].x, img0_8points[i].y) << ")\n";
	//	std::cout << "Normalized1: (" << Point2d(img1_8points[i].x, img1_8points[i].y) << ")\n";
	//}
	
	// Calculating matrix F with normalized coordinates 
	// Construct matrix W 
	for (int i = 0; i < 8; i++) {
		// x1=u1; x2=u1'; y1=v1; y2=v1'
		x1 = img0_8points[i].x;
		x2 = img1_8points[i].x;
		y1 = img0_8points[i].y;
		y2 = img1_8points[i].y;
		matW[i][0] = x1 * x2;
		matW[i][1] = y1 * x2;
		matW[i][2] = x2;
		matW[i][3] = x1 * y2;
		matW[i][4] = y1 * y2;
		matW[i][5] = y2;
		matW[i][6] = x1;
		matW[i][7] = y1;
		matW[i][8] = 1.0;

		for (int j = 0; j < 9; j++) {
			W.at<double>(i, j) = matW[i][j];
		}
	}
	// SVD
	SVD::compute(W, s, u, vt, SVD::FULL_UV);
	f = vt.row(8).reshape(0, 3);
	// Enforce rank 2
	SVD::compute(f, s, u, vt, SVD::MODIFY_A);		// Save space and speed up
	s.at<double>(2) = 0;
	Fq = u * Mat::diag(s) * vt;
	// Denormalize
	F = T2.t() * Fq * T1;
	// Normalize F, like OpenCV 
	F = F / F.at<double>(2, 2);
	//std::cout << "F: \n" << F << endl;

	return F;
}
// Key: feature_num; value: point (x, y)
void readPoints(const string& filename, map<int, vector<Point2d>>& points_map) {
	ifstream file(filename);
	string line;
	while (getline(file, line)) {
		stringstream ss(line);
		int image_num, feature_num;
		double x, y;

		ss >> image_num >> feature_num >> x >> y;
		points_map[feature_num].push_back(Point2d(x, y));		// Write
	}
}
// Calculate x2^T * F * x1 to verify, equal about 0
void calValue(const Mat& F, const map<int, vector<Point2d>>& points_map) {
	// Search each feature_num
	for (const auto& entry : points_map) {
		const vector<Point2d>& points = entry.second;
		if (points.size() == 2) {
			Mat x1 = (Mat_<double>(3, 1) << points[0].x, points[0].y, 1.0);
			Mat x2 = (Mat_<double>(3, 1) << points[1].x, points[1].y, 1.0);

			// Cal 
			Mat result = x2.t() * F * x1;
			//cout << "Point " << entry.first << " test result (x2^T * F * x1): " << abs(result.at<double>(0, 0)) << endl;
		}
	}
}

void verifyF(Mat F) {
	string file = "G:/cpp/cv_2/Data/data.txt";
	map<int, vector<Point2d>> points_map;
	readPoints(file, points_map);
	calValue(F, points_map);
}

Mat calE(const Mat& F) {
	Mat E = K.t() * F * K;
	// SVD while enforcing singular values diag(1,1,0)
	Mat u, s, vt, E_corrected;
	SVD::compute(E, s, u, vt, SVD::MODIFY_A);
	//std::cout << "S: \n" << s << endl;
	
	s.at<double>(0) = 1.0;
	s.at<double>(1) = 1.0;
	s.at<double>(2) = 0.0;
	E_corrected = u * Mat::diag(s) * vt;
	E_corrected /= norm(E_corrected);

	//std::cout << "E: \n" << E_corrected << endl;
	
	return E_corrected;
}
// Triangulate
Vector4d triangulatePoint(const Matrix<double, 3, 4>& P1, const Matrix<double, 3, 4>& P2, const Vector2d& x1, const Vector2d& x2) {
	Matrix4d A;
	Vector4d X;
	// DLT 
	A.row(0) = x1(0) * P1.row(2) - P1.row(0);
	A.row(1) = x1(1) * P1.row(2) - P1.row(1);
	A.row(2) = x2(0) * P2.row(2) - P2.row(0);
	A.row(3) = x2(1) * P2.row(2) - P2.row(1);
	JacobiSVD<Matrix4d> svd(A, ComputeFullV);
	X = svd.matrixV().col(3);
	//std::cout << X / X(3) << endl;

	return X / X(3);
}
// Calculate R and T
vector<MatrixXd> calRT(const Mat& E, const vector<Point2d>& pts1, const vector<Point2d>& pts2, const Matrix3d& K) {
	vector<MatrixXd> RT;							// Combined [R|t]��R3*4 
	Mat s, u, vt, R1, R2, W, t1, t2, R, t;
	Matrix<double, 3, 4>  P1, P2, best_RT;
	Vector3d x1_norm, x2_norm, X1, X2;
	MatrixXd R_m, t_m;
	Vector4d X;
	int max_front_count = -1;
	int front_count = 0;

	W = (cv::Mat_<double>(3, 3) << 0, -1, 0, 1, 0, 0, 0, 0, 1);
	SVD::compute(E, s, u, vt, SVD::MODIFY_A);
	// 2 possibily solutions for R and t, respectively 
	R1 = u * W * vt;
	R2 = u * W.t() * vt;
	t1 = u.col(2);
	t2 = -u.col(2);
	// Ensure det(R) > 0
	if (determinant(R1) < 0) 
		R1 = -R1;
	if (determinant(R2) < 0)
		R2 = -R2;
	// Make 4 pairs
	vector<pair<Mat, Mat>> pose_candidates = {
		{R1, t1}, {R1, t2}, {R2, t1}, {R2, t2}
	};
	// Search for the best one
	for (size_t i = 0; i < pose_candidates.size(); ++i) {
		R = pose_candidates[i].first;
		t = pose_candidates[i].second;
		cv2eigen(R, R_m);
		cv2eigen(t, t_m);
		front_count = 0;

		for (int j = 0; j < pts1.size(); ++j) {
			x1_norm = K.inverse() * Vector3d(pts1[j].x, pts1[j].y, 1.0);
			x2_norm = K.inverse() * Vector3d(pts2[j].x, pts2[j].y, 1.0);
			// P1=[I|0]; P2=[R|t]
			P1 << Matrix3d::Identity(), Vector3d::Zero();
			P2 << R_m, t_m;

			X = triangulatePoint(P1, P2, x1_norm.head<2>(), x2_norm.head<2>());
			X1 = X.head<3>();
			X2 = R_m * X1 + t_m;
			// Verify all the points are in front of both cameras  
			if (X1(2) > 0 && X2(2) > 0) 
				front_count++;
		}
		// Update with the best sol 
		if (front_count > max_front_count) {
			max_front_count = front_count;
			best_RT.resize(3, 4);
			best_RT << R_m, t_m;
		}
		//cout << "front_count: \n" << front_count << endl;
	}

	//cout << "Points in front of both cameras: " << max_front_count << " / " << pts1.size() << endl;

	if (max_front_count > 0) {
		RT.push_back(best_RT);
	}

	return RT;
}