#pragma once

#include <iostream>
#include <opencv2/opencv.hpp>
#include <vector>
#include <map>
#include <cmath>
#include <Eigen/Core>
#include <Eigen/SVD>
#include <Eigen/Dense>
#include <opencv2/core/eigen.hpp>
#include <fstream>
#include <sstream>
#include <string>

using namespace Eigen;
using namespace std;
using namespace cv;

// Internal matrix K 
const Mat K = (cv::Mat_<double>(3, 3) << 4705.5337, 0, 3944.07, 0, 4705.5337, 2612.675, 0, 0, 1);

Mat normalize(vector<Point2d>& fig);
Mat calF(const Point2d fig0[], const Point2d fig1[]);
void readPoints(const string& filename, map<int, vector<Point2d>>& points_map);
void calValue(const Mat& F, const map<int, vector<Point2d>>& points_map);
void verifyF(Mat F);
Mat calE(const Mat& F);
Vector4d triangulatePoint(const Matrix<double, 3, 4>& P1, const Matrix<double, 3, 4>& P2, const Vector2d& x1, const Vector2d& x2);
vector<MatrixXd> calRT(const Mat& E, const vector<Point2d>& pts1, const vector<Point2d>& pts2, const Matrix3d& K);
