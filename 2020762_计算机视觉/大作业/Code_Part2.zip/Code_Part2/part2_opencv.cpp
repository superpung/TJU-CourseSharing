#include "part2_opencv.h"
#include "part2.h";
#include "calLength.h"
const Point2d fig0_1(3522.5512, 942.5185);
const Point2d fig1_1(5907.4902, 2557.3595);
const Point2d fig0_2(4295.4749, 2698.9412);
const Point2d fig1_2(3380.9717, 2697.2484);
const Point2d fig0_3(3043.512, 3559.9259);
const Point2d fig1_3(2896.8671, 1516.4858);
const Point2d fig0_4(5616.793, 2486.5359);
const Point2d fig1_4(3227.4749, 4288.1481);
const Point2d fig0_5(2606.549, 1842.9913);
const Point2d fig1_5(4691.5251, 1472.6383);
const Point2d fig0_6(2670.8824, 3619.915);
const Point2d fig1_6(2926.5142, 1252.146);
const Point2d fig0_7(3337.5948, 3087.3878);
const Point2d fig1_7(3219.4096, 1775.8519);
const Point2d fig0_8(5371.3442, 3125.2789);
const Point2d fig1_8(2545.8736, 3594.1373);

const Point2d fig0[8] = { fig0_1, fig0_2, fig0_3, fig0_4, fig0_5, fig0_6, fig0_7, fig0_8 };
const Point2d fig1[8] = { fig1_1, fig1_2, fig1_3, fig1_4, fig1_5, fig1_6, fig1_7, fig1_8 };

vector<Vector2d> pointImg0 = {
        Vector2d(fig0_5.x, fig0_5.y),
        Vector2d(fig0_6.x, fig0_6.y),
        Vector2d(fig0_7.x, fig0_7.y),
        Vector2d(fig0_8.x, fig0_8.y)
};
vector<Vector2d> pointImg1 = {
    Vector2d(fig1_5.x, fig1_5.y),
    Vector2d(fig1_6.x, fig1_6.y),
    Vector2d(fig1_7.x, fig1_7.y),
    Vector2d(fig1_8.x, fig1_8.y)
};

void opencvTest(vector<Point2d> pts1, vector<Point2d> pts2) {
    // 1. Cal F 
    Mat F = findFundamentalMat(pts1, pts2, FM_8POINT);
    // 2. Cal E
    Mat E = findEssentialMat(pts1, pts2, K);            // 8-points
    //Mat E = calE(F);                                  // Self-defined
    // 3. Cal R, t
    Mat R, t;
    recoverPose(E, pts1, pts2, K, R, t);
    // 4. Euler angles 
    Matrix3d R_m;
    cv2eigen(R, R_m);
    Vector3d euler = R_m.eulerAngles(2, 1, 0);
    // 5. Cal length
    MatrixXd t_m;
    cv2eigen(t, t_m);
    
    vector<MatrixXd> RT;
    MatrixXd rt(3, 4);
    rt.block<3, 3>(0, 0) = R_m;
    rt.col(3) = t_m;
    RT.push_back(rt);
    
    // Output 
    cout << "F = \n" << F << endl;
    cout << "E = \n" << E << endl;
    cout << "R = \n" << R << endl;
    cout << "Euler angles (ZYX: degree) : \n" << endl;
    cout << "Z = " << euler[0] * 180.0 / CV_PI << endl;
    cout << "Y = " << euler[1] * 180.0 / CV_PI << endl;
    cout << "X = " << euler[2] * 180.0 / CV_PI << endl;
    cout << "t = \n" << t << endl;
    verifyF(F);

    cout << "OpenCV "; 
    calLength(RT, pointImg0, pointImg1);
    
}