/*******************************************************************************
* FileName:         BinTree.cpp
* Author:           Your_name
* Student Number:   Student_Number
* Date:             2020/04/01 09:24:55
* Version:          v1.0
* Description:      Data Structure Experiment #8
*******************************************************************************/


#include "BinTree.h"

BinTree::BinTree(){
}


BinTree::~BinTree(){
}

void BinTree::insert(int val, int parent, int flg){
}

int* BinTree::p_traversal() const{
    int*p = new int[1];
    p[0] = 2;
    return p;
}

int* BinTree::m_traversal() const{
    int *p = new int[1];
    p[0] = 2;
    return p;
}

int BinTree::countNode() const{

}

int BinTree::height() const{

}