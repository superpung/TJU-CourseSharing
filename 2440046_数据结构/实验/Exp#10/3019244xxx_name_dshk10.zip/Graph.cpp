/*******************************************************************************
* FileName:         Graph.cpp
* Author:           Your_name
* Student Number:   Student_Number
* Date:             2020/04/14 09:24:55
* Version:          v1.0
* Description:      Data Structure Experiment #10
*******************************************************************************/

#include "Graph.h"


Graph::Graph(int v){

}

Graph::~Graph(){

}

void Graph::addedge(int s, int t, int w){

}

int Graph::getInDegree(int v){

}

int Graph::getOutDegree(int v){

}

int Graph::access(int s, int t){

}