/*******************************************************************************
* FileName:         SeqStack.cpp
* Author:           Your_Name
* Student Number:   3019244xxx
* Date:             2020/03/04 11:24:55
* Version:          v1.0
* Description:      Data Structure Experiment #4
*******************************************************************************/
#include "SeqStack.h"

SeqStack::SeqStack(){

}
SeqStack::~SeqStack(){

}
void SeqStack::push_back(int data){

}
int SeqStack::top() const{

}
void SeqStack::pop(){

}