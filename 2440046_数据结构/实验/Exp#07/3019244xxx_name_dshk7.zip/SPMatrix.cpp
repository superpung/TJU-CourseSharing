/*******************************************************************************
* FileName:         SPMatrix.cpp
* Author:           Your_name
* Student Number:   3019244XXX
* Date:             2020/03/20 11:24:55
* Version:          v1.0
* Description:      Data Structure Experiment #7
*
*******************************************************************************/

#include "SPMatrix.h"

SPMatrix::SPMatrix(int r, int c){

}

SPMatrix::SPMatrix(int r, int c, int max_element){

}

int SPMatrix::get(int i, int j)const{

}

void SPMatrix::set(int i, int j, int val){

}

void SPMatrix::rotate(){

}

SPMatrix SPMatrix::operator+(const SPMatrix& b){
}

SPMatrix SPMatrix::operator-(const SPMatrix& b){
}

SPMatrix SPMatrix::operator*(const SPMatrix& b){
}

SPMatrix::~SPMatrix(){

}