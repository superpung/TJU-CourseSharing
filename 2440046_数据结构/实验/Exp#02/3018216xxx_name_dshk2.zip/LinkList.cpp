/*******************************************************************************
* FileName:         LinkList.cpp
* Author:           记得改成你的名字
* Student Number:   3018216xxx
* Date:             2019/03/05 11:24:55
* Version:          v1.0
* Description:      Data Structure Experiment #2
*                   完成程度：
*                       简要说一下自己写了多少，完成了哪些函数?
*                   备注：
*                       有没有助教判作业时需要注意的？
*******************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef char ListData;


/**
 *   @brief 链表节点的结构体声明
 *   允许大家对结构进行修改，但是修改之后记得更新一下注释。
 *
 *   链表的index从0开始计数。
 *
 *   data:  数据域
 *   next:  节点域
 *   last:  尾节点指针
 */
typedef struct node {
	ListData  data;
    struct node* next;
    struct node* last;
} ListNode;

typedef ListNode  * LinkList;   //链表头指针


/**
    将链表进行初始化操作
    @name void initList(LinkList&);
    @param arg1 需要初始化的链表
    @return void
*/
void InitList(LinkList& head);


/**
    将数据插入到链表头
    @name void insertHead(LinkList&, ListData);
    @param arg1 需要执行插入的链表
    @param arg2 需要插入的数据
    @return void
*/
void InsertHead(LinkList& head, ListData data);


/**
    将数据插入到链表尾
    @name void insertTail(LinkList&, ListData);
    @param arg1 需要执行插入的链表
    @param arg2 需要插入的数据
    @return void
*/
void insertTail(LinkList& head, ListData data);


/**
    删除表中第i个数据
    @name void Delete(LinkList&, int);
    @param arg1 需要执行插入的链表
    @param arg2 需要删除的数据的位置
    @return  0: 数据成功删除
             1: 删除时出现错误
*/
int Delete(LinkList& head, int i);


/**
    查找并返回第i个元素。
    @name void FindIndex(LinkList&, ListData);
    @param arg1 需要查找的链表
    @param arg2 需要查找的数据的位置
    @return  ListData: 第i个数据是什么
*/
ListData FindIndex(const LinkList& head, int i);


/**
    查找并返回第一个值为value的数据的序号
    @name void FindValue(LinkList&, ListData);
    @param arg1 需要查找的链表
    @param arg2 需要查询的值
    @return  (int)  i:  ListData 的序号
                -1   :  没有找到value时返回-1
*/
int FindValue(const LinkList& head, ListData value);


/**
    打印输出链表内容
	每两个元素之间有空格，最后输出换行
	例如：  1 2 3 5 3\n
    @name void PrintList(const LinkList&);
    @param arg1 需要打印的链表
    @return  void
*/
void PrintList(const LinkList& head);


