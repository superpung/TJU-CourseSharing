/*******************************************************************************
* FileName:         LinkList.cpp
* Author:           Your_Name
* Student Number:   3019244xxx
* Date:             2020/02/26 11:24:55
* Version:          v1.0
* Description:      Data Structure Experiment #2
*                   作业在这个文件中完成，需要补全LinkList类的实现，
*                   写明必要的注释
*******************************************************************************/

#include "LinkList.h"

LinkList::LinkList(){
}

LinkList::~LinkList(){
}

int LinkList::length(){
}

int LinkList::getData(const int& location){
}

void LinkList::insert(const int& data, const int& location){
}

bool LinkList::remove(const int& location){
}

void LinkList::converse(){
}

void LinkList::append(const LinkList& append_list){
}