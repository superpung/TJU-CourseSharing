/*******************************************************************************
* FileName:         Haffman.cpp
* Author:           Your_name
* Student Number:   Student_Number
* Date:             2020/04/08 09:24:55
* Version:          v1.0
* Description:      Data Structure Experiment #10
*******************************************************************************/

#include "Huffman.h"

HuffmanTree::HuffmanTree(const char* str){

}

HuffmanTree::~HuffmanTree(){

}

char* HuffmanTree::getcode(char c){

}

int HuffmanTree::getWPL(){

}