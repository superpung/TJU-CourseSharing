/*******************************************************************************
* FileName:         MyString.cpp
* Author:           Your_Name
* Student Number:   3018216xxx
* Date:             2020/03/18 11:24:55
* Version:          v1.0
* Description:      Data Structure Experiment #3
*                   完成程度：
*                       简要说一下自己写了多少，完成了哪些函数
*******************************************************************************/
#include <cstdio>
#include <cstdlib>
#include "MyString.h"


MyString::MyString(const char*){

}

MyString::~MyString(){

}

int MyString::length() const{

}

void MyString::replace(const char* replace, int loc){

}

int MyString::find(const char* str) const{

}

const char* MyString::c_string() const{

}