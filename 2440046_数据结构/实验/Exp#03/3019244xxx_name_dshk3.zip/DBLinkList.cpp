/*******************************************************************************
* FileName:         DBLinkList.cpp
* Author:           Your_Name
* Student Number:   3018216xxx
* Date:             2019/03/13 11:24:55
* Version:          v1.0
* Description:      Data Structure Experiment #3
*                   完成程度：
*                       简要说一下自己写了多少，完成了哪些函数
*                   备注：
*                       有没有助教判作业时需要注意的
*******************************************************************************/
#include <cstdio>
#include <cstdlib>
#include "DBLinkList.h"


void initDBL(DBLinkList& dbl){
    dbl.head = NULL;
    dbl.tail = NULL;
    dbl.eleNumber = 0;
}


int insertDBL(DBLinkList& dbl, datatype dt, int loc){

}



int removeDBL(DBLinkList& dbl, int loc){

}


datatype findByIndex(DBLinkList& dbl,int loc){

}

void convertDBL(DBLinkList& dbl){

}


void printDBL(DBLinkList& dbl){
    printf("1 2 3\n");
}