/*******************************************************************************
* FileName:         DBLinkList.cpp
* Author:           Your_Name
* Student Number:   3019244xxx
* Date:             2020/03/04 11:24:55
* Version:          v1.0
* Description:      Data Structure Experiment #3
*******************************************************************************/

#include "DBLinkList.h"

DBLinkList::DBLinkList(){
}
DBLinkList::~DBLinkList(){
}

void DBLinkList::insert(int data, int location){
}

void DBLinkList::remove(int location){
}

int DBLinkList::length(){
}

int DBLinkList::getData(int location){
}

void DBLinkList::bubbleSort(){
}