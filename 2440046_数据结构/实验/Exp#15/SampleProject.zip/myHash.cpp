/*******************************************************************************
* FileName:         myHash.cpp
* Author:           Your_name
* Student Number:   Student_Number
* Date:             2020/05/20 09:24:55
* Version:          v1.0
* Description:      Data Structure Experiment #15
*******************************************************************************/

#include "myHash.h"


MyHash::MyHash(int max_element){

}

MyHash::~MyHash(){

}

void MyHash::setvalue(int key, int value){

}

int MyHash::getvalue(int key){

}