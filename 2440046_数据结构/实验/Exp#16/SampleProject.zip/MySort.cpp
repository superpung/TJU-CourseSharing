/*******************************************************************************
* FileName:         MySort.cpp
* Author:           Your_name
* Student Number:   Student_Number
* Date:             2019/05/27 09:24:55
* Version:          v1.0
* Description:      Data Structure Experiment #16
*******************************************************************************/

#include "MySort.h"

void MySort::bubbleSort(int* arr, int len){
}


void MySort::quickSort(int* arr, int len){

}

void MySort::heapSort(int* arr, int len){

}