/*******************************************************************************
* FileName:         Graph.cpp
* Author:           Your_name
* Student Number:   Student_Number
* Date:             2020/04/22 09:24:55
* Version:          v1.0
* Description:      Data Structure Experiment #11
*******************************************************************************/

#include "Graph.h"

Graph::Graph(int max_v){

}

Graph::~Graph(){

}

void Graph::addedge(int s, int t, int w){

}

int Graph::prim(){

}

int Graph::kruskal(){

}