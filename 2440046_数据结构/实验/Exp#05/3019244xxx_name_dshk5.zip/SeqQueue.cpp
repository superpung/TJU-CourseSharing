#include "SeqQueue.h"



SeqQueue::SeqQueue(){


}
SeqQueue::~SeqQueue(){

}
void SeqQueue::pop_front(){

}
void SeqQueue::push_back(int data){

}
int SeqQueue::front() const{

}