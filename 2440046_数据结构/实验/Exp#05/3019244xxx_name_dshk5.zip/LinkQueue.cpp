#include "LinkQueue.h"

LinkQueue::LinkQueue(){

}

LinkQueue::~LinkQueue(){

}

void LinkQueue::push_back(int data){

}

void LinkQueue::pop_front(){

}


int LinkQueue::front() const{

}