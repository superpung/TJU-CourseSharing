package com.huawei.classroom.student.h52;

import java.util.Set;

public class NumDecompose {
	/**
	 * 将num进行质因数分解，将分解到的质因数放到Set里面返回
	 */
	public Set<Integer> decompose(int num) {
		return null;
		
	}
}
