package com.huawei.classroom.student.h61;

public enum EnumState {
	health,latent,ill_home,ill_hospital,cured,dead ;
}
