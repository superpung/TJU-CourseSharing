package com.huawei.classroom.student.h57;

public class FileTool {

	/*
	 * 统计一个目录下所有文件大小的加和
	 */
	public long recursiveCalcFileSize(String homeDir) {
		return 0;
	}
}
