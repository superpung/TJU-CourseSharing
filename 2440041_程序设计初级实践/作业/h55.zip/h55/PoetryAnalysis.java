package com.huawei.classroom.student.h55;

public class PoetryAnalysis {

	/**
	 * 
	 * @param pathFilename 包含诗歌内容的源文件
	 * @param chars 需要统计的字 以半角分号分割 
	 * 统计  
	 * 
	 */
	public void analysis(String pathFilename,String chars) {
		
	}
}
