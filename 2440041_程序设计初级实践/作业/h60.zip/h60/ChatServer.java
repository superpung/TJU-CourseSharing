package com.huawei.classroom.student.h60;

import java.io.IOException;

public class ChatServer {
	/**
	 * 初始化 ， 根据情况适当抛出异常
	 * @param port
	 * @param passwordFilename 所有用户的用户名 口令
	 */

	public ChatServer (int port, String passwordFilename) throws IOException {
	 
	}
	/**
	 *  根据情况适当抛出异常
	 * 开始监听
	 */
	public void startListen( ) {
		
	}
	 
}
