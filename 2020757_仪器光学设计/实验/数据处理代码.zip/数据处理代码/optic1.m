close all;
% Loading file
filename1 = 'optic1.csv';    
filename2 = 'optic1_MoS2.csv';

opts1 = detectImportOptions(filename1);
opts1.VariableNamingRule = 'preserve';
data1 = readtable(filename1, opts1);
opts2 = detectImportOptions(filename2);
opts2.VariableNamingRule = 'preserve';
data2 = readtable(filename2, opts2);

x1 = data1{:, 'row'};
y1 = data1{:, 'col'};
x2 = data2{:, 'row'};
y2 = data2{:, 'col'};

figure;
subplot(2,1,1);
plot(x1, y1, 'LineWidth', 1);
grid on;
title('Substrate');
xlabel('Wavelength (nm)');
ylabel('Intensity');

subplot(2,1,2);
plot(x2, y2, 'LineWidth', 1);
grid on;
title('Substrate with MoS2 thin film');
xlabel('Wavelength (nm)');
ylabel('Intensity');

% Differential reflectance
figure;
n1 = y1./35367.765;
n2 = y2./35367.765;
%Normalization
n1_norm = n1./max(n1);
n2_norm = n2./max(n2);
R = (n1_norm-n2_norm)./n2_norm;
% x1 = x2
plot(x1, R);
title('Differential Reflectance');
xlabel('Wavelength (nm)');
ylabel('Differential Reflectance');
grid on;
