%% LED本征光谱
filename = '本征光.csv';    
opts = detectImportOptions(filename);
opts.VariableNamingRule = 'preserve';
data = readtable(filename, opts);

x = data{:, 'row'};
y = data{:, 'col'};
figure;
plot(x, y, 'LineWidth', 1);
grid on;
title('LED本征光谱');
xlabel('波长 (nm)');
ylabel('强度');
xlim([400, 800]);

%% 采集点合成光谱
folderPath = 'C:\Users\lym\Desktop\巴斯光年\大三\光学设计\Final\实验数据\实验二';
files = dir(fullfile(folderPath, '*.csv'));
wavelengths = [];  % 用来存储波长
intensities = [];  % 用来存储光强

for i = 1:length(files)
    % 获取文件名
    fileName = fullfile(folderPath, files(i).name);
    
    % 读取Excel表格中的数据，假设数据在第一张工作表中
    data = xlsread(fileName);
    
    % 假设波长数据在第一列，光强数据在第二列
    wavelength = data(:, 1);  % 第一列为波长
    intensity = data(:, 2);   % 第二列为光强
    
    % 查找最大光强及对应的波长
    [maxIntensity, maxIndex] = max(intensity);
    correspondingWavelength = wavelength(maxIndex);
    
    % 将最大光强和对应波长保存下来
    wavelengths = [wavelengths; correspondingWavelength];
    intensities = [intensities; maxIntensity];
end
[wavelengths, idx] = sort(wavelengths);  % idx 是排序后的索引
intensities = intensities(idx);  % 使用排序后的索引对B排序

% 绘制最大光强与波长的曲线
figure;
plot(wavelengths, intensities, '-o', 'LineWidth', 1.5);
xlabel('波长 (nm)');
ylabel('强度');
title('采集点合成光谱');
xlim([400 800]);
grid on;
