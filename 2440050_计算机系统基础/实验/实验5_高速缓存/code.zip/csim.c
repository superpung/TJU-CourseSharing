#include "cachelab.h"
#include <getopt.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <unistd.h>

void printUsage()//打印帮助信息
{
    printf("Usage: ./csim-ref [-hv] -s <num> -E <num> -b <num> -t <file>\n"
            "Options:\n"
            "  -h         Print this help message.\n"
            "  -v         Optional verbose flag.\n"
            "  -s <num>   Number of set index bits.\n"
            "  -E <num>   Number of lines per set.\n"
            "  -b <num>   Number of block offset bits.\n"
            "  -t <file>  Trace file.\n\n"
            "Examples:\n"
            "  linux>  ./csim-ref -s 4 -E 1 -b 4 -t traces/yi.trace\n"
            "  linux>  ./csim-ref -v -s 8 -E 2 -b 4 -t traces/yi.trace\n");
    // -h：显示使用帮助
    // -v：输出跟踪信息
    // -s <s> 内存地址中组序号所占的位宽（高速缓存的组数 $S=2^s$）
    // -E <E> 相关性（高速缓存每组的缓存块个数）
    // -b <b> 内存地址中偏移量所占的位宽（缓存块大小 $B=2^b$）
    // -t <tracefile> valgrind生成的跟踪文件的名称
}

//标志位，对应了六种输入参数
int h;//显示使用帮助
int v;//输出跟踪信息
int s;//S = 2^s 
int S;//S行数
int E;//E列数
int b;//B = 2^b
//C = S*E*B 总大小


int hit_count, miss_count, eviction_count;//计数器
// 命中总次数，未命中总次数，块替换总次数

char t[1000];

typedef struct{//高速缓存块，结构体
    int valid_bit;//合法位
    int tag;
    int stamp;
}cache_block, *cache_line, **cache;
cache CACHE = NULL;//全局变量，高速缓存

void init_cache()//初始化
{
    //先申请S行
    CACHE = (cache) malloc( sizeof(cache_line) * S);
    for(int i=0;i<S;i++)//遍历每一行
    {
        //对每一行申请E列
        CACHE[i] = (cache_line) malloc(sizeof(cache_block)*E);
        for(int j=0;j<E;j++)//遍历每一列
        {
            CACHE[i][j].valid_bit=0;
            CACHE[i][j].tag=0;
            CACHE[i][j].stamp=-1;
        }
    }
}

void update(unsigned int address)
{
    int setindex_add=(address>>b)&((-1U)>>(64-s));
    int tag_add=address>>(b+s);
    int max_stamp=INT_MIN;
    int max_stamp_index=-1;
    for(int i=0;i<E;i++)
    {
        if(CACHE[setindex_add][i].tag==tag_add)
        {
            CACHE[setindex_add][i].stamp=0;
            hit_count++;
            return ;
        }
    }
    for(int i=0;i<E;i++)
    {
        if(CACHE[setindex_add][i].valid_bit==0)
        {
            CACHE[setindex_add][i].valid_bit=1;
            CACHE[setindex_add][i].tag=tag_add;
            CACHE[setindex_add][i].stamp=0;
            miss_count++;
            return ;
        }
    }
    eviction_count++;miss_count++;
    for(int i=0;i<E;i++)
    {
        if(CACHE[setindex_add][i].stamp>max_stamp)
        {
            max_stamp=CACHE[setindex_add][i].stamp;
            max_stamp_index=i;
        }
    }
    CACHE[setindex_add][max_stamp_index].tag=tag_add;
    CACHE[setindex_add][max_stamp_index].stamp=0;
    return ;
}

void update_stamp()
{
    for(int i=0;i<S;i++)
        for(int j=0;j<E;j++)
            if(CACHE[i][j].valid_bit==1)
                CACHE[i][j].stamp++;
}

void parse_trace()
{
    FILE* fp=fopen(t,"r");
    if(fp==NULL)
    {
        printf("open error");
        exit(-1);
    }
    char operation;
    unsigned int address;
    int size;
    while(fscanf(fp," %c %xu,%d\n",&operation,&address,&size)>0)
    {
        switch(operation)
        {
            case 'I':continue;
            case 'L':{update(address);break;}
            case 'M':{update(address);update(address);break;}
            case 'S':{update(address);break;}
        }
        update_stamp();
    }
    fclose(fp);
    for(int i=0;i<S;i++)
        free(CACHE[i]);
    free(CACHE);
}



int main(int argc, char* argv[])
{
    //默认不输出帮助信息
    h = 0;
    //默认不输出跟踪信息
    v = 0;
    //数据初始化
    hit_count = 0;
    miss_count = 0;
    eviction_count = 0;
    //具体设置
    int opt;
    while( (opt = getopt(argc,argv,"hvs:E:b:t:")) != -1)
    {
        switch(opt)
        {
            case 'h':{h=1;printUsage();break;}
            case 'v':{v=1;printUsage();break;}
            case 's':{s=atoi(optarg);break;}
            case 'E':{E=atoi(optarg);break;}
            case 'b':{b=atoi(optarg);break;}
            case 't':{strcpy(t,optarg);break;}
            default:{printUsage();break;}
        }
    }

    if(s<=0||E<=0||b<=0||t==NULL)return -1;//数据不合法
    
    S = 1<<s;

    FILE* fp=fopen(t,"r");
    if(fp==NULL)
    {
        printf("open error");
        exit(-1);
    }
    init_cache();
    parse_trace();
    printSummary(hit_count, miss_count, eviction_count);
    return 0;
}
