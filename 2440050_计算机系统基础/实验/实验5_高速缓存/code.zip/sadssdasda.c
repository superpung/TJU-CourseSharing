#include "cachelab.h"
#include <getopt.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <unistd.h>

int h = 0,v = 0,d = 0;
int s,S,E,b,B;
char t[100];//tracefile
#define INVALID -1

void input_options(int argc, char** argv){
    // Usage: ./csim-ref [-hv] -s <s> -E <E> -b <b> -t <tracefile>
    // -h：显示使用帮助
    // -v：输出跟踪信息
    // -s <s> 内存地址中组序号所占的位宽（高速缓存的组数 $S=2^s$）
    // -E <E> 相关性（高速缓存每组的缓存块个数）
    // -b <b> 内存地址中偏移量所占的位宽（缓存块大小 $B=2^b$）
    // -t <tracefile> valgrind生成的跟踪文件的名称
    int opt;
    while( (opt = getopt(argc,argv,"hvs:E:b:t:")) != -1)
    {
        switch(opt)
        {
            case 'h':
                h = 1;break;
            case 'v':
                v = 1;break;
            case 's':
                s = atoi(optarg);
                
                break;
            case 'E':
                E = atoi(optarg);break;
            case 'b':
                b = atoi(optarg);break;
            case 't':
                strcpy(t,optarg);break;
            default:
                d = 1;break;
        }
    }
    if(s<=0||E<=0||b<=0||t==NULL)exit(-1);//数据不合法
    S = 1 << s;
    B = 1 << b;
    // extern char* optarg;
    // extern int optind;
    // extern int opterr;
    // extern int optopt;
    if(h||d)
        fprintf(stdout, "Usage: ./csim-ref [-hv] -s <num> -E <num> -b <num> -t <file>\n"
                        "Options:\n"
                        "  -h         Print this help message.\n"
                        "  -v         Optional verbose flag.\n"
                        "  -s <num>   Number of set index bits.\n"
                        "  -E <num>   Number of lines per set.\n"
                        "  -b <num>   Number of block offset bits.\n"
                        "  -t <file>  Trace file.\n\n"
                        "Examples:\n"
                        "  linux>  ./csim-ref -s 4 -E 1 -b 4 -t traces/yi.trace\n"
                        "  linux>  ./csim-ref -v -s 8 -E 2 -b 4 -t traces/yi.trace\n");
    return;
}

int hit_count = 0, miss_count = 0, eviction_count = 0;//计数器
// 命中总次数，未命中总次数，块替换总次数

//高速缓存块
typedef struct{
    int valid_bit;
    int tag;
    int age;
}cache_block, *cache_set, **cache;
cache CACHE = NULL;//全局变量，高速缓存

void cache_update(unsigned int address){
    // tag标记(t位) + 组索引(s位) + 块偏移(b位)
    int new_set = (address>>b)&((-1U)>>(64-s));
    int new_tag = (address>>(b+s));
    //命中
    for(int i = 0;i < E;i++)
    {
        if(CACHE[new_set][i].tag == new_tag)
        {
            CACHE[new_set][i].age = 0;
            hit_count++;//命中数++
            return;
        }
    }
    //未命中
    for(int i = 0;i < E;i++)
    {
        if(CACHE[new_set][i].valid_bit == 0)//在new_set的对应组中有空行
        {
            CACHE[new_set][i].valid_bit = 1;
            CACHE[new_set][i].tag = new_tag;
            CACHE[new_set][i].age = 0;
            miss_count++;//未命中数++
            return;
        }
    }
    //冲突不命中，LRU算法
    int max_age = 0;
    int max_age_line = -1;
    for(int i = 0;i < E;i++)
    {
        if(CACHE[new_set][i].age > max_age)
        {
            max_age = CACHE[new_set][i].age;
            max_age_line = i;
        }
    }
    eviction_count++;//未命中数++
    miss_count++;//未命中数++
    // CACHE[new_set][max_age_line].valid_bit = 1;
    CACHE[new_set][max_age_line].tag = new_tag;
    CACHE[new_set][max_age_line].age = 0;
    return;
}

void aging(){//LRU老化算法
    for(int i=0;i<S;i++){
        for(int j=0;j<E;j++){
            if(CACHE[i][j].valid_bit == 1){
                CACHE[i][j].age++;
            }
        }
    }
    return;
}

void init_cache()//初始化
{
    //先申请S行
    CACHE = (cache) malloc( sizeof(cache_set) * S);
    for(int i=0;i<S;i++)//遍历每一行
    {
        //对每一行申请E列
        CACHE[i] = (cache_set) malloc(sizeof(cache_block)*E);
        for(int j=0;j<E;j++)//遍历每一列
        {
            CACHE[i][j].valid_bit = 0;
            CACHE[i][j].tag = INVALID;
            CACHE[i][j].age = INVALID;
        }
    }
    return;
}

void free_cache(){
    for(int i=0;i<S;i++)
        free(CACHE[i]);
    free(CACHE);
    return;
}

void parse_tracefile()
{
    FILE* fp = fopen(t,"r");
    if(fp == NULL)
    {
        fprintf(stderr, "open error\n");
        exit(-1);
    }
    // [空格]操作  地址，长度
    //  L 10,1
    //  S 18,1
    //  M 12,1
    char operation;
    unsigned int address;
    int offset;//忽略该字段
    while(fscanf(fp, " %c %xu,%d\n",&operation,&address,&offset) > 0 )
    {
        switch(operation)
        {
            case 'I':
                // break;
                continue;//完全忽略，不进行老化
            case 'L':
                cache_update(address);
                break;
            case 'M':
                cache_update(address);
                cache_update(address);
                break;
            case 'S':
                cache_update(address);
                break;
        }
        aging();
    }
    fclose(fp);
}



int main(int argc, char** argv)
{
    input_options(argc,argv);
    init_cache();
    parse_tracefile();
    printSummary(hit_count, miss_count, eviction_count);
    return 0;
}
