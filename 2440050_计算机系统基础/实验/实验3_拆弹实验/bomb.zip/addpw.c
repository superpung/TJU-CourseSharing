#include <stdio.h>
int main()
{
    FILE *p = fopen("pw.txt","w");
    if(p)
    {
        fputs("Border relations with Canada have never been better.\n\r", p);
        fputs("1 2 4 8 16 32\n\r", p);
        fputs("7 327\n", p);
        fputs("7 0\n", p);
        fputs("IONEFG\n\r", p);
        fputs("4 3 2 1 6 5\n\r", p);
        fclose(p);
    }
    return 0;
}
