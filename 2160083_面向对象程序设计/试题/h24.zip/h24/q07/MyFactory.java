package com.huawei.classroom.student.h24.q07;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public interface MyFactory {

	public static <T> T createClass(String string) {
		return null;
	}}
