package com.huawei.classroom.student.h24.q07;

/**
 * @author  //{41ff58111399038a4e1ecdae236512e2}       
 * 
 * 本题目7分，共计10道题,本题难度系数3星
 */
public class Test {
	
	public Test() {
		// TODO Auto-generated constructor stub //{42e860116490b0562381e01080e50371}
	}

	public static void main(String[] args) {
		// TODO Auto-generated constructor stub //{47235b48a34dd5a3e0230ed65926b0a8}
		//在本包下增加合适的类或者接口，使得如下代码编译通过并正确运行
		//本题目所有答案必须放在和本Test同级的目录下,除了JDK1.8自带的包以外，不允许引用第三方的包
		//本题目下的程序不要引用其他考题的类，否则会导致编译失败
		//除非特殊说明，否则必须是无状态类，也就是new 一个实例可以使用多次。
		//最后上交的时候，不要在程序里面调用System.out 或者System.error等会向控制台输出字符的方法 。
		//其他要求和平时作业一样。
		//Test类在批改试卷的时候会删除掉

		
		/**
		 * 根据下面的代码，自己定义A、B、C 三个类（或者接口），定义他们之间的关系
		 * 并完成 MyFactory.createClass(String type)方法 
		 * 该方法的作用是 根据输入的type构造实例, type的取值有可能为"A"或"B"或"C",不会有其他的取值
		 * 使得下面的测试用例能够通过
		 */
		A a =(A)MyFactory.createClass("A");
		System.out.println("case1 ok!");
		
		B b =(B)MyFactory.createClass("B");
		System.out.println("case2 ok!");
		
		C c =(C)MyFactory.createClass("C");
		System.out.println("case3 ok!");
		
		if(a instanceof D) {
			System.out.println("case4 ok!");
		}
		
		if(a instanceof B) {
			System.out.println("case5 ok!");
		}
		
		if(c instanceof B) {
			System.out.println("case6 ok!");
		}
		
		if(!(c instanceof D)) {
			System.out.println("case7 ok!");
		}
		
		
		
		
		
	}
}
//TODO Auto-generated constructor stub //{476cbd174e1f6fc7dcfe338c06b6a8a2}