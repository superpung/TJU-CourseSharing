package com.huawei.classroom.student.h24.q01;


public class Rectangular {
	
	public Rectangular(int i, int j, int k) {
		
	}

}
