package com.huawei.classroom.student.h24.q01;

import java.util.HashSet;
import java.util.Set;
/*
 * 12分 ,共计10道题,本题难度系数2星
 */
public class Test {
	public Test() {
		// TODO Auto-generated constructor stub 
	}

	public static void main(String[] args) {
		// TODO Auto-generated constructor stub 
		//在本包下增加合适的类或者接口，使得如下代码编译通过并正确运行
		//本题目所有答案必须放在和本Test同级的目录下,除了JDK1.8自带的包以外，不允许引用第三方的包
		//本题目下的程序不要引用其他考题的类，否则会导致编译失败
		//除非特殊说明，否则必须是无状态类，也就是new 一个实例可以使用多次。
		//最后上交的时候，不要在程序里面调用System.out 或者System.error等会向控制台输出字符的方法 。
		//其他要求和平时作业一样。
		//Test类在批改试卷的时候会删除掉


		 
		//完成长方体Rectangular类，构造函数中的三个整数分别为长、宽、高 ，在Rectangular增加适当的方法，
		//使得将这个Rectangular对象放到一个 HashSet中以后，如果两个长方体如果边长相等，则视为同一个长方体 
		//例如下面6个长方体（1,2,3）和（1,3,2）和（2,1,3）和（2,3,1）和（3,1,2）和（3,2,1）视为同一个长方体
		Set<Rectangular> set=new HashSet<Rectangular>();
		//构造长方体Rectangular类，new Rectangular(1,2,3) 三个边长分别为1,2,3
		set.add(new Rectangular(1,2,3));
		//边长为1、2、3的长方体和边长为3、2、1的长方体实际上形状是一样的，所以视为同一个对象
		set.add(new Rectangular(3,2,1));
		//这两个长方体放到set里面以后，set.size()应该为1
		System.out.println(set.size()+"*");
		if(set.size() ==1) {
			//测试用例通过
			System.out.println(" case 1 pass");
		}
		//边长为2、3、1的长方体和前述两个显然形状也是一样的
		set.add(new Rectangular(2,3,1));
		System.out.println(set.size()+"*");
		if(set.size() ==1) {
			//测试用例通过
			System.out.println(" case 2 pass");
		}
		
		//边长为2,1,1的长方体形状和前三个不一样，视为不同的长方体
		set.add(new Rectangular(2,1,1));
		System.out.println(set.size()+"*");
		if(set.size() ==2) {
			//测试用例通过
			System.out.println(" case 3 pass");
		}
	
	}

}
