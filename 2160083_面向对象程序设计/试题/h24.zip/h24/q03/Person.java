package com.huawei.classroom.student.h24.q03;

/**
 * @author //{0cb94e6b6d213186349a1da801887de9}
 * 
 */
public interface Person {
	// TODO Auto-generated constructor stub //{0ea786f8bbe6612f359c56d73bf2dbd6}
	public String getName();
}
// TODO Auto-generated constructor stub //{1092ec444a4dbb4c361d3d91aaf5074e}