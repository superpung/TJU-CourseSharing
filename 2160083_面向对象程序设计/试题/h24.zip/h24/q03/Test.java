package com.huawei.classroom.student.h24.q03;

/**
 * @author  //{132f8d9062e82f96071cf1f8b59cc0da}       
 * 
 * 本题目12分,共计10道题,本题难度系数1星
 */
public class Test {

	public Test() {
		// TODO Auto-generated constructor stub //{1381e5548c8545a5b9aeb2fae3110231}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub //{148c17081c25535be97e921172228b9a}
		//在本包下增加合适的类或者接口，使得如下代码编译通过并正确运行
		//本题目所有答案必须放在和本Test同级的目录下,除了JDK1.8自带的包以外，不允许引用第三方的包
		//本题目下的程序不要引用其他考题的类，否则会导致编译失败
		//除非特殊说明，否则必须是无状态类，也就是new 一个实例可以使用多次。
		//最后上交的时候，不要在程序里面调用System.out 或者System.error等会向控制台输出字符的方法 。
		//其他要求和平时作业一样。
		//Test类在批改试卷的时候会删除掉

		Person p=new Teacher("tom");
		if("tom".equals(p.getName())){
			System.out.println("case 1 pass!");
		}
		Person p2=new Teacher( );
		if("unname".equals(p2.getName())){
			System.out.println("case 2 pass!");
		}
	}

}
//TODO Auto-generated constructor stub //{15361124d192d2b81cbae49b8e40e2e1} 