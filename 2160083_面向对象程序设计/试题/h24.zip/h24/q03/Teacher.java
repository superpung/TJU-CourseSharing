package com.huawei.classroom.student.h24.q03;

public class Teacher implements Person {

	String name;
	
	public Teacher(String string) {
		// TODO Auto-generated constructor stub
		
	}

	public Teacher() {
		// TODO Auto-generated constructor stub
		
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		
		return name;
	}

}
