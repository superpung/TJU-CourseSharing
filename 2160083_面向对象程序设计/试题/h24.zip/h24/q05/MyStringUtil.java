package com.huawei.classroom.student.h24.q05;

import java.util.ArrayList;

public class MyStringUtil {

	public MyStringUtil() {
		// TODO Auto-generated constructor stub
	}
	
	/**
	 * 将一个StringBuffer中的字符串反转顺序,并将反转(逆序)的StringBuffer放在原StringBuffer中
	 * @param buf
	 */
	public void reverseStr(StringBuffer buf) {
		
	}
	
	/**
	 * 将str中的字符 ch 移除掉，然后通过函数返回
	 * @param str
	 * @return
	 */
	public String removeChars(String str,char ch) {
		
	}

}
