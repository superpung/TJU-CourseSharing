package com.huawei.classroom.student.h24.q09;

import java.util.HashMap;
import java.util.Map;

/**
 * @author 
 *
 */
public class MyRelation {
	
	// 
	
	// TODO Auto-generated constructor stub 
	public MyRelation() {
		// TODO Auto-generated constructor stub 
	}
	
	/**
	 * 根据lines中的信息，算出srcName的曾祖母（父亲的父亲的母亲），如果不存在则返回 "UNEXIST"
	 * @param lines  是一个字符串数组，存放了若干家族信息，每个字符串用 ","分割为三部分，分别是  "父亲姓名,母亲姓名,孩子姓名"
	 * @param srcName 
	 * @return
	 */
	public String getGreatGrandMother(String[] lines, String srcName) {
		// 
		
	}
	
	/**
	 * 根据lines中的信息，算出srcName的曾祖母（父亲的父亲的父亲），如果不存在则返回 "UNEXIST"
	 * @param lines  是一个字符串数组，存放了若干家族信息，每个字符串用 ","分割为三部分，分别是  "父亲姓名,母亲姓名,孩子姓名"
	 * @param srcName 
	 * @return
	 */

	public String getGreatGrandFather(String[] lines, String srcName) {
		// 
	}
	
	
	/**
	 * 根据lines中的信息，算出srcName的奶奶（父亲的母亲），如果不存在则返回 "UNEXIST"
	 * @param lines  是一个字符串数组，存放了若干家族信息，每个字符串用 ","分割为三部分，分别是  "父亲姓名,母亲姓名,孩子姓名"
	 * @param srcName 
	 * @return
	 */
	
	public String getGrandMother(String[] lines, String srcName) {
		// 
	}

	
	/**
	 * 根据lines中的信息，算出srcName的爷爷（父亲的父亲），如果不存在则返回 "UNEXIST"
	 * @param lines  是一个字符串数组，存放了若干家族信息，每个字符串用 ","分割为三部分，分别是  "父亲姓名,母亲姓名,孩子姓名"
	 * @param srcName 
	 * @return
	 */
	public String getGrandFather(String[] lines, String srcName) {
		
		// 
	}
	
	
	// 
}
// TODO Auto-generated constructor stub 