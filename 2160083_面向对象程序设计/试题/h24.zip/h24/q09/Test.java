package com.huawei.classroom.student.h24.q09;

import java.util.ArrayList;
import java.util.List;

/**
 * @author  
 * 
 * 本题目7分，共计10道题,本题难度系数4星
 */
public class Test {

	public Test() {
		// TODO Auto-generated constructor stub 
	}

	public static void main(String[] args) {
		// TODO Auto-generated constructor stub 
		//在本包下增加合适的类或者接口，使得如下代码编译通过并正确运行
		//本题目所有答案必须放在和本Test同级的目录下,除了JDK1.8自带的包以外，不允许引用第三方的包
		//本题目下的程序不要引用其他考题的类，否则会导致编译失败
		//除非特殊说明，否则必须是无状态类，也就是new 一个实例可以使用多次。
		//最后上交的时候，不要在程序里面调用System.out 或者System.error等会向控制台输出字符的方法 。
		//其他要求和平时作业一样。
		//Test类在批改试卷的时候会删除掉

		
		String[] data= {"谢霆锋,张柏芝,谢振轩",
				"谢霆锋,张柏芝,谢振南",
				"谢贤,李敏仪,谢霆锋",
				"谢贤父亲,谢贤母亲,谢贤",				
				"李敏仪父亲,李敏仪母亲,李敏仪",
				"黄有龙,赵薇,黄新"};
		//data是一个字符串数组，存放了若干家族信息
		//每个字符串用 ","分割为三部分，分别是  "父亲姓名,母亲姓名,孩子姓名"
		//一对夫妻如果有2个孩子，占用数组中两个元素，例如：  "父亲姓名,母亲姓名,孩子1"  , "父亲姓名,母亲姓名,孩子2"
		//存在同父异母的情况（一个男人分别同两个女人结婚，剩下几个母亲不相同的孩子;
		//不考虑重名的情况
		
		//写一个方法，根据data给的数据能够推导出某个人如下亲属关系：
		//1 爷爷（父亲的父亲）  getGrandFather
		//2 奶奶（父亲的母亲） getGrandMother
		//3 曾祖父（父亲的父的父亲) getGrandFather
		//4 曾祖母（父亲的父的母亲） getGreatGrandMother
		//如果根据上述数据无法推导出某人的亲属则返回 "UNEXIST"
		
		 MyRelation q=new MyRelation();
		 if("谢贤".equals(q.getGrandFather(data,"谢振轩"))) {
			 System.out.println("case 1 ok");
		 }
		 
		 if("谢贤父亲".equals(q.getGrandFather(data,"谢霆锋"))) {
			 System.out.println("case 2 ok");
		 }
		 
		 if("李敏仪".equals(q.getGrandMother(data,"谢振南"))) {
			 System.out.println("case 3 ok");
		 }
		 
		 if("谢贤父亲".equals(q.getGreatGrandFather(data,"谢振轩"))) {
			 System.out.println("case 4 ok");
		 }
		 
		 if("谢贤母亲".equals(q.getGreatGrandMother(data,"谢振轩"))) {
			 System.out.println("case 5 ok");
		 }
		 
		 if("UNEXIST".equals(q.getGrandMother(data,"黄新"))) {
			 System.out.println("case 6 ok");
		 }

	}
}
// TODO Auto-generated constructor stub 