package com.huawei.classroom.student.h24.q08;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;

/**
 * TODO Auto-generated constructor stub //{47d3ce4097b6726284728e921f6c301b}
 * 完成本类中没有完成的方法，可以增加新的方法，甚至新的类，但是不能改变原有方法的声明
 * 
 * @author
 *
 */
public class MyNameUtil {

	/**
	 * 根据天津大学本届所有学生名单，返回哪个姓氏的学生最多
	 * 
	 * @param names 存放了本届所有学生名字
	 * @return 请返回哪个姓氏的学生最多
	 * 不考虑少数民族和外国人命名方法 ，不会出现top1姓并列的情况，但是需要考虑到中国常见的80个复姓情况，
	 * 这80个复姓如下：
	 * 欧阳","太史","端木","上官","司马","东方","独孤","南宫","万俟","闻人","夏侯","诸葛","尉迟","公羊","赫连","澹台","
	 * 皇甫","宗政","濮阳","公冶","太叔","申屠","公孙","慕容","仲孙","钟离","长孙","宇文","司徒","鲜于","司空","闾丘","
	 * 子车","亓官","司寇","巫马","公西","颛孙","壤驷","公良","漆雕","乐正","宰父","谷梁","拓跋","夹谷","轩辕","令狐","
	 * 段干","百里","呼延","东郭","南门","羊舌","微生","公户","公玉","公仪","梁丘","公仲","公上","公门","公山","公坚","
	 * 左丘","公伯","西门","公祖","第五","公乘","贯丘","公皙","南荣","东里","东宫","仲长","子书","子桑","即墨","达奚","
	 */
	String[] fuxing = {
			"欧阳","太史","端木","上官","司马","东方","独孤","南宫","万俟","闻人","夏侯","诸葛","尉迟","公羊","赫连","澹台",
			"皇甫","宗政","濮阳","公冶","太叔","申屠","公孙","慕容","仲孙","钟离","长孙","宇文","司徒","鲜于","司空","闾丘",
			"子车","亓官","司寇","巫马","公西","颛孙","壤驷","公良","漆雕","乐正","宰父","谷梁","拓跋","夹谷","轩辕","令狐",
			"段干","百里","呼延","东郭","南门","羊舌","微生","公户","公玉","公仪","梁丘","公仲","公上","公门","公山","公坚",
			"左丘","公伯","西门","公祖","第五","公乘","贯丘","公皙","南荣","东里","东宫","仲长","子书","子桑","即墨","达奚"
	};
	List<String> fx = new ArrayList<>();
	
	public MyNameUtil() {
		for(String fname:fuxing) {
			fx.add(fname);
		}
	}
	
	public String getTop1Surname(List<String> names) {
		HashMap<String, Integer> hashMap = new HashMap<>();
		Iterator<String> it= names.iterator();
		while(it.hasNext()) {
			String name = it.next();
			String finame = name.substring(0, 2);
			if(!fx.contains(finame)) {
				finame = finame.substring(0,1);
			}
			//System.out.print(finame);
			hashMap.put(finame, hashMap.getOrDefault(finame,0) + 1);
		}
		String top= null;
		int max= 0;
		for(Entry<String, Integer> x: hashMap.entrySet()) {
			//System.out.println(x.getKey());
			if(x.getValue()>max) {
				//System.out.println(x.getKey());
				top= x.getKey();
				max= x.getValue();
			}
		}
		//System.out.printf(top);
		return top;
	}
	
	//
}
