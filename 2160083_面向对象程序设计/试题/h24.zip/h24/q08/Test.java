package com.huawei.classroom.student.h24.q08;

import java.util.ArrayList;
import java.util.List;

/**
 * @author //{4a77fadcf213686d7956dab6ae741a5f}
 * 
 *  本题目7分，共计10道题 难度系数3星
 */
public class Test {

	public static void main(String[] args) {
		//在本包下增加合适的类或者接口，使得如下代码编译通过并正确运行
		//本题目所有答案必须放在和本Test同级的目录下,除了JDK1.8自带的包以外，不允许引用第三方的包
		//本题目下的程序不要引用其他考题的类，否则会导致编译失败
		//除非特殊说明，否则必须是无状态类，也就是new 一个实例可以使用多次。
		//最后上交的时候，不要在程序里面调用System.out 或者System.error等会向控制台输出字符的方法 。
		//其他要求和平时作业一样。
		//Test类在批改试卷的时候会删除掉

		
		MyNameUtil myutil = new MyNameUtil();
		List<String> allNames=new ArrayList<String>();
		allNames.add("郭靖");
		allNames.add("杨康");
		allNames.add("黄药师");
		allNames.add("黄蓉");				
		//根据天津大学本届所有学生名单，返回哪个姓氏的学生最多，具体要求见MyNameUtil.getTop1Surname 方法说明
		//需要考虑复姓的情况，需要考虑的复姓见MyNameUtil.getTop1Surname 方法说明
		if (myutil.getTop1Surname(allNames).equals("黄")) {
			System.out.println("case 1 pass!");
		}
		allNames.add("欧阳锋");
		allNames.add("欧阳克");
		allNames.add("欧阳锋");
		if (myutil.getTop1Surname(allNames).equals("欧阳")) {
			System.out.println("case 2 pass!");
		}

	}

}
