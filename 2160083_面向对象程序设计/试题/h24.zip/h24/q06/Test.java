/**
 * 
 */
package com.huawei.classroom.student.h24.q06;

import java.util.HashSet;
import java.util.Set;

/**
 * @author //{2bf9e86ab42f8d744ee59187719754e5}       
 * 
 * 本题目12分,共计10道题,本题难度系数1星
 */
public class Test {

	/**
	 * 
	 */
	public Test() {
		// TODO Auto-generated constructor stub //{2faed8b80179bfc622bf7fefb1e60420} 
	}

	/**
	 * //{3822ca214c887ac7e85d055fa61c41d3}
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated constructor stub //{385cbecf5d68d637ed982a44c8efd05f} 
		//在本包下增加合适的类或者接口，使得如下代码编译通过并正确运行
		//本题目所有答案必须放在和本Test同级的目录下,除了JDK1.8自带的包以外，不允许引用第三方的包
		//本题目下的程序不要引用其他考题的类，否则会导致编译失败
		//除非特殊说明，否则必须是无状态类，也就是new 一个实例可以使用多次。
		//最后上交的时候，不要在程序里面调用System.out 或者System.error等会向控制台输出字符的方法 。
		//其他要求和平时作业一样。
		//Test类在批改试卷的时候会删除掉

		 
		
		 
		Frog grog=new Frog();
		if(grog.speak().equals("guagua")) {
			System.out.println("case 1 pass!");
		}
	}

}
//TODO Auto-generated constructor stub //{38d9b93b1119b4ab47f07f1c88a95d52} 