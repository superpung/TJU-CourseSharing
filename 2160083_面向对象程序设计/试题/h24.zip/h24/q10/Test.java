/**
 * 
 */
package com.huawei.classroom.student.h24.q10;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/**
 * @author  //{63b464a7f862776d8947a617cef919c6}       
 * 
 * 本题目7分，共计10道题,本题难度系数3星
 */
public class Test {
	public Test() { 
		// TODO Auto-generated constructor stub //{63dc695966f497a6490b0ab4f64fe8f4}
	}
	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated constructor stub //{6ad4fffb91970849ec744cc4260d0235}
		//在本包下增加合适的类或者接口，使得如下代码编译通过并正确运行
		//本题目所有答案必须放在和本Test同级的目录下,除了JDK1.8自带的包以外，不允许引用第三方的包
		//本题目下的程序不要引用其他考题的类，否则会导致编译失败
		//除非特殊说明，否则必须是无状态类，也就是new 一个实例可以使用多次。
		//最后上交的时候，不要在程序里面调用System.out 或者System.error等会向控制台输出字符的方法 。
		//其他要求和平时作业一样。
		//Test类在批改试卷的时候会删除掉

		
		MyFileUtil util=new MyFileUtil();
		//查找出一个目录（包括子目录下），文件内容完全相同的文件(但是文件名可能不同），将所有这些重复的文件的文件名（不要包括路径名）放到set中返回
		//所有文件名不会重复，每个文件大小不超过4K，所有文件数量不超过1000个
		//{6bafe44f5d12e2d18439f7312073da52}
		//"此处修改为你可以访问的目录 dir1 已经随考题发在Test同级目录下了 //{6ed3075039fc79930f0b264b077c0317}");
		Set<String> set=util.findDuplicateFileSet("D:/course/course/exam/src/main/java/com/huawei/classroom/student/h24/q09/dir1/");
		Set<String> result=new HashSet<String>();
		result.add("b1.txt");
		result.add("b2.txt");
		result.add("b3.txt");
		result.add("a1.txt");
		//b1.txt和a1.txt内容完全相同,b2.txt和b3.txt内容完全相同，因此都要放到set中返回
		if(result.equals(set)){
			System.out.println("case 1 pass");
		}
	}

}
//TODO Auto-generated method stub 