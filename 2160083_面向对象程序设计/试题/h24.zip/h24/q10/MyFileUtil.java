/**
 * 
 */
package com.huawei.classroom.student.h24.q10;

import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

/**
 * @author 
 *
 */
public class MyFileUtil {

	/**
	 * // TODO Auto-generated constructor stub 
	 * 查找出一个目录（包括子目录下），文件内容完全相同的文件(但是文件名可能不同），将所有这些重复的文件的文件名（不要包括路径名）放到set中返回
	 * 所有文件名不会重复，每个文件大小不超过4K，所有文件数量不超过100个
	 * 
	 * @param home
	 *            根目录
	 * @return 将这些文件的文件名（不要包括路径名）放到set中返回 
	 * @throws Exception 
	 */
	public Set<String> findDuplicateFileSet(String home) throws Exception {
		
	}
	


	
	// 
}
// TODO Auto-generated constructor stub