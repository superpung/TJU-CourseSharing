package com.huawei.classroom.student.h24.q02;

public class Ractangle {
	

}
