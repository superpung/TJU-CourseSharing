package com.huawei.classroom.student.h24.q02;

/**
 * @author  //{061a166074ce205427a59d4eec402e2d}       
 * 
 * 本题目12分,共计10道题,难度系数 2星
 * 
 */
public class Test {
	
	public Test() {
		// TODO Auto-generated constructor stub //{062587841c2d44d6a1330b4b38f75cf5}
	}

	public static void main(String[] args) {
		// TODO Auto-generated constructor stub //{0792092eeb30283ca08e0eb649e403cc}
		//在本包下增加合适的类或者接口，使得如下代码编译通过并正确运行
		//本题目所有答案必须放在和本Test同级的目录下,除了JDK1.8自带的包以外，不允许引用第三方的包
		//本题目下的程序不要引用其他考题的类，否则会导致编译失败
		//除非特殊说明，否则必须是无状态类，也就是new 一个实例可以使用多次。
		//最后上交的时候，不要在程序里面调用System.out 或者System.error等会向控制台输出字符的方法 。
		//其他要求和平时作业一样。
		//Test类在批改试卷的时候会删除掉

		
		int width=10;
		int height=5;
		//构造一个长方形，宽=10，高=5 
		Ractangle shape=new Ractangle(width,height);
	
		//getArea返回长方形面积,宽=10，高=5，所以面积=50
		if(Math.abs(50-shape.getArea())<0.1) {
			System.out.println("case 1 ok");			
		}
		
		
		//构造一个没有指定宽高的长方形,边长默认为0，面积默认0
		
		shape=new Ractangle();
		if(Math.abs(0-shape.getArea())<0.1) {
			System.out.println("case 2 ok");			
		}
		
		
		 
	}
}
//TODO Auto-generated constructor stub //{0b6a61e41ae89299908f3a6bafa4b929}