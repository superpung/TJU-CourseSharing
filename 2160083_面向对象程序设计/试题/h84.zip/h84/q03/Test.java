package com.huawei.classroom.student.h84.q03;
/**
 * @author //{2cd528572a9fe8302f602e0ff0985b79}
 * 
 *  本题目15分,共计8道题,难度系数2星
 */
public class Test {
	// TODO Auto-generated constructor stub //{2d17862d8b41dfdd94ec05fb9da42817}
	public static void main(String[] args) {
		// TODO Auto-generated constructor stub //{2e2cfe88184a252168684ae760332f92}
		
		//在本包下增加合适的类或者接口，使得如下代码编译通过并正确运行
		//本题目所有答案必须放在和本Test同级的目录下,除了JDK1.8自带的包以外，不允许引用第三方的包
		//本题目下的程序【不要】引用【其他考题】或者【作业的类】（例如不能 import 原来作业的类），否则会导致编译失败
		//程序写好以后，务必检查一下每个题目是不是仅仅依赖本题目的类+JDK1.8自带的包就可以运行，否则会导致编译失败
		//除非特殊说明，否则必须是无状态类，也就是new 一个实例可以使用多次。
		//最后上交的时候，不要在程序里面调用System.out 或者System.error等会向控制台输出字符的方法 。
		//其他要求和平时作业一样。
		//Test类在批改试卷的时候会删除掉
 
		
		MyWordUtil h = new MyWordUtil();
		//完成MyWordUtil.isAlphabets(String str)方法， 判断一个字符串是否仅仅是是由a-zA-Z构成的
		if (h.isAlphabets("abcZ")) {
			System.out.println("case 1 ok !");
		}
		if (!h.isAlphabets("a bc")) {
			System.out.println("case 2 ok !");
		}
	}

}
//TODO Auto-generated constructor stub //{30f074429e122949a4f7d7454f5c41ce}