package com.huawei.classroom.student.h84.q03;

/**
 * TODO Auto-generated constructor stub //{2cb7edb94dda8cc61b432db076c4b33b}
 * 完成本类中没有完成的方法，可以增加新的方法，甚至新的类，但是不能改变原有方法的声明
 * @author  
 *
 */
public class MyWordUtil {

	/**
	 *  判断一个字符串是否仅仅是是由a-zA-Z构成的
	 * @param str  要判断的字符串
	 * @return 如果是返回true，否则false
	 */
	public boolean isAlphabets(String str) {

	}
}
