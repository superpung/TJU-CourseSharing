package com.huawei.classroom.student.h84.q05;

import java.util.HashSet;
import java.util.Set;
/**
 * @author //{5207aa16d37d4aa320e884160daec4c5}
 * 
 *  本题目10分,共计8道题,难度系数3星
 */
//TODO Auto-generated constructor stub //{5365f4080097912320aabe82b3bea4ad}
public class Test {
	// TODO Auto-generated constructor stub //{556c978ad028901e871cd2e801db5fba}
	public static void main(String[] args) {
		//在本包下增加合适的类或者接口，使得如下代码编译通过并正确运行
		//本题目所有答案必须放在和本Test同级的目录下,除了JDK1.8自带的包以外，不允许引用第三方的包
		//本题目下的程序【不要】引用【其他考题】或者【作业的类】（例如不能 import 原来作业的类），否则会导致编译失败
		//程序写好以后，务必检查一下每个题目是不是仅仅依赖本题目的类+JDK1.8自带的包就可以运行，否则会导致编译失败
		//除非特殊说明，否则必须是无状态类，也就是new 一个实例可以使用多次。
		//最后上交的时候，不要在程序里面调用System.out 或者System.error等会向控制台输出字符的方法 。
		//其他要求和平时作业一样。
		//Test类在批改试卷的时候会删除掉

		
		
		// 此目录在考试时候要根据实际情况改写成你自己的目录
		String homedir = "D:/course/course/exam/src/main/java/com/huawei/classroom/student/h84/q06/test_dir/";

		// homedir下面存放了所有同学上交的历次作业（没有子目录），每个作业名字命名规则为 学号_姓名_作业批次.zip
		// 例如 002_wang_h01.zip
		// 学号由数字组成，位数不固定 ，姓名由英文字母组成，长度不固定，作业批次为 h+两位数字构成
		// 上述三个项目由 "_" 分割
		MyHomeworkDetectUtil h = new MyHomeworkDetectUtil();
		// 完成 public Set<String> findCopyStudentList(String homeworkdir)方法，返回所有涉嫌作业抄袭的学生学号
		// 1 所有作业直接存放到 homeworkdir 目录下，没有子目录
		// 2 只有命名规则符合 学号_姓名_hxx.zip 的文件才予以考虑，否则不予考虑
		// 3 所谓抄袭作业就是(a)作业批次相同,(b)学号不同,(c)文件内容完全相同(差一个字节都不算相同)
		// 4 如果某个人第01次作业和另一个人02次作业完全相同，不算抄袭
		// 不会出现某个作业文件，学号相同，但是姓名不同的情况
		// 把所有有抄袭嫌疑学生的学号放到set里面返回
		// **注意测试的时候，测试目录只有读权限，不能随便写文件。
		Set<String> result = h.findCopyStudentList(homedir);
		Set<String> target = new HashSet<String>();
		// 为了方便大家调试，这个作业目录下zip文件其实不是真zip文件，可以直接用记事本打开
		// 001_li_h01.zip内容和002_wang_h01.zip 作业内容、批次完全相同，学号不同，所以定义为抄袭
		// 005_liu_h03.zip内容和006_meng_h03.zip 作业内容、批次完全相同，学号不同，所以定义为抄袭
		// 003_zhao_h01.rar 文件内容虽然和001_li_h01.zip 一样，但是不是zip文件 忽略
		// 003_zhao_h02.zip 内容和 001_li_h01.zip相同，但是不是同一个批次 忽略
		// 注意测试的时候，可能用这个h实例去多次判断不同的目录，所以不能让上次运行结果影响这一次判断
		// 批改的时候可能用这个h再去去判断另外一个目录
		// 例如 result=h.findCopyStudentList(homedir2);

		target.add("001");
		target.add("002");
		target.add("005");
		target.add("006");
		if (target.equals(result)) {
			System.out.println("测试用例1通过");
		}
		
	}
	//TODO Auto-generated constructor stub //{57577582edb62a02c3bd25db82bb0f78}
}
//TODO Auto-generated constructor stub //{577113f651e0adbf7fed950fa982205d}