package com.huawei.classroom.student.h84.q05;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * TODO Auto-generated constructor stub //{41921be510a70a4f3771f4b46976c539}
 * 完成本类中没有完成的方法，可以增加新的方法，甚至新的类，但是不能改变原有方法的声明
 * 
 * @author
 *
 */
public class MyHomeworkDetectUtil {

	/**
	 * homedir下面存放了所有同学上交的历次作业，每个作业名字命名规则为 学号_姓名_作业批次.zip 例如 002_wang_h01.zip
	 * 学号由数字组成，位数不固定 ，姓名由英文字母组成，长度不固定，作业批次为 h+两位数字构成 上述三个项目由 "_" 分割 所有作业直接存放到
	 * homeworkdir 目录下，没有子目录 只有命名规则符合 学号_姓名_hxx.zip 的文件才予以考虑，否则不予考虑
	 * 所谓抄袭作业就是(a)作业批次相同,(b)学号不同,(c)文件内容完全相同(差一个字节都不算相同)
	 * 如果某个人第01次作业和另一个人02次作业完全相同，不算抄袭 不会出现某个作业文件，学号相同，但是姓名不同的情况
	 * 把所有有抄袭嫌疑学生的学号放到set里面返回 注意测试的时候，测试目录只有读权限，不能随便写文件。
	 *  Auto-generated constructor stub //{4701e7aee0b59ad9912e3622c2c79b59}
	 * @param homeworkdir
	 * @return 把所有有抄袭嫌疑学生的学号放到set里面返回
	 * 
	 */
	public Set<String> findCopyStudentList(String homeworkdir) {
		// 
	}

	// 
}
//Auto-generated constructor stub //{4d2253d6a48f42aa8bd2f10978176de9}