package com.huawei.classroom.student.h84.q02;



/**
 * @author  //{25d0fd8a300d6a984fa17779e9d072f6}       
 * 
 * 本题目15分,共计8道题,难度系数1星
 */
public class Test {	
	
	public Test() { 
		// TODO Auto-generated constructor stub //{2a26061e7cc0292a9f6f9edda452067c}
	}

	public static void main(String[] args) {
		// TODO Auto-generated constructor stub //{2a686c93d2da1969461b3b612b55739c}
		//在本包下增加合适的类或者接口，使得如下代码编译通过并正确运行
		//本题目所有答案必须放在和本Test同级的目录下,除了JDK1.8自带的包以外，不允许引用第三方的包
		//本题目下的程序【不要】引用【其他考题】或者【作业的类】（例如不能 import 原来作业的类），否则会导致编译失败
		//程序写好以后，务必检查一下每个题目是不是仅仅依赖本题目的类+JDK1.8自带的包就可以运行，否则会导致编译失败
		//除非特殊说明，否则必须是无状态类，也就是new 一个实例可以使用多次。
		//最后上交的时候，不要在程序里面调用System.out 或者System.error等会向控制台输出字符的方法 。
		//其他要求和平时作业一样。
		//Test类在批改试卷的时候会删除掉

		
		MyRandomUtil h=new MyRandomUtil();
		
		double start =100;
		double end=200;
		//完成MyRandomUtil中的getRand方法，返回一个介于[start,end]之间的double类型随机数(测试集中end肯定大于start)
		double rand=h.getRand(start, end);
		if(start<=rand&&rand<=end) {
			System.out.println("case 1 ok  !");
		}
	 
		
	}
}
//TODO Auto-generated constructor stub //{2b51c30d94ab45a07c234b5ac289a982}