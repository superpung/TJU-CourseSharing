package com.huawei.classroom.student.h84.q02;
import java.util.Random;
/**
 * // TODO Auto-generated constructor stub //{22fede981a58bdd52491704ca234424e}
 * @author Administrator
 *
 */
public class MyRandomUtil {


	/**
	 * 返回一个[start,end]之间的随机数
	 * end>start
	 * @param start
	 * @param end
	 * @return  返回一个[start,end]之间的随机数
	 */
	public double getRand(double start,double end) {
		
	}
	// TODO Auto-generated constructor stub //{23b97e367eab7d9b618f543767d0bc01}
}
//TODO Auto-generated constructor stub //{24bd59ac30d0f05f8c158b41cf3e0b73}