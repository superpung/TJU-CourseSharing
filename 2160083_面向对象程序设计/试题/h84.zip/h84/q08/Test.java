package com.huawei.classroom.student.h84.q08;

/**
 * @author //{761b5516febf61c2640d96261e0a2060}
 * 
 *  本题目10分,共计8道题,难度系数3星
 */
//TODO Auto-generated constructor stub //{794c925ccb37c4c15b33fa77920242f6}
public class Test {
	// TODO Auto-generated constructor stub //{7bf9a37cb4fc49a3184391e70b2247ae}
	public static void main(String[] args) {
		//在本包下增加合适的类或者接口，使得如下代码编译通过并正确运行
		//本题目所有答案必须放在和本Test同级的目录下,除了JDK1.8自带的包以外，不允许引用第三方的包
		//本题目下的程序【不要】引用【其他考题】或者【作业的类】（例如不能 import 原来作业的类），否则会导致编译失败
		//程序写好以后，务必检查一下每个题目是不是仅仅依赖本题目的类+JDK1.8自带的包就可以运行，否则会导致编译失败
		//除非特殊说明，否则必须是无状态类，也就是new 一个实例可以使用多次。
		//最后上交的时候，不要在程序里面调用System.out 或者System.error等会向控制台输出字符的方法 。
		//其他要求和平时作业一样。
		//Test类在批改试卷的时候会删除掉
 
		
		MyClassRoomUtil h = new MyClassRoomUtil();
		// 某教室每天可以安排12节课 分别命名为1,2....11,12。
		// 完成 public boolean detectConflict(int t11, int t12, int t21, int t22)
		// t11,t12是教师甲开始和结束使用的这个教室节数,t21,t22是教师乙开始和结束使用这个教室的节数
		// 请判断这样安排这个教室教室是否会有时间上的冲突，如果有冲突返回true，否则返回false;
		// 教师甲1-2节用这个教室，教师乙3-6用这个教室，这样安排没有冲突
		if (!h.detectConflict(1, 2, 3, 6)) {
			System.out.println("case 1 pass!");
		}
		// 教师甲3-4节用这个教室，教师乙4-5节用这个教室，这样安排有冲突，因为教师甲第4节使用教室，而教师乙也要在第4节使用这个教室
		if (h.detectConflict(3, 4, 4, 5)) {
			System.out.println("case 2 pass!");
		}
	}

}
//TODO Auto-generated constructor stub //{7e4f266d45bd21a1ab191a282b58257b}