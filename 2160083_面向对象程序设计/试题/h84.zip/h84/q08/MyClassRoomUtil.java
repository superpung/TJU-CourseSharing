package com.huawei.classroom.student.h84.q08;

/**
 * TODO Auto-generated constructor stub //{66e123f06f62967f2bedd27d0b1475af}
 * 完成本类中没有完成的方法，可以增加新的方法，甚至新的类，但是不能改变原有方法的声明
 * @author  
 *
 */
//TODO Auto-generated constructor stub //{691dd93f3814dac2fcbbe602a2402c5a}
public class MyClassRoomUtil {
	// TODO Auto-generated constructor stub //{6aec8c793563ceccee4328276028ae17}
	/**
	 * 每个教室每天可以安排12节课 分别命名为1,2....11,12。
	 * t11,t12是教师甲开始和结束使用的节数,t21,t22是教师乙开始和结束使用的节数
	 * 请判断这样安排教室是否会有时间上的冲突，如果有冲突返回true，否则返回false;
	 * @param t11 老师甲开始使用节号
	 * @param t12  老师甲开结束使用节号
	 * @param t21 老师乙开始使用节号
	 * @param t22 老师乙开结束使用节号
	 * @return 如果有冲突返回true，否则 false
	 */
	public boolean detectConflict(int t11, int t12, int t21, int t22) {
		// TODO Auto-generated constructor stub //{7277806d1b75b4da3ed7b49fd7278df3}
		// 
	}
}
//TODO Auto-generated constructor stub //{735a136267ad0791f9ec1b7f87bc6690}