package com.huawei.classroom.student.h84.q01;
import java.util.*;

/**
 * TODO Auto-generated constructor stub //{01d8dfd6a7c62cdc129abf5d2082a424}
 * 完成本类中没有完成的方法，可以增加新的方法，但是不能改变原有方法的声明
 * @author  
 *
 */
public class MyFibonacci {

	// TODO Auto-generated constructor stub //{02dac140d5a07adbfba8d70d00fb6ce6}
	/**
	 * 在数学上，斐波那契数列以如下被以递推的方法定义：
	 * F(0)=0, F(1)=1, F(n)=F(n - 1)+F(n - 2)
	 * 请完成如下方法，该方法能够返回 斐波那契数列 的F(i)个元素值
	 * @param i 
	 * @return
	 */
	public MyFibonacci() {
		
	}
	
	public int getFibonacci(int i) {
		
		
	}
}
//TODO Auto-generated constructor stub //{104ad59aa719dfd94e92fc342216cfdf}