package com.huawei.classroom.student.h84.q01;

/**
 * @author //{1a54bac0d2ea7e29432491269e4ad4d5}
 * 
 *  本题目15分,共计8道题,难度系数1星
 */
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated constructor stub //{1e4918dd88e1e5f889f6c755f2a9a094}
		//在本包下增加合适的类或者接口，使得如下代码编译通过并正确运行
		//本题目所有答案必须放在和本Test同级的目录下,除了JDK1.8自带的包以外，不允许引用第三方的包
		//本题目下的程序【不要】引用【其他考题】或者【作业的类】（例如不能 import 原来作业的类），否则会导致编译失败
		//程序写好以后，务必检查一下每个题目是不是仅仅依赖本题目的类+JDK1.8自带的包就可以运行，否则会导致编译失败
		//除非特殊说明，否则必须是无状态类，也就是new 一个实例可以使用多次。
		//最后上交的时候，不要在程序里面调用System.out 或者System.error等会向控制台输出字符的方法 。
		//其他要求和平时作业一样。
		//Test类在批改试卷的时候会删除掉
 
		
		MyFibonacci h = new MyFibonacci();

		// 在数学上，斐波那契数列以如下被以递推的方法定义：
		// F(0)=0，F(1)=1, F(n)=F(n - 1)+F(n - 2)
		// 完成 MyFibonacci.getFibonacci(int i) 方法，使其能够计算
		// 斐波那契数列的第i项目的值(0<=i<=20)
		

		if (h.getFibonacci(3) == 2) {
			System.out.println("case 1 pass!");
		}
	}

}
//TODO Auto-generated constructor stub //{1e562258ba0025fdfc1f956ffa35ee26}