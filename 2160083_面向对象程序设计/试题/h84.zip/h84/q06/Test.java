package com.huawei.classroom.student.h84.q06;

import java.io.BufferedReader;
import java.io.Closeable;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

/**
 * @author //{58f3c06254dec99cd0d5ab0ceba363c1}
 * 
 *  本题目10分,共计8道题,难度系数3星
 */
public class Test {
	// {comment}

	// 本题目里面的server只能使用1次就行，也就是一旦start了，就不能再start
	public static void main(String[] args) {
		// 完成一个监听服务程序
		// 端口号，测试的时候可能不是这个整数
		int PORT = 9999;
		// 考点2 若干个客户端可以和服务器建立连接
		Socket client = null;
		PrintWriter out = null;
		BufferedReader in = null;

		try {
			// 考点1 ，完成MyServer，并能够通过调用线程的start方法启动
			MyServer server = new MyServer(PORT);
			server.start();
			System.out.println(" case 1 pass!");
			
			// 考点2 若干个客户端可以和服务器建立连接
			client = new Socket("127.0.0.1", PORT);
			out = new java.io.PrintWriter(client.getOutputStream());
			in = new BufferedReader(new InputStreamReader(client.getInputStream()));
			System.out.println(" case 2 pass!");
			
			String send = "abc";
			// 发给 服务器端，测试的时候可能是其他的字符串（英文+数字，没有汉字）
			out.write(send + "\r\n");
			out.flush();
			
			// 考点3，刚才 send给服务器的文本，服务器要原封不动返回
			String receive = in.readLine();
			if (send.equals(receive)) {
				System.out.println(" case 3 pass!");
			} 

			// 考点4，再次给服务器发消息（测试的时候可能发n次消息） ，服务器要原封不动返回
			send = "123";
			// 发给 服务器端
			out.write(send + "\r\n");
			out.flush();
			receive = in.readLine();
			if (send.equals(receive)) {
				System.out.println(" case 4 pass!");
			} 
			
			// 考点5， 在server中增加terminate方法， server结束监听。
			server.terminate();
			System.out.println(" case 5 pass!");

		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		} finally {
			close(in);
			close(out);
			close(client);
		}
		// TODO Auto-generated constructor stub //{5a719621b9307cadd30b77f3c04e3f8d}
	}

	// TODO Auto-generated constructor stub //{5bf338533964eee19630a5594c36b5d2}
	// 学生答卷的时候，不能依赖TEST里面的这个方法，测试的时候TEST类会被删掉
	private static void close(Closeable io) {
		if (io != null) {
			try {
				io.close();
			} catch (Exception e) {
				System.out.println(e.getMessage());
				e.printStackTrace();

			}
		}
	}
}
// TODO Auto-generated constructor stub //{5c6c3b7a584841af152e3198e40b8aa9}