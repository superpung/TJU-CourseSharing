package com.huawei.classroom.student.h84.q06;

public class MyServer extends Thread{
	
	public void run() {
	
		
	}
	

}
