/**
 * @author  //{314603cf8507d25ad84cfc8805464bcb}       
 * 
 * 本题目10分，共计8道题
 * 难度系数1星
 */
package com.huawei.classroom.student.h84.q04;

/**
 * @author  //{3235f38aa5775a6d2fb3d2c8773e8863}       
 * 
 * 本题目15分,共计8道题,难度系数1星
 */
//TODO Auto-generated constructor stub //{36a214f9eae187843aef2a5ec7f4eaa3}
public class Test {


	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated constructor stub //{3b2ab4e3893bee79867a1cd2e0aca49b}
		//在本包下增加合适的类或者接口，使得如下代码编译通过并正确运行
		//本题目所有答案必须放在和本Test同级的目录下,除了JDK1.8自带的包以外，不允许引用第三方的包
		//本题目下的程序【不要】引用【其他考题】或者【作业的类】（例如不能 import 原来作业的类），否则会导致编译失败
		//程序写好以后，务必检查一下每个题目是不是仅仅依赖本题目的类+JDK1.8自带的包就可以运行，否则会导致编译失败
		//除非特殊说明，否则必须是无状态类，也就是new 一个实例可以使用多次。
		//最后上交的时候，不要在程序里面调用System.out 或者System.error等会向控制台输出字符的方法 。
		//其他要求和平时作业一样。
		//Test类在批改试卷的时候会删除掉
 
		
		Fruit fruit=new Fruit();
		
		//测试过程中color值可能被设置为其他值
		String color="red";
		//测试过程中weight值可能被设置为其他值
		int weight=10;
		fruit.setColor(color);
		fruit.setWeight(weight);
		
		if(fruit.getColor().equals(color)) {
			System.out.println(" test case 1 ok!");
		}
		
		if(fruit.getWeight()==weight) {
			System.out.println(" test case 2 ok!");
		}
		
	}

}
//TODO Auto-generated constructor stub //{3bd574629a061053381d297aa29b69ad}