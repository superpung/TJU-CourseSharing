package com.huawei.classroom.student.h84.q07;

import java.text.ParseException;
import java.text.SimpleDateFormat;

/**
 * @author //{6205180440dcb0238c86a9602b2770ee}
 * 
 * 本题目10分,共计8道题,难度系数3星
 */
public class Test {
	 
	public static void main(String[] args) {
		//在本包下增加合适的类或者接口，使得如下代码编译通过并正确运行
		//本题目所有答案必须放在和本Test同级的目录下,除了JDK1.8自带的包以外，不允许引用第三方的包
		//本题目下的程序【不要】引用【其他考题】或者【作业的类】（例如不能 import 原来作业的类），否则会导致编译失败
		//程序写好以后，务必检查一下每个题目是不是仅仅依赖本题目的类+JDK1.8自带的包就可以运行，否则会导致编译失败
		//除非特殊说明，否则必须是无状态类，也就是new 一个实例可以使用多次。
		//最后上交的时候，不要在程序里面调用System.out 或者System.error等会向控制台输出字符的方法 。
		//其他要求和平时作业一样。
		//Test类在批改试卷的时候会删除掉

		
		// TODO Auto-generated method stub
		MyPasswordUtil home = new MyPasswordUtil();
		 
		// passwordfile 中存放了加密的密码，具体格式见password.txt 
		// passwordfile 中每一行规定了将待加密字符串中的某个源字符 替换为目标字符
		// 如果在 passwordfile  找不到某个字符的加密/解密规则，则改字符原样返回
		// 在批改作业的时候 passwordfile 中内容会有变化
		
		// 此目录在考试时候要根据实际情况改写成你自己的目录
		String passwordfile = "D:/course/course/exam/src/main/java/com/huawei/classroom/student/h84/q08/password.txt";
		
		try {

			// 完成 MyPasswordUtil.encode/decode方法，实现对一个字符串的加密解密
	
			String src = "hellow";
			String target = home.encode(src, passwordfile);
			System.out.println(target);
			if ("gdkknv".equals(target)) {
				System.out.println("case 1 pass");
			}
			if (src.equals(home.decode("gdkknv", passwordfile))) {
				System.out.println("case 2 pass");
			}
			
			//密码文件中没有规定 + 这个字符怎么加密解密，则原样保留
			if ("+".equals(home.encode("+", passwordfile))) {
				System.out.println("case 3 pass");
			}

			// TODO Auto-generated constructor stub //{6583f2ae7d35c3fde16d4cc0e48676a5}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	// 不许使用Test里面的方法，同学可以把代码复制走，但是不能调用Test
	private static java.util.Date strToDate(String str) throws ParseException {
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		return formatter.parse(str);
	}
}
// TODO Auto-generated constructor stub //{65cd276d9a24c55d997174716107067e}
