package com.huawei.classroom.student.examkit;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.net.ServerSocket;
import java.net.Socket;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

/**
 * Java 上机考试通用工具箱，兼容 JDK 1.8。
 *
 * 设计原则：
 * 1. 只依赖 JDK，不依赖第三方包。
 * 2. 大多数公开方法不向外抛异常，内部 try-catch 后返回空集合、默认值、false 或 null。
 * 3. 方法注释都写了“怎么传参、怎么调用、失败返回什么”。
 * 4. 适合开卷时复制整个类，或复制某个内部类的方法。
 */
public final class ExamKit {
    public static final String UTF_8 = "UTF-8";

    private ExamKit() {
    }

    /**
     * String / Character / StringBuilder 相关工具。
     */
    public static final class Str {
        private Str() {
        }

        /**
         * 判断字符串是否为 null 或长度为 0。
         * 调用：ExamKit.Str.isEmpty(s)
         * 传参：s 可以为 null。
         * 返回：null 或 "" 返回 true，其余 false。
         */
        public static boolean isEmpty(String s) {
            return s == null || s.length() == 0;
        }

        /**
         * 判断字符串是否为空白。
         * 调用：ExamKit.Str.isBlank(s)
         * 传参：s 可以为 null，可包含空格、换行、tab。
         * 返回：null、""、"   " 都返回 true。
         */
        public static boolean isBlank(String s) {
            return s == null || s.trim().length() == 0;
        }

        /**
         * null 安全地转成空串。
         * 调用：String safe = ExamKit.Str.nullToEmpty(s)
         * 返回：s 为 null 时返回 ""，否则返回原字符串。
         */
        public static String nullToEmpty(String s) {
            return s == null ? "" : s;
        }

        /**
         * 空白安全 trim。
         * 调用：String r = ExamKit.Str.trim(s)
         * 返回：s 为 null 返回 ""，否则返回 s.trim()。
         */
        public static String trim(String s) {
            return s == null ? "" : s.trim();
        }

        /**
         * 判断两个字符串内容是否相等，避免空指针。
         * 调用：ExamKit.Str.equals(a, b)
         * 返回：两个都 null 或内容相等返回 true。
         */
        public static boolean equals(String a, String b) {
            return a == null ? b == null : a.equals(b);
        }

        /**
         * 忽略大小写比较字符串，避免空指针。
         * 调用：ExamKit.Str.equalsIgnoreCase(a, b)
         */
        public static boolean equalsIgnoreCase(String a, String b) {
            return a == null ? b == null : a.equalsIgnoreCase(b);
        }

        /**
         * 安全取字符。
         * 调用：char c = ExamKit.Str.charAt(s, 0, '\0')
         * 传参：s 是字符串，index 是下标，defaultValue 是越界或 null 时的默认字符。
         * 返回：合法时返回 s.charAt(index)，否则返回 defaultValue。
         */
        public static char charAt(String s, int index, char defaultValue) {
            if (s == null || index < 0 || index >= s.length()) {
                return defaultValue;
            }
            return s.charAt(index);
        }

        /**
         * 安全 substring，自动修正越界。
         * 调用：String sub = ExamKit.Str.substring(s, 1, 3)
         * 传参：begin 包含，end 不包含；越界会自动夹到合法范围。
         * 返回：s 为 null 返回 ""。
         */
        public static String substring(String s, int begin, int end) {
            if (s == null) {
                return "";
            }
            int len = s.length();
            begin = Math.max(0, Math.min(begin, len));
            end = Math.max(begin, Math.min(end, len));
            return s.substring(begin, end);
        }

        /**
         * 安全查找子串。
         * 调用：int i = ExamKit.Str.indexOf(text, key)
         * 返回：任意参数为 null 返回 -1。
         */
        public static int indexOf(String text, String key) {
            if (text == null || key == null) {
                return -1;
            }
            return text.indexOf(key);
        }

        /**
         * 安全判断是否包含子串。
         * 调用：boolean ok = ExamKit.Str.contains(text, key)
         */
        public static boolean contains(String text, String key) {
            return indexOf(text, key) >= 0;
        }

        /**
         * 去掉普通英文空格。
         * 调用：String r = ExamKit.Str.removeSpaces(" a b ")
         * 返回："ab"；s 为 null 返回 ""。
         */
        public static String removeSpaces(String s) {
            return s == null ? "" : s.replace(" ", "");
        }

        /**
         * 去掉所有空白字符：空格、tab、换行等。
         * 调用：String r = ExamKit.Str.removeWhitespace(" a\tb\n")
         * 返回："ab"；s 为 null 返回 ""。
         */
        public static String removeWhitespace(String s) {
            return s == null ? "" : s.replaceAll("\\s+", "");
        }

        /**
         * 字符串反转。
         * 调用：String r = ExamKit.Str.reverse("abc")
         * 返回："cba"；s 为 null 返回 ""。
         */
        public static String reverse(String s) {
            return s == null ? "" : new StringBuilder(s).reverse().toString();
        }

        /**
         * 判断是否回文。
         * 调用：ExamKit.Str.isPalindrome("abba")
         * 返回：null 返回 false。
         */
        public static boolean isPalindrome(String s) {
            if (s == null) {
                return false;
            }
            int left = 0;
            int right = s.length() - 1;
            while (left < right) {
                if (s.charAt(left++) != s.charAt(right--)) {
                    return false;
                }
            }
            return true;
        }

        /**
         * 保留首次出现顺序，去掉重复字符。
         * 调用：String r = ExamKit.Str.distinctChars("abca")
         * 返回："abc"；s 为 null 返回 ""。
         */
        public static String distinctChars(String s) {
            if (s == null) {
                return "";
            }
            Set<Character> seen = new LinkedHashSet<Character>();
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < s.length(); i++) {
                char c = s.charAt(i);
                if (seen.add(c)) {
                    sb.append(c);
                }
            }
            return sb.toString();
        }

        /**
         * 按分隔符拆分字符串，并过滤空白结果。
         * 调用：List<String> list = ExamKit.Str.splitToList("a,b,,c", ",")
         * 传参：regex 是正则表达式；如果按点拆分，要传 "\\."。
         * 返回：参数异常返回空 List。
         */
        public static List<String> splitToList(String s, String regex) {
            List<String> list = new ArrayList<String>();
            if (s == null || regex == null) {
                return list;
            }
            try {
                String[] arr = s.split(regex);
                for (String item : arr) {
                    if (!isBlank(item)) {
                        list.add(item.trim());
                    }
                }
            } catch (Exception e) {
                return new ArrayList<String>();
            }
            return list;
        }

        /**
         * 把集合拼接成字符串。
         * 调用：String s = ExamKit.Str.join(list, ",")
         * 传参：values 可以是 List/Set；delimiter 是分隔符。
         * 返回：values 为 null 返回 ""。
         */
        public static String join(Collection<?> values, String delimiter) {
            if (values == null) {
                return "";
            }
            if (delimiter == null) {
                delimiter = "";
            }
            StringBuilder sb = new StringBuilder();
            int i = 0;
            for (Object value : values) {
                if (i++ > 0) {
                    sb.append(delimiter);
                }
                sb.append(value);
            }
            return sb.toString();
        }

        /**
         * 字符出现次数统计。
         * 调用：Map<Character,Integer> map = ExamKit.Str.charCount("abca")
         * 返回：按首次出现顺序保存，null 返回空 Map。
         */
        public static Map<Character, Integer> charCount(String s) {
            Map<Character, Integer> map = new LinkedHashMap<Character, Integer>();
            if (s == null) {
                return map;
            }
            for (int i = 0; i < s.length(); i++) {
                char c = s.charAt(i);
                Integer old = map.get(c);
                map.put(c, old == null ? 1 : old + 1);
            }
            return map;
        }

        /**
         * 单词出现次数统计，按空白拆分。
         * 调用：Map<String,Integer> map = ExamKit.Str.wordCount("a b a")
         * 返回：{"a":2,"b":1}；空文本返回空 Map。
         */
        public static Map<String, Integer> wordCount(String text) {
            Map<String, Integer> map = new LinkedHashMap<String, Integer>();
            if (isBlank(text)) {
                return map;
            }
            String[] arr = text.trim().split("\\s+");
            for (String word : arr) {
                Integer old = map.get(word);
                map.put(word, old == null ? 1 : old + 1);
            }
            return map;
        }

        /**
         * 统计某个子串出现次数。
         * 调用：int n = ExamKit.Str.countSubstring("ababab", "ab")
         * 返回：key 为空或 null 返回 0。
         */
        public static int countSubstring(String text, String key) {
            if (isEmpty(text) || isEmpty(key)) {
                return 0;
            }
            int count = 0;
            int index = 0;
            while ((index = text.indexOf(key, index)) >= 0) {
                count++;
                index += key.length();
            }
            return count;
        }

        /**
         * 统计固定长度子串出现次数。
         * 调用：Map<String,Integer> map = ExamKit.Str.ngramCount(text, 2, true)
         * 传参：width 是子串长度；skipWhitespace 为 true 时跳过包含空白的子串。
         * 返回：异常或 width<=0 返回空 Map。
         */
        public static Map<String, Integer> ngramCount(String text, int width, boolean skipWhitespace) {
            Map<String, Integer> map = new LinkedHashMap<String, Integer>();
            if (text == null || width <= 0 || text.length() < width) {
                return map;
            }
            for (int i = 0; i <= text.length() - width; i++) {
                String sub = text.substring(i, i + width);
                if (skipWhitespace && sub.matches(".*\\s+.*")) {
                    continue;
                }
                Integer old = map.get(sub);
                map.put(sub, old == null ? 1 : old + 1);
            }
            return map;
        }

        /**
         * 安全转 int。
         * 调用：int n = ExamKit.Str.toInt(s, 0)
         * 失败返回 defaultValue。
         */
        public static int toInt(String s, int defaultValue) {
            try {
                return Integer.parseInt(trim(s));
            } catch (Exception e) {
                return defaultValue;
            }
        }

        /**
         * 安全转 long。
         * 调用：long n = ExamKit.Str.toLong(s, 0L)
         */
        public static long toLong(String s, long defaultValue) {
            try {
                return Long.parseLong(trim(s));
            } catch (Exception e) {
                return defaultValue;
            }
        }

        /**
         * 安全转 double。
         * 调用：double d = ExamKit.Str.toDouble(s, 0.0)
         */
        public static double toDouble(String s, double defaultValue) {
            try {
                return Double.parseDouble(trim(s));
            } catch (Exception e) {
                return defaultValue;
            }
        }
    }

    /**
     * 集合、Map、Set、统计、排序相关工具。
     */
    public static final class Coll {
        private Coll() {
        }

        /**
         * 创建 ArrayList，避免反复写泛型。
         * 调用：List<String> list = ExamKit.Coll.arrayList()
         */
        public static <T> List<T> arrayList() {
            return new ArrayList<T>();
        }

        /**
         * 创建 HashSet。
         * 调用：Set<String> set = ExamKit.Coll.hashSet()
         */
        public static <T> Set<T> hashSet() {
            return new HashSet<T>();
        }

        /**
         * 创建 LinkedHashSet，去重并保留插入顺序。
         * 调用：Set<String> set = ExamKit.Coll.linkedHashSet()
         */
        public static <T> Set<T> linkedHashSet() {
            return new LinkedHashSet<T>();
        }

        /**
         * 创建 HashMap。
         * 调用：Map<String,Integer> map = ExamKit.Coll.hashMap()
         */
        public static <K, V> Map<K, V> hashMap() {
            return new HashMap<K, V>();
        }

        /**
         * 创建 LinkedHashMap，保留 put 顺序。
         * 调用：Map<String,Integer> map = ExamKit.Coll.linkedHashMap()
         */
        public static <K, V> Map<K, V> linkedHashMap() {
            return new LinkedHashMap<K, V>();
        }

        /**
         * 统计集合里每个元素出现次数。
         * 调用：Map<String,Integer> map = ExamKit.Coll.count(list)
         * 传参：items 可以是 List/Set；元素可以为 null。
         * 返回：items 为 null 返回空 Map。
         */
        public static <T> Map<T, Integer> count(Collection<T> items) {
            Map<T, Integer> map = new LinkedHashMap<T, Integer>();
            if (items == null) {
                return map;
            }
            for (T item : items) {
                Integer old = map.get(item);
                map.put(item, old == null ? 1 : old + 1);
            }
            return map;
        }

        /**
         * Map 的 value 加一，适合边遍历边统计。
         * 调用：ExamKit.Coll.addCount(map, key)
         * 传参：map 是 Map<K,Integer>，key 是要统计的对象。
         */
        public static <K> void addCount(Map<K, Integer> map, K key) {
            if (map == null) {
                return;
            }
            Integer old = map.get(key);
            map.put(key, old == null ? 1 : old + 1);
        }

        /**
         * 根据 Map 的 value 排序，返回 Entry 列表。
         * 调用：List<Map.Entry<String,Integer>> list = ExamKit.Coll.sortMapByValue(map, false)
         * 传参：ascending=true 升序，false 降序。
         * 返回：map 为 null 返回空 List。
         */
        public static <K, V extends Comparable<? super V>> List<Map.Entry<K, V>> sortMapByValue(
                Map<K, V> map, final boolean ascending) {
            List<Map.Entry<K, V>> list = new ArrayList<Map.Entry<K, V>>();
            if (map == null) {
                return list;
            }
            list.addAll(map.entrySet());
            Collections.sort(list, new Comparator<Map.Entry<K, V>>() {
                public int compare(Map.Entry<K, V> a, Map.Entry<K, V> b) {
                    int r = compareNullable(a.getValue(), b.getValue());
                    return ascending ? r : -r;
                }
            });
            return list;
        }

        /**
         * 根据 Map 的 key 排序，返回 Entry 列表。
         * 调用：List<Map.Entry<String,Integer>> list = ExamKit.Coll.sortMapByKey(map, true)
         */
        public static <K extends Comparable<? super K>, V> List<Map.Entry<K, V>> sortMapByKey(
                Map<K, V> map, final boolean ascending) {
            List<Map.Entry<K, V>> list = new ArrayList<Map.Entry<K, V>>();
            if (map == null) {
                return list;
            }
            list.addAll(map.entrySet());
            Collections.sort(list, new Comparator<Map.Entry<K, V>>() {
                public int compare(Map.Entry<K, V> a, Map.Entry<K, V> b) {
                    int r = compareNullable(a.getKey(), b.getKey());
                    return ascending ? r : -r;
                }
            });
            return list;
        }

        /**
         * 根据 Map 的 value 排序，只返回 key 列表。
         * 调用：List<String> keys = ExamKit.Coll.keysSortedByValue(map, false)
         */
        public static <K, V extends Comparable<? super V>> List<K> keysSortedByValue(
                Map<K, V> map, boolean ascending) {
            List<K> keys = new ArrayList<K>();
            List<Map.Entry<K, V>> entries = sortMapByValue(map, ascending);
            for (Map.Entry<K, V> e : entries) {
                keys.add(e.getKey());
            }
            return keys;
        }

        /**
         * 根据 Map 的 value 排序，只返回 value 列表。
         * 调用：List<Integer> values = ExamKit.Coll.valuesSorted(map, false)
         */
        public static <K, V extends Comparable<? super V>> List<V> valuesSortedByValue(
                Map<K, V> map, boolean ascending) {
            List<V> values = new ArrayList<V>();
            List<Map.Entry<K, V>> entries = sortMapByValue(map, ascending);
            for (Map.Entry<K, V> e : entries) {
                values.add(e.getValue());
            }
            return values;
        }

        /**
         * 取 Map 中 value 最大的前 n 个 Entry。
         * 调用：List<Map.Entry<String,Integer>> top = ExamKit.Coll.topNByValue(map, 5)
         * 返回：n<=0 或 map 为空返回空 List。
         */
        public static <K, V extends Comparable<? super V>> List<Map.Entry<K, V>> topNByValue(Map<K, V> map, int n) {
            List<Map.Entry<K, V>> sorted = sortMapByValue(map, false);
            if (n <= 0 || sorted.isEmpty()) {
                return new ArrayList<Map.Entry<K, V>>();
            }
            return new ArrayList<Map.Entry<K, V>>(sorted.subList(0, Math.min(n, sorted.size())));
        }

        /**
         * 取 Map 中 value 最大的前 n 个 key。
         * 调用：List<String> topKeys = ExamKit.Coll.topNKeysByValue(map, 10)
         */
        public static <K, V extends Comparable<? super V>> List<K> topNKeysByValue(Map<K, V> map, int n) {
            List<K> keys = new ArrayList<K>();
            List<Map.Entry<K, V>> entries = topNByValue(map, n);
            for (Map.Entry<K, V> e : entries) {
                keys.add(e.getKey());
            }
            return keys;
        }

        /**
         * 把 Set 排序后返回 List。
         * 调用：List<String> list = ExamKit.Coll.sortSet(set, true)
         * 传参：ascending=true 升序，false 降序。
         */
        public static <T extends Comparable<? super T>> List<T> sortSet(Set<T> set, final boolean ascending) {
            List<T> list = new ArrayList<T>();
            if (set == null) {
                return list;
            }
            list.addAll(set);
            Collections.sort(list, new Comparator<T>() {
                public int compare(T a, T b) {
                    int r = compareNullable(a, b);
                    return ascending ? r : -r;
                }
            });
            return list;
        }

        /**
         * 集合去重并保留原顺序，返回 List。
         * 调用：List<String> list = ExamKit.Coll.distinctKeepOrder(list)
         */
        public static <T> List<T> distinctKeepOrder(Collection<T> items) {
            if (items == null) {
                return new ArrayList<T>();
            }
            return new ArrayList<T>(new LinkedHashSet<T>(items));
        }

        /**
         * 过滤集合，保留满足条件的元素。
         * 调用：List<String> r = ExamKit.Coll.filter(list, new ExamKit.Coll.Filter<String>() {...})
         */
        public static <T> List<T> filter(Collection<T> items, Filter<T> filter) {
            List<T> result = new ArrayList<T>();
            if (items == null || filter == null) {
                return result;
            }
            for (T item : items) {
                try {
                    if (filter.accept(item)) {
                        result.add(item);
                    }
                } catch (Exception e) {
                    // 某个元素判断失败就跳过，保证整体鲁棒。
                }
            }
            return result;
        }

        /**
         * 按自定义比较器排序并返回新 List，不修改原集合。
         * 调用：List<Student> r = ExamKit.Coll.sort(list, comparator)
         */
        public static <T> List<T> sort(Collection<T> items, Comparator<T> comparator) {
            List<T> result = new ArrayList<T>();
            if (items == null) {
                return result;
            }
            result.addAll(items);
            if (comparator != null) {
                Collections.sort(result, comparator);
            }
            return result;
        }

        /**
         * 自定义过滤接口，兼容 JDK8 之前写法，也可以用 lambda。
         */
        public interface Filter<T> {
            boolean accept(T item);
        }

        private static <T extends Comparable<? super T>> int compareNullable(T a, T b) {
            if (a == null && b == null) {
                return 0;
            }
            if (a == null) {
                return -1;
            }
            if (b == null) {
                return 1;
            }
            return a.compareTo(b);
        }
    }

    /**
     * 文件、字节流、字符流、编码相关工具。
     */
    public static final class Io {
        private Io() {
        }

        /**
         * 按 UTF-8 一次性读取整个文本文件。
         * 调用：String text = ExamKit.Io.readText("a.txt")
         * 失败返回 ""，不会抛异常。
         */
        public static String readText(String filename) {
            return readText(filename, UTF_8);
        }

        /**
         * 按指定编码一次性读取整个文本文件。
         * 调用：String text = ExamKit.Io.readText("a.txt", "GBK")
         * 传参：filename 是文件路径；charsetName 如 "UTF-8"/"GBK"。
         * 失败返回 ""。
         */
        public static String readText(String filename, String charsetName) {
            StringBuilder sb = new StringBuilder();
            BufferedReader reader = null;
            try {
                reader = newBufferedReader(filename, charsetName);
                if (reader == null) {
                    return "";
                }
                char[] buffer = new char[8192];
                int len;
                while ((len = reader.read(buffer)) != -1) {
                    sb.append(buffer, 0, len);
                }
            } catch (Exception e) {
                return "";
            } finally {
                close(reader);
            }
            return sb.toString();
        }

        /**
         * 按 UTF-8 高效按行读取文件。
         * 调用：List<String> lines = ExamKit.Io.readLines("a.txt")
         * 返回：读取失败返回空 List。
         */
        public static List<String> readLines(String filename) {
            return readLines(filename, UTF_8);
        }

        /**
         * 按指定编码高效按行读取文件。
         * 调用：List<String> lines = ExamKit.Io.readLines("a.txt", "UTF-8")
         * 特点：用 BufferedReader，不会把换行符放入每行字符串。
         * 返回：失败返回空 List。
         */
        public static List<String> readLines(String filename, String charsetName) {
            List<String> lines = new ArrayList<String>();
            BufferedReader reader = null;
            try {
                reader = newBufferedReader(filename, charsetName);
                if (reader == null) {
                    return lines;
                }
                String line;
                while ((line = reader.readLine()) != null) {
                    lines.add(line);
                }
            } catch (Exception e) {
                return new ArrayList<String>();
            } finally {
                close(reader);
            }
            return lines;
        }

        /**
         * 按行处理大文件，不把所有行放进内存。
         * 调用：
         * ExamKit.Io.eachLine("a.txt", new ExamKit.Io.LineHandler() {
         *     public void handle(String line, int lineNo) { System.out.println(lineNo + ":" + line); }
         * });
         * 返回：成功 true，失败 false。
         */
        public static boolean eachLine(String filename, LineHandler handler) {
            return eachLine(filename, UTF_8, handler);
        }

        /**
         * 按指定编码逐行处理大文件。
         * 传参：handler 里写每一行要做的事；lineNo 从 1 开始。
         * 返回：成功 true，失败 false。
         */
        public static boolean eachLine(String filename, String charsetName, LineHandler handler) {
            if (handler == null) {
                return false;
            }
            BufferedReader reader = null;
            try {
                reader = newBufferedReader(filename, charsetName);
                if (reader == null) {
                    return false;
                }
                String line;
                int lineNo = 0;
                while ((line = reader.readLine()) != null) {
                    lineNo++;
                    handler.handle(line, lineNo);
                }
                return true;
            } catch (Exception e) {
                return false;
            } finally {
                close(reader);
            }
        }

        /**
         * 按 UTF-8 写文本，默认覆盖旧文件。
         * 调用：boolean ok = ExamKit.Io.writeText("a.txt", "hello")
         * 返回：成功 true，失败 false。
         */
        public static boolean writeText(String filename, String content) {
            return writeText(filename, content, UTF_8, false);
        }

        /**
         * 按 UTF-8 追加文本。
         * 调用：boolean ok = ExamKit.Io.appendText("a.txt", "hello\n")
         */
        public static boolean appendText(String filename, String content) {
            return writeText(filename, content, UTF_8, true);
        }

        /**
         * 按指定编码写文本。
         * 调用：ExamKit.Io.writeText("a.txt", text, "UTF-8", false)
         * 传参：append=false 覆盖，append=true 追加。
         * 返回：成功 true，失败 false。
         */
        public static boolean writeText(String filename, String content, String charsetName, boolean append) {
            BufferedWriter writer = null;
            try {
                if (Str.isBlank(filename)) {
                    return false;
                }
                ensureParentDir(filename);
                writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(filename, append),
                        safeCharset(charsetName)));
                writer.write(content == null ? "" : content);
                return true;
            } catch (Exception e) {
                return false;
            } finally {
                close(writer);
            }
        }

        /**
         * 按 UTF-8 写多行文本，每个元素一行。
         * 调用：ExamKit.Io.writeLines("a.txt", lines)
         * 返回：成功 true，失败 false。
         */
        public static boolean writeLines(String filename, Collection<String> lines) {
            return writeLines(filename, lines, UTF_8, false);
        }

        /**
         * 按指定编码写多行文本。
         * 调用：ExamKit.Io.writeLines("a.txt", lines, "UTF-8", true)
         * 传参：append=true 追加；lines 为 null 时写空文件或不追加内容。
         */
        public static boolean writeLines(String filename, Collection<String> lines, String charsetName, boolean append) {
            BufferedWriter writer = null;
            try {
                if (Str.isBlank(filename)) {
                    return false;
                }
                ensureParentDir(filename);
                writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(filename, append),
                        safeCharset(charsetName)));
                if (lines != null) {
                    for (String line : lines) {
                        writer.write(line == null ? "" : line);
                        writer.newLine();
                    }
                }
                return true;
            } catch (Exception e) {
                return false;
            } finally {
                close(writer);
            }
        }

        /**
         * 读取二进制文件。
         * 调用：byte[] bytes = ExamKit.Io.readBytes("a.jpg")
         * 返回：失败返回长度为 0 的 byte[]。
         */
        public static byte[] readBytes(String filename) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            InputStream in = null;
            try {
                if (Str.isBlank(filename)) {
                    return new byte[0];
                }
                in = new BufferedInputStream(new FileInputStream(filename));
                byte[] buffer = new byte[8192];
                int len;
                while ((len = in.read(buffer)) != -1) {
                    out.write(buffer, 0, len);
                }
                return out.toByteArray();
            } catch (Exception e) {
                return new byte[0];
            } finally {
                close(in);
                close(out);
            }
        }

        /**
         * 写二进制文件。
         * 调用：boolean ok = ExamKit.Io.writeBytes("a.bin", bytes)
         * 返回：成功 true，失败 false。
         */
        public static boolean writeBytes(String filename, byte[] bytes) {
            OutputStream out = null;
            try {
                if (Str.isBlank(filename)) {
                    return false;
                }
                ensureParentDir(filename);
                out = new BufferedOutputStream(new FileOutputStream(filename));
                if (bytes != null) {
                    out.write(bytes);
                }
                return true;
            } catch (Exception e) {
                return false;
            } finally {
                close(out);
            }
        }

        /**
         * 复制文件，适合图片、文本、任意二进制。
         * 调用：boolean ok = ExamKit.Io.copyFile("src.jpg", "out/dst.jpg")
         * 返回：成功 true，失败 false。
         */
        public static boolean copyFile(String src, String dst) {
            InputStream in = null;
            OutputStream out = null;
            try {
                if (Str.isBlank(src) || Str.isBlank(dst)) {
                    return false;
                }
                ensureParentDir(dst);
                in = new BufferedInputStream(new FileInputStream(src));
                out = new BufferedOutputStream(new FileOutputStream(dst));
                byte[] buffer = new byte[8192];
                int len;
                while ((len = in.read(buffer)) != -1) {
                    out.write(buffer, 0, len);
                }
                return true;
            } catch (Exception e) {
                return false;
            } finally {
                close(in);
                close(out);
            }
        }

        /**
         * 列出目录下文件。
         * 调用：List<File> files = ExamKit.Io.listFiles("D:/tmp", ".txt", true)
         * 传参：suffix 可传 ".txt"；传 null 表示不过滤；recursive=true 递归子目录。
         * 返回：目录不存在或失败返回空 List。
         */
        public static List<File> listFiles(String dir, String suffix, boolean recursive) {
            List<File> result = new ArrayList<File>();
            if (Str.isBlank(dir)) {
                return result;
            }
            listFiles0(new File(dir), suffix, recursive, result);
            return result;
        }

        /**
         * 读取 key=value 配置文件。
         * 调用：Map<String,String> map = ExamKit.Io.readKeyValue("a.ini")
         * 规则：跳过空行和 # 开头注释；自动去掉值两边双引号。
         * 返回：失败返回空 Map。
         */
        public static Map<String, String> readKeyValue(String filename) {
            return readKeyValue(filename, UTF_8);
        }

        /**
         * 按指定编码读取 key=value 配置文件。
         * 调用：Map<String,String> map = ExamKit.Io.readKeyValue("a.ini", "UTF-8")
         */
        public static Map<String, String> readKeyValue(String filename, String charsetName) {
            final Map<String, String> map = new LinkedHashMap<String, String>();
            eachLine(filename, charsetName, new LineHandler() {
                public void handle(String line, int lineNo) {
                    String s = line == null ? "" : line.trim();
                    if (s.length() == 0 || s.startsWith("#")) {
                        return;
                    }
                    int index = s.indexOf('=');
                    if (index < 0) {
                        return;
                    }
                    String key = s.substring(0, index).trim();
                    String value = s.substring(index + 1).trim();
                    map.put(key, unquote(value));
                }
            });
            return map;
        }

        /**
         * 读取“类名.属性=值”形式配置。
         * 调用：Map<String,Map<String,String>> cfg = ExamKit.Io.readDottedConfig("a.ini")
         * 例：com.xxx.Apple.color=red 会变成 cfg.get("com.xxx.Apple").get("color")。
         */
        public static Map<String, Map<String, String>> readDottedConfig(String filename) {
            Map<String, String> flat = readKeyValue(filename);
            Map<String, Map<String, String>> grouped = new LinkedHashMap<String, Map<String, String>>();
            for (Map.Entry<String, String> e : flat.entrySet()) {
                String key = e.getKey();
                int dot = key.lastIndexOf('.');
                if (dot <= 0 || dot == key.length() - 1) {
                    continue;
                }
                String group = key.substring(0, dot);
                String prop = key.substring(dot + 1);
                Map<String, String> props = grouped.get(group);
                if (props == null) {
                    props = new LinkedHashMap<String, String>();
                    grouped.put(group, props);
                }
                props.put(prop, e.getValue());
            }
            return grouped;
        }

        /**
         * 关闭流，吞掉异常。
         * 调用：ExamKit.Io.close(reader)
         */
        public static void close(Closeable c) {
            if (c != null) {
                try {
                    c.close();
                } catch (Exception e) {
                    // ignore
                }
            }
        }

        /**
         * 大文件逐行处理接口。
         */
        public interface LineHandler {
            void handle(String line, int lineNo);
        }

        private static BufferedReader newBufferedReader(String filename, String charsetName) {
            try {
                if (Str.isBlank(filename)) {
                    return null;
                }
                return new BufferedReader(new InputStreamReader(new FileInputStream(filename),
                        safeCharset(charsetName)), 8192);
            } catch (Exception e) {
                return null;
            }
        }

        private static String safeCharset(String charsetName) {
            return Str.isBlank(charsetName) ? UTF_8 : charsetName;
        }

        private static void ensureParentDir(String filename) {
            try {
                File file = new File(filename);
                File parent = file.getParentFile();
                if (parent != null && !parent.exists()) {
                    parent.mkdirs();
                }
            } catch (Exception e) {
                // ignore
            }
        }

        private static void listFiles0(File dir, String suffix, boolean recursive, List<File> result) {
            try {
                if (dir == null || !dir.exists() || !dir.isDirectory()) {
                    return;
                }
                File[] files = dir.listFiles();
                if (files == null) {
                    return;
                }
                for (File file : files) {
                    if (file.isDirectory() && recursive) {
                        listFiles0(file, suffix, true, result);
                    } else if (file.isFile()) {
                        if (suffix == null || file.getName().toLowerCase().endsWith(suffix.toLowerCase())) {
                            result.add(file);
                        }
                    }
                }
            } catch (Exception e) {
                // ignore
            }
        }

        private static String unquote(String value) {
            if (value == null) {
                return "";
            }
            if (value.length() >= 2 && value.startsWith("\"") && value.endsWith("\"")) {
                return value.substring(1, value.length() - 1);
            }
            return value;
        }
    }

    /**
     * 反射工具：创建对象、调用方法、读写字段、配置注入。
     */
    public static final class Reflect {
        private Reflect() {
        }

        /**
         * 根据完整类名创建对象，要求类有无参构造。
         * 调用：Object obj = ExamKit.Reflect.newObject("com.xxx.Apple")
         * 返回：失败返回 null，不抛异常。
         */
        public static Object newObject(String className) {
            try {
                if (Str.isBlank(className)) {
                    return null;
                }
                Class<?> clazz = Class.forName(className);
                return newObject(clazz);
            } catch (Exception e) {
                return null;
            }
        }

        /**
         * 根据 Class 创建对象，要求类有无参构造。
         * 调用：Apple a = ExamKit.Reflect.newObject(Apple.class)
         * 返回：失败返回 null。
         */
        public static <T> T newObject(Class<T> clazz) {
            try {
                if (clazz == null) {
                    return null;
                }
                Constructor<T> c = clazz.getDeclaredConstructor();
                c.setAccessible(true);
                return c.newInstance();
            } catch (Exception e) {
                return null;
            }
        }

        /**
         * 根据构造参数创建对象。
         * 调用：Apple a = (Apple) ExamKit.Reflect.newObject("com.xxx.Apple", "red", 100)
         * 说明：会自动匹配基本类型和包装类型，如 int 与 Integer。
         * 返回：失败返回 null。
         */
        public static Object newObject(String className, Object... args) {
            try {
                if (Str.isBlank(className)) {
                    return null;
                }
                return newObject(Class.forName(className), args);
            } catch (Exception e) {
                return null;
            }
        }

        /**
         * 根据 Class 和构造参数创建对象。
         * 调用：Apple a = ExamKit.Reflect.newObject(Apple.class, "red", 100)
         * 返回：失败返回 null。
         */
        public static <T> T newObject(Class<T> clazz, Object... args) {
            try {
                if (clazz == null) {
                    return null;
                }
                Constructor<?> c = findConstructor(clazz, args);
                if (c == null) {
                    return null;
                }
                c.setAccessible(true);
                @SuppressWarnings("unchecked")
                T obj = (T) c.newInstance(args);
                return obj;
            } catch (Exception e) {
                return null;
            }
        }

        /**
         * 调用对象方法。
         * 调用：Object r = ExamKit.Reflect.invoke(obj, "setColor", "red")
         * 传参：obj 是对象；methodName 是方法名；args 是参数。
         * 返回：方法有返回值则返回结果；void 或失败返回 null。
         */
        public static Object invoke(Object obj, String methodName, Object... args) {
            try {
                if (obj == null || Str.isBlank(methodName)) {
                    return null;
                }
                Method m = findMethod(obj.getClass(), methodName, args);
                if (m == null) {
                    return null;
                }
                m.setAccessible(true);
                return m.invoke(obj, args);
            } catch (Exception e) {
                return null;
            }
        }

        /**
         * 调用静态方法。
         * 调用：Object r = ExamKit.Reflect.invokeStatic("java.lang.Math", "max", 1, 2)
         * 返回：失败返回 null。
         */
        public static Object invokeStatic(String className, String methodName, Object... args) {
            try {
                if (Str.isBlank(className) || Str.isBlank(methodName)) {
                    return null;
                }
                Class<?> clazz = Class.forName(className);
                Method m = findMethod(clazz, methodName, args);
                if (m == null || !Modifier.isStatic(m.getModifiers())) {
                    return null;
                }
                m.setAccessible(true);
                return m.invoke(null, args);
            } catch (Exception e) {
                return null;
            }
        }

        /**
         * 调用 setter。
         * 调用：boolean ok = ExamKit.Reflect.setProperty(obj, "color", "red")
         * 说明：优先调用 setColor；找不到 setter 时尝试直接设置字段 color。
         * 返回：成功 true，失败 false。
         */
        public static boolean setProperty(Object obj, String propertyName, Object value) {
            try {
                if (obj == null || Str.isBlank(propertyName)) {
                    return false;
                }
                String methodName = "set" + upperFirst(propertyName);
                Method setter = findSetter(obj.getClass(), methodName);
                if (setter != null) {
                    setter.setAccessible(true);
                    Class<?> type = setter.getParameterTypes()[0];
                    setter.invoke(obj, convert(value, type));
                    return true;
                }
                return setField(obj, propertyName, value);
            } catch (Exception e) {
                return false;
            }
        }

        /**
         * 调用 getter。
         * 调用：Object color = ExamKit.Reflect.getProperty(obj, "color")
         * 说明：优先 getColor，再 isColor，最后直接读字段。
         * 返回：失败返回 null。
         */
        public static Object getProperty(Object obj, String propertyName) {
            try {
                if (obj == null || Str.isBlank(propertyName)) {
                    return null;
                }
                String name = upperFirst(propertyName);
                Method getter = findNoArgMethod(obj.getClass(), "get" + name);
                if (getter == null) {
                    getter = findNoArgMethod(obj.getClass(), "is" + name);
                }
                if (getter != null) {
                    getter.setAccessible(true);
                    return getter.invoke(obj);
                }
                return getField(obj, propertyName);
            } catch (Exception e) {
                return null;
            }
        }

        /**
         * 直接设置字段，包括 private 字段。
         * 调用：ExamKit.Reflect.setField(obj, "age", 18)
         * 返回：成功 true，失败 false。
         */
        public static boolean setField(Object obj, String fieldName, Object value) {
            try {
                Field f = findField(obj.getClass(), fieldName);
                if (f == null) {
                    return false;
                }
                f.setAccessible(true);
                f.set(obj, convert(value, f.getType()));
                return true;
            } catch (Exception e) {
                return false;
            }
        }

        /**
         * 直接读取字段，包括 private 字段。
         * 调用：Object v = ExamKit.Reflect.getField(obj, "age")
         * 返回：失败返回 null。
         */
        public static Object getField(Object obj, String fieldName) {
            try {
                if (obj == null || Str.isBlank(fieldName)) {
                    return null;
                }
                Field f = findField(obj.getClass(), fieldName);
                if (f == null) {
                    return null;
                }
                f.setAccessible(true);
                return f.get(obj);
            } catch (Exception e) {
                return null;
            }
        }

        /**
         * 用 Map 批量给对象设置属性。
         * 调用：ExamKit.Reflect.setProperties(obj, map)
         * 说明：map 的 key 是属性名，value 是属性值；内部自动类型转换。
         * 返回：成功设置的属性个数。
         */
        public static int setProperties(Object obj, Map<String, ?> properties) {
            if (obj == null || properties == null) {
                return 0;
            }
            int count = 0;
            for (Map.Entry<String, ?> e : properties.entrySet()) {
                if (setProperty(obj, e.getKey(), e.getValue())) {
                    count++;
                }
            }
            return count;
        }

        /**
         * 根据类名和属性 Map 创建对象并注入属性。
         * 调用：Object obj = ExamKit.Reflect.createAndSet("com.xxx.Apple", props)
         * 返回：失败返回 null。
         */
        public static Object createAndSet(String className, Map<String, ?> properties) {
            Object obj = newObject(className);
            if (obj == null) {
                return null;
            }
            setProperties(obj, properties);
            return obj;
        }

        /**
         * 根据 Class 和属性 Map 创建对象并注入属性。
         * 调用：Apple a = ExamKit.Reflect.createAndSet(Apple.class, props)
         */
        public static <T> T createAndSet(Class<T> clazz, Map<String, ?> properties) {
            T obj = newObject(clazz);
            if (obj == null) {
                return null;
            }
            setProperties(obj, properties);
            return obj;
        }

        /**
         * 用“类名.属性=值”的配置文件创建某个类的实例。
         * 调用：
         * Object apple = ExamKit.Reflect.createFromDottedConfig("config.ini", "com.xxx.Apple")
         * 配置示例：
         * com.xxx.Apple.color=red
         * com.xxx.Apple.weight=500
         * 返回：失败返回 null。
         */
        public static Object createFromDottedConfig(String filename, String className) {
            Map<String, Map<String, String>> cfg = Io.readDottedConfig(filename);
            Map<String, String> props = cfg.get(className);
            return createAndSet(className, props);
        }

        /**
         * 获取某个类的所有方法名。
         * 调用：List<String> names = ExamKit.Reflect.methodNames(obj.getClass())
         * 返回：失败返回空 List。
         */
        public static List<String> methodNames(Class<?> clazz) {
            List<String> list = new ArrayList<String>();
            try {
                if (clazz == null) {
                    return list;
                }
                Method[] methods = clazz.getMethods();
                for (Method m : methods) {
                    list.add(m.getName());
                }
            } catch (Exception e) {
                return new ArrayList<String>();
            }
            return list;
        }

        /**
         * 获取某个类的所有字段名。
         * 调用：List<String> names = ExamKit.Reflect.fieldNames(obj.getClass())
         */
        public static List<String> fieldNames(Class<?> clazz) {
            List<String> list = new ArrayList<String>();
            try {
                Class<?> current = clazz;
                while (current != null) {
                    Field[] fields = current.getDeclaredFields();
                    for (Field f : fields) {
                        list.add(f.getName());
                    }
                    current = current.getSuperclass();
                }
            } catch (Exception e) {
                return new ArrayList<String>();
            }
            return list;
        }

        /**
         * 把字符串或包装类型转换成目标类型。
         * 调用：Object v = ExamKit.Reflect.convert("123", int.class)
         * 支持：String、int、long、double、float、boolean、char、枚举。
         * 失败时返回原值或对应默认值。
         */
        public static Object convert(Object value, Class<?> targetType) {
            try {
                if (targetType == null) {
                    return value;
                }
                if (value == null) {
                    if (targetType.isPrimitive()) {
                        return primitiveDefault(targetType);
                    }
                    return null;
                }
                Class<?> wrapped = wrap(targetType);
                if (wrapped.isInstance(value)) {
                    return value;
                }
                String s = String.valueOf(value);
                if (wrapped == String.class) {
                    return s;
                }
                if (wrapped == Integer.class) {
                    return Integer.valueOf(s.trim());
                }
                if (wrapped == Long.class) {
                    return Long.valueOf(s.trim());
                }
                if (wrapped == Double.class) {
                    return Double.valueOf(s.trim());
                }
                if (wrapped == Float.class) {
                    return Float.valueOf(s.trim());
                }
                if (wrapped == Boolean.class) {
                    return Boolean.valueOf(s.trim());
                }
                if (wrapped == Character.class) {
                    return s.length() == 0 ? Character.valueOf('\0') : Character.valueOf(s.charAt(0));
                }
                if (targetType.isEnum()) {
                    @SuppressWarnings({ "rawtypes", "unchecked" })
                    Object enumValue = Enum.valueOf((Class<? extends Enum>) targetType, s.trim());
                    return enumValue;
                }
                return value;
            } catch (Exception e) {
                return targetType != null && targetType.isPrimitive() ? primitiveDefault(targetType) : value;
            }
        }

        private static Constructor<?> findConstructor(Class<?> clazz, Object[] args) {
            Constructor<?>[] constructors = clazz.getDeclaredConstructors();
            for (Constructor<?> c : constructors) {
                if (matchTypes(c.getParameterTypes(), args)) {
                    return c;
                }
            }
            return null;
        }

        private static Method findMethod(Class<?> clazz, String methodName, Object[] args) {
            Class<?> current = clazz;
            while (current != null) {
                Method[] methods = current.getDeclaredMethods();
                for (Method m : methods) {
                    if (m.getName().equals(methodName) && matchTypes(m.getParameterTypes(), args)) {
                        return m;
                    }
                }
                current = current.getSuperclass();
            }
            Method[] publicMethods = clazz.getMethods();
            for (Method m : publicMethods) {
                if (m.getName().equals(methodName) && matchTypes(m.getParameterTypes(), args)) {
                    return m;
                }
            }
            return null;
        }

        private static Method findSetter(Class<?> clazz, String methodName) {
            Class<?> current = clazz;
            while (current != null) {
                Method[] methods = current.getDeclaredMethods();
                for (Method m : methods) {
                    if (m.getName().equals(methodName) && m.getParameterTypes().length == 1) {
                        return m;
                    }
                }
                current = current.getSuperclass();
            }
            return null;
        }

        private static Method findNoArgMethod(Class<?> clazz, String methodName) {
            Class<?> current = clazz;
            while (current != null) {
                Method[] methods = current.getDeclaredMethods();
                for (Method m : methods) {
                    if (m.getName().equals(methodName) && m.getParameterTypes().length == 0) {
                        return m;
                    }
                }
                current = current.getSuperclass();
            }
            return null;
        }

        private static Field findField(Class<?> clazz, String fieldName) {
            try {
                Class<?> current = clazz;
                while (current != null) {
                    try {
                        return current.getDeclaredField(fieldName);
                    } catch (NoSuchFieldException e) {
                        current = current.getSuperclass();
                    }
                }
            } catch (Exception e) {
                return null;
            }
            return null;
        }

        private static boolean matchTypes(Class<?>[] types, Object[] args) {
            int argLen = args == null ? 0 : args.length;
            if (types.length != argLen) {
                return false;
            }
            for (int i = 0; i < types.length; i++) {
                if (args[i] == null) {
                    continue;
                }
                Class<?> need = wrap(types[i]);
                Class<?> got = wrap(args[i].getClass());
                if (need.isAssignableFrom(got)) {
                    continue;
                }
                if (canConvert(args[i], types[i])) {
                    args[i] = convert(args[i], types[i]);
                    continue;
                }
                return false;
            }
            return true;
        }

        private static boolean canConvert(Object value, Class<?> targetType) {
            if (value == null) {
                return true;
            }
            if (value instanceof String) {
                Class<?> type = wrap(targetType);
                return type == String.class || type == Integer.class || type == Long.class || type == Double.class
                        || type == Float.class || type == Boolean.class || type == Character.class
                        || targetType.isEnum();
            }
            return false;
        }

        private static Class<?> wrap(Class<?> type) {
            if (type == null || !type.isPrimitive()) {
                return type;
            }
            if (type == int.class) return Integer.class;
            if (type == long.class) return Long.class;
            if (type == double.class) return Double.class;
            if (type == float.class) return Float.class;
            if (type == boolean.class) return Boolean.class;
            if (type == char.class) return Character.class;
            if (type == byte.class) return Byte.class;
            if (type == short.class) return Short.class;
            return type;
        }

        private static Object primitiveDefault(Class<?> type) {
            if (type == boolean.class) return false;
            if (type == char.class) return '\0';
            if (type == byte.class) return (byte) 0;
            if (type == short.class) return (short) 0;
            if (type == int.class) return 0;
            if (type == long.class) return 0L;
            if (type == float.class) return 0f;
            if (type == double.class) return 0d;
            return null;
        }

        private static String upperFirst(String s) {
            if (Str.isEmpty(s)) {
                return s;
            }
            return s.substring(0, 1).toUpperCase() + s.substring(1);
        }
    }

    /**
     * 日期工具：SimpleDateFormat 是讲义常用内容。
     */
    public static final class Datex {
        private Datex() {
        }

        /**
         * 字符串转 Date。
         * 调用：Date d = ExamKit.Datex.parse("2026-06-20", "yyyy-MM-dd")
         * 返回：失败返回 null。
         */
        public static Date parse(String text, String pattern) {
            try {
                return new SimpleDateFormat(pattern).parse(text);
            } catch (ParseException e) {
                return null;
            } catch (Exception e) {
                return null;
            }
        }

        /**
         * Date 转字符串。
         * 调用：String s = ExamKit.Datex.format(new Date(), "yyyy-MM-dd HH:mm:ss")
         * 返回：失败返回 ""。
         */
        public static String format(Date date, String pattern) {
            try {
                if (date == null || Str.isBlank(pattern)) {
                    return "";
                }
                return new SimpleDateFormat(pattern).format(date);
            } catch (Exception e) {
                return "";
            }
        }

        /**
         * 当前时间格式化。
         * 调用：String now = ExamKit.Datex.now("yyyy-MM-dd HH:mm:ss")
         */
        public static String now(String pattern) {
            return format(new Date(), pattern);
        }
    }

    /**
     * 简单线程工具，覆盖讲义里的 sleep/join/wait/notifyAll 常用模式。
     */
    public static final class Threadx {
        private Threadx() {
        }

        /**
         * 启动一个线程。
         * 调用：Thread t = ExamKit.Threadx.start(new Runnable(){ public void run(){...} })
         * 返回：失败返回 null。
         */
        public static Thread start(Runnable task) {
            try {
                if (task == null) {
                    return null;
                }
                Thread t = new Thread(task);
                t.start();
                return t;
            } catch (Exception e) {
                return null;
            }
        }

        /**
         * 线程睡眠，内部处理 InterruptedException。
         * 调用：ExamKit.Threadx.sleep(1000)
         */
        public static void sleep(long millis) {
            try {
                Thread.sleep(millis);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            } catch (Exception e) {
                // ignore
            }
        }

        /**
         * 等待一个线程结束。
         * 调用：ExamKit.Threadx.join(t)
         * 返回：成功 true，失败 false。
         */
        public static boolean join(Thread t) {
            try {
                if (t == null) {
                    return false;
                }
                t.join();
                return true;
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return false;
            } catch (Exception e) {
                return false;
            }
        }

        /**
         * 有界阻塞队列，生产者消费者模板。
         * 调用：
         * ExamKit.Threadx.BlockingBox<Integer> box = new ExamKit.Threadx.BlockingBox<Integer>(10);
         * box.put(1); Integer x = box.take();
         */
        public static final class BlockingBox<T> {
            private final Queue<T> queue = new LinkedList<T>();
            private final int capacity;

            public BlockingBox(int capacity) {
                this.capacity = capacity <= 0 ? 1 : capacity;
            }

            /**
             * 放入元素；队列满时等待。
             * 调用：box.put(value)
             * 返回：成功 true，被中断或异常 false。
             */
            public synchronized boolean put(T value) {
                try {
                    while (queue.size() >= capacity) {
                        wait();
                    }
                    queue.add(value);
                    notifyAll();
                    return true;
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    return false;
                } catch (Exception e) {
                    return false;
                }
            }

            /**
             * 取出元素；队列空时等待。
             * 调用：T value = box.take()
             * 返回：异常时返回 null。
             */
            public synchronized T take() {
                try {
                    while (queue.isEmpty()) {
                        wait();
                    }
                    T value = queue.remove();
                    notifyAll();
                    return value;
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    return null;
                } catch (Exception e) {
                    return null;
                }
            }

            public synchronized int size() {
                return queue.size();
            }
        }
    }

    /**
     * Socket 文本通信工具，适合讲义中的 echo server / calc server。
     */
    public static final class Net {
        private Net() {
        }

        /**
         * 发送一行文本并读取一行响应。
         * 调用：String r = ExamKit.Net.requestLine("127.0.0.1", 8888, "hello")
         * 返回：失败返回 null。
         */
        public static String requestLine(String host, int port, String message) {
            Socket socket = null;
            BufferedReader in = null;
            PrintWriter out = null;
            try {
                socket = new Socket(host, port);
                in = new BufferedReader(new InputStreamReader(socket.getInputStream(), UTF_8));
                out = new PrintWriter(new OutputStreamWriter(socket.getOutputStream(), UTF_8), true);
                out.println(message == null ? "" : message);
                return in.readLine();
            } catch (Exception e) {
                return null;
            } finally {
                Io.close(in);
                Io.close(out);
                Io.close(socket);
            }
        }

        /**
         * 启动一个简单的按行处理服务器。
         * 调用：
         * ExamKit.Net.startLineServer(8888, new ExamKit.Net.LineService() {
         *     public String handle(String line) { return line; }
         * });
         * 返回：服务端线程；失败返回 null。
         */
        public static Thread startLineServer(final int port, final LineService service) {
            if (service == null) {
                return null;
            }
            Thread t = new Thread(new Runnable() {
                public void run() {
                    ServerSocket server = null;
                    try {
                        server = new ServerSocket(port);
                        while (true) {
                            final Socket socket = server.accept();
                            Threadx.start(new Runnable() {
                                public void run() {
                                    handleClient(socket, service);
                                }
                            });
                        }
                    } catch (Exception e) {
                        // 服务器关闭或端口失败时退出。
                    } finally {
                        Io.close(server);
                    }
                }
            });
            try {
                t.setDaemon(true);
                t.start();
                return t;
            } catch (Exception e) {
                return null;
            }
        }

        /**
         * 计算形如 "1 + 2" 的表达式。
         * 调用：String r = ExamKit.Net.calcExpression("10 / 2")
         * 支持：+ - * /，整数 long；除 0 或格式错误返回 "error"。
         */
        public static String calcExpression(String expression) {
            try {
                if (Str.isBlank(expression)) {
                    return "error";
                }
                String[] p = expression.trim().split("\\s+");
                if (p.length != 3) {
                    return "error";
                }
                long a = Long.parseLong(p[0]);
                long b = Long.parseLong(p[2]);
                String op = p[1];
                if ("+".equals(op)) return String.valueOf(a + b);
                if ("-".equals(op)) return String.valueOf(a - b);
                if ("*".equals(op)) return String.valueOf(a * b);
                if ("/".equals(op)) return b == 0 ? "error" : String.valueOf(a / b);
                return "error";
            } catch (Exception e) {
                return "error";
            }
        }

        public interface LineService {
            String handle(String line);
        }

        private static void handleClient(Socket socket, LineService service) {
            BufferedReader in = null;
            PrintWriter out = null;
            try {
                in = new BufferedReader(new InputStreamReader(socket.getInputStream(), UTF_8));
                out = new PrintWriter(new OutputStreamWriter(socket.getOutputStream(), UTF_8), true);
                String line;
                while ((line = in.readLine()) != null) {
                    if ("bye".equalsIgnoreCase(line)) {
                        break;
                    }
                    String result = service.handle(line);
                    out.println(result == null ? "" : result);
                }
            } catch (Exception e) {
                // ignore
            } finally {
                Io.close(in);
                Io.close(out);
                Io.close(socket);
            }
        }
    }

    /**
     * 常用数学和数组小工具，不绑定具体作业题。
     */
    public static final class Algo {
        private Algo() {
        }

        /**
         * 判断质数。
         * 调用：boolean ok = ExamKit.Algo.isPrime(97)
         */
        public static boolean isPrime(long n) {
            if (n <= 1) return false;
            if (n <= 3) return true;
            if (n % 2 == 0 || n % 3 == 0) return false;
            for (long i = 5; i <= n / i; i += 6) {
                if (n % i == 0 || n % (i + 2) == 0) return false;
            }
            return true;
        }

        /**
         * 数组最小值。
         * 调用：int min = ExamKit.Algo.min(arr, 0)
         * 传参：defaultValue 是数组为空时返回的默认值。
         */
        public static int min(int[] arr, int defaultValue) {
            if (arr == null || arr.length == 0) {
                return defaultValue;
            }
            int min = arr[0];
            for (int x : arr) {
                if (x < min) min = x;
            }
            return min;
        }

        /**
         * 数组最大值。
         * 调用：int max = ExamKit.Algo.max(arr, 0)
         */
        public static int max(int[] arr, int defaultValue) {
            if (arr == null || arr.length == 0) {
                return defaultValue;
            }
            int max = arr[0];
            for (int x : arr) {
                if (x > max) max = x;
            }
            return max;
        }

        /**
         * 数组求和。
         * 调用：long sum = ExamKit.Algo.sum(arr)
         */
        public static long sum(int[] arr) {
            long sum = 0;
            if (arr != null) {
                for (int x : arr) sum += x;
            }
            return sum;
        }

        /**
         * 浮点数近似相等。
         * 调用：ExamKit.Algo.doubleEquals(a, b, 1e-6)
         */
        public static boolean doubleEquals(double a, double b, double eps) {
            return Math.abs(a - b) < Math.abs(eps);
        }
    }
}
