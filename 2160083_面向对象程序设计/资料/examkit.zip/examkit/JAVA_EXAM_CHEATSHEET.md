# Java 上机开卷速查小抄（讲义知识点导向 / JDK 1.8）

配套源码：[ExamKit.java](D:/Java_for_class/eclipse-workspace/HomeWork/src/com/huawei/classroom/student/examkit/ExamKit.java)

核心用法：

```java
import com.huawei.classroom.student.examkit.ExamKit;

String text = ExamKit.Io.readText("a.txt");
List<String> lines = ExamKit.Io.readLines("a.txt", "UTF-8");
Map<Character, Integer> count = ExamKit.Str.charCount("abca");
Object obj = ExamKit.Reflect.newObject("com.xxx.Apple");
```

> 这版不按作业题生成模板，主要按讲义知识点整理：String、集合、文件 IO、编码、反射、线程、Socket、日期、OOP 和泛型。

---

## 1. String / Character / StringBuilder

### 1.1 String 常用 API

```java
String s = " Hello Java ";

s.length();                 // 长度
s.charAt(0);                // 指定下标字符
s.substring(1);             // 从下标 1 到末尾
s.substring(1, 4);          // 左闭右开 [1,4)
s.trim();                   // 去掉首尾空白
s.toLowerCase();            // 小写
s.toUpperCase();            // 大写
s.contains("Java");         // 是否包含
s.startsWith(" H");         // 是否以某串开头
s.endsWith(" ");            // 是否以某串结尾
s.indexOf("a");             // 第一次出现位置
s.lastIndexOf("a");         // 最后一次出现位置
s.replace("Java", "JDK");   // 替换
s.split("\\s+");            // 正则拆分
s.matches("\\d+");          // 是否匹配正则
```

高频坑：

- 字符串内容比较用 `equals`，不要用 `==`。
- `substring(begin, end)` 的 `end` 不包含。
- `split(".")` 是错的，点号是正则通配符，要写 `split("\\.")`。
- `String` 不可变，大量拼接用 `StringBuilder`。

### 1.2 ExamKit 字符串工具

```java
ExamKit.Str.isBlank(s);                    // null、空串、全空白都 true
ExamKit.Str.trim(s);                       // null 安全 trim
ExamKit.Str.equals(a, b);                  // null 安全 equals
ExamKit.Str.charAt(s, 0, '\0');            // 安全取字符
ExamKit.Str.substring(s, 1, 3);            // 自动处理越界
ExamKit.Str.removeWhitespace(s);           // 去掉所有空白
ExamKit.Str.reverse(s);                    // 反转
ExamKit.Str.distinctChars("abca");         // "abc"
ExamKit.Str.splitToList("a,b,,c", ",");    // 拆分并过滤空白
ExamKit.Str.join(list, ",");               // 集合拼字符串
ExamKit.Str.countSubstring(text, key);      // 子串出现次数
ExamKit.Str.toInt(s, 0);                   // 安全转 int
```

### 1.3 Character 常用 API

```java
Character.isDigit(c);       // 数字
Character.isLetter(c);      // 字母
Character.isWhitespace(c);  // 空白
Character.isUpperCase(c);
Character.isLowerCase(c);
Character.toUpperCase(c);
Character.toLowerCase(c);
```

### 1.4 StringBuilder / StringBuffer

```java
StringBuilder sb = new StringBuilder();
sb.append("a");
sb.append(123);
sb.insert(1, "X");
sb.delete(1, 2);
sb.replace(0, 1, "B");
sb.reverse();
String r = sb.toString();
```

| 类 | 重点 |
|---|---|
| `String` | 不可变 |
| `StringBuilder` | 可变，非线程安全，单线程推荐 |
| `StringBuffer` | 可变，线程安全 |

---

## 2. 集合：List / Set / Map

### 2.1 List

```java
List<String> list = new ArrayList<String>();
list.add("a");
list.add(0, "b");
list.get(0);
list.set(0, "x");
list.remove(0);
list.remove("x");
list.size();
list.contains("a");
```

遍历：

```java
for (String x : list) {}

for (int i = 0; i < list.size(); i++) {
    String x = list.get(i);
}

Iterator<String> it = list.iterator();
while (it.hasNext()) {
    String x = it.next();
}
```

遍历时删除：

```java
Iterator<String> it = list.iterator();
while (it.hasNext()) {
    if (it.next().length() == 0) {
        it.remove();
    }
}
```

### 2.2 Set

```java
Set<String> a = new HashSet<String>();        // 去重，无序
Set<String> b = new LinkedHashSet<String>();  // 去重，保留插入顺序
Set<String> c = new TreeSet<String>();        // 去重，排序
```

自定义对象放入 `HashSet` 或作为 `HashMap` 的 key，通常要重写：

```java
public boolean equals(Object obj) { ... }
public int hashCode() { ... }
```

### 2.3 Map

```java
Map<String, Integer> map = new HashMap<String, Integer>();
map.put("a", 1);
map.get("a");
map.containsKey("a");
map.remove("a");
map.size();
```

遍历：

```java
for (String key : map.keySet()) {
    System.out.println(key + "=" + map.get(key));
}

for (Map.Entry<String, Integer> e : map.entrySet()) {
    System.out.println(e.getKey() + "=" + e.getValue());
}
```

### 2.4 ExamKit 统计和排序

统计集合元素次数：

```java
Map<String, Integer> count = ExamKit.Coll.count(list);
```

边遍历边统计：

```java
Map<String, Integer> map = new HashMap<String, Integer>();
for (String x : list) {
    ExamKit.Coll.addCount(map, x);
}
```

按 value 排序返回 Entry 列表：

```java
List<Map.Entry<String, Integer>> sorted =
    ExamKit.Coll.sortMapByValue(map, false); // false 降序，true 升序

for (Map.Entry<String, Integer> e : sorted) {
    System.out.println(e.getKey() + ":" + e.getValue());
}
```

按 value 排序只要 key：

```java
List<String> keys = ExamKit.Coll.keysSortedByValue(map, false);
```

取 value 最大的前 N 个：

```java
List<Map.Entry<String, Integer>> top = ExamKit.Coll.topNByValue(map, 10);
List<String> topKeys = ExamKit.Coll.topNKeysByValue(map, 10);
```

Set 排序成 List：

```java
List<String> list = ExamKit.Coll.sortSet(set, true);
```

Set 按出现次数/value 排序：Set 自己没有 value，先统计成 Map，再按 Map 的 value 排序。

```java
Map<String, Integer> count = ExamKit.Coll.count(listOrSet);
List<Map.Entry<String, Integer>> sorted = ExamKit.Coll.sortMapByValue(count, false);
```

集合去重并保留顺序：

```java
List<String> distinct = ExamKit.Coll.distinctKeepOrder(list);
```

---

## 3. Comparable / Comparator / 排序

### 3.1 Comparable：类自己定义排序规则

```java
class Student implements Comparable<Student> {
    String name;
    int score;

    public int compareTo(Student other) {
        int d = other.score - this.score; // 分数降序
        if (d != 0) return d;
        return this.name.compareTo(other.name); // 姓名升序
    }
}

Collections.sort(students);
```

### 3.2 Comparator：外部临时排序规则

```java
Collections.sort(students, new Comparator<Student>() {
    public int compare(Student a, Student b) {
        return b.score - a.score;
    }
});
```

JDK8 Lambda：

```java
students.sort((a, b) -> b.score - a.score);
```

---

## 4. 文件 IO / 编码 / 高效按行

### 4.1 File 常用方法

```java
File f = new File("a.txt");
f.exists();
f.isFile();
f.isDirectory();
f.getName();
f.getAbsolutePath();
f.length();
f.lastModified();
f.delete();

File dir = new File("out");
dir.mkdirs();
File[] files = dir.listFiles();
```

### 4.2 按行读取文本

讲义标准写法：

```java
try (BufferedReader br = new BufferedReader(
        new InputStreamReader(new FileInputStream("a.txt"), "UTF-8"))) {
    String line;
    while ((line = br.readLine()) != null) {
        System.out.println(line);
    }
} catch (Exception e) {
    e.printStackTrace();
}
```

ExamKit 快速写法：

```java
List<String> lines = ExamKit.Io.readLines("a.txt");          // 默认 UTF-8
List<String> lines2 = ExamKit.Io.readLines("a.txt", "GBK");  // 指定编码
```

大文件不要一次放入内存：

```java
ExamKit.Io.eachLine("a.txt", new ExamKit.Io.LineHandler() {
    public void handle(String line, int lineNo) {
        System.out.println(lineNo + ":" + line);
    }
});
```

### 4.3 写文本

```java
ExamKit.Io.writeText("out/a.txt", "hello");          // 覆盖写，UTF-8
ExamKit.Io.appendText("out/a.txt", "world\n");       // 追加写，UTF-8
ExamKit.Io.writeLines("out/a.txt", lines);           // 每个元素一行
ExamKit.Io.writeText("out/a.txt", text, "GBK", true); // 指定编码，追加
```

### 4.4 字节流：复制图片/任意文件

```java
boolean ok = ExamKit.Io.copyFile("a.jpg", "out/a.jpg");
byte[] bytes = ExamKit.Io.readBytes("a.bin");
ExamKit.Io.writeBytes("b.bin", bytes);
```

### 4.5 配置文件

读取 `key=value`：

```java
Map<String, String> cfg = ExamKit.Io.readKeyValue("config.ini");
String port = cfg.get("port");
```

读取 `类名.属性=值`：

```java
Map<String, Map<String, String>> cfg = ExamKit.Io.readDottedConfig("config.ini");
Map<String, String> appleProps = cfg.get("com.xxx.Apple");
```

### 4.6 编码乱码

乱码根源：写入时的编码和读取时的编码不一致。

常见编码：

| 编码 | 特点 |
|---|---|
| ASCII | 英文基础字符 |
| ISO-8859-1 | 西欧字符，不能表示中文 |
| GB2312/GBK | 中文常见编码 |
| UTF-8 | 推荐，跨平台常用 |
| UTF-16 | Java 内部字符相关常见 |

考试建议：读写文本都显式指定 `"UTF-8"`。

---

## 5. 反射 / 动态调用 / 配置创建对象

### 5.1 核心类

```java
Class<?> clazz = Class.forName("com.xxx.Apple");
Constructor<?> c = clazz.getDeclaredConstructor();
Object obj = c.newInstance();

Method m = clazz.getMethod("setColor", String.class);
m.invoke(obj, "red");

Field f = clazz.getDeclaredField("color");
f.setAccessible(true);
Object value = f.get(obj);
```

### 5.2 ExamKit 快速创建对象

```java
Object obj = ExamKit.Reflect.newObject("com.xxx.Apple");
Apple apple = ExamKit.Reflect.newObject(Apple.class);
Object obj2 = ExamKit.Reflect.newObject("com.xxx.Apple", "red", 100);
```

失败都返回 `null`，不会抛异常。

### 5.3 快速调用方法

```java
ExamKit.Reflect.invoke(obj, "setColor", "red");
Object color = ExamKit.Reflect.invoke(obj, "getColor");
Object max = ExamKit.Reflect.invokeStatic("java.lang.Math", "max", 1, 2);
```

### 5.4 快速读写属性

优先走 getter/setter，找不到再直接读写字段：

```java
ExamKit.Reflect.setProperty(obj, "color", "red");
Object color = ExamKit.Reflect.getProperty(obj, "color");
```

直接字段：

```java
ExamKit.Reflect.setField(obj, "age", 18);
Object age = ExamKit.Reflect.getField(obj, "age");
```

批量注入：

```java
Map<String, Object> props = new HashMap<String, Object>();
props.put("color", "red");
props.put("weight", 500);

Object apple = ExamKit.Reflect.createAndSet("com.xxx.Apple", props);
```

### 5.5 配置文件创建对象

配置：

```text
com.xxx.Apple.color=red
com.xxx.Apple.weight=500
```

调用：

```java
Object apple = ExamKit.Reflect.createFromDottedConfig(
    "config.ini",
    "com.xxx.Apple"
);
```

类型转换支持：

- `String`
- `int / Integer`
- `long / Long`
- `double / Double`
- `float / Float`
- `boolean / Boolean`
- `char / Character`
- `enum`

---

## 6. Object / equals / hashCode / toString

### 6.1 equals 和 hashCode

自定义类用于去重、HashSet、HashMap key 时：

```java
public boolean equals(Object obj) {
    if (this == obj) return true;
    if (!(obj instanceof Student)) return false;
    Student other = (Student) obj;
    if (id == null) return other.id == null;
    return id.equals(other.id);
}

public int hashCode() {
    return id == null ? 0 : id.hashCode();
}
```

规则：

- `equals` 相等，`hashCode` 必须相等。
- `hashCode` 相等，`equals` 不一定相等。
- 重写 `equals` 通常也重写 `hashCode`。

### 6.2 toString

```java
public String toString() {
    return "Student{name='" + name + "', score=" + score + "}";
}
```

---

## 7. 面向对象：继承 / 接口 / 多态

### 7.1 继承和抽象类

```java
abstract class Animal {
    private String name;
    public Animal(String name) { this.name = name; }
    public abstract String speak();
}

class Dog extends Animal {
    public Dog(String name) { super(name); }
    public String speak() { return "wang"; }
}
```

### 7.2 接口分离

```java
interface Flyable { String fly(); }
interface Swimmable { String swim(); }
interface Speakable { String speak(); }
```

哪个类有哪个能力，就实现哪个小接口。不要写一个巨大接口让所有类被迫实现无关方法。

### 7.3 多态和类型转换

```java
Animal a = new Dog("d"); // 向上转型，安全
a.speak();              // 调用真实对象 Dog 的 speak

if (a instanceof Dog) {
    Dog d = (Dog) a;     // 向下转型前先判断
}
```

---

## 8. 泛型

### 8.1 泛型类和泛型方法

```java
class Box<T> {
    private T value;
    public void set(T value) { this.value = value; }
    public T get() { return value; }
}
```

```java
public static <T> T first(List<T> list) {
    return list == null || list.isEmpty() ? null : list.get(0);
}
```

### 8.2 通配符

```java
// 主要读取：extends
public static double sum(List<? extends Number> list) {
    double s = 0;
    for (Number n : list) s += n.doubleValue();
    return s;
}

// 主要写入：super
public static void addInts(List<? super Integer> list) {
    list.add(1);
    list.add(2);
}
```

口诀：`Producer Extends, Consumer Super`。

泛型不变性：

```java
List<String> a = new ArrayList<String>();
// List<Object> b = a; // 错
List<? extends Object> c = a; // 可读，不方便写
```

---

## 9. Iterator / for-each

`for-each` 可用于数组和实现 `Iterable` 的集合：

```java
for (String s : list) {}
for (int x : arr) {}
```

Map 不是 `Iterable`，遍历 Map 用：

```java
for (Map.Entry<String, Integer> e : map.entrySet()) {}
```

Iterator 注意点：`next()` 会消耗一个元素，不要在一次循环里乱调多次。

---

## 10. 多线程

### 10.1 创建线程

```java
new Thread(new Runnable() {
    public void run() {
        System.out.println("run");
    }
}).start();
```

JDK8：

```java
new Thread(() -> System.out.println("run")).start();
```

### 10.2 ExamKit 线程工具

```java
Thread t = ExamKit.Threadx.start(new Runnable() {
    public void run() {
        System.out.println("task");
    }
});

ExamKit.Threadx.join(t);
ExamKit.Threadx.sleep(1000);
```

生产者消费者：

```java
ExamKit.Threadx.BlockingBox<Integer> box =
    new ExamKit.Threadx.BlockingBox<Integer>(10);

box.put(1);
Integer x = box.take();
```

### 10.3 synchronized / wait / notifyAll

```java
public synchronized void add() {
    count++;
}
```

```java
public synchronized void put(Object x) throws InterruptedException {
    while (full) {
        wait();
    }
    // 放入
    notifyAll();
}
```

重点：

- `wait()` 必须在 `synchronized` 内。
- 条件判断用 `while`。
- 多生产者/消费者优先 `notifyAll()`。

---

## 11. Socket 网络编程

### 11.1 客户端

```java
try (Socket socket = new Socket("127.0.0.1", 8888);
     BufferedReader in = new BufferedReader(
         new InputStreamReader(socket.getInputStream(), "UTF-8"));
     PrintWriter out = new PrintWriter(
         new OutputStreamWriter(socket.getOutputStream(), "UTF-8"), true)) {

    out.println("hello");
    String r = in.readLine();
}
```

ExamKit：

```java
String r = ExamKit.Net.requestLine("127.0.0.1", 8888, "hello");
```

### 11.2 服务端

```java
ExamKit.Net.startLineServer(8888, new ExamKit.Net.LineService() {
    public String handle(String line) {
        return line; // echo
    }
});
```

简单计算：

```java
String r = ExamKit.Net.calcExpression("10 + 20"); // "30"
```

---

## 12. Lambda / 函数式接口

常用接口：

| 接口 | 方法 | 含义 |
|---|---|---|
| `Consumer<T>` | `accept(T)` | 消费一个值 |
| `Supplier<T>` | `get()` | 提供一个值 |
| `Function<T,R>` | `apply(T)` | T 转 R |
| `Predicate<T>` | `test(T)` | 判断 |
| `BiFunction<T,U,R>` | `apply(T,U)` | 两参转结果 |

```java
list.forEach(x -> System.out.println(x));
map.forEach((k, v) -> System.out.println(k + "=" + v));
list.removeIf(x -> x.length() == 0);
list.sort((a, b) -> a.compareTo(b));
list.forEach(System.out::println);
```

---

## 13. 日期

```java
Date d = ExamKit.Datex.parse("2026-06-20", "yyyy-MM-dd");
String s = ExamKit.Datex.format(new Date(), "yyyy-MM-dd HH:mm:ss");
String now = ExamKit.Datex.now("yyyy-MM-dd HH:mm:ss");
```

格式符：

| 符号 | 含义 |
|---|---|
| `yyyy` | 年 |
| `MM` | 月 |
| `dd` | 日 |
| `HH` | 24小时 |
| `mm` | 分 |
| `ss` | 秒 |

---

## 14. 快速定位 ExamKit API

| 需求 | API |
|---|---|
| 字符串判空 | `ExamKit.Str.isBlank` |
| 安全 substring | `ExamKit.Str.substring` |
| 去空白 | `ExamKit.Str.removeWhitespace` |
| 字符统计 | `ExamKit.Str.charCount` |
| 单词统计 | `ExamKit.Str.wordCount` |
| 子串统计 | `ExamKit.Str.ngramCount` |
| 集合元素计数 | `ExamKit.Coll.count` |
| Map 按 value 排序 | `ExamKit.Coll.sortMapByValue` |
| Map value 前 N | `ExamKit.Coll.topNByValue` |
| Set 排序为 List | `ExamKit.Coll.sortSet` |
| 按行读文件 | `ExamKit.Io.readLines` |
| 大文件逐行处理 | `ExamKit.Io.eachLine` |
| 写文本 | `ExamKit.Io.writeText` |
| 写多行 | `ExamKit.Io.writeLines` |
| 复制文件 | `ExamKit.Io.copyFile` |
| 读配置 | `ExamKit.Io.readKeyValue` |
| 创建对象 | `ExamKit.Reflect.newObject` |
| 调用方法 | `ExamKit.Reflect.invoke` |
| setter 注入 | `ExamKit.Reflect.setProperty` |
| 配置创建对象 | `ExamKit.Reflect.createFromDottedConfig` |
| 启动线程 | `ExamKit.Threadx.start` |
| 生产者消费者 | `ExamKit.Threadx.BlockingBox` |
| Socket 请求 | `ExamKit.Net.requestLine` |
| Socket 服务端 | `ExamKit.Net.startLineServer` |
