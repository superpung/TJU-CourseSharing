# examkit 使用说明

本目录是为 Java 上机开卷考试准备的讲义知识点速查包，全部适配 JDK 1.8。

## 文件

- `JAVA_EXAM_CHEATSHEET.md`：按讲义知识点组织的小抄，适合 `Ctrl+F` 搜索。
- `ExamKit.java`：单文件工具类，重点覆盖 String、集合统计排序、文件高效读写、编码、反射创建对象/调用方法、线程、Socket、日期等通用能力。

## 推荐用法

1. 考试先打开 `JAVA_EXAM_CHEATSHEET.md` 搜关键词。
2. 需要完整函数时，打开 `ExamKit.java`，复制对应内部类的方法。公开函数基本都已内部 `try-catch`，失败返回空集合、默认值、`false` 或 `null`。
3. 如果允许直接带源码工程，可以保留包名：

```java
import com.huawei.classroom.student.examkit.ExamKit;
```

4. 如果题目要求固定包名，把 `ExamKit.java` 复制到题目包下，并把第一行 `package ...;` 改成题目包名。
5. `ExamKit.java` 带中文注释，建议用 UTF-8 打开和复制。

## 编译检查

已使用：

```bash
javac --release 8 -encoding UTF-8 -d <temp> examkit/ExamKit.java
```

检查通过。新版 `javac` 会提示 `--release 8` 过时警告，不影响 JDK 1.8 兼容。
