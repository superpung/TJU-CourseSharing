package ch07.list;

import java.util.ArrayList;
import java.util.List;

/**
 * List 加入和输出的顺序相同，这点和Set不同  
 * @author Administrator
 *
 */
public class ListDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List list=new ArrayList();
		list.add("a");
		list.add("b");
		list.add("a");
		for(int i=0;i<list.size();i++) {
			System.out.println(list.get(i));
		}
	}

}
