package ch07.list;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * 本例子演示了如何对List中的对象进行排序
 * @author Administrator
 *
 */
public class SortList {	

	public SortList() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List  list=new ArrayList ();
		list.add(12);
		list.add(34);
		list.add(11);
		Collections.sort(list);		 
		for(int i=0;i<list.size();i++) {
			System.out.println(list.get(i));
		}
	}

}
