package ch07.comparator;

import java.util.ArrayList;
import java.util.List;

import ch07.Student;
import ch07.set.EnumField;
import ch07.set.EnumOrder;
import ch07.set.StudentComparator;

/**
 * 本例子演示了如何对List中的对象进行排序
 * @author Administrator
 *
 */
public class SortListDemoComparator {	

	public SortListDemoComparator() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Student> list=new ArrayList<Student>();
		list.add(new Student("009","liu",500,178));
		list.add(new Student("008","wang",510,160));
		list.add(new Student("003","li",520,171));
		list.sort(new StudentComparator(EnumField.id,EnumOrder.asc));
		for(int i=0;i<list.size();i++) {
			System.out.println(list.get(i));
		}
	}

}
