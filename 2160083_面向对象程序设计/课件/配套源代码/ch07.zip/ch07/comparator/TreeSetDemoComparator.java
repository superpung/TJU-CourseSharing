package ch07.comparator;

import java.util.HashSet;
import java.util.Hashtable;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

import ch07.Student;
import ch07.bak.Dog;
import ch07.set.EnumField;
import ch07.set.EnumOrder;
import ch07.set.StudentComparator;

public class TreeSetDemoComparator {

	public TreeSetDemoComparator() {
		// TODO Auto-generated constructor stub
	}
 

	public static void main (String[] args) {
		// TODO Auto-generated method stub
		Set<Student> set = new TreeSet<Student>(new StudentComparator(EnumField.id,EnumOrder.asc));
		set.add(new Student("01", "zhang"));
		set.add(new Student("03", "zhang"));	
		set.add(new Student("02", "zhang"));	
		Student[] ds =   set.toArray(new Student[0] );
		for (int i = 0; i < ds.length; i++) {
			System.out.println(ds[i]  );
		}

	}

}
