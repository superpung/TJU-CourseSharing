package ch07.it;

/**
 * 本例子演示了Iterator的用法
 */
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

 

public class IteratorDemo {

	public IteratorDemo() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List list=new ArrayList();
		addObject(list);
		itColleciton(list);
		
		Set  set=new HashSet();
		addObject(set);
		//留意 itColleciton(set) 和 itColleciton(list) 区别
		itColleciton(set);

	}
	public static void addObject(Collection collection) {
		collection.add("天津");
		collection.add("大学");
	}
	public static void itColleciton(Collection collection) {
		Iterator it=collection.iterator();
		while(it.hasNext()) {
			System.out.println(it.next());
		}
	}

}
