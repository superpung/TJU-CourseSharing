package ch07.map;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

/**
 * 本例子演示了TreeMap和HashMap区别
 * @author Administrator
 *
 */
public class HashMapTreeMap {
	Comparable c;
	public static void main(String[] args) {
		testMap(new HashMap());
		System.out.println("=====================");
		testMap(new TreeMap());
	}
	public static void testMap(Map map) {
		map.put("zhang", 10);
		map.put("li", 20);
		map.put("wan", 30);
		map.put("an", 40);
		Iterator it = map.keySet().iterator();
		while (it.hasNext()) {			 
			Object key = it.next();
			Object value = map.get(key);
			System.out.println(key + " " + value);
		}
	}

}
