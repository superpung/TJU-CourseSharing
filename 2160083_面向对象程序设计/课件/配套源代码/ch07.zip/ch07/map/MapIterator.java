package ch07.map;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * Map Set综合使用的例子
 * 
 * @author cjy
 *
 */
public class MapIterator {

	public static void main(String[] args) {
		String str = "China will strengthen international cooperation on novel coronavirus epidemic control and continue to provide assistance within its ability to countries affected by the epidemic, Xi Jinping, general secretary of the Communist Party of China Central Committee, said on Wednesday.";

		String freq = getFrequentWord(str);
		System.out.println(freq);

	}

	public static String getFrequentWord(String content) {
		Map map = new HashMap();
		String[] words=content.split(" ");
		for(int i=0;i<words.length;i++) { 
			String word = words[i];
			int count = 0;
			if (map.containsKey(word)) {
				count = (Integer) map.get(word);
			}
			map.put(word, count + 1);
		}
		Iterator it = map.keySet().iterator();
		int maxCount = 0;
		String maxKey = "";
		while (it.hasNext()) {
			String key = (String) it.next();
			if ((Integer) map.get(key) > maxCount) {
				maxKey = key;
				maxCount = (Integer) map.get(key);
			}
		}
		System.out.println(maxKey+"="+maxCount);
		return maxKey;
	}
}
