
package ch07;

public class Test {

	public Test() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Integer i1 = Integer.valueOf(1127);
		Integer i2 = Integer.valueOf(1127);
		System.out.println(i1 == i2);
		StringBuffer buf = new StringBuffer("0123");
		buf.replace(1, 2, "");
		System.out.println(buf.toString());
	}

}
