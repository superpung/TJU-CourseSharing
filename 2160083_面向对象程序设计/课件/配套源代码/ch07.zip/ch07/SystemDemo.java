/**
 * 
 */
package ch07;

import java.util.Iterator;
import java.util.Properties;

/**
 * 本例子演示了System的一些方法
 * @author Administrator
 *
 */
public class SystemDemo {

	/**
	 * 
	 */
	public SystemDemo() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Properties prop = System.getProperties();
		Iterator it = prop.keySet().iterator();
		while (it.hasNext()) {
			String key = (String) it.next();
			System.out.println(key + "=" + prop.getProperty(key) );
		}
	}

}
