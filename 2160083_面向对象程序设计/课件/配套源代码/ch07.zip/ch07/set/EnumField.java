package ch07.set;
/**
 * 枚举类型
 * @author cjy
 *
 */
public enum EnumField {
	id,name,score,height
}
