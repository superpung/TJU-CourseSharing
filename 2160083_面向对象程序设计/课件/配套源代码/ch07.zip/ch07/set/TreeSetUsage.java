package ch07.set;

import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

public class TreeSetUsage {

	public TreeSetUsage() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		Set set = new TreeSet();
		String content = "China will strengthen international cooperation on novel coronavirus epidemic control and continue to provide assistance within its ability to countries affected by the epidemic, Xi Jinping, general secretary of the Communist Party of China Central Committee, said on Wednesday.";
		String[] words = content.split(" ");
		for (int i = 0; i < words.length; i++) {
			String word = words[i];
			set.add(words[i]);
		}
		Iterator it = set.iterator();
		while (it.hasNext()) {
			System.out.println(it.next());

		}

	}

}
