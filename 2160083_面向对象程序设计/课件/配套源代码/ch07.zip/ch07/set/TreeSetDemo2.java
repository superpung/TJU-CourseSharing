package ch07.set;

import java.util.HashSet;
import java.util.Hashtable;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

import ch07.Student;
import ch07.bak.Dog;

public class TreeSetDemo2 {

	public TreeSetDemo2() {
		// TODO Auto-generated constructor stub
	}
 

	public static void main (String[] args) {
		// TODO Auto-generated method stub
		Set set = new TreeSet();
		set.add(new Student("01", "zhang"));
		set.add(new Student("03", "zhang"));	
		set.add(new Student("02", "zhang"));	
		Object[] ds =   set.toArray( );
		for (int i = 0; i < ds.length; i++) {
			System.out.println(ds[i].toString()); 
		}

	}

}
