package ch07.set;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import ch07.Student;

/**
 * 本例子演示了Student中 hashCode equals方法的重要性
 * @author Administrator
 *
 */
public class SetHashCodeEqDemo {

	public SetHashCodeEqDemo() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Set set = new HashSet();
		Student st1=new Student("01", "zhang");
		Student st2=new Student("01", "zhang");
//		System.out.println(st1.hashCode());
//		System.out.println(st2.hashCode());
		set.add(st1);
		set.add(st2); 
		
		printSet(set);
	}

	public static void printSet(Set set) {
		// 遍历一个set的方法
		System.out.println(set.size());
		Iterator it = set.iterator();
		while (it.hasNext()) {
			System.out.println(it.next());
		}
	}

}
