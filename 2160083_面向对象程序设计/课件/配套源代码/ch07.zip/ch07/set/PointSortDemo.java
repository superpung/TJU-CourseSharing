package ch07.set;

import java.util.Set;
import java.util.TreeSet;

public class PointSortDemo {
	public PointSortDemo() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		Set s = new TreeSet();
		
		s.add(new Point(2, 1));
		s.add(new Point(1, 1));
		s.add(new Point(2, 2));
		s.add(new Point(1, 2));
		Point[] ps = (Point[]) s.toArray(new Point[0]);
		for (int i = 0; i < ps.length; i++) {
			System.out.println(ps[i].toString());
		}
	}
}

class Point implements Comparable {
	private int x;
	private int y;

	public Point(int x, int y) {
		this.x = x;
		this.y = y;
	}

	public String toString() {
		return "<" + x + "," + y + ">";
	}

	public int compareTo(Object obj) {
		if (obj instanceof Point) {
			Point p = (Point) obj;
			return (x * x + y * y) - (p.x * p.x + p.y * p.y);
		} else {
			return -1;
		}
	}
}