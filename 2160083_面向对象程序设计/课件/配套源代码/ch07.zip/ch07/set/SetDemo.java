package ch07.set;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

/**
 * 本例子演示了如何使用set
 * 
 * @author cjy
 *
 */
public class SetDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Set set = new HashSet();
		String str = "我是天津大学一名学生";
		char[] chars = str.toCharArray();
		for (int i = 0; i<chars.length; i++) {
			set.add(chars[i]);
		}
		System.out.println("不同字符数量： " + set.size());

		printSet(set);
	}

	public static void printSet(Set set) {
		// 遍历一个set的方法
		 
		Iterator it = set.iterator();
		while (it.hasNext()) {
			System.out.print(it.next());
		}
	}

}
