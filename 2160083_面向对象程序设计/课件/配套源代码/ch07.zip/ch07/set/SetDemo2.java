package ch07.set;

import java.util.HashSet;
import java.util.Set;
import java.util.StringTokenizer;

public class SetDemo2 {

	public SetDemo2() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Set set = new HashSet();
		String str = "China will strengthen international cooperation on novel coronavirus epidemic control and continue to provide assistance within its ability to countries affected by the epidemic, Xi Jinping, general secretary of the Communist Party of China Central Committee, said on Wednesday.";
		String[] strs=str.split(" ");
		for(int i=0;i<strs.length;i++) {
			set.add(strs[i]);
			System.out.println(strs[i]);
		}
		 
		System.out.println("不同单词数量： " + set.size());

		 
	}

}
