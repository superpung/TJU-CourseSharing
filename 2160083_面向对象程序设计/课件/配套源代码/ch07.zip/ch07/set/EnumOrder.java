package ch07.set;

/*
 * 枚举类型
 */
public enum EnumOrder {
	asc,desc
}
