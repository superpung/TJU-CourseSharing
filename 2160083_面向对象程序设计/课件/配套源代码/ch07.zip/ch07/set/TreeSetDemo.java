package ch07.set;

import java.util.HashSet;
import java.util.Hashtable;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

import ch07.Student;
import ch07.bak.Dog;

public class TreeSetDemo {

	public TreeSetDemo() {
		// TODO Auto-generated constructor stub
	}
 

	public static void main (String[] args) {
		// TODO Auto-generated method stub
		Set set = new TreeSet();
		set.add(0);
		set.add(5);
		set.add(2);
		set.add(01);
		
		Object[] ds =   set.toArray( );
		for (int i = 0; i < ds.length; i++) {
			System.out.println(ds[i]);

		}

	}

}
