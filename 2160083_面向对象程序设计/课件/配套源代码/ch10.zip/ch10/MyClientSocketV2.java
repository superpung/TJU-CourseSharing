package ch10;

import java.io.PrintWriter;
import java.net.Socket;

public class MyClientSocketV2 {
	public static void main(String[] args) {
		Socket client = null;
		PrintWriter out = null;
		try {
			// 获得远程连接
			client = new Socket("127.0.0.1", Config.PORT);
			System.out.println("connection " + client.getInetAddress().toString() + " port=" + Config.PORT + " ok!");

			// 获得输出Writer
			out = new java.io.PrintWriter(client.getOutputStream());
			for (int i = 0; i < 10; i++) {
				Thread.sleep(1000);
				String line = "I say " + i;
				System.out.println("From client:" + line);
				// 向writer中写数据
				out.write(line + "\r\n");
				out.flush();
			}

			out.write(Config.BYE);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		} finally {
			MyUtil.close(out);
			MyUtil.close(client);

		}
	}
}
