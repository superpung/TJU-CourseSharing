package ch10;

import java.io.OutputStream;
import java.net.Socket;

/**
 * 本例子和 演示了 ch10.MyServerSocketV1配合，演示了如何使用socket 获得 OutputStream,
 * 需要在命令行模式下，将当前目录切换到 bin目录下 执行 java ch10.MyServerSocketV1 再打开一个命令行模式，将当前目录切换到
 * bin目录下 执行 java ch10.MyClientV1
 * 
 * @author Administrator
 *
 */
public class MyClientSocketV1 {

	public MyClientSocketV1() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		Socket client = null;
		OutputStream out = null;
		try {
			// 构建远程连接
			client = new Socket("127.0.0.1", Config.PORT);
			System.out.println("connection " + client.getInetAddress().toString() + " port=" + Config.PORT + " ok!");
			// 获得输出流
			out = client.getOutputStream();
			for (int i = 0; i < 10; i++) {
				Thread.sleep(1000);
				String line = "I say " + i;
				System.out.println("From client:" + line);
				// 向输出流中写
				out.write(line.getBytes());
				out.flush();
			}
			out.write(Config.BYE.getBytes());
			out.close();
			client.close();
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		} finally {
			MyUtil.close(out);
			MyUtil.close(client);
		}
	}
}
