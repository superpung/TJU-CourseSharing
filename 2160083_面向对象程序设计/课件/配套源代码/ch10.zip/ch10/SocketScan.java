package ch10;

import java.io.IOException;
import java.net.Socket;

public class SocketScan {

	public SocketScan() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		//远程的地址，可以是IP 地址，也可以是域名
		String address = "www.163.com";
		for (int port = 80; port < 10000; port++) {
			Socket socket =null;
			try {
				System.out.println("scan "+address +":" + port);
				socket = new Socket(address, port);	
				//远程主机名
				System.out.println("hostname=" + socket.getInetAddress().getHostName());
				//远程地址
				System.out.println("ip=" + socket.getInetAddress().getHostAddress());				
				System.out.println(address + " listen on port:" + port);
			} catch (IOException e) {
				System.out.println(address + " port=" + port + " connect error:" + e);
			}finally {
				if(socket!=null) {
					try {
						socket.close();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
		}
	}

}
