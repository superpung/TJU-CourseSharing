package ch10;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class MyServerSocketV3 {
	public static void main(String[] args) {
		ServerSocket server = null;
		try {
			server = new ServerSocket(Config.PORT);
			System.out.println("server listen on port:" + Config.PORT + " ok!");
			while (true) {
				Socket socket = server.accept(); // 等待客户端连接，注意这种方式，可以和多个客户端建立连接
				System.out.println("client " + socket.getInetAddress() + " connect ok!");
				new ServerThread(socket).start();
			}
		} catch (IOException e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		} finally {
			MyUtil.close(server);
		}
	}
}
