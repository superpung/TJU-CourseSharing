package ch10;

public class Config {
	public static int PORT = 5555;
	public static String BYE = "bye";
	public static int MAX_LEN = 100;
}
