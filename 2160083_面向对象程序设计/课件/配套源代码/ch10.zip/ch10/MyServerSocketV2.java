package ch10;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;

public class MyServerSocketV2 {
	public static void main(String[] args) {
		ServerSocket server =null;
		Socket socket =null;
		BufferedReader in=null;
		try {
			 server = new ServerSocket(Config.PORT);
			System.out.println("server listen on port:" + Config.PORT + " ok!");
			 socket = server.accept(); // 等待客户端连接，只能和一个客户端连接
			 in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			String line = in.readLine();
			while (!Config.BYE.equals(line)) {
				System.out.println("From server received: " + line);
				line = in.readLine();
			}
		 
		} catch (IOException e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}finally {
			MyUtil.close(in);			
			MyUtil.close(socket); 
			MyUtil.close(server);
		}
	}
}
