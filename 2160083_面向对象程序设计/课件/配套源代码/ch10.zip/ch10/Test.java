/**
 * 
 */
package ch10;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;

/**
 * @author cjy
 *
 */
public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ServerSocket s;
		Socket s2;
	}

	public void test() throws UnknownHostException, IOException {
		
	}

}
