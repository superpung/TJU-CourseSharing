package ch11;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;

public class DynamicField {
	public static void main(String[] args) {
		Object obj = new StudentPublic("jack", 123);
		try {
			dynamicField(obj, "name", "tom");
			System.out.println(((StudentPublic) obj).getName());
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
	}
	public static void dynamicField(Object obj, String fieldName, Object value) throws IllegalAccessException,
			IllegalArgumentException, InvocationTargetException, NoSuchMethodException, SecurityException, NoSuchFieldException {
		//取得所有public类型的属性
		Field field = obj.getClass().getField(fieldName);
		//直接设置属性值
		field.set(obj, value);
	}
}
