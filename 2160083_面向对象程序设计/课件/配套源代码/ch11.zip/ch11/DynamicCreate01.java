package ch11;

/**
 * 本例子演示了如何动态构建
 * 
 * @author cjy
 *
 */
public class DynamicCreate01 {

	public static void main(String[] args) {
		try {
			//要动态创建的类的全名
			String className = "ch11.Student";
			Class clazz = Class.forName(className);
			//实例化，本例子要求"ch11.Student"必须有无参数的构造方法。
			Object obj = clazz.newInstance();
			Student student = (Student) obj;
			System.out.println("obj.class=" + obj.getClass().toString());
			System.out.println("student.class=" + student.getClass().toString());
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
	}

}
