package ch11;

import java.lang.reflect.InvocationTargetException;

/**
 * 本例子演示了如何动态构建
 * 
 * @author cjy
 *
 */
public class DynamicCreate04 {

	public static void main(String[] args) {
		try {
			String className = "ch11.Student";
			//用变长参数调用
			Object obj = createObject4(className, "aaa", 456);
			Student student = (Student) obj;
			System.out.println("obj.class=" + obj.getClass().toString());
			System.out.println("student.class=" + student.getClass().toString());

		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
	}
	public static Object createObject4(String className, Object... values)
			throws ClassNotFoundException, InstantiationException, IllegalAccessException, IllegalArgumentException,
			InvocationTargetException, NoSuchMethodException, SecurityException {
		Class clazz = Class.forName(className);
		Class[] classes = new Class[values.length];
		for (int i = 0; i < classes.length; i++) {
			classes[i] = values[i].getClass();
		}
		Object obj = clazz.getConstructor(classes).newInstance(values);
		return obj;
	}

}
