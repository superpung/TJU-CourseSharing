package ch11;

import java.lang.reflect.InvocationTargetException;

/**
 * 本例子演示了如何动态构建
 * 
 * @author cjy
 *
 */
public class DynamicCreate02 {
	public static void main(String[] args) {
		try {
			String className = "ch11.Student";
			Class clazz = Class.forName(className);
			//动态构造的另外一种方法，这种方法和DynamicCreate01类似
			Object obj = clazz.getConstructor(new Class[0]).newInstance();
			Student student = (Student) obj;
			System.out.println("obj.class=" + obj.getClass().toString());
			System.out.println("student.class=" + student.getClass().toString());
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
	}
}
