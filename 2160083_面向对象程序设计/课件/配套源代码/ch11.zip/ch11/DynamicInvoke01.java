package ch11;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/**
 * 这个例子展示了如何动态的调用一个带有参数的方法
 * 
 * @author cjy
 *
 */
public class DynamicInvoke01 {
	public static void main(String[] args) {
		Student student = new Student("jack", 123);
		try {			
			System.out.println(dynamicInvokeMethod(student,"getName"));
			Object result=dynamicInvokeMethod(student, "getName");
			System.out.println(result);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
	}

	public static Object dynamicInvokeMethod(Object obj, String methodName) throws IllegalAccessException,
			InvocationTargetException, NoSuchMethodException, SecurityException {
		Method method = obj.getClass().getMethod(methodName);
		return method.invoke(obj);
	}

}
