package ch11;

import java.lang.reflect.InvocationTargetException;

/**
 * 本例子演示了如何动态构建
 * 
 * @author cjy
 *
 */
public class DynamicCreate03 {

	public static void main(String[] args) {
		try {
			String className = "ch11.Student";
			Class clazz = Class.forName(className);
			Class[] classes = new Class[2];
			classes[0] = String.class;
			classes[1] = Integer.class;
			// clazz.getConstructor(classes) 寻找Student的带有参数的构造函数
			// 且构造函数的第一个是参数String,第二个是Integer。
			// .newInstance("tom", 123)： 用"tom", 123 实例化
			Object obj = clazz.getConstructor(classes).newInstance("tom", 123);
			Student student = (Student) obj;
			System.out.println("obj.class=" + obj.getClass().toString());
			System.out.println("student.class=" + student.getClass().toString());
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
	}

}
