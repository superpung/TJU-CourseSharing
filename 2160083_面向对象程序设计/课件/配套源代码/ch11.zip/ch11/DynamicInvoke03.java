package ch11;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/**
 * 这个例子展示了如何动态调用带有原始数据类型的函数
 * 
 * @author cjy
 *
 */
public class DynamicInvoke03 {
	public static void main(String[] args) {
		StudentPrime student = new StudentPrime("jack", 123);
		try {
			dynamicInvokeMethod1(student, "setAge", 20);
			dynamicInvokeMethod2(student, "setAge", 20);
			System.out.println(student.getAge());
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
	}

	/**
	 * 这个方法是错误的，无法调用原始数据类型的方法
	 * @param obj
	 * @param methodName
	 * @param values
	 * @return
	 * @throws IllegalAccessException
	 * @throws IllegalArgumentException
	 * @throws InvocationTargetException
	 * @throws NoSuchMethodException
	 * @throws SecurityException
	 * @throws ClassNotFoundException
	 */
	public static Object dynamicInvokeMethod1(Object obj, String methodName, Object... values)
			throws IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException,
			SecurityException, ClassNotFoundException {
		Class[] classes = new Class[values.length];
		for (int i = 0; i < values.length; i++) {
			classes[i] = values[i].getClass();
		}
		Method method = obj.getClass().getMethod(methodName, classes);
		return method.invoke(obj, values);
	}
	
	/**
	 * 这个方法可以调用包含int参数的方法
	 * @param obj
	 * @param methodName
	 * @param values
	 * @return
	 * @throws IllegalAccessException
	 * @throws IllegalArgumentException
	 * @throws InvocationTargetException
	 * @throws NoSuchMethodException
	 * @throws SecurityException
	 * @throws ClassNotFoundException
	 */
	public static Object dynamicInvokeMethod2(Object obj, String methodName, Object... values)
			throws IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException,
			SecurityException, ClassNotFoundException {
		Class[] classes = new Class[values.length];
		for (int i = 0; i < values.length; i++) {
			if (values[i] instanceof Integer) {
				classes[i] = Integer.TYPE;
				classes[i] = int.class;
			} else {
				classes[i] = values[i].getClass();
			}
		}
		Method method = obj.getClass().getMethod(methodName, classes);
		return method.invoke(obj, values);
	}

}
