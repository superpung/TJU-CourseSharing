package ch11;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/**
 * 这个例子展示了如何动态的调用一个带有参数的方法
 * 
 * @author cjy
 *
 */
public class DynamicInvoke02 {
	public static void main(String[] args) {
		Student student = new Student("jack", 123);
		try {			
			dynamicInvokeMethod (student, "setName", "tom");
			System.out.println(student.getName());
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
	}	 
	public static Object dynamicInvokeMethod (Object obj, String methodName, Object... values)
			throws IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException,
			SecurityException, ClassNotFoundException {
		Class[] classes = new Class[values.length];
		for (int i = 0; i < values.length; i++) {
			classes[i] = values[i].getClass();
		}
		Method method = obj.getClass().getMethod(methodName, classes);
		return method.invoke(obj, values);
	}

}
