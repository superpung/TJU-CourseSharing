package ch11;

import java.util.ArrayList;
import java.util.List;
/**
 * 本例子展示了如何使用不定长参数
 * @author Administrator
 *
 */
public class VariantParams {
	public static void main(String[] args) { 
		List<String> list =  asList("a", "b", "c");
		for(String str:list) {
			System.out.println(str);
		}
	}
	public static <T> List<T> asList(T... a) {
		//不定长参数 a是一个数组
		java.util.ArrayList<T> list = new ArrayList<T>();
		for (int i = 0; i < a.length; i++) {
			list.add(a[i]);
		}
		return list;
	}
}
