package ch03;

/**
 * Fibonacci 数列问题，展示了一维数组的使用方法
 * 
 * @author Administrator
 *
 */
public class Fibonacci {
	public static void main(String args[]) {
		int i;
		int f[] = new int[10];
		f[0] = f[1] = 1;
		for (i = 2; i < f.length; i++) {
			f[i] = f[i - 1] + f[i - 2];
		}
		//for (i = 1; i <=  10; i++) { 这种写法和下面的写那个好，为什么？
		for (i = 1; i <= f.length; i++) {
			System.out.println("F[" + i + "]= " + f[i - 1]);
		}
	}
}
