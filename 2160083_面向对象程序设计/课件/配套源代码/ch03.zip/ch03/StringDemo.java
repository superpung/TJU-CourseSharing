/**
 * 
 */
package ch03;

/**
 * 字符串如何相加
 * @author Administrator
 *
 */
public class StringDemo {

	/**
	 * 
	 */
	public StringDemo() {
		// TODO Auto-generated constructor stub
	}
	public static void main(String[] args) {
		String s1="abc";
		String s2;
		s2="def";
		String s3=s1+s2;//字符串可以直接相加
		int i=100;
		String s4=s3+i+i;//字符串可以和任何对象连接 用 + 操作符 
		//字符串可以和char相加
		String s5="1"+'1';
		System.out.println("s1="+s1);
		System.out.println("s2="+s2);
		System.out.println("s3="+s3);
		System.out.println("s4="+s4);
		System.out.println("\"1\"+'1'="+s5);
		
		char c1='1';
		char c2='1'+'1'; 
		System.out.println("c1="+c1);
		System.out.println("int c1="+(int)c1);
		System.out.println("'1'+'1'="+c2);
		
		
		s1="abcdefg";
		//取得长度
		System.out.println("s1.length()="+s1.length());
		//判断大小写
		System.out.println("s1.toUpperCase="+s1.toUpperCase());
		//是否包含某种字符串
		System.out.println("s1.indexOf(\"ce\")="+s1.indexOf("ce"));
		//截取 
		System.out.println("substr="+s1.substring(2,4));
		
		String s6=null;
		String s7="";
		System.out.println("s6 is null="+(s6==null));
		System.out.println("s7 is null="+(s7==null));
		
	}

}
