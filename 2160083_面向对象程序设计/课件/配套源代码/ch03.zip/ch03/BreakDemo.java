/**
 * 
 */
package ch03;

/**
 * break的例子
 * @author Administrator
 *
 */
public class BreakDemo {

	/**
	 * @param args
	 */
	public static void main(String args[]) {
		for (int i = 0; i < 10; i++) {
			if (i == 3)
				break;
			System.out.println(" i =" + i);
		}
		System.out.println("Game Over!");
	}

}
