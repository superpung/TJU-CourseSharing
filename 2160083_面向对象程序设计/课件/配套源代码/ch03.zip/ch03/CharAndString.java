/**
 * 
 */
package ch03;

/**
 * 字符和字符串的区别
 * @author Administrator
 *
 */
public class CharAndString {
 

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		//char 是基本数据类型，可以保存一个字符，用' '
		char c='a';
		//可以把一个整数转换为char
		char c2=(char)256;
		//String 是一个类，可以保存0个或者更多char ，用 "";
		String s1="abc";
		//把char转换为String的方法
		String s2=String.valueOf(c);
		System.out.println("c="+c);
		System.out.println("c2="+c2);
		System.out.println("s1="+s1);
		System.out.println("s2="+s2);


	}

}
