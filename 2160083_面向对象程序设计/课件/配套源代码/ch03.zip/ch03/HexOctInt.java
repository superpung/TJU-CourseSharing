package ch03;

/**
 * 本例子演示了八、十、十六进制数字写法
 * @author Administrator
 *
 */
public class HexOctInt {

	public HexOctInt() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		int i = 10; 
		int j = 010;//八进制
		int k = 0x10;//十六进制
		System.out.println("10=" + i);
		System.out.println("010=" + j);
		System.out.println("0x10=" + k); 
	}
}
