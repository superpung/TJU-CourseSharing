/**
 * 
 */
package ch03;

/**
 * @author Administrator
 *
 */
public class StringCompare {

	/**
	 * 
	 */
	public StringCompare() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String s1="";
		String s2="123";
		for(int i=0;i<4;i++) {
			s1=s1 + i;
		} 
		//注意 字符串的比较，应该用 equals,不能用 == 
		System.out.println("s1.equals(s2):"+s1.equals(s2));
		System.out.println("s1 == s2 :"+(s1==s2));
		//equals是区分大小写的
		System.out.println("abc.equals(ABc) :"+"abc".equals("ABc"));
		//equalsIgnoreCase不区分大小写
		System.out.println("abc.equals(ABc) :"+"abc".equalsIgnoreCase( "ABc"));
		//compareTo 相等返回0，小于返回-1，大于返回1 
		System.out.println("abc.compareTo(aaa) :"+"abc".compareTo("aaa"));
		System.out.println("abc.compareTo(abc) :"+"abc".compareTo("abc"));
		System.out.println("abc.compareTo(abd) :"+"abc".compareTo("abd"));
	}

}
