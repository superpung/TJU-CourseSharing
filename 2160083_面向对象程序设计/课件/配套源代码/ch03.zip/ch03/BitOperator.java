package ch03;

/**
 * 位操作的例子
 * 
 * @author Administrator
 *
 */
public class BitOperator {

	public static void main(String args[]) {
		int FLAG1 = 1; //  (0x0001)
		int FLAG2 = 2; //  (0x0010)
		int FLAG3 = 7; //  (0x0111)
		System.out.println("0x0001|0x0010=" + (FLAG1 | FLAG2));
		System.out.println("0x0001&0x0111=" + (FLAG1 & FLAG3));
		System.out.println("0x0001^0x0111=" + (FLAG1 ^ FLAG3));
		// 下面这个例子涉及补码的知识，不理解可以跳过
		System.out.println("0x0001&0x0111=" + (~FLAG1));
		System.out.println("2<<1=" + (2 << 1));
		System.out.println("2>>1=" + (2 >> 1));
		System.out.println("2>>1=" + ((-2) >> 1));
		// 下面这个例子涉及补码的知识，不理解可以跳过
		System.out.println("2>>>1=" + ((-2) >>> 1));
	}
}
