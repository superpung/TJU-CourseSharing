/**
 * 
 */
package ch03;

/**
 * break的例子
 * 
 * @author Administrator
 *
 */
public class ContinueDemo {

	/**
	 * @param args
	 */
	public static void main(String args[]) {
		round1:for (int i = 0; i < 10; i++) {
			round2:for (int j = 0; j < 10; j++) {
				if (j %2!=0)
					continue round2;
				if (i %2==0)
					continue round1;
				System.out.println(" i =" + i+"\t j =" + j);
			}
		}
		System.out.println("Game Over!");
	}

}
