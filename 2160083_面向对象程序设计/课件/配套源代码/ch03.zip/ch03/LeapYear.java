/**
 * 
 */
package ch03;

/**
 * 判断某一年是否是闰年
 * @author Administrator
 *
 */
public class LeapYear {

	/**
	 * 
	 */
	public LeapYear() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int year = 2003;
		if ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0)) {
			System.out.println(year + " is a leap year.");
		} else {
			System.out.println(year + " is not a leap year.");
		}
	}

}
