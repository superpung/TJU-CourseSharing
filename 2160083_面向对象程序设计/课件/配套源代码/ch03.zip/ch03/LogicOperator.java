package ch03;

/**
 * 逻辑运算符的例子
 * @author Administrator
 *
 */
public class LogicOperator{
	public static void main( String args[] ){
		 
		System.out.println("true&&false ="+(true&&false) ); 
		System.out.println("true||false ="+(true||false) );  
		System.out.println("!true =" +(!true)); 
		System.out.println("true^false =" +(true^false)); 
		System.out.println("true&false ="+(true&false) ); 
		System.out.println("true|false ="+(true|false) ); 
	}
}
