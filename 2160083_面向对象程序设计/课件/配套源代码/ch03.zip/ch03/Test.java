/**
 * 
 */
package ch03;

/**
 * @author Administrator
 *
 */
public class Test {
	
	/**
	 * 
	 */
	public Test() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		float f1=2.0f;
		float f2=1.0f+1.0f;
		System.out.println(Math.abs(f1-f2)<0.0001);
	}

}
