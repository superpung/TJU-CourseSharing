/**
 * 
 */
package ch03;

/**
 * 本例子演示了char[] 和 String之间的转换
 * 
 * @author Administrator
 *
 */
public class CharArrayStringInt {

	/**
	 * 
	 */
	public CharArrayStringInt() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String s1 = "abc";
		// 把String转换为char[]的方法
		char[] charArray = s1.toCharArray();
		// 把char[]转换为字符串的方法
		String s2 = new String(charArray);
		// 取得String长度的方法
		int len = s1.length();
		int num=123;
		//如何把一个整数转换为字符串
		String s3=String.valueOf(num);
		//如何把一个字符串转换为整数
		int num2=Integer.valueOf(s3);
	}

}
