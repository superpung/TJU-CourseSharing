/**
 * 
 */
package ch03;

/**
 * 赋值时候的类型问题题
 * @author Administrator
 *
 */
public class AssignOpertor {

	/**
	 * 
	 */
	public AssignOpertor() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double d=65;		
		//float f1=d;//错误的写法
		float f2=(float)d;//正确的写法		
		//int i1=f2;//错误的写法
		int i2=(int)f2;//正确的写法
		//char c1=i2;//错误的写法
		char c2=(char)i2;//正确的写法
		//byte b1=c2;//错误的写法
		byte b2=(byte)c2;//正确的写法
		//byte b3=128;//错误的写法
		byte b4=65;//正确
		System.out.println("i2="+i2);
		System.out.println("c2="+c2);
		System.out.println("b2="+b2);
		
	}

}
