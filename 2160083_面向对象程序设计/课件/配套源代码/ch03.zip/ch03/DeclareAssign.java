package ch03;

/**
 * 声明基本数据类型并赋值
 * @author Administrator
 *
 */
public class DeclareAssign
{
	public static void main (String args []) {
		boolean b = true; 	//声明boolean型变量并赋值	  	 
		int x, y=8; 	    	// 声明int型变量
		float f = 4.5f; 	// 声明float型变量并赋值
		double d = 3.1415; 	//声明double型变量并赋值
		char c; 		//声明char型变量
		c ='\u0031';		//为char型变量赋值        	
		x = 12; 		//为int型变量赋值 
		System.out.println("b=" + b);
		System.out.println("x=" + x);
		System.out.println("y=" + y);
		System.out.println("f=" + f);
		System.out.println("d=" + d);
		System.out.println("c=" + c);		
	}
}
