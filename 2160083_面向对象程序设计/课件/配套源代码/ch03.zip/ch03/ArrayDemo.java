package ch03;

/**
 * 一维数组的声明和初始化
 * @author Administrator
 *
 */
public class ArrayDemo {
	public static void main( String args[ ] ){		
		int[]  a;
		a  = new int[3];
		a[0] = 3;
		a[1] = 9;
		a[2] = 8;
		
		int[]  b= new int[3];
		b[0] = 3;
		b[1] = 9;
		b[2] = 8;
		
		int[]  c= {1,2,3}; 
		//下面这种方式非法
		//int[] d=new int[3];
		//d= {1,2,3};
		
		int f[]= {1,2,3}; 
		//数组也是对象 Object是所有子类的父类。
		// instanceof 表示判断 f是否为 Object的实例
		System.out.println(f instanceof Object);
		
	}
}
