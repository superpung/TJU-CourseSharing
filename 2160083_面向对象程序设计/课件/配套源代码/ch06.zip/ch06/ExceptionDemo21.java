package ch06;

public class ExceptionDemo21 {

	public ExceptionDemo21() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
