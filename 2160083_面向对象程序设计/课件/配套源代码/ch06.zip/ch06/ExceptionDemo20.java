package ch06;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.SQLException;

/**
 * 异常引发的问题 buy 函数为什么会有编译错误？？
 * 
 * @author cjy
 *
 */
public class ExceptionDemo20   {

	public ExceptionDemo20() {
		// TODO Auto-generated constructor stub
	}

	public int getBalance(String username) throws InvalidUserException {
		// 这个地方实际上应该访问数据库查询，为了简单，我们直接判断
		if (username.equals("张三")) {

			return 10000;
		}
		// 不是什么都能throw
		throw new InvalidUserException("用户" + username + "不存在！");
	}

	/**
	 * 这个函数为什么编译不过？？
	 * 
	 * @param username
	 * @param amount
	 * @return
	 * @throws Exception
	 */
	public int buy(String username, int amount) throws Exception {
		try {
			int orgBalance = this.getBalance(username);
			if (orgBalance < amount) {
				throw new BalanceException("余额不足！");
			}
			return orgBalance - amount;
		} catch (Exception e) {

			System.out.println(e.getMessage());

			// 这里没有返回值，也就意味着如果发生异常，函数就没用返回，所以会报错。
		}
	}

	/**
	 * 这个函数为什么编译不过去？
	 * 
	 * @param username
	 * @param amount
	 * @throws Exception
	 */
	public void buy2(String username, int amount) throws Exception {
		int orgBalance;
		try {
			orgBalance = this.getBalance(username);
			if (orgBalance < amount) {
				throw new BalanceException("余额不足！");
			}
		} catch (Exception e) {
			System.out.println("余额不足:" + orgBalance);
			// 系统编译的时候认为try里面代码完全有可能一行都不被执行，所以必须要在try前面给变量赋值
		}
	}

	public void readFromFile(String fileName) {
		InputStream in;
		// 正确的写法是InputStream in=null;
		try {
			in = new FileInputStream(fileName);
			// ....以后还有代码，此处省略
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (in != null) {
				// in没有初始化
				in.close();
				// in close的时候可能再次发生异常
			}
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			new ExceptionDemo20().buy("ssdf", 100);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
