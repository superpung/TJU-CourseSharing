/**
 * 
 */
package ch06;

/**
 * @author Administrator
 *
 */
public class UserDefineException {

	/**
	 * 
	 */
	public UserDefineException() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try{
			throw new MyException("user define!");
		}catch(Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
				
	}

}
