package ch06;

/**
 * 异常的处理，自己继续往上抛出
 * 
 * @author cjy
 *
 */
public class ExceptionDemo5 {
	public int getBalance(String username) throws Exception {
		// 这个地方实际上应该访问数据库查询，为了简单，我们直接判断
		if (username.equals("张三")) {
			return 10000;
		}
		// 不是什么都能throw
		throw new Exception("用户" + username + "不存在！");
	}

	public int getNewBalance2(String username, int amount) throws Exception {
		int orgBalance = this.getBalance(username);
		return orgBalance - amount;

	}

	public static void main(String[] args) {
		String name = "张三8";
		ExceptionDemo5 demo = new ExceptionDemo5();

		try {
			int balance = demo.getNewBalance2(name, 100);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// demo.getBalance(name);
	}

}
