package ch06;

/**
 * 异常的处理，自己来处理
 * 
 * @author cjy
 *
 */
public class ExceptionDemo4 {
	public int getBalance(String username) throws Exception {
		// 这个地方实际上应该访问数据库查询，为了简单，我们直接判断
		if (username.equals("张三")) {
			return 10000;
		}
		// 不是什么都能throw
		throw new Exception("用户" + username + "不存在！");
	}

	public int getNewBalance1(String username, int amount) {
		int orgBalance = 0;
		try {
			orgBalance = this.getBalance(username);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		return orgBalance - amount;
	}

	public static void main(String[] args) {
		String name = "张三";
		ExceptionDemo4 demo = new ExceptionDemo4();

		int balance = demo.getNewBalance1(name, 100);
		System.out.println("The new balance of " + name + " is:" + balance);

	}

}
