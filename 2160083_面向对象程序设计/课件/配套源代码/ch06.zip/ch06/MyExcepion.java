/**
 * 
 */
package ch06;

/**
 * @author Administrator
 *
 */
public class MyExcepion extends Exception {

	/**
	 * 
	 */
	public MyExcepion(String s) {
		// TODO Auto-generated constructor stub
		super(s);
	}

}
