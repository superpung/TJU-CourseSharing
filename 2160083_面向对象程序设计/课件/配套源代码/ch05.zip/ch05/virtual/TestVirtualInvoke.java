package ch05.virtual;

class Shape  {
	void draw() {
		System.out.println("Shape Drawing"); 
	} 
	static void stDraw() {
		System.out.println("static Shape Drawing");
	}
}

class Circle extends Shape {
	void draw() {
		System.out.println("Draw Circle"); 
	}
	static void stDraw() {
		System.out.println("static Shape Drawing");
	} 
}

class Triangle extends Shape {
	void draw() {
		System.out.println("Draw Triangle");
	}
	static void stDraw() {
		System.out.println("static Draw Triangle");
	}
}

class Line extends Shape {
	void draw() {
		System.out.println("Draw Line");
	}
	static void stDraw() {
		System.out.println("static Draw Line");
	}
}

public class TestVirtualInvoke {
	static void doStuff(Shape s) {
		s.draw();
	}

	public static void main(String[] args) {
		Circle c = new Circle();
		Triangle t = new Triangle();
		Line l = new Line();
		c.draw();
		t.draw();
		l.draw();
		
		Shape c2=new Circle();
		c2.draw();
		c2.stDraw();
		System.out.println(" c2 instancof Shape="+(c2 instanceof Shape));
		c2=new Triangle();
		c2.draw();
		c2.stDraw();
		System.out.println(" c2 instancof Triangle="+(c2 instanceof Triangle));
		c2=new Line();
		c2.draw();
		c2.stDraw();
		System.out.println(" c2 instancof Line="+(c2 instanceof Line));
		
		
		
		
		
	}
}