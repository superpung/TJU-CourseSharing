package ch05.ref_val;

/**
 * 函数中如果传递的是对象，未必一定可以在函数内部修改这个参数
 * @author Administrator
 *
 */
public class TestValue {

	public TestValue() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		String str="a";		
		modify(str);
		System.out.println(str);
		
		StringBuffer buf=new StringBuffer("a");
		modify(buf);		
		System.out.println(buf.toString());
	}
	
	/**
	 * s能被修改么？
	 * @param s
	 */
	public static void modify(String s) {
		 
		s=s+"1";
	}
	/**
	 * buf能被修改么
	 * @param buf
	 */
	public static void modify(StringBuffer buf) {
		
		buf.append("1");
	}
}
