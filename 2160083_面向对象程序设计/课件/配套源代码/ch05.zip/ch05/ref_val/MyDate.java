package ch05.ref_val;

/**
 * 本例子演示了两个对象指向的是同一个地址，而不是简单的值的复制
 * 
 * @author Administrator
 *
 */
public class MyDate {
	private int day = 12;
	private int month = 6;
	private int year = 1900;

	public MyDate(int y, int m, int d) {
		year = y;
		month = m;
		day = d;
	}

	void addYear() {

		year++;
	}

	@Override
	public Object clone() {
		// TODO Auto-generated method stub
		return new MyDate(this.year, this.month, this.day);
	}

	public void display() {
		System.out.println(year + "-" + month + "-" + day);
	}

	public static void main(String[] args) {
		// MyDate m, n;
		// m = new MyDate(2020, 3, 2);// m指向了一个对象
		// // n = (MyDate)m.clone();// n和m指向了同一个对象
		// n=m;
		// n.addYear();// m n同时改变
		// m.display();
		// n.display();// m n都变成了2021

		// n = new MyDate(2019, 3, 2);// n指向了一个新对象
		// m.display();
		// n.display();// m n 具有不同的值
		MyDate m = new MyDate(2020, 3, 6);
		modifyDate(m);
		m.display();
	}

	public static void modifyDate(MyDate m) {
		m=new MyDate(2020, 3, 6);
		m.addYear();
	}
}
