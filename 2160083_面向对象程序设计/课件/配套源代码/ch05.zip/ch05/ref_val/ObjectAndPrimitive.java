package ch05.ref_val;

public class ObjectAndPrimitive {

	public ObjectAndPrimitive() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Integer i1 = new Integer(0);
		int i2 = i1;
		
		String s="abc";
		Object o=s;
		((String)o).length();

		test(i1);
		// Integer可以用的地方，int也可以
		test(678);

		// 但是Integer的方法，int是不能直接用的
		i1.hashCode();
		// 下面这个是不可以的
		((Integer) i2).hashCode();

		Boolean b1 = Boolean.FALSE;
		boolean b2 = b1;

	}

	public static void test(Integer i) {

	}
 

}
