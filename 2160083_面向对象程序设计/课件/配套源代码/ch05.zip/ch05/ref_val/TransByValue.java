package ch05.ref_val;

/**
 * 本例子演示了什么样的情况下传递的是地址，什么情况下是值的复制
 * 
 * @author Administrator
 *
 */
public class TransByValue {
	private static int a;

	public static void main(String[] args) {

		int a = 0;
		modify( a);
		// System.out.println(a);// 输出0

		int[] b = new int[1];   
		modify(b); 
		System.out.println(b[0]); 
	}

	/**
	 * 值的复制
	 * 
	 * @param a
	 */
	public static void modify(int  a) {
		// 原始类型 传递值
		// a++;
		a = a + 1;

	}

	/**
	 * 传递的是地址
	 * 
	 * @param b
	 */
	public static void modify(int[] c) {
		// 对象类型 传递地址
		c[0]++;
		c = new int[5];
	}

	
}
 
