package ch05.intergate;

public interface Integrable {

	public double getValue(double x);
}
