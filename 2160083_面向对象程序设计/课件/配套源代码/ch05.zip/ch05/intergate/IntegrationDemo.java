package ch05.intergate;

/**
 * 本例子演示了接口的作用
 * @author cjy
 *
 */
public class IntegrationDemo {

	public IntegrationDemo() {
		// TODO Auto-generated constructor stub
	}
	/**
	 * 计算积分的一个函数
	 * @param fun
	 * @param a
	 * @param b
	 * @param step
	 * @return
	 */
	public double integrateAB(Integrable fun,double a,double b,double step) {
		
		double sum=0;
		while(a<b) {
			sum=sum+step*fun.getValue(a);
			a=a+step;
		}
		return sum;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		IntegrationDemo demo=new IntegrationDemo();		
		
		Integrable myFun=new MyFunction();
		
		//Integrable myFun=new MyFun2();
		
		double sum=demo.integrateAB(myFun,0,1,0.0005);
		System.out.println(sum);
	}


}
