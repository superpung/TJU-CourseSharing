package ch05.intergate;

public class MyFunction implements Integrable {

	public MyFunction() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public double getValue(double x) {
		return Math.sin(x);
	}

}
