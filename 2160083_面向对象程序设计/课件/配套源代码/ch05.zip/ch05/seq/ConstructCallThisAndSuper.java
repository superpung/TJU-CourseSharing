package ch05.seq;

class ConstructCallThisAndSuper 
{
	public static void main(String[] args){ 
		PersonThisAndSuper p = new Graduate();
	}
}

class PersonThisAndSuper
{
	String name; 
	int age;
	PersonThisAndSuper(){}
	PersonThisAndSuper( String name, int age ){
		this.name=name; this.age=age; 
		System.out.println("In Person(String,int)");
	}
}

class StudentThisAndSuper extends PersonThisAndSuper
{
	String school;
	StudentThisAndSuper(){
		this( null, 0, null );
		System.out.println("In Student()");
	}
	StudentThisAndSuper( String name, int age, String school ){
		super( name, age );
		this.school = school;
		System.out.println("In Student(String,int,String)");
	}
}

class Graduate extends StudentThisAndSuper
{
	Graduate(){
		System.out.println("In Graduate()");
	}
}