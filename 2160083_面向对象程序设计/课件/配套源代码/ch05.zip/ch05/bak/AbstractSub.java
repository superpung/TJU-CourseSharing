package ch05.bak;
/**
 * 本例子和AbstractBase演示了abstract的用法
 * 
 *
 */
public class AbstractSub extends AbstractBase {

	public AbstractSub() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * 必须要有method1，否则该子类就应该声明为抽象类
	 */
	@Override
	public void method1(String arg1) {
		// TODO Auto-generated method stub

	}

}
