package ch05.bak;

public class Const {
	public final static String url1="http://163.com ";
	public static String url2="192.168.0.2";
	Object o;
	
}
