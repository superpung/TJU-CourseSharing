package ch05.bak;

import java.io.Serializable;

import ch06.bak.MyInterface;


public class MyObject implements MyInterface {

	public MyObject() {
		// TODO Auto-generated constructor stub
	}

}
