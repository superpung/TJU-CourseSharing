package ch05.bak;

/**
 * 本类演示了@Deprecated 用法
 */

@Deprecated
public class DeprecationDemo {
	public DeprecationDemo() {
	}
	@Deprecated
	public void myMethod() {
	}
}
