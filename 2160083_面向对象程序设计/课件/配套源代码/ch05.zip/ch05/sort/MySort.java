package ch05.sort;

public class MySort {

	public MySort() {
		// TODO Auto-generated constructor stub
	}
	public void sort(Comparable[] arr) {
		// 冒泡排序,大家不要去过分深究这个算法，只要知道这个可以排序就可以了
		if (arr.length >= 2) {
            for (int i = 1; i < arr.length; i++) { 
            	Comparable x = arr[i];
                int j = i - 1; 
                while (j >= 0 &&  (arr[j].compareTo(x) > 0)) { 
                    arr[j + 1] = arr[j];
                    j--;
                } 
                arr[j + 1] = x;
            }
        } 
	}

}
