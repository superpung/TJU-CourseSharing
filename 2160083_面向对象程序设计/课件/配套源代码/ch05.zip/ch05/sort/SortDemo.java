package ch05.sort;

import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

/**
 * 本例子演示了如果自动对学生进行排序， 也是接口作用的演示
 * 
 * @author cjy
 *
 */
public class SortDemo {

	public SortDemo() {
		// TODO Auto-generated constructor stub

	}

	public static void main(String[] args) {
		Student[] students=new Student [4];
		students[0]=new Student("张三", 200) ;
		students[1]=new Student("李四", 600) ;
		students[2]=new Student("王武", 300) ;
		students[3]=new Student("赵六", 500) ;
		MySort mySort=new MySort();
		mySort.sort(students);
		for(Student student :students) {
			System.out.println(student);
		}
		
		Worker[] workers=new Worker [4];
		workers[0]=new Worker("张", 32,8000) ;
		workers[1]=new Worker("王", 21,3000) ;
		workers[2]=new Worker("李",41, 4000) ;
		workers[3]=new Worker("陈", 55,9000) ;
		 
		mySort.sort(workers);
		for(Worker worker :workers) {
			System.out.println(worker);
		}
		System.out.println("张".compareTo("李"));

	}

}
