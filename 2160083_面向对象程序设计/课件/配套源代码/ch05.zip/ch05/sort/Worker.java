package ch05.sort;

public class Worker implements Comparable {
	private int salary;
	private int age;
	public Worker( String name,int age,int salary) {
		super();
		this.salary = salary;
		this.age = age;
		this.name = name;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	private String name;

	public Worker(String name, int salary) {
		super();
		this.salary = salary;
		this.name = name;
	}

	public Worker() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public int compareTo(Object o) {
		// TODO Auto-generated method stub
		Worker that = (Worker) o;
		return -Integer.valueOf(age).compareTo(that.age);
	}

	@Override
	public String toString() {
		return "Worker [salary=" + salary + ", age=" + age + ", name=" + name + "]";
	}

}
