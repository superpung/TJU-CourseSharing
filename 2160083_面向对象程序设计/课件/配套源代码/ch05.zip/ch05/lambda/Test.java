package ch05.lambda;

import java.util.Arrays;
import java.util.Comparator;

import org.apache.tools.ant.types.resources.selectors.Compare;

public class Test {

	public Test() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		People[] a = new People[10];
		Arrays.sort(a, (People p1, People p2) -> {return (p1.i - p2.i)  ;})  ;
	}

}

class People {
	int i;
}