package ch05.lambda;

import java.util.Comparator;

public class TT implements Comparator<String> {

	public TT() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public int compare(String o1, String o2) {
		// TODO Auto-generated method stub
		
		return 0;
	}

}
