package ch05.clean;

/**
 * 本例子演示了finalize的调用
 * @author Administrator
 *
 */
public class TestFinalize {

	public TestFinalize() {
		// TODO Auto-generated constructor stub
	}

	@Override
	protected void finalize() throws Throwable {
		// TODO Auto-generated method stub
		System.out.println(" this finalize");
		//finalize应该放在最后，这个和构造函数调用super正好相反
		super.finalize();

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TestFinalize t = new TestFinalize();
		t = null;
		System.gc();
	}

}
