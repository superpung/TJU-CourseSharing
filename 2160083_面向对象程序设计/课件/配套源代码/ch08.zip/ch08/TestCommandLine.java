package ch08;

/**
 * 演示了命令行的作用 
 * @author Administrator
 *
 */
public class TestCommandLine {
	public static void main(String[] args) {
		for (int i = 0; i < args.length; i++) {
			// 运行时，使用java TestCommandLine lisa "bily" "Mr Brown"
			System.out.println("args[" + i + "] = " + args[i]);
		}
	}
}

