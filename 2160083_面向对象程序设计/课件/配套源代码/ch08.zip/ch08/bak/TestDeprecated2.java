package ch08.bak;
public class TestDeprecated2{
    public static void main(String args[]){
 		String f;
 		f = System.getProperty("java.class.path");
		System.out.println(f);
    }
} 
