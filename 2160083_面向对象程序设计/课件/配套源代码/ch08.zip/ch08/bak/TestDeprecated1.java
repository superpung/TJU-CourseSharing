package ch08.bak;
public class TestDeprecated1{
    public static void main(String args[]){
 		String f;
 		f = System.getenv("java.class.path");
		System.out.println(f);
    }
}
