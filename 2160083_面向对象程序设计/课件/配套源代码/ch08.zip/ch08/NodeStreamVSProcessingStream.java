package ch08;

import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.LineNumberReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class NodeStreamVSProcessingStream {

	public static void main(String[] args) {
		try {
			// 节点流 可以直接根据一个目标构造 
			FileInputStream fin = new FileInputStream("D:/temp/1.txt");
			FileOutputStream fout = new FileOutputStream("D:/temp/1.txt");
			ByteArrayInputStream bin = new ByteArrayInputStream("hellow".getBytes());
			FileReader freader = new FileReader("D:/temp/1.txt");
			FileWriter fwriter = new FileWriter("D:/temp/1.txt");
			// 处理流必须依托已经存在的流构造，一般作用是对已有流做一些功能上的增强
			ObjectInputStream oin = new ObjectInputStream(fin);
			ObjectOutputStream oout = new ObjectOutputStream(fout);
			LineNumberReader lin=new LineNumberReader(freader);
			//这里的代码不规范，流打开了没有关闭
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
