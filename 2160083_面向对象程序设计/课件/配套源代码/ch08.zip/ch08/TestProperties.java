package ch08;

import java.util.Iterator;
import java.util.Properties;

/**
 * 本例子演示了如何取得System.properties
 * @author Administrator
 *
 */
public class TestProperties {
	public static void main(String[] args) {
		Properties ps = System.getProperties();
		Iterator<Object> it = ps.keySet().iterator();

		while (it.hasNext()) {
			String pName = (String) it.next();
			String pValue = ps.getProperty(pName);
			System.out.println(pName + "=" + pValue);
			
		}
	}
}
