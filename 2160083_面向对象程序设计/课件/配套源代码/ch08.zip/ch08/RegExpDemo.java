package ch08;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 本例子演示了正则表达式的用法
 * @author Administrator
 *
 */
public class RegExpDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		findEmail( );
		testTels();
		splitContent();
	}

	public static void testTels( ) {
		testTel("13820477575");
		testTel("123456");
	}
	private static void testTel(String content) {
		boolean match=content.matches("[0-9]{11}");
		System.out.println(content +(match?" ":" 不")+"是合法的电话号码");
	}

	public static void findEmail( ) {
		String content = "天外天技术支持：cs@tju.edu.cn  联系我们：1234567890@qq.com 地址：天津市南开区";
		String telReg = "\\w+@\\w+.[\\w+]+";
		Pattern telPattern = Pattern.compile(telReg);

		Matcher m = telPattern.matcher(content);
		while (m.find()) {
			System.out.println(m.group(0));
		}
	}
	public static void splitContent() {
		String content=" 第一回 甄士隐梦幻识通灵 贾雨村风尘怀闺秀 ... 第二回 贾夫人仙逝扬州城 冷子兴演说荣国府 ... 第三回 托内兄如海酬训教 接外孙贾母惜孤女 ....";
		String contents[] = content.split("第[一,二,三,四,五,六,七,八,九,十,零]{1,3}回 ");
		for(String title:contents) {
			System.out.println(title);
		}
	}
}
