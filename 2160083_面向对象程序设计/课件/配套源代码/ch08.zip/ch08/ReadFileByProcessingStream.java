package ch08;

import java.io.Closeable;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.LineNumberReader;
import java.io.OutputStream;
import java.io.Reader;
import java.util.ArrayList;
import java.util.List;

/**
 * 本例子演示了如何使用char的方式 读取、写入文件
 * 
 * @author cjy
 *
 */
public class ReadFileByProcessingStream {
	public static int CHUNK_SIZE = 4096;

	public ReadFileByProcessingStream() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {

		try {
			List<String> lines = readLines("D:\\course\\course\\code_demo\\src\\ch08\\XiaoHe.ini");
			for (String line : lines) {
				System.out.println(line);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * 从一个文本文件中，一次读取一行，放到list中
	 * 
	 * @param fsrc
	 * @return
	 * @throws IOException
	 */
	public static List<String> readLines(String fsrc) throws IOException {
		try (Reader reader = new FileReader(fsrc); 
				//LineNumberReader 必须在其他流基础上构建
				LineNumberReader lineReader = new LineNumberReader(reader);) {
			String line = "";
			List<String> lines = new ArrayList<String>();
			while (line != null) {
				lines.add(line);
				//每次读取一行
				line = lineReader.readLine();
			}
			return lines;
		}
	}

}
