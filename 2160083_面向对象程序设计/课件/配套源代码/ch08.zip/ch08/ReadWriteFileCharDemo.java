package ch08;

import java.io.Closeable;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.LineNumberReader;
import java.io.OutputStream;
import java.io.Reader;
import java.util.ArrayList;
import java.util.List;

/**
 * 本例子演示了如何使用char的方式 读取、写入文件
 * 
 * @author cjy
 *
 */
public class ReadWriteFileCharDemo {
	public static int CHUNK_SIZE = 4096;

	public ReadWriteFileCharDemo() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		String s = "";
		try {
			s = readFile("D:\\course\\course\\code_demo\\src\\ch08\\src.txt");
		} catch (IOException e) {
			e.printStackTrace();
		}

		System.out.println(s);
		try {
			writeFile("D:\\course\\course\\code_demo\\src\\ch08\\target.txt", s);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	/**
	 * 注意readFile和readFile2等效
	 * 
	 * @param fsrc
	 * @return
	 * @throws IOException
	 */
	public static String readFile(String fsrc) throws IOException {
		//这句话是否可以写成Reader reader ;为什么？
		Reader reader = null;
		try {
			reader = new FileReader(fsrc);
			StringBuffer buf = new StringBuffer();
			char[] chars = new char[CHUNK_SIZE];
			int readed = reader.read(chars);
			// 从一个流里面读取内容的经典写法
			while (readed != -1) {
				// 文件是size不能被CHUNK_SIZE整除，所以要记录每次读到的长度readed
				// 写入到buf的时候，不是用的 buf.append(chars);
				// 而是用buf.append(chars, 0, readed);
				buf.append(chars, 0, readed);
				readed = reader.read(chars);
			}
			return buf.toString();
		} finally {
			//reader!=null的判断是否可以取消，为什么？
			if (reader != null) {
				reader.close();
			}
		}
	}

	/**
	 * 从一个文件中读取字符串
	 * 
	 * @param fsrc
	 * @return
	 * @throws IOException
	 */
	public static String readFile2(String fsrc) throws IOException {
		try (Reader reader = new FileReader(fsrc);) {
			StringBuffer buf = new StringBuffer();
			char[] chars = new char[CHUNK_SIZE];
			int readed = reader.read(chars);
			// 从一个流里面读取内容的经典写法
			while (readed != -1) {
				buf.append(chars, 0, readed);
				readed = reader.read(chars);
			}
			return buf.toString();
		}
	}

	/**
	 * 把字符串写到文件中
	 * 
	 * @param fileName
	 * @param content
	 * @throws IOException
	 */
	public static void writeFile(String fileName, String content) throws IOException {
		try (OutputStream out = new FileOutputStream(fileName, false)) {
			out.write(content.getBytes());
			out.flush();
		}

	}

	/**
	 * 关闭输入输入流
	 * 
	 * @param inout
	 */
	public static void close(Closeable inout) {
		if (inout != null) {
			try {
				inout.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
