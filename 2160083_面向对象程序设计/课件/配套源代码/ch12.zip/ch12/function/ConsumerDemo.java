/**
 * 
 */
package ch12.function;

import java.util.function.Consumer;

/**
 * @author Administrator
 *
 */
public class ConsumerDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Consumer<Integer> consumer1 = (param) -> {System.out.println("hellow "+param);};
		Consumer<Integer> consumer2 =  System.out::println ;
		consumer1.accept(1);
		consumer2.andThen(consumer1).accept(2); 
		
		Consumer<String> consumer3 =  ConsumerDemo::method ;
		consumer3.accept("123");
		
		Consumer<String> consumer4 =  new ConsumerDemo()::method2 ;
		consumer4.accept("123");
		
	}
	public static void method(String str) {
		System.out.println("static method:"+str);
	}
	
	public  void method2 (String str) {
		System.out.println("method:"+str);
	}

}
