package ch12.function;

public class LambdaDemo2 {

	public LambdaDemo2() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ICar car1 = new IcarImpl();
		car1.drive();		
		// 1.匿名内部类使用
		ICar car2 = new ICar() {
			@Override
			public void drive() {
				System.out.println("Drive BMW");
			}
		};
		car2.drive();

		// 2.无参无返回Lambda表达式
		ICar car3 = () -> {
			System.out.println("Drive Audi");
		};
		// ()代表的就是方法，只是匿名的。因为接口只有一个方法所以可以反推出方法名
		// 类似Java7中的泛型 List<String> list = new ArrayList<>(); Java可以推断出ArrayList的泛型。
		car3.drive();
 
	}
}

/**
 * 一个java文件可以定义多个类，但是只能有一个public
 * 
 * @author Administrator
 *
 */
@FunctionalInterface
interface ICar {
	
	void drive();
}

class IcarImpl implements ICar {

	@Override
	public void drive() {
		System.out.println("Drive Benz");
	}
}
 