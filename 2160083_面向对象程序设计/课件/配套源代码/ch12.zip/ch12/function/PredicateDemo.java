/**
 * 
 */
package ch12.function;

import java.util.function.Predicate;

/**
 * @author Administrator
 *
 */
public class PredicateDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Predicate<String> p = o -> o.startsWith("test"); 
		System.out.println(p.test("testa") );
	}

}
