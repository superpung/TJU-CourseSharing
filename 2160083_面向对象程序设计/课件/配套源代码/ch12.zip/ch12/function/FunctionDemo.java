/**
 * 
 */
package ch12.function;

import java.util.function.Function;

/**
 * @author Administrator
 *
 */
public class FunctionDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Function<Integer, Integer> add = (s) -> ++s;
		Function<Integer, Integer> abs = (s) ->{ 
			if(s>=0) {
				return s;
			}else {
				return -s;
			}
		};
		System.out.println(add.apply(100));
		System.out.println(abs.apply(-100));
		System.out.println(add.compose(abs).apply(-100));
	}

}
