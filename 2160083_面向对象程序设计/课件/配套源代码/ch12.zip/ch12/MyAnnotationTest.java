package ch12;

import java.lang.reflect.Method;

public class MyAnnotationTest {

	public static void main(String[] args) throws Exception {

		// 新建Person
		Person person = new Person();
		// 获取Person的Class实例
		Class<Person> c = Person.class;
		// 获取 somebody() 方法的Method实例
		Method mSomebody = c.getMethod("somebody", new Class[] { String.class, int.class });
		iteratorAnnotations(person.getClass());
		iteratorAnnotations(mSomebody);

	}

	public static void iteratorAnnotations(Class<? extends Person> clazz) {
		// 判断 somebody() 方法是否包含MyAnnotation注解
		if (clazz.isAnnotationPresent(MyAnnotation.class)) {
			// 获取该方法的MyAnnotation注解实例
			MyAnnotation myAnnotation = clazz.getAnnotation(MyAnnotation.class);
			// 获取 myAnnotation的值，并打印出来
			String author = myAnnotation.author();
			System.out.println(clazz.getName()+" 作者:" + author);
		}
	}

	public static void iteratorAnnotations(Method method) {

		// 判断 somebody() 方法是否包含MyAnnotation注解
		if (method.isAnnotationPresent(MyAnnotation.class)) {
			// 获取该方法的MyAnnotation注解实例
			MyAnnotation myAnnotation = method.getAnnotation(MyAnnotation.class);
			// 获取 myAnnotation的值，并打印出来
			String author = myAnnotation.author();
			System.out.println(method.getName() + " 作者:" + author);
		}
	}

}
