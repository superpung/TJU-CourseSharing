package ch12;

/**
 * 内部类例子
 * 
 * @author Administrator
 *
 */
public class InnerClassDemo {

	public InnerClassDemo() {
		// TODO Auto-generated constructor stub
	}

	// 静态内部类
	static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	// 成员内部类
	class StaticInner {

	}

	// 匿名类
	public void go() {
		new Thread(new Runnable() {
			@Override
			public void run() {

			}
		}).start();
	}
}
