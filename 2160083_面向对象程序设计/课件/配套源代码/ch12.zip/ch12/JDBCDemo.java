/**
 * 
 */
package ch12;

import java.io.Closeable;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * @author Administrator
 *
 */
public class JDBCDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// 声明Connection对象
		Connection con = null;
		Statement stmt = null;
		ResultSet rest = null;
		// 驱动程序名
		String driver = "com.mysql.jdbc.Driver";
		// URL指向要访问的数据库名mydata
		String url = "jdbc:mysql://localhost:3306/poem";
		// MySQL配置时的用户名
		String user = "root";
		// MySQL配置时的密码
		String password = "123456";
		// 遍历查询结果集
		try {
			// 加载驱动程序
			Class.forName(driver);
			// 1.getConnection()方法，连接MySQL数据库！！
			con = DriverManager.getConnection(url, user, password);
			// 2. statement类对象，用来执行SQL语句！！
			stmt = con.createStatement();
			// 要执行的SQL语句
			String sql = "select * from poetries";
			// 3.ResultSet类，用来存放获取的结果集！！
			rest = stmt.executeQuery(sql);
			while (rest.next()) {
				// 获取title这列数据
				String title = rest.getString("title");
				String content = rest.getString("content");
				// 输出结果
				System.out.println(title + "\t" + content);
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally {
			close(rest);
			close(stmt);
			close(con);
		}
	}

	public static void close(AutoCloseable obj) {
		if (obj != null) {
			try {
				obj.close();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
