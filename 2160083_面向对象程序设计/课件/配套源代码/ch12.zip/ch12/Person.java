
package ch12;

@MyAnnotation(author="李四")
public class Person {  
   
    @MyAnnotation(author="张三")
    public void somebody(String name, int age){
       // System.out.println("\nsomebody: "+name+", "+age);
    }
    
}