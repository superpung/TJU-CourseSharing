package ch04;
/**
 * final的例子
 * @author Administrator
 *
 */
//这个类声明为final，表示这个类不能再有子类
public final class TestFinal  {
		
		//static类型的 final变量必须在声明的时候赋值; 或者类初始化的时候赋值
		private static final int totalNumber=0;
		private static final int totalId;
		//类初始化的时候赋值
		static {
			totalId=0;
			System.out.println("class init!");
			
		}
		 
		
		
		//final类型实例变量要么在声明时候赋值，要么类初始化时候赋值
		private final int myNumber=0;
		private final int myId;
		public TestFinal(){
			// 在构造方法中对声明为final的变量id赋值
			System.out.println("instance init!");
			myId=1;
		}
		public TestFinal(int id){
			System.out.println("instance init!");
			// 在构造方法中对声明为final的变量id赋值
			myId=id;
		}
		public void setMyId() {
			
			//这里面再给myId赋值非法
			//myId=1;
			//这里面再给totalId赋值非法
			//totalId=1;
		}
   		public static void main(String[] args) {
			new TestFinal();
    	}
}
