package ch04.en;

/**
 * 枚举类型定义
 * 
 * @author Administrator
 *
 */
public enum EnumDirection {
	EAST, SOUTH, WEST, NORTH;
}
