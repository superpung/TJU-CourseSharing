package ch04.en;

//枚举类型另外的用法
public enum EnumDirection2 {
	EAST("东"), SOUTH("南"), WEST("西"), NORTH("北");
	private EnumDirection2(String desc) {//私有类型构造函数
		this.desc = desc;
	}
	private String desc;//存放其他属性，其他属性可以随意增减 
	public String getDesc() {//取得其他属性
		return desc;
	}
}
