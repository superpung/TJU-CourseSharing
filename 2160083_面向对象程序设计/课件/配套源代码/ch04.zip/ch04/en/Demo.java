/**
 * 
 */
package ch04.en;

/**
 * @author admin
 *
 *
 *  
 */
public class Demo {
 
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		//用在switch中
		EnumDirection dir=EnumDirection.NORTH;
		switch(dir) {
		case EAST:
			System.out.println("向东");
			break;
		case WEST:
			System.out.println("向西");
			break;
		case SOUTH:
			System.out.println("向南");
			break;
		case NORTH:
			System.out.println("向北");
			break;
		}
		
		//枚举类型用在 ==中 
		if(dir==EnumDirection.EAST) {
			System.out.println("向东");
		}else if(dir==EnumDirection.WEST) {
			System.out.println("向西");
		}else if(dir==EnumDirection.SOUTH) {
			System.out.println("向南");
		}else if(dir==EnumDirection.NORTH) {
			System.out.println("向北");
		}
		 
	}

}
