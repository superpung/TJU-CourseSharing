/**
 * 
 */
package ch04.en;

/**
 * @author admin
 *
 *
 * 
 */
public class Demo2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		for (int i = 0; i < EnumDirection2.values().length; i++) {
			EnumDirection2 dir = EnumDirection2.values()[i];
			//ordinal()取得序号;getDesc()取得自定义描述
			System.out.println(dir + "=" + dir.getDesc() + "\tindex=" + dir.ordinal());
		}
	}

}
