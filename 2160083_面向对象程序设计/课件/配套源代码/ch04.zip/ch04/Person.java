package ch04;

/**
 * 演示了Java中的一个类
 * 
 * @author Administrator 类的定义
 */
public class Person extends Object{
	/**
	 * 实例变量 又叫域变量、成员变量 访问修饰符可以是private/protected/public 或者干脆没有，但是没有friend 实例
	 * 变量不能重名，例如有一个变量是name，不能再有另外一个name 实例变量如果没有赋值，会有默认值。字符串为null，整数为0....
	 */
	private String name;
	private int age;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	/**
	 * 构造函数同样也可以有修饰符 。构造函数必须和类名字同名，且不能有类型，也不能有返回值，构造函数也可以有修饰符。 构造函数可以有多个
	 * 
	 * @param n
	 * @param a
	 */
	public Person(String n, int a) {
		name = n;
		age = a;
	}

	/**
	 * 实例方法又叫 成员方法、对象方法。同样可以有修饰符。 方法和构造函数最大的区别在于必须要有返回类型（如果什么都不返回则返回void)。
	 */
	public  void sayHello() {

		// 局部变量
		String content=null;
		content = "Hello!  My name is " + name + "!";
		System.out.println(content);

	}

	public void eat() {
		System.out.println("eating!");
	}

	/**
	 * main方法和类没有关系
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
//		System.out.println(new Person("tom", 20).name);
//		System.out.println(new Person("tom", 20).age);
		// 类的使用
		// Person是一个类，person是类的一个实例
		Person person = new Person("tom", 20);
		// 注意调用方法格式
		person.sayHello();
		
		person = new Person("abc", 30);
		// 下面这种方法是错误的
		//Person.sayHello();
		// 也可以这样使用
		Person p;
		p = new Person("li", 19);
		// 和c++不同，使用完以后，不需要释放内存
	}

	@Override
	public String toString() {
		return "Person [name=" + name + ", age=" + age + "]";
	}
	
}
