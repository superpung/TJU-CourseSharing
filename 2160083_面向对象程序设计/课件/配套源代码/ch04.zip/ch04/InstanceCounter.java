package ch04;

public class InstanceCounter {
	private  int id;
	private static int totalCount=0;
	
	public int getId() {
		return id;
	}

	public static int getTotalCount() {
		return totalCount;
	}	
	
	public InstanceCounter() {
		// TODO Auto-generated constructor stub
		id=totalCount++;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		InstanceCounter[] array=new InstanceCounter[10];
		for(int i=0;i<array.length ;i++) {
			array[i] =new InstanceCounter();
			System.out.println("totalCount="+getTotalCount()) ;
		}
		for(int i=0;i<array.length ;i++) {
			System.out.println("myid="+array[i].getId()) ;
		}

	}

}
