package ch04;

/**
 * 
 * @author Administrator
 *
 */
// 用 exctends 表示继承 关系
public class Student extends Person {
	//子类增加的属性
	private String school;
	
	@Override
	public void sayHello() {
		// 如何在子类中调用父类的方法
		super.sayHello();
		System.out.println("My school is " + school);
	}
	
	//子类新增加的方法
	public void study() {
		System.out.println("I am studying! ");
	}

	public Student(String name, int age, String school) {
		// 如何在子类中调用父类的构造函数
		
		super(name, age);
		this.school = school;
	}

	public static void main(String[] arggs) {
		Person p = new Person("Liming", 50);
		p.sayHello();
		Student student = new Student("Wangqiang", 20, "PKU");
		student.sayHello();
		//Student没有定义eat方法，但是在其父类Person中定义了，所以一样可以调用
		student.eat();
		String str="3";
		str=str+student;
		System.out.println(str);
	}

	@Override
	public String toString() {
		return "Student [school=" + school + ", toString()=" + super.toString() + "]";
	}

	
}
