package ch04;

import java.util.Date;

public class Test {

	public Test() {
		// TODO Auto-generated constructor stub
		Date d;
	}
	 
	

}
