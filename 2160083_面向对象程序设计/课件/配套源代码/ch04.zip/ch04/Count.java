package ch04;

/**
 * 本类演示了 变量前面带有static 和不带static 的区别
 * @author cjy
 *
 */
public class Count {
	//每个对象有一个myCount
	public int myCount;
	//整个类（所有的对象）共享一个count
	public static int totalCount;
	
	public int getMyCount() {
		//这里面既可以访问myCount,也可以访问totalCount
		return myCount;
	}

	public void setMyCount(int myCount) {
		this.myCount = myCount;
		//这里面既可以访问myCount,也可以访问totalCount
	}

	public static int getTotalCount() {
		//注意这里不能使用myCount		 
		return totalCount;
	}

	public static void setTotalCount(int totalCount) {
		//注意这里不能使用myCount
		Count.totalCount = totalCount;
	}

	public static void main(String args[]) {		 
		Count count = new Count();
		count.setMyCount(1);
		//下面的方法可以，但是编程风格不好，建议Count.setTotalCount(1);
		Count.setTotalCount(1); 
		System.out.println("count.myCount=" + count.getMyCount());
		System.out.println("count.count=" + Count.getTotalCount());
		
		Count count2 = new Count();
		count2.setMyCount(2);

		Count.setTotalCount(2);
		
		System.out.println("count1.myCount=" + count.getMyCount());
		System.out.println("count2.myCount=" + count2.getMyCount());
		System.out.println("count1.count=" + Count.getTotalCount());

	}

}
