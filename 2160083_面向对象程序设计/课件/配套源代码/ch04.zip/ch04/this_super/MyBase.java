package ch04.this_super;

public class MyBase {

	public MyBase(String s) {

	}
	
}
