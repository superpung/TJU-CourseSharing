package ch04.this_super;

/**
 * 推论2：如果一个类，显示的声明了构造函数，
 * 且没有无参数构造函数，则其子类必须显式的声明构造函数

 * @author  cjy
 * 这个类编译不过去 为什么？？
 */
public class MySub2 extends MyBase {

}
