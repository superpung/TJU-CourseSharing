package ch04.this_super;

/**
 * this super在什么情况下默认调用
 * @author Administrator
 *
 */
public class Son extends Father{
	  String sonName;
	  public Son( ){
	    System.out.println("I am default constrctor of son!");
	  }
	  /**
	   * @param sonName
	   */
	  public Son(String sonName){
		 //每个子类的构造函数，第一行其实默认的调用了父类 无参数构造方法super();
		  //但是如果手工调用了父类构造函数，则不会默认调用父类无参数构造方法
		  //本例子会调用super();
	    this.sonName=sonName;    
	  }
	  public Son(String sonName,String fatherName){
		  //每个子类的构造函数，第一行其实默认的调用了父类 无参数构造方法super();
		  //但是如果手工调用了父类构造函数，则不会默认调用父类无参数构造方法
		  //本例子不会调用super();
	    super(fatherName);
	    this.sonName=sonName;    
	  }

}
