package ch04;

/**
 * 展示了重载overload,以及this的用法
 * 
 * @author Administrator
 *
 */
public class Dog {

	private String name;
	private int weight;
	
	//构造函数
	public Dog(String name, int weight) {
		//this.name表示对象的属性，name表示函数送入的参数
		this.name = name;
		this.weight = weight;
	}	
	//构造函数的重载
	public Dog( int weight,String name) {
		//构造函数里面可以用this...调用其他构造函数
		//但是只能放在构造函数第一行
		this(name,weight); 		
 		//this.name = name;
 		//this.weight = weight;	
	}	
	//构造函数的重载
	public Dog(int weight) {
		this("noname",weight);
	}
	
	
	/**
	 * 重载的例子
	 * 两个speak一个有参数，一个没有参数
	 */
	public void speak() {
		System.out.println("wang wang!");
	}
	/**
	 * 重载的例子
	 * 两个speak一个有参数，一个没有参数
	 */
	public void speak(String content) {
		System.out.println(content);
	}
	

	public static void main(String[] args) {
		Dog dog=new Dog( 0 ); 
		 
	}
	

}
