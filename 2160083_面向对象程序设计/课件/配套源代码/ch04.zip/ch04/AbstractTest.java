package ch04;

/**
 * abstract的例子
 * @author Administrator
 *
 */

//这个类是抽象类，不能实例化
//实际上抽象类通常定义在自己的文件中
abstract class C{
	abstract void callme( );
	void metoo( ){
		System.out.println("Inside C's metoo( ) method");
	}
}
//这个类继承了抽象类，并且自己本身不是抽象类，则必须实现抽象类方法
class D extends C{
	void callme( ){
		System.out.println("Inside D's callme( ) method");
	}
}
	
//这个类是抽象类，可以仍然不实现父类的抽象方法
abstract class E extends C{
	 
}
	
public class AbstractTest{
	public static void main( String args[ ] ){
		 
		C c = new D( );
		c.callme( );
		c.metoo( );
	}
}