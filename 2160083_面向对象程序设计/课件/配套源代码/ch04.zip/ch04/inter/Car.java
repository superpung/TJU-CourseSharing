package ch04.inter;

public class Car implements Runner {

	public Car() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println("car run!");
	}

}
