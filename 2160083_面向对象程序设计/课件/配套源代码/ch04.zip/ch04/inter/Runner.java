package ch04.inter;

//一个接口的例子
public interface Runner {
	//接口中的方法不能有实现，并且必须是共有的
	public void run();

}
