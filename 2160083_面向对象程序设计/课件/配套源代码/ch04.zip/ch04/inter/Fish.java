package ch04.inter;

public class Fish extends Animal implements Swimmer {

	public Fish() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void swim() {
		// TODO Auto-generated method stub
		System.out.println("Fish swim!");
	}

	@Override
	public void eat() {
		// TODO Auto-generated method stub
		System.out.println("Fish eat!");
	}

}
