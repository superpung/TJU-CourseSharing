/**
 * 
 */
package ch04.inter;

/**
 * @author Administrator
 *
 */
public class ParentSubInterfaceAssign {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="1";
		//子类赋值给父类，可以
		Object obj=str;
		//父类赋值给子类，不可以
		str =obj;
		//如果父类一定要赋值给子类，需要强制类型转换,并且要保证父类可以转换为子类
		str =(String)obj;
		
		obj=new Object();
		//下面的写法编译时候不会报错，但是运行时候肯定报错
		str =(String)obj;
		
		//Frog实现了Swimmer;		
		
		Frog frog=new Frog();
		//Frog可以赋值给Swimmer/Runner
		Swimmer swimmer=frog;
		Runner runner=frog;
		//接口赋值给子类，不可以 
		frog=swimmer;
		//如果一定要赋值，强制转换
		frog=(Frog)swimmer;
		
		swimmer=new Fish();
		//下面的类型转换运行的时候要报错
		frog=(Frog)swimmer;
		
	}

}
