package ch04.inter;

public class Frog extends Animal implements Runner,Swimmer {

	public Frog() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void eat() {
		// TODO Auto-generated method stub
		System.out.println("Frog eat!");
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println("Frog run!");
	}

	@Override
	public void swim() {
		// TODO Auto-generated method stub
		System.out.println("Frog swim!");
	}

}
