package ch04.inter;

/**
 * 接口实现的例子
 * 
 * @author Administrator
 *
 */
public abstract class Animal {
	abstract public void eat();

}
