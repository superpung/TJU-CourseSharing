package ch04.inter;

//一个接口的例子
public interface Swimmer {
	//接口中只能有公有或者没有修饰符的方法
	//private String name; 错误
	//接口中的方法不能有实现，并且必须是共有的,如果没有修饰符默认为公有（这个和类中不一样）	
	public void swim(); 
	/**
	 * 允许有default方法实现
	 * jdk1.8新特性，
	 * @return
	 */
	default int getSwimSpeed () {
		return 0;
	}
}
