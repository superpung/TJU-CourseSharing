package ch04.inter;

public class InterfaceUsage {

	public InterfaceUsage() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		InterfaceUsage demo = new InterfaceUsage();
		Car car = new Car();
		Fish fish = new Fish();
		Frog fog = new Frog();
		demo.startRun(car);
		demo.startRun(fog);
		demo.startSwim(fish);
		demo.startSwim(fog);
	}

	public void startRun(Runner runner) {
		System.out.println("start run...");
		runner.run();
		System.out.println("end run...");
		System.out.println("------------------------------");
	}

	public void startSwim(Swimmer swimmer) {
		System.out.println("start swim...");
		swimmer.swim();
		System.out.println("end swim...");
		System.out.println("------------------------------");
	}
}
