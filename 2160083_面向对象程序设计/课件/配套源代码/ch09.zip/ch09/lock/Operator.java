package ch09.lock;

/**
 * 死锁的例子
 * @author Administrator
 *
 */
public class Operator implements Runnable {

	Operator anotherOperator;

	synchronized public void methodA(int depth) {
		System.out.println(Thread.currentThread().getName() + ":begin methodA");
		if(depth<=0) {
			return;
		}
		try {
			 Thread.sleep(100);
		} catch (Exception e) {
		}
		System.out.println(Thread.currentThread().getName() + ":call another methodA");
		anotherOperator.methodA(--depth);
		System.out.println(Thread.currentThread().getName() + ":end methodA");
	}

	public void run() {
		methodA(1);
		
	}

}
