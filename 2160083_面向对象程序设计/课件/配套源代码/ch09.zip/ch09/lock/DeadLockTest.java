package ch09.lock;

/**
 * 死锁的例子
 * 
 * @author Administrator
 *
 */
public class DeadLockTest {
	public static void main(String args[]) {
		Operator o1 = new Operator();
		Operator o2 = new Operator();

		o1.anotherOperator = o2;
		o2.anotherOperator = o1;

		Thread t1 = new Thread(o1);
		Thread t2 = new Thread(o2);
		t1.start();
		t2.start();
		
	}

}
