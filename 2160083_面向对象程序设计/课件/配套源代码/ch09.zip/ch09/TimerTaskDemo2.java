package ch09;

import java.util.Timer;
import java.util.TimerTask;

/**
 * timertask例子
 * 
 * @author cjy
 *
 */

public class TimerTaskDemo2 extends  TimerTask {
	private int i=0;
	public TimerTaskDemo2() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		Timer timer = new Timer();
		timer.schedule(new TimerTaskDemo2(), 0, 1000L);
	}
	public void run() {
		System.out.println(i++);
	}
}
