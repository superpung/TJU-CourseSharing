package ch09;

/**
 * 多线程的例子
 * 
 * @author Administrator
 *
 */
public class TestThread2 {
	public static void main(String args[]) {
		MyThread2 mytask = new MyThread2(100);
		Thread t = new Thread(mytask);
		t.start();
	}
}

class MyThread2 implements Runnable {
	private int n;
	public MyThread2(int n) {
		this.n = n;
	}
	public void run() {
		for (int i = 0; i < n; i++) {
			System.out.print(" " + i);
			if ((i + 1) % 20 == 0) {
				System.out.println("");
			}
			try {
				Thread.sleep(200);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
