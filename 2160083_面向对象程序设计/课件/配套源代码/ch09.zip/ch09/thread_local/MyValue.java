/**
 * 
 */
package ch09.thread_local;

/**
 * ThreadLocal的例子
 * @author cjy
 *
 */
public class MyValue {
	private static final ThreadLocal<String> session = new ThreadLocal<String>();

	public static ThreadLocal<String> getSession() { 
		return session;
	}


}
