package ch09.thread_local;

/**
 *  ThreadLocal 变量
 * @author cjy
 *
 */
public class MyThreadLocal extends Thread {
	public void run() {
		for(int i=0;i<5;i++){
			try {
				Thread.currentThread().getName();
				String value=this.getName()+" "+i;
				MyValue.getSession().set(value);
				Thread.sleep(1000);
				MyFunction.print();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}			
		}
	}
	public static void main(String[] args) {
		for (int i = 0; i < 2; i++) {
			new MyThreadLocal().start();
		}
	}	
}
