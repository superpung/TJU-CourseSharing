package ch09.thread_local;

public class MyFunction {
	public static void print() {

		System.out.println(MyValue.getSession().get());

	}
}
