package ch09;

/**
 * 本例子显示了不同的优先级对线程的影响
 * 
 * @author Administrator
 *
 */
public class TestThreadPriority {
	public static void main(String args[]) {
		Thread[] threads = new Thread[10];
		for (int i = 0; i < threads.length; i++) {
			threads[i] = new Thread(new MyRunner(i));
			if (i % 3 == 0) {
				threads[i].setPriority(Thread.MAX_PRIORITY);
			} else if (i % 3 == 1) {
				threads[i].setPriority(Thread.NORM_PRIORITY);
			} else {
				threads[i].setPriority(Thread.MIN_PRIORITY);
			}
		}
		for (int i = 0; i < threads.length; i++) {
			threads[i].start();
		}
	}
}

class MyRunner implements Runnable {
	int id;

	MyRunner(int id) {
		this.id = id;
	}

	public void run() {
		double t = 0;

		for (int j = 0; j < 100000000; j++) {
			t = t + j;
			// if (j % 100 == 0) {
			// Thread.currentThread().yield();
			// }
		}

		System.out.println(id + " finished!");
	}
}
