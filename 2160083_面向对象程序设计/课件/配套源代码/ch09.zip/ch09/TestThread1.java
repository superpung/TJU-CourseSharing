package ch09;

/**
 * 多线程的例子，注意运行程序时候的输出
 * 
 * @author Administrator
 *
 */
public class TestThread1 {
	public static void main(String args[]) {
		Thread t = new MyThread1(100);
		t.start();
		System.out.println("Main thead end!");
	}
}

class MyThread1 extends Thread {
	private int n;
	public MyThread1(int n) {
		this.n = n;
	}
	public void run() {
		for (int i = 0; i < n; i++) {
			System.out.print(" " + i);
			if ((i + 1) % 20 == 0) {
				System.out.println("");
			}
			try {
				Thread.sleep(200);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}