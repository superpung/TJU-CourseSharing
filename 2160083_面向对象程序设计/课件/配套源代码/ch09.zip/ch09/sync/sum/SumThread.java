package ch09.sync.sum;

public class SumThread extends Thread{
	private long start;
	private long end;
	private double sum;
	public SumThread(long start, long end) {
		super();
		this.start = start;
		this.end = end;
	}
	 public double getSum() {
		return sum;
	}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		sum=0;
		for(long i=start;i<end;i++) {
			sum=sum+i;
		}
	}
}
