package ch09.sync.sum;

public class SumMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int threadCount = 100;
		double sum = 0;
		long mill=System.currentTimeMillis();
		SumThread[] threads = new SumThread[threadCount];
		long start = 0;
		long end = 1000000000L;
		for (int i = 0; i < threads.length; i++) {
			long threadStart = start + (end - start) / threadCount * i;
			long threadEnd = start + (end - start) / threadCount * (i + 1);
			threads[i] = new SumThread(threadStart, threadEnd);
			threads[i].start();
		}
		for (int i = 0; i < threads.length; i++) {
			try {
				threads[i].join();
				sum = sum + threads[i].getSum();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		System.out.println((System.currentTimeMillis()-mill)+" ms cost!");
		System.out.println("sum=" + sum);

	}

}
