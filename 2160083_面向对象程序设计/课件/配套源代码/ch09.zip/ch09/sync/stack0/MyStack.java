/**
 * 
 */
package ch09.sync.stack0;

/**
 * @author Administrator
 *
 */
public class MyStack {
	private static int SIZE = 1;
	private int index = 0;
	private Object[] data = new Object[SIZE];

	public boolean push(Object obj) {
		if (!this.isFull()) {
			dosth();
			data[index++] = obj;
			return true;
		}
		return false;
	}

	public Object pop() {
		if (!this.isEmpty()) {
			dosth();
			return data[--index];
		}
		return null;
	}

	public void dosth() {
		try {
			Thread.sleep(10);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public boolean isFull() {
		return index >= SIZE;
	}

	public boolean isEmpty() {
		return index == 0;
	}

	

}
 
