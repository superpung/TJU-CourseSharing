package ch09.sync.stack1;

public class MyStackUserThread extends Thread {
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyStack  stack = new MyStack ();
		int threadCount=10;
		MyStackUserThread[] threads = new MyStackUserThread[threadCount];
		for (int i = 0; i < threads.length; i++) {
			threads[i] = new MyStackUserThread(stack);
		}
		for (int i = 0; i < threads.length; i++) {
			threads[i].start();
		}

	}
	
	private MyStack stack;

	MyStackUserThread(MyStack stack) {
		this.stack = stack;
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		for (int i = 0; i < 100; i++) {
			if (Math.random() > 0.5) {
				System.out.println(Thread.currentThread().getName() + " push!");
				stack.push("test");
			} else {
				System.out.println(Thread.currentThread().getName() + " pop!");
				stack.pop();
			}
		}
	}
}
