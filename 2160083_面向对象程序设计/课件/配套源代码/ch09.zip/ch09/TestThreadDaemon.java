package ch09;

/**
 * Daemon线程和非Daemon线程的区别
 * 
 * @author Administrator
 *
 */
public class TestThreadDaemon {
	public static void main(String args[]) {

		Thread t1 = new MyThread();
		// 尝试一下false
		t1.setDaemon(true);
		t1.start();
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("main thread end");
	}
}

class MyThread extends Thread {
	static int id = 0;

	MyThread() {
		id++;
	}

	public void run() {
		System.out.println("Start");
		for (int i = 0; i < 100; i++) {
			System.out.println(i);
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
			}
			// yield();
		}
	}
}

/*
 * 9.2.4 Daemon线程
 * 线程有两种，一类是Daemon线程，一类是非Daemon线程。在Java程序中，若还有非Demon线程，则整个程序就不会结束；而Daemon线程，
 * 可以在整个程序结束后继续运行，所以Demon线程可以用于后台服务程序。
 * 通过调用isDaemon()，可检查一个线程是不是一个Daemon；用setDaemon (boolean
 * flg)方法可以将一个线程设为Daemon线程。在一个Daemon线程中创建的子线程，也自动是Daemon线程。
 * 
 */