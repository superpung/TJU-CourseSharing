package ch09.producer_consumer;

/**
 * 一个生产者、消费者模型的例子
 */
public 
/** 生产者线程 */
class Producer extends Thread {
	private Stack theStack;
	private int index = 0;
	public Producer(Stack s, String name) {
		super(name);
		theStack = s; 
	}

	public void run() {
		try {
			String goods;
			while (true) {
				goods = "goods " + (index++);
				theStack.push(goods);
				Thread.sleep((long) (100+Math.random() * 1000L));
			}
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}

