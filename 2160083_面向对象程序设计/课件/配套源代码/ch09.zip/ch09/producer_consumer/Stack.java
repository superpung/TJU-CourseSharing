package ch09.producer_consumer;

/**
 * 一个支持生产者、消费者模型的堆栈
 * @author Administrator
 *
 */
public class Stack {
	private int SIZE=10;
	private String name;
	private String[] buffer = new String[SIZE];
	int point = -1;

	public Stack(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public int getPoint() {
		return point;
	}

	public  synchronized String pop() throws InterruptedException {
		while ((point + 1) <= 0) {
			this.wait();
		}
		String goods = buffer[point];
		buffer[point--] = null;
		System.out.println(" pop " + goods + " cur stack size  =" + (point + 1));
		this.notifyAll();
		return goods;
	}

	public synchronized void push(String goods) throws InterruptedException {
		while ((point + 1) >= SIZE) {
			this.wait();
		}
		buffer[++point] = goods;
		System.out.println(" push " + goods + " cur stack size  =" + (point + 1));
		this.notifyAll();
	}
}
