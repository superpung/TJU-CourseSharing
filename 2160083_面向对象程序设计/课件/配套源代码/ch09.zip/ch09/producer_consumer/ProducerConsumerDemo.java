﻿package ch09.producer_consumer;

/**
 * 一个生产者、消费者模型的例子
 * @author Administrator
 *
 */
public class ProducerConsumerDemo {
	

	public static void main(String args[]) {
		Stack stack = new Stack("stack1");

		new Producer(stack, "producer1").start();

		new Consumer(stack, "consumer1").start();

	}

	
	
}
