package ch09.producer_consumer;

/**
 * 一个生产者、消费者模型的例子
 * 
 * @author Administrator
 *
 */
public class Consumer extends Thread {
	private Stack theStack;

	public Consumer(Stack s, String name) {
		super(name);
		theStack = s;
	}

	public void run() {
		try {
			String goods;
			while (true) {
				goods = theStack.pop();
				Thread.sleep((long) (100 + Math.random() * 1000L));
			}

		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
