package ch02;

//导入输入输出包
import java.io.*;

/**
 * 例子2-5 本例子演示了如何从控制台读入一个数字（浮点或者整数）并输出
 * 
 * @author Administrator
 * 
 */
public class AppNumInOut {
	public static void main(String[] args) {
		String s = "";
		int n = 0;
		double d = 0;
		try {
			BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
			System.out.print("Please input an int: ");
			s = in.readLine();
			n = Integer.parseInt(s);
			System.out.print("Please input a double: ");
			s = in.readLine();
			d = Double.parseDouble(s);
			//异常的处理，初学者可以忽略这部分
		} catch (IOException e) {
		}
		System.out.println("You have entered: " + n + " and " + d);
	}
}
