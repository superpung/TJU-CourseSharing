/**
 * 例子2-1 重点掌握
 * Hellow world的例子
 * 本例子演示如何执行一个最简单的hello world程序
 *
 * @author Administrator
 *
 */

package ch02;//包的名字，注意一定要和目录严格匹配

// 注意如何定义一个类，每个.java文件只能定义一个public 类，类名字必须和文件名完全符合
public class HelloWorldApp {
	
	//任何一个Application程序必须要有一个 public static void main(String arg[])方法
	//但是不是所有的类都需要 main方法
	public static void main(String args[]) {
		System.out.println("Hello World!");
		// System.out.println("")等价于C++中的printf()
	}
}
