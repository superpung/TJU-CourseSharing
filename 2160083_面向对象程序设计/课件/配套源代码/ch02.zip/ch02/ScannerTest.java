/**
 * 
 */
package ch02;

import java.util.Scanner;

/**
 * 例子2-4，一般了解 从控制台读入一个整数，将平方输出。
 * 
 * @author Administrator
 *
 */
public class ScannerTest {

	/**
	 * 
	 */
	public ScannerTest() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		System.out.println("please input num:");
		int a = scanner.nextInt();
		System.out.printf("%d ^2=%d", a, a * a);
	}

}
