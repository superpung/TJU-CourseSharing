package ch02;

import java.io.*;

/**
 * 本例子演示了如何从控制台读入一个行字符，并输出。
 * 
 * @author Administrator
 *
 */
public class AppLineInOut {
	public static void main(String[] args) {
		String s = "";
		System.out.print("Please input a line: ");
		try {
			BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
			s = in.readLine();
		} catch (IOException e) {
		}
		System.out.println("You have entered: " + s);
	}
}
