//包的名字
package ch02;
//引用其他的包，类似C++中的 include
import java.util.*;

/**
 * 显示日期的一个例子
 * 
 * @author Administrator
 *
 */
public class HelloDate {
	
	public static void main(String[] args) {
		System.out.println("Hello, it's: ");
		//注意输出日期的格式取决于本机操作系统的区域、语言
		System.out.println(new Date());
	}
}
