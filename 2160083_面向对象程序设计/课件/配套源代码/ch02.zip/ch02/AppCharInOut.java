package ch02;

import java.io.*;

/**
 * 例子2-3
 * 
 * 本例子演示了如何从控制台读入一个字符，并输出。
 * 
 * @author Administrator
 *
 */
public class AppCharInOut {
	public static void main(String[] args) {
		char c = ' ';
		System.out.print("Please input a char: ");
		try {
			c = (char) System.in.read();
		} catch (IOException e) {
		}
		System.out.println("You have entered: " + c);
	}
}
