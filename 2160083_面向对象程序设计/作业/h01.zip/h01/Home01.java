/**
 * 
 */
package com.huawei.classroom.student.h01;

/**
 * 本程序存在错误，请修改本程序存在的错误，完成hello world程序
 * @author Administrator
 *
 */
public class Home01 {



	/**
	 * @param args
	 */
	public void main() 
		// TODO Auto-generated method stub
		System.out.println(hello world)
	}

}
