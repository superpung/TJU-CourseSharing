package com.huawei.classroom.student.h17;

public class HeavyTank extends Tank {

	public HeavyTank( GameObjectVo vo) {
		super(vo);
		// TODO Auto-generated constructor stub
		//super( Param.TANK_HEAVY_HEALTH,Param.TANK_HEAVY_STRENGTH);
	}


}
