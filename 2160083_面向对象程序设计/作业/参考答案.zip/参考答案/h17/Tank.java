package com.huawei.classroom.student.h17;

public  class Tank extends GameObject  {
 
	public Tank( GameObjectVo vo) {
		super(vo); 
		// TODO Auto-generated constructor stub
	}
 


}
