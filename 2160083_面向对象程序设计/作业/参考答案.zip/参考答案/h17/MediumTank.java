package com.huawei.classroom.student.h17;

public class MediumTank extends Tank {

	public MediumTank( GameObjectVo vo) {
		super(vo);
		// TODO Auto-generated constructor stub
		//super( Param.TANK_MEDIUM_HEALTH,Param.TANK_MEDIUM_STRENGTH );
	}
}
