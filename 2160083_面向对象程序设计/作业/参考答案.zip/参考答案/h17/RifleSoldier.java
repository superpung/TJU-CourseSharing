package com.huawei.classroom.student.h17;

public class RifleSoldier extends Soldier {



	public RifleSoldier( GameObjectVo vo ) {
		super(vo);
		//super(  Param.SOLDIER_HEALTH,Param.SOLDIER_RIFLE_STRENGTH);
		// TODO Auto-generated constructor stub
	}


}
