import scipy.io as sio
from sklearn import svm
from sklearn.metrics import accuracy_score
import numpy as np
from sklearn.model_selection import train_test_split

# 加载.mat文件
EEG = sio.loadmat('EEGdata.mat')

# 查看文件中的变量
print(EEG.keys())
# print(EEG['de_1'].shape)
data_dict = ['de_1','de_2','de_3','de_4','de_5',
            'de_6','de_7','de_8','de_9','de_10',
            'de_11','de_12','de_13','de_14','de_15']
EEG_label = EEG['label'][0]

for f in range(5):
    data_obj = EEG[data_dict[0]][:,:,f].T
    data_label = np.full((1, EEG[data_dict[0]].shape[1]), EEG_label[0])
    # print(data_label)

    for i in range(1,15):
        data_obj = np.vstack([data_obj, EEG[data_dict[i]][:,:,f].T])
        data_label = np.hstack([data_label, np.full((1, EEG[data_dict[i]].shape[1]), EEG_label[i])])

    data_label = data_label.ravel()

    X_train, X_test, y_train, y_test = train_test_split(data_obj,data_label,test_size=0.2, random_state=42)
    print(X_train.shape)
    # 训练SVM模型
    svm_model = svm.SVC(kernel='rbf')
    svm_model.fit(X=X_train, y=y_train)

    # 在测试集上进行预测
    predict_label_svm = svm_model.predict(X_test)

    # 计算预测准确率
    accuracy_SVM = accuracy_score(y_test, predict_label_svm)
    print("当频域为%d时，准确率为%.6f" % (f , accuracy_SVM))