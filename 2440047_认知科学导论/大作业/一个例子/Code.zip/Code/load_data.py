from collections import defaultdict
import h5py
import numpy as np
import pickle
from typing import List, Optional, Tuple
import torch
import random
import os
from torch.utils.data import DataLoader, Dataset

class EEGDataset(torch.utils.data.Dataset):
    """EEG数据集基类"""
    def __init__(self, file_path: str, remove_inx: List = None, is_train: bool = True):
        self.is_train = is_train
        self.remove_inx = remove_inx or []  # 确保remove_inx不是None

        with open(file_path, 'rb') as f:
            data_dict = pickle.load(f)
            eeg_data = data_dict['data']
            if is_train:
                labels = data_dict['label']

        # 过滤需要排除的受试者
        eeg_data = [v[0] for k, v in eeg_data.items() if k not in remove_inx]
        eeg_data = np.vstack(eeg_data)
        self.data = torch.from_numpy(eeg_data).to(torch.float32)
        
        if is_train:
            labels = [v for k, v in labels.items() if k not in remove_inx]
            labels = np.hstack(labels)
            self.label = torch.from_numpy(labels).reshape(-1).to(torch.long)
            
    def __getitem__(self, index):
        if self.is_train:
            return self.data[index], self.label[index]
        else:
            return self.data[index]  # 测试集只返回数据，没有标签

    def __len__(self):
        return self.data.shape[0]


class FeatureFusionDataset(Dataset):
    """特征融合数据集"""
    def __init__(self, de_file: str, power_file: str, remove_inx: List = None, is_train: bool = True):
        self.de_dataset = EEGDataset(de_file, remove_inx, is_train)
        self.power_dataset = EEGDataset(power_file, remove_inx, is_train)
        self.is_train = is_train
        
        # 验证两个数据集是否对齐
        assert len(self.de_dataset) == len(self.power_dataset), "DE和Power特征数据集大小不一致"
        if is_train:
            assert torch.equal(self.de_dataset.label, self.power_dataset.label), "DE和Power标签不一致"
    
    def __len__(self):
        return len(self.de_dataset)
    
    def __getitem__(self, index):
        # 获取DE特征
        de_data = self.de_dataset[index]
        # 获取Power特征
        power_data = self.power_dataset[index]
        
        if self.is_train:
            # 训练模式：返回数据和标签
            de_data, de_label = de_data
            power_data, power_label = power_data
            # 验证标签一致性
            assert de_label == power_label, f"索引 {index} 的标签不一致: DE={de_label}, Power={power_label}"
            # 特征融合 - 拼接
            combined = torch.cat([de_data, power_data], dim=-1)  # 在最后一个维度拼接
            return combined, de_label
        else:
            # 测试模式：只返回数据，没有标签
            # 特征融合 - 拼接
            combined = torch.cat([de_data, power_data], dim=-1)
            return combined


class EEGDataLoader:
    """EEG数据加载器（支持特征融合开关和测试集加载）"""
    def __init__(self, config):
        self.config = config
        self.data_path = config.data_path
        self.use_fusion = config.use_fusion  # 是否使用特征融合
        self.feature_type = config.feature_type.lower() if hasattr(config, 'feature_type') else 'de'  # 当不使用融合时的特征类型

        
        # 验证特征类型
        if not self.use_fusion and self.feature_type not in ['de', 'power']:
            raise ValueError(f"无效的特征类型: {self.feature_type}。请选择 'de' 或 'power'")
    
    def load_dataset_for_subject(self, test_subject_id: int, subject_ids: List[int]) -> Tuple[DataLoader, DataLoader, int]:
        """
        为指定受试者加载训练集和测试集（有标签）
        
        参数:
        test_subject_id: 测试受试者ID
        subject_ids: 所有受试者ID列表
        
        返回:
        train_loader: 训练数据加载器
        test_loader: 测试数据加载器（有标签）
        num_classes: 类别数量
        """
        # 创建训练集（排除测试受试者）
        train_remove_inx = [test_subject_id]
        # 创建测试集（仅包含测试受试者）
        test_remove_inx = [i for i in subject_ids if i != test_subject_id]
        
        # 创建数据集
        if self.use_fusion:
            # 特征融合模式
            train_dataset = FeatureFusionDataset(
                de_file=os.path.join(self.data_path, self.config.train_de_file),
                power_file=os.path.join(self.data_path, self.config.train_power_file),
                remove_inx=train_remove_inx,
                is_train=True
            )
            
            test_dataset = FeatureFusionDataset(
                de_file=os.path.join(self.data_path, self.config.train_de_file),
                power_file=os.path.join(self.data_path, self.config.train_power_file),
                remove_inx=test_remove_inx,
                is_train=True
            )
        else:
            # 单特征模式
            # 根据feature_type选择正确的文件
            feature_file = self.config.train_de_file if self.feature_type == 'de' else self.config.train_power_file
            
            train_dataset = EEGDataset(
                file_path=os.path.join(self.data_path, feature_file),
                remove_inx=train_remove_inx,
                is_train=True
            )
            
            test_dataset = EEGDataset(
                file_path=os.path.join(self.data_path, feature_file),
                remove_inx=test_remove_inx,
                is_train=True
            )
        
        # 打印数据集信息
        sample_input, sample_label = train_dataset[0]
        feature_mode = "特征融合" if self.use_fusion else f"单特征({self.feature_type})"
        print(f"[训练/验证模式] {feature_mode} | 训练集大小: {len(train_dataset)} | 测试集大小: {len(test_dataset)}")
        print(f"输入形状: {sample_input.shape} | 标签: {sample_label}")
        
        # 创建数据加载器
        train_loader = DataLoader(
            train_dataset, 
            batch_size=self.config.batch_size, 
            shuffle=True,
            num_workers=0
        )
        
        test_loader = DataLoader(
            test_dataset, 
            batch_size=self.config.batch_size, 
            shuffle=False,
            num_workers=0
        )
        
        # 类别数量
        num_classes = 2
        
        return train_loader, test_loader, num_classes
    
    def load_test_set(self,) -> DataLoader:
        """
        加载测试集（无标签）
        
        参数:
        test_subject_id: 测试受试者ID
        subject_ids: 所有受试者ID列表
        
        返回:
        test_loader: 测试数据加载器（无标签）
        """
        # 测试集只包含指定受试者
        test_remove_inx = []
        
        if self.use_fusion:
            # 特征融合测试集
            test_dataset = FeatureFusionDataset(
                de_file=os.path.join(self.data_path, self.config.test_de_file if hasattr(self.config, 'test_de_file') else self.config.train_de_file),
                power_file=os.path.join(self.data_path, self.config.test_power_file if hasattr(self.config, 'test_power_file') else self.config.train_power_file),
                remove_inx=test_remove_inx,
                is_train=False  # 测试模式，无标签
            )


        else:
            # 单特征测试集
            feature_file = self.config.test_de_file if self.feature_type == 'de' and hasattr(self.config, 'test_de_file') else self.config.test_power_file if self.feature_type == 'power' and hasattr(self.config, 'test_power_file') else self.config.train_de_file if self.feature_type == 'de' else self.config.train_power_file
            
            test_dataset = EEGDataset(
                file_path=os.path.join(self.data_path, feature_file),
                remove_inx=test_remove_inx,
                is_train=False  # 测试模式，无标签
            )
        
        # 打印测试集信息
        sample_input = test_dataset[0]
        feature_mode = "特征融合" if self.use_fusion else f"单特征({self.feature_type})"
        print(f"[测试模式] {feature_mode} | 测试集大小: {len(test_dataset)}")
        print(f"输入形状: {sample_input.shape}")
        
        # 创建测试数据加载器
        test_loader = DataLoader(
            test_dataset, 
            batch_size=self.config.batch_size, 
            shuffle=False,  # 测试集不需要打乱
            num_workers=0
        )
        
        return test_loader


class Config:
    """配置类"""
    def __init__(self, use_fusion=True, feature_type='de'):
        self.data_path = './data/'
        self.train_de_file = 'train_de_data.pkl'
        self.train_power_file = 'train_power_data.pkl'
        # 可选的测试集文件（如果与训练集文件不同）
        self.test_de_file = 'test_de_data.pkl'
        self.test_power_file = 'test_power_data.pkl'
        self.batch_size = 32
        self.use_fusion = use_fusion  # 是否使用特征融合
        self.feature_type = feature_type  # 当不使用融合时的特征类型


if __name__ == '__main__':
    # 测试不同配置
    subject_ids = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]  # 假设有12个受试者
    
    print("="*50)
    print("测试特征融合模式")
    # 创建配置实例（特征融合模式）
    config_fusion = Config(use_fusion=True)
    data_loader_fusion = EEGDataLoader(config_fusion)
    
    # 加载训练/验证集
    print("\n加载训练/验证集:")
    train_loader, val_loader, _ = data_loader_fusion.load_dataset_for_subject(
        test_subject_id=4,
        subject_ids=subject_ids
    )
    
    # 加载测试集
    print("\n加载测试集:")
    test_loader = data_loader_fusion.load_test_set()
    
    print("\n" + "="*50)
    print("测试单特征模式 (DE)")
    # 创建配置实例（单特征模式 - DE）
    config_de = Config(use_fusion=False, feature_type='de')
    data_loader_de = EEGDataLoader(config_de)
    
    # 加载训练/验证集
    print("\n加载训练/验证集:")
    train_loader, val_loader, _ = data_loader_de.load_dataset_for_subject(
        test_subject_id=4,
        subject_ids=subject_ids
    )
    
    # 加载测试集
    print("\n加载测试集:")
    test_loader = data_loader_de.load_test_set()
    
    print("\n" + "="*50)
    print("测试单特征模式 (Power)")
    # 创建配置实例（单特征模式 - Power）
    config_power = Config(use_fusion=False, feature_type='power')
    data_loader_power = EEGDataLoader(config_power)
    
    # 加载训练/验证集
    print("\n加载训练/验证集:")
    train_loader, val_loader, _ = data_loader_power.load_dataset_for_subject(
        test_subject_id=4,
        subject_ids=subject_ids
    )
    
    # 加载测试集
    print("\n加载测试集:")
    test_loader = data_loader_power.load_test_set()
