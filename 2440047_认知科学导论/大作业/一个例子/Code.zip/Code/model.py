import torch
import torch.nn as nn
import torch.nn.functional as F





class EEGFusionNet(nn.Module):
    """支持特征融合的时空频EEG网络"""
    def __init__(self, num_classes, channels=5, time_steps=59):
        super(EEGFusionNet, self).__init__()
        self.input_channels = channels
        
        # 时间特征提取流
        self.time_stream = nn.Sequential(
            nn.Conv1d(channels, 64, kernel_size=15, padding=7),
            nn.BatchNorm1d(64),
            nn.ELU(),
            nn.MaxPool1d(2),
            nn.Conv1d(64, 128, kernel_size=7, padding=3),
            nn.BatchNorm1d(128),
            nn.ELU(),
            nn.MaxPool1d(2)
        )
        
        # 频段特征提取流 - 自适应不同通道数
        self.freq_stream = nn.Sequential(
            nn.Conv1d(time_steps, 64, kernel_size=5, padding=2),
            nn.BatchNorm1d(64),
            nn.ELU(),
            nn.MaxPool1d(2),
            nn.Conv1d(64, 128, kernel_size=3, padding=1),
            nn.BatchNorm1d(128),
            nn.ELU(),
            nn.MaxPool1d(2)
        )
        
        # 自适应通道融合模块
        self.channel_attention = nn.Sequential(
            nn.Linear(channels, channels//2),
            nn.ELU(),
            nn.Linear(channels//2, channels),
            nn.Sigmoid()
        )
        
        # 时空注意力模块
        self.spatial_attention = nn.Sequential(
            nn.Conv1d(256, 128, kernel_size=1),
            nn.BatchNorm1d(128),
            nn.ELU(),
            nn.Conv1d(128, 256, kernel_size=1),
            nn.Sigmoid()
        )
        
        # 分类器
        self.classifier = nn.Sequential(
            nn.Linear(256, 128),
            nn.ELU(),
            nn.Dropout(0.5),
            nn.Linear(128, num_classes)
        )
    
    def forward(self, x):
        # 输入形状: (batch, time_steps, channels)
        
        # 通道注意力加权
        channel_weights = self.channel_attention(
            x.mean(dim=1)  # 沿时间维度平均
        ).unsqueeze(1)  # 形状: (batch, 1, channels)
        x = x * channel_weights
        
        # 时间特征提取
        time_feat = self.time_stream(x.permute(0, 2, 1))  # 形状: (batch, 128, 14)
        
        # 频段特征提取
        freq_feat = self.freq_stream(x)  # 形状: (batch, 128, 14)
        
        # 特征融合
        time_pooled = F.adaptive_avg_pool1d(time_feat, 1).squeeze(2)  # (batch, 128)
        freq_pooled = F.adaptive_avg_pool1d(freq_feat, 1).squeeze(2)  # (batch, 128)
        fused_feat = torch.cat([time_pooled, freq_pooled], dim=1)  # (batch, 256)
        
        # 空间注意力加权
        attention_weights = self.spatial_attention(
            fused_feat.unsqueeze(2)  # 增加维度
        ).squeeze(2)
        weighted_feat = fused_feat * attention_weights
        
        # 分类
        return self.classifier(weighted_feat)
    

