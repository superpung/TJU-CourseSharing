load_data.py实现了用于加载数据集的函数，包括使用特征融合加载，以及封装了EEGDataLoader类，调用该类的函数可以直接返回数据集加载器对象。

model.py是实现的模型定义，为EEGFusionNet

train.py是用于训练的，Config类中包含一些必要的超参数，该文件实现的是使用LOSO交叉验证训练10次，并保存最好的模型。

test.py用于最终的预测测试集的结果，要注意该文件里面的Config类里面一些参数要和训练模型使用的参数一致，否则会报错

train_test.py用于验证集成学习的方法是否有效

在运行代码之前，需要进行如下的安装：

```bash
conda create -n myenv python=3.11 -y
pip install matplotlib seaborn mne mne-icalabel numpy
pip install onnxruntime
pip install h5py
pip3 install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu128 
pip install einops
pip install scikit-learn
pip install torchinfo
```

