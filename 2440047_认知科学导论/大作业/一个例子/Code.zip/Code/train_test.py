import os
import numpy as np
import torch
import torch.optim as optim
import torch.nn as nn
from torch.utils.data import DataLoader
import pickle
from model import EEGFusionNet
from load_data import EEGDataLoader, FeatureFusionDataset
from copy import deepcopy
import matplotlib.pyplot as plt
from sklearn.metrics import confusion_matrix, classification_report, accuracy_score
from utils import set_seed
import time
import random
import pandas as pd
from tqdm import tqdm

# ======================== 配置类 ========================
class Config:
    def __init__(self):
        self.data_path = './data/'
        self.train_de_file = 'train_de_data.pkl'
        self.train_power_file = 'train_power_data.pkl'
        self.test_de_file = 'test_de_data.pkl'
        self.test_power_file = 'test_power_data.pkl'
        self.batch_size = 64
        self.num_epochs = 100
        self.lr = 0.04
        self.patience = 30
        self.model_type = 'FusionNet'  
        self.num_subjects = 10
        self.model_save_path = './models/'
        self.use_fusion = True  # 是否使用特征融合
        self.feature_type = 'de'  # 当不使用融合时的特征类型
        self.results_save_path = './results/'
        os.makedirs(self.model_save_path, exist_ok=True)
        os.makedirs(self.results_save_path, exist_ok=True)

config = Config()

# ======================== 模型初始化 ========================
def initialize_model(num_classes, input_shape):
    """根据配置初始化模型"""
    if config.model_type == 'FusionNet':
        model = EEGFusionNet(num_classes=num_classes, channels=input_shape[1])
    else:
        raise ValueError(f"未知模型类型: {config.model_type}")
    
    return model.to(device)

# ======================== 训练函数 ========================
def train_model(model, train_loader, val_loader, test_subject_id, save_model=True):
    """训练模型并返回结果"""
    # 损失函数和优化器
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=config.lr, weight_decay=0.0001)
    scheduler = optim.lr_scheduler.ReduceLROnPlateau(
        optimizer, mode='max', factor=0.9, patience=5
    )
    
    # 训练变量初始化
    best_acc = 0.0
    best_model = None
    no_improve_epochs = 0
    train_losses = []
    val_accuracies = []
    
    # 训练循环
    for epoch in range(config.num_epochs):
        epoch_start = time.time()
        model.train()
        running_loss = 0.0
        batch_count = 0
        
        # 训练批次
        for inputs, labels in train_loader:
            inputs = inputs.to(device)
            labels = labels.to(device)
            
            # 前向传播
            outputs = model(inputs)
            loss = criterion(outputs, labels)
            
            # 反向传播
            optimizer.zero_grad()
            loss.backward()
            
            # 梯度裁剪
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
            
            optimizer.step()
            
            # 记录损失
            running_loss += loss.item()
            batch_count += 1
        
        # 计算平均损失
        epoch_loss = running_loss / batch_count
        train_losses.append(epoch_loss)
        
        # 验证阶段
        val_acc, _, _ = evaluate(model, val_loader, device)
        val_accuracies.append(val_acc)
        
        # 计算epoch耗时
        epoch_time = time.time() - epoch_start
        
        # 打印epoch信息
        print(f"Epoch [{epoch+1}/{config.num_epochs}] - "
              f"Loss: {epoch_loss:.4f}, "
              f"Val Acc: {val_acc:.4f}, "
              f"Time: {epoch_time:.2f}s")
        
        # 更新学习率
        scheduler.step(val_acc)
        
        # 保存最佳模型
        if val_acc > best_acc:
            best_acc = val_acc
            best_model = deepcopy(model.state_dict())
            no_improve_epochs = 0
            if save_model:
                model_path = os.path.join(config.model_save_path, f"best_model_subject{test_subject_id}.pth")
                torch.save(best_model, model_path)
                print(f"新最佳准确率: {best_acc:.4f}，模型已保存至 {model_path}")
        else:
            no_improve_epochs += 1
            if no_improve_epochs >= config.patience:
                print(f"早停触发，在 {epoch+1} 轮后准确率未提升")
                break
    
    # 加载最佳模型
    model.load_state_dict(best_model)
    
    return model, train_losses, val_accuracies

# ======================== 评估函数 ========================
def evaluate(model, data_loader, device, detailed=False):
    """评估模型性能"""
    model.eval()
    correct = 0
    total = 0
    all_preds = []
    all_labels = []
    
    with torch.no_grad():
        for inputs, labels in data_loader:
            inputs = inputs.to(device)
            labels = labels.to(device)
            
            outputs = model(inputs)
            _, predicted = torch.max(outputs.data, 1)
            
            total += labels.size(0)
            correct += (predicted == labels).sum().item()
            
            if detailed:
                all_preds.extend(predicted.cpu().numpy())
                all_labels.extend(labels.cpu().numpy())
    
    accuracy = correct / total
    return accuracy, all_labels, all_preds

# ======================== 集成预测函数 ========================
def ensemble_predict(models, data_loader, device):
    """使用多个模型进行集成预测"""
    all_preds = []
    all_probs = []
    
    with torch.no_grad():
        for inputs, labels in data_loader:
            inputs = inputs.to(device)
            
            # 收集所有模型的预测概率
            model_probs = []
            for model in models:
                outputs = model(inputs)
                probs = torch.softmax(outputs, dim=1)
                model_probs.append(probs.cpu().numpy())
            
            # 平均所有模型的概率
            avg_probs = np.mean(model_probs, axis=0)
            preds = np.argmax(avg_probs, axis=1)
            all_preds.extend(preds)
            all_probs.extend(avg_probs)
    
    return all_preds, all_probs

# ======================== 比较两种方法 ========================
def compare_methods(device):
    """比较传统方法和集成方法在10位受试者上的性能"""
    subject_ids = list(range(config.num_subjects))
    results = []
    
    # 打印配置信息
    print("\n" + "="*60)
    print("方法比较配置:")
    print(f"模型类型: {config.model_type}")
    print(f"特征融合: {'启用' if config.use_fusion else '禁用'}")
    print(f"批大小: {config.batch_size}, 轮次数: {config.num_epochs}")
    print(f"学习率: {config.lr}, 早停耐心值: {config.patience}")
    print("="*60)
    
    # 创建数据加载器实例
    data_loader = EEGDataLoader(config)
    
    # 为每个受试者作为测试集运行
    for test_subject in tqdm(subject_ids, desc="测试受试者"):
        print(f"\n{'='*60}")
        print(f"测试受试者: {test_subject}")
        print(f"{'='*60}")
        
        # 1. 传统方法：直接使用9位受试者训练模型
        print("\n传统方法: 使用9位受试者直接训练模型")
        
        # 加载数据集
        train_loader, test_loader, num_classes = data_loader.load_dataset_for_subject(
            test_subject_id=test_subject,
            subject_ids=subject_ids
        )
        
        # 获取输入形状
        sample_input, _ = next(iter(train_loader))
        input_shape = sample_input.shape[1:]  # (time_steps, features)
        
        # 初始化模型
        model = initialize_model(num_classes, input_shape)
        print(f"模型参数数量: {sum(p.numel() for p in model.parameters())}")
        
        # 训练模型（使用整个训练集，没有验证集）
        model, train_losses, _ = train_model(
            model, 
            train_loader, 
            test_loader,  # 这里使用测试集作为验证集（仅用于早停）
            test_subject,
            save_model=False
        )
        
        # 评估模型
        trad_acc, trad_true, trad_pred = evaluate(model, test_loader, device, detailed=True)
        print(f"传统方法准确率: {trad_acc:.4f}")
        
        # 2. 集成方法：使用9位受试者进行交叉验证训练多个模型
        print("\n集成方法: 使用9位受试者进行交叉验证训练多个模型")
        
        # 准备训练集（排除测试受试者）
        train_subjects = [s for s in subject_ids if s != test_subject]
        ensemble_models = []
        
        # 对每个训练受试者进行交叉验证
        for val_subject in tqdm(train_subjects, desc="交叉验证模型", leave=False):
            # 准备训练集和验证集
            inner_train_subjects = [s for s in train_subjects if s != val_subject]
            
            # 创建训练集和验证集
            inner_train_loader, inner_val_loader, _ = data_loader.load_dataset_for_subject(
                test_subject_id=val_subject,
                subject_ids=train_subjects
            )
            
            # 初始化模型
            inner_model = initialize_model(num_classes, input_shape)
            
            # 训练模型
            inner_model, _, _ = train_model(
                inner_model, 
                inner_train_loader, 
                inner_val_loader, 
                test_subject,
                save_model=False
            )
            
            # 保存模型用于集成
            ensemble_models.append(inner_model)
        
        # 使用集成模型进行预测
        ensemble_preds, ensemble_probs = ensemble_predict(ensemble_models, test_loader, device)
        ensemble_acc = accuracy_score(trad_true, ensemble_preds)
        print(f"集成方法准确率: {ensemble_acc:.4f}")
        
        # 保存结果
        results.append({
            'test_subject': test_subject,
            'traditional_acc': trad_acc,
            'ensemble_acc': ensemble_acc,
            'improvement': ensemble_acc - trad_acc
        })
        
        # 释放内存
        del model, ensemble_models
        torch.cuda.empty_cache()
    
    # 保存并打印总体结果
    results_df = pd.DataFrame(results)
    results_path = os.path.join(config.results_save_path, 'method_comparison.csv')
    results_df.to_csv(results_path, index=False)
    
    print("\n\n" + "="*60)
    print("方法比较最终结果")
    print("="*60)
    print(results_df)
    
    # 计算平均性能
    mean_trad = results_df['traditional_acc'].mean()
    mean_ensemble = results_df['ensemble_acc'].mean()
    mean_improvement = results_df['improvement'].mean()
    
    print(f"\n平均传统方法准确率: {mean_trad:.4f}")
    print(f"平均集成方法准确率: {mean_ensemble:.4f}")
    print(f"平均提升: {mean_improvement:.4f}")
    
    # 绘制结果
    plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']  # 指定中文字体
    plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示问题
    plt.figure(figsize=(12, 6))
    plt.plot(results_df['test_subject'], results_df['traditional_acc'], 'o-', label='传统方法')
    plt.plot(results_df['test_subject'], results_df['ensemble_acc'], 'o-', label='集成方法')
    plt.axhline(mean_trad, color='blue', linestyle='--', alpha=0.5)
    plt.axhline(mean_ensemble, color='orange', linestyle='--', alpha=0.5)
    plt.xlabel('测试受试者')
    plt.ylabel('准确率')
    plt.title('传统方法与集成方法性能比较')
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    
    plot_path = os.path.join(config.results_save_path, 'method_comparison.png')
    plt.savefig(plot_path)
    plt.close()
    print(f"结果图表已保存至 {plot_path}")
    
    return results_df

# ======================== LOSO交叉验证 ========================
def loso_cross_validation(device):
    all_subject_results = {}
    subject_ids = list(range(config.num_subjects))
    
    # 打印配置信息
    print("\n" + "="*60)
    print("实验配置:")
    print(f"模型类型: {config.model_type}")
    print(f"特征融合: {'启用' if config.use_fusion else '禁用'}")
    print(f"批大小: {config.batch_size}, 轮次数: {config.num_epochs}")
    print(f"学习率: {config.lr}, 早停耐心值: {config.patience}")
    print("="*60)
    
    # 创建数据加载器实例
    data_loader = EEGDataLoader(config)
    
    for test_subject in subject_ids:
        print(f"\n{'='*60}")
        print(f"训练受试者 {test_subject} 作为测试集")
        print(f"{'='*60}")
        
        # 加载数据集
        train_loader, test_loader, num_classes = data_loader.load_dataset_for_subject(
            test_subject_id=test_subject,
            subject_ids=subject_ids
        )
        
        # 获取输入形状
        sample_input, _ = next(iter(train_loader))
        input_shape = sample_input.shape[1:]  # (time_steps, features)
        
        # 初始化模型
        model = initialize_model(num_classes, input_shape)
        print(f"模型参数数量: {sum(p.numel() for p in model.parameters())}")
        
        # 训练模型
        model, train_losses, val_accuracies = train_model(model, train_loader, test_loader, test_subject)
        
        # 最终评估
        test_acc, y_true, y_pred = evaluate(model, test_loader, device, detailed=True)
        
        # 保存结果
        all_subject_results[test_subject] = {
            'accuracy': test_acc,
            'true_labels': y_true,
            'pred_labels': y_pred,
            'train_losses': train_losses,
            'val_accuracies': val_accuracies
        }
        
        # 打印结果
        print(f"\n受试者 {test_subject} 测试准确率: {test_acc:.4f}")
        print(classification_report(
            y_true, 
            y_pred, 
            digits=4
        ))
        
        # 绘制学习曲线
        plt.figure(figsize=(12, 5))
        plt.subplot(1, 2, 1)
        plt.plot(train_losses)
        plt.title(f'Subject {test_subject} Training Loss')
        plt.xlabel('Epoch')
        plt.ylabel('Loss')
        
        plt.subplot(1, 2, 2)
        plt.plot(val_accuracies)
        plt.title(f'Subject {test_subject} Validation Accuracy')
        plt.xlabel('Epoch')
        plt.ylabel('Accuracy')
        
        plt.tight_layout()
        plt.savefig(os.path.join(config.model_save_path, f'learning_curve_subject{test_subject}.png'))
        plt.close()
        
        # 释放内存
        del model, train_loader, test_loader
        torch.cuda.empty_cache()
    
    # 计算并打印整体性能
    print("\n\n" + "="*60)
    print("LOSO交叉验证最终结果")
    print("="*60)
    
    accuracies = [result['accuracy'] for result in all_subject_results.values()]
    mean_acc = np.mean(accuracies)
    std_acc = np.std(accuracies)
    
    print(f"平均准确率: {mean_acc:.4f} ± {std_acc:.4f}")
    print(f"各受试者准确率: {accuracies}")
    
    # 绘制准确率分布图
    plt.figure(figsize=(10, 6))
    plt.bar(range(len(accuracies)), accuracies)
    plt.axhline(mean_acc, color='r', linestyle='--', label=f'Mean Accuracy: {mean_acc:.4f}')
    plt.xlabel('Subject ID')
    plt.ylabel('Accuracy')
    plt.title('Subject-wise Accuracy Distribution')
    plt.legend()
    plt.grid(True)
    plt.savefig(os.path.join(config.model_save_path, 'accuracy_distribution.png'))
    plt.close()
    
    # 保存总体结果
    results_path = os.path.join(config.model_save_path, 'loso_results.pkl')
    with open(results_path, 'wb') as f:
        pickle.dump(all_subject_results, f)
    print(f"结果已保存至 {results_path}")
    
    return all_subject_results

if __name__ == '__main__':
    # 设置设备
    device = torch.device("cuda" if torch.cuda.is_available() else "mps" if torch.backends.mps.is_available() else "cpu")
    print(f"Using device: {device}")
    
    # 设置随机种子
    set_seed(42)
    
    # 记录总开始时间
    total_start = time.time()
    
    # 执行方法比较
    print("\n" + "="*60)
    print("开始方法比较: 传统方法 vs 集成方法")
    print("="*60)
    comparison_results = compare_methods(device)
    
    # 执行交叉验证
    print("\n" + "="*60)
    print("开始LOSO交叉验证")
    print("="*60)
    loso_results = loso_cross_validation(device)
    
    # 计算总耗时
    total_time = time.time() - total_start
    hours, rem = divmod(total_time, 3600)
    minutes, seconds = divmod(rem, 60)
    print(f"\n总训练时间: {int(hours)}小时 {int(minutes)}分钟 {seconds:.2f}秒")
