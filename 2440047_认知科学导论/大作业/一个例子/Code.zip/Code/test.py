import os
import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from load_data import EEGDataLoader, FeatureFusionDataset
from model import EEGFusionNet
import argparse
import time
from copy import deepcopy

# ======================== 配置类 ========================
class Config:
    def __init__(self):
        self.data_path = './data/'
        self.train_de_file = 'train_de_data.pkl'
        self.train_power_file = 'train_power_data.pkl'
        self.test_de_file = 'test_de_data.pkl'
        self.test_power_file = 'test_power_data.pkl'
        self.batch_size = 64
        self.model_type = 'FusionNet'  
        self.num_subjects = 10
        self.model_save_path = './models/'
        self.use_fusion = True  # 是否使用特征融合
        self.feature_type = 'de'  # 当不使用融合时的特征类型
        os.makedirs(self.model_save_path, exist_ok=True)

# ======================== 模型初始化 ========================
def initialize_model(num_classes, input_shape, config):
    """根据配置初始化模型"""
    if config.model_type == 'FusionNet':
        model = EEGFusionNet(num_classes=num_classes, channels=input_shape[1])
    else:
        raise ValueError(f"未知模型类型: {config.model_type}")
  
    return model

# ======================== 集成预测函数 ========================
def ensemble_predict(models, data_loader, device):
    """使用多个模型进行集成预测"""
    all_preds = []
    
    with torch.no_grad():
        for inputs in data_loader:
            inputs = inputs.to(device)
            
            # 收集所有模型的预测概率
            model_probs = []
            for model in models:
                outputs = model(inputs)
                probs = torch.softmax(outputs, dim=1)
                model_probs.append(probs.cpu().numpy())
            
            # 平均所有模型的概率
            avg_probs = np.mean(model_probs, axis=0)
            preds = np.argmax(avg_probs, axis=1)
            all_preds.extend(preds)
    
    return all_preds

# ======================== 生成预测CSV ========================
def save_predictions_to_csv(predictions, save_path):
    """将预测结果保存为CSV文件"""
    with open(save_path, 'w') as f:
        f.write(",prediction\n")
        for idx, pred in enumerate(predictions):
            f.write(f"{idx},{pred}\n")
    print(f"预测结果已保存至 {save_path}")

def main():
    # 设置设备
    device = torch.device("cuda" if torch.cuda.is_available() else "mps" if torch.backends.mps.is_available() else "cpu")
    print(f"使用设备: {device}")
    
    # 创建配置
    config = Config()
    
    # 打印配置信息
    print("\n" + "="*60)
    print("测试配置:")
    print(f"模型类型: {config.model_type}")
    print(f"特征融合: {'启用' if config.use_fusion else '禁用'}")
    if not config.use_fusion:
        print(f"特征类型: {config.feature_type}")
    print(f"批大小: {config.batch_size}")
    print(f"模型路径: {config.model_save_path}")
    print(f"受试者数量: {config.num_subjects}")
    print("="*60)
    
    # 创建数据加载器实例
    data_loader = EEGDataLoader(config)
    
    # 加载测试集
    print("\n加载测试集...")
    test_loader = data_loader.load_test_set()
    
    # 获取一个样本以确定输入形状
    sample_input = next(iter(test_loader))
    if isinstance(sample_input, tuple):  # 如果返回的是元组（数据, 标签）
        sample_input = sample_input[0]
    input_shape = sample_input.shape[1:]
    print(f"输入形状: {input_shape}")
    
    # 加载所有保存的模型
    ensemble_models = []
    for subject_id in range(config.num_subjects):
        model_path = os.path.join(config.model_save_path, f"best_model_subject{subject_id}.pth")
        
        if not os.path.exists(model_path):
            print(f"未找到模型 {model_path}，跳过")
            continue
        
        # 初始化模型
        model = initialize_model(2, input_shape, config)  # 假设二分类
        model.load_state_dict(torch.load(model_path, map_location=device))
        model.to(device)
        model.eval()
        ensemble_models.append(model)
        print(f"已加载模型: {model_path}")
    
    if not ensemble_models:
        print("错误: 未找到任何模型，请检查模型路径")
        return
    
    print(f"已加载 {len(ensemble_models)} 个模型用于集成预测")
    
    # 进行集成预测
    print("\n开始预测...")
    start_time = time.time()
    predictions = ensemble_predict(ensemble_models, test_loader, device)
    inference_time = time.time() - start_time
    print(f"预测完成! 耗时: {inference_time:.2f}秒")
    print(f"测试样本数量: {len(predictions)}")
    
    # 保存预测结果
    csv_path = os.path.join(config.model_save_path, 'test_predictions.csv')
    save_predictions_to_csv(predictions, csv_path)
    
    # 打印一些预测结果示例
    print("\n预测结果示例:")
    for i in range(min(10, len(predictions))):
        print(f"样本 {i}: 预测类别 = {predictions[i]}")
    
    print("\n测试完成!")

if __name__ == '__main__':
    main()
