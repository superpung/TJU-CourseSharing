# HMM Algorithm
# Author: songtongmail@163.com (Tongtong Song (TJU))
# Date: 2021/8/28 16:00
# Last modified: 2021/9/27 11:27
import os
import numpy as np
import logging
def init_logger(log_file=None):
    log_format = logging.Formatter("[%(asctime)s %(levelname)s] %(message)s")
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)

    console_handler = logging.StreamHandler()
    console_handler.setFormatter(log_format)
    logger.handlers = [console_handler]

    if log_file and log_file != '':
        file_handler = logging.FileHandler(log_file)
        file_handler.setFormatter(log_format)
        logger.addHandler(file_handler)

    return logger

class HMM:
    def __init__(self):
        super().__init__()
        # 隐藏状态初始概率分布
        self.pi = np.array([0.2, 0.4, 0.4])
        # 状态转移概率矩阵，在该实验中有三种隐藏状态，则矩阵大小为3X3
        self.A = np.array( [[0.5, 0.2, 0.3],
                            [0.3, 0.5, 0.2],
                            [0.2, 0.3, 0.5]])
        # 状态对应观测值的概率矩阵，在该实验中观测值有两种，则矩阵大小为3X2
        self.B = np.array( [[0.5, 0.5],
                            [0.4, 0.6],
                            [0.7, 0.3]])
        # 状态集合个数
        self.s_set_num = len(self.pi)
        # 观测集合个数
        self.o_set_num = len(self.B[0])

    def forward(self, O):
        r"""
        get P(O|M) by forward algorithm
            \alpha_{t+1}(j) =b_{j}(o_{t+1})\sum_{i=1}^M(\alpha_{t}(i)a_{ij})
            At+1(j) = ∑i{At(i) x aij} x bj(ot+1)
        :param O:
        :return:
        """
        #  definition forward probability matrix
        self.o_len = len(O) # 观测序列长度
        self.forward_prob_matrix = np.zeros((self.o_len, self.s_set_num)) # O x P

        # t=0
        # 初始化:令α0(i)=πi×bi(o1),其中πi是初态概率。
        self.forward_prob_matrix[0,:] = self.pi * self.B[:, O[0]]

        # T=1:T, compute forward probability matrix
        # 递推:对t=1至T-1重复计算αt+1(j)。
        # TODO
        for j in range(1, self.o_len):
            for i in range(self.s_set_num):
                #前一时刻所有状态的概率乘以转移概率得到i状态概率
                #i状态的概率*i状态到j观测的概率
                temp = 0
                for k in range(self.s_set_num):
                    temp = temp + self.forward_prob_matrix[j-1, k] * self.A[k, i]
                self.forward_prob_matrix[j, i] = temp * self.B[i, O[j]]
        # get the last time total forward probability
        # 终止:总概率P(O|λ)=∑jαT(j)。
        forward_prob = np.sum(self.forward_prob_matrix[self.o_len-1, :])
        return forward_prob

    def backward(self, O):
        r"""
        get P(O|M) by backward algorithm
            \beta_{t}(i) = \sum_{j=1}^M(\beta_{t+1}(j)a_{ij}b_{j}(o_{t+1}))
            βt(i) = ∑j{βt+1(j) x aji x bj(ot+1)}
        :param O: 
        :return:
        """
        # definition backward probability matrix
        self.o_len = len(O)
        self.backward_prob_matrix = np.zeros((self.o_len, self.s_set_num))
        # t = T-1
        # 初始化:令βT(i)=1,即最后一个时间节点的后向概率为1。
        self.backward_prob_matrix[self.o_len - 1, :] = 1
        # t=T-2:-1, compute backward probability matrix
        # 递推:对t=T-1至0重复计算βt(i)。
        # TODO
        for j in range(self.o_len - 2, -1, -1):
            for i in range(self.s_set_num):
                for k in range(self.s_set_num):
                    self.backward_prob_matrix[j, i] += self.A[i, k] * self.B[k, O[j+1]] * self.backward_prob_matrix[j+1, k]
        # get the first time total backward probability
        # 终止:得到初态πi的后向概率η = ∑i{πi*bi(o1)*β1(i)}
        backward_prob = np.sum(self.pi*self.B[:,O[0]]*self.backward_prob_matrix[0])
        return backward_prob

    def get_state_probability(self, t, q):
        r"""get the probability when time is t and state is q
            \alpha_{t}(q)*\beta_{t}(q)/\sum(\alpha_{t}\beta_{t})
        :param forward_prob_matrix: forward probability matrix
        :param backward_prob_matrix: backward probability matrix
        :param t: time
        :param q: state
        :return:
            prob: the probability
        """
        assert 0<=t<=self.o_len, 't must be in {}-{}'.format(0,self.o_len)
        assert 0<=q<=self.s_set_num, 'q must be in {}-{}'.format(0,self.s_set_num)
        q_prob = self.forward_prob_matrix[t][q]*self.backward_prob_matrix[t][q]
        total_prob = np.sum(self.forward_prob_matrix[t]*self.backward_prob_matrix[t])
        prob = q_prob/total_prob
        return prob

    def decoding(self,O):
        """ Viterbi Decoding
        get argmax P(Q|O,M)
            \delta_{t+1}(j) = max\limits_{1<=i<=M}(\delta_{t}(i)a_{ij}))b_{j}(o_{t+1}
        :return:
            best_path:
            best_prob:
        """
        #  definition the best probability matrix and last node maxtrix
        o_len = len(O)
        best_prob_matrix = np.zeros((o_len,self.s_set_num))
        last_node_matrix = np.zeros((o_len,self.s_set_num),dtype=int)
        # t=0
        best_prob_matrix[0,:] = self.pi * self.B[:,O[0]]
        last_node_matrix[0,:] = -1
        # T=1:T, compute best probability matrix and last node matrix
        # TODO
        for t in range(1, o_len):
            for j in range(self.s_set_num):
                max_prob = -float('inf')
                max_i = -1
                for i in range(self.s_set_num):
                    prob = best_prob_matrix[t-1, i] * self.A[i, j] * self.B[j, O[t]]
                    if prob > max_prob:
                        max_prob = prob
                        max_i = i
                best_prob_matrix[t, j] = max_prob 
                last_node_matrix[t, j] = max_i
        # t=T-1, get best_prob and the last node
        last_node =  np.argmax(best_prob_matrix[o_len-1,:])
        best_prob = best_prob_matrix[o_len - 1,last_node]
        best_path = [last_node]
        # t=T-1:0,backtrack the path
        for t in range(o_len-1,0,-1):
            last_node = last_node_matrix[t, last_node]
            best_path.append(last_node)
        # reverse to the noraml path
        best_path = best_path[::-1]
        return best_path, best_prob

if __name__ == '__main__':
    result_path = './result'
    if not os.path.exists(result_path):
        os.mkdir(result_path)
    logger = init_logger(log_file='result/hmm.log')
    # observation sequence
    O = [0, 1, 0]
    O1 = [0, 0, 1]

    hmm_model = HMM()
    # 评估观察序列概率。在给定HMM(pi, A, B)模型的情况下，用前向后向算法，评定观察序列O出现的概率。
    forward_prob = hmm_model.forward(O)
    logger.info('forward_prob:{:.6f}'.format(forward_prob))
    
    backward_prob = hmm_model.backward(O)
    logger.info('backward_prob:{:.6f}'.format(backward_prob))

    prob = hmm_model.get_state_probability(2, 2)
    logger.info('state(2,2) prob:{:.6f}'.format(prob))
    
    # 预测问题，也称为解码问题。给定模型和观测序列，求给定观测序列条件下，最可能出现的对应的状态序列。
    best_path, best_prob = hmm_model.decoding(O1)
    logger.info('best_state_sequence:{},best_prob:{:.6f}'.format(best_path, best_prob))