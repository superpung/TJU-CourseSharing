# HMM Algorithm
# Author: songtongmail@163.com (Tongtong Song (TJU))
# Date: 2021/09/04 16:00
# Last modified: 2023/10/10 19:16
# Last modifier: jabberwocky238@gmail.com (Quan Zhang (TJU))


import os
import numpy as np
import scipy.cluster.vq as vq

from utils import Dataloader, get_feats, get_all_feats, extract_feat
from typing import Dict, List
import logging

def init_logger(log_file=None):
    log_format = logging.Formatter("[%(asctime)s %(levelname)s] %(message)s")
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)

    console_handler = logging.StreamHandler()
    console_handler.setFormatter(log_format)
    logger.handlers = [console_handler]

    if log_file and log_file != '':
        file_handler = logging.FileHandler(log_file)
        file_handler.setFormatter(log_format)
        logger.addHandler(file_handler)
    return logger

class GMM:
    def __init__(self, K, feats):
        super().__init__()
        self.K = K
        self.D = feats.shape[1]
        # 权重(pi)、均值(mu)和协方差矩阵(sigma)

        self.pi, self.mu, self.sigma = self.kmeans_initial(feats)
        # print(self.pi.shape, self.mu.shape, self.sigma.shape)

    def kmeans_initial(self,feats):
        mu = []
        sigma = []
        (centroids, labels) = vq.kmeans2(feats, self.K, minit="points", iter=100)
        clusters = [[] for i in range(self.K)]
        for (l, d) in zip(labels, feats):
            clusters[l].append(d)

        for cluster in clusters:
            mu.append(np.mean(cluster, axis=0))
            sigma.append(np.cov(cluster, rowvar=False))
        pi = [len(c) * 1.0 / len(feats) for c in clusters]
        return  np.array(pi), np.array(mu), np.array(sigma)

    def gaussian(self, x, mu, sigma):
        """
        :param x: D x 1
        :param mu: D x 1
        :param sigma: D x D
        :return:
        """
        sigma = np.where(sigma == 0, np.finfo(float).eps, sigma)
        det_sigma = np.linalg.det(sigma)
        inv_sigma = np.linalg.inv(sigma)
        x_diff = x-mu # D x 1

        coeff = 1/((2 * np.pi) ** (self.D/2))
        prob = coeff * det_sigma**(-0.5) * np.exp(-0.5*(np.dot(x_diff.T,inv_sigma).dot(x_diff)))
        prob = np.nan_to_num(prob)
        if prob==0:
            prob = np.finfo(float).eps
        return prob

    def log_likelihood(self, feats):
        N = len(feats)
        # E step
        gamma = np.zeros((N, self.K))
        self.Estep(gamma, feats)

        llh = np.mean(np.log10(np.sum(gamma, axis=1)))
        return llh

    def Estep(self, gamma:np.ndarray, feats: np.ndarray):
        """
        :param feats: N x D
        :param gamma: N x K
        pi: K
        mu: K x D
        sigma: K x D x D
        """
        N, K = gamma.shape
        for n in range(N):
            for k in range(K):
                gamma[n, k] = self.pi[k] * self.gaussian(feats[n], self.mu[k], self.sigma[k])
    
    def Mstep(self, gamma: np.ndarray, feats: np.ndarray):
        K, N = gamma.shape
        Nsum = np.sum(gamma, axis=1)
        for i in range(K):
            mu = np.dot(gamma[i, :], feats) / Nsum[i]
            sigma = np.zeros((self.D,self.D))
            for j in range(N):
                sigma += gamma[i,j] * np.outer(feats[j,:] - mu, feats[j,:] - mu)
            sigma = sigma / Nsum[i]
            
            self.mu[i] = mu # update the normal with new parameters
            self.sigma[i] = sigma
            self.pi[i] = Nsum[i] / np.sum(Nsum) # normalize the new priors

    def EM(self, feats: np.ndarray):
        """
        :param feats: N x D
        :return:
        """
        N = len(feats)
        # E step
        gamma = np.zeros((N, self.K))
        self.Estep(gamma, feats)
        gamma = gamma.T / np.sum(gamma, axis=1)
        # M step
        # 用最大似然的方法求出模型参数
        self.Mstep(gamma, feats)
        return self.log_likelihood(feats)


def train(gmms, class2utt, utt2wav, epochs, class_items):
    # 按类别进行训练
    for class_ in class_items:
        # 提取语音的mfcc特征
        feats = get_feats(class_, class2utt, utt2wav)
        logger.info('Class:{} Initial llh:{:.6f}'.format(class_, gmms[class_].log_likelihood(feats)))
        for epoch in range(epochs):
            # 调用期望最大化类方法
            llh = gmms[class_].EM(feats)
            logger.info('Class:{} Train Epoch[{}/{}], log_likelihood:{:.6f}'.format(class_, epoch+1, epochs, llh))
    return gmms


def test(gmms, class2utt, utt2wav, class_items):
    utt2class = {}
    for key in class2utt.keys():
        values = class2utt[key]
        for value in values:
            utt2class[value] = key
    N = len(utt2class)
    correct = 0
    for idx, utt in enumerate(utt2class.keys()):
        true_class = utt2class[utt]
        feats = extract_feat(utt2wav[utt])
        scores = []
        for class_ in class_items:
            scores.append(gmms[class_].log_likelihood(feats))
        pred_class = class_items[np.argmax(np.array(scores))]
        if pred_class == true_class:
            correct += 1
        logger.info('Test[{}/{}]-True_class:{}, Pred_class:{}, ACC:{:.3f}'.format(idx+1, N, true_class, pred_class, correct/(idx+1)))
        
    return correct / N

if __name__ == '__main__':
    result_path = './result'
    if not os.path.exists(result_path):
        os.mkdir(result_path)
    logger = init_logger(log_file='result/gmm.log')
    class_items = ['Z', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'O']
    
    # 训练参数
    K = 3 # gaussian numbers of one class
    epochs = 3
    
    # 提取音频特征
    feats = get_all_feats('data/train/wav.scp')
    gmms = {}
    
    # class2utt, utt2wav 分别是两个字典，存放对应的类别和音频路径
    class2utt, utt2wav = Dataloader('data/train/wav.scp', 'data/train/text')
    # 对每个类别初始化一个GMM的对象，存放在字典中，字典的键为类别，值为GMM初始化的对象
    for class_ in class_items:
        gmms[class_] = GMM(K, feats)
    
    # 训练
    gmms = train(gmms, class2utt, utt2wav, epochs, class_items)
    
    # 测试
    class2utt, utt2wav = Dataloader('data/test/wav.scp', 'data/test/text')
    acc = test(gmms, class2utt, utt2wav, class_items)
    logger.info('ACC:{:.3f}'.format(acc))
