#!/bin/bash

# 1. 创建主目录和子目录
mkdir -p ./data/TinyImageNet200 ./datazips ./data/DownsampledImageNet32

# 2. 下载并解压 imagenet64x64 数据集
#echo "下载 imagenet64x64 数据集..."
#wget -O ./datazips/imagenet64x641.zip https://image-net.org/data/downsample/Imagenet64_train_part1.zip
#wget -O ./datazips/imagenet64x642.zip https://image-net.org/data/downsample/Imagenet64_train_part2.zip
#wget -O ./datazips/imagenet64x64val.zip https://image-net.org/data/downsample/Imagenet64_val_npz.zip

#echo "解压 imagenet64x64..."
#unzip ./datazips/imagenet64x641.zip -d ./data/DownsampledImageNet/
#unzip ./datazips/imagenet64x642.zip -d ./data/DownsampledImageNet/
#unzip ./datazips/imagenet64x64val.zip -d ./data/DownsampledImageNet/
#

# 3. 下载并解压 imagenet32x32 数据集
echo "下载 imagenet32x32 数据集..."
wget -O ./datazips/imagenet32x32.zip https://image-net.org/data/downsample/Imagenet32_train.zip

wget -O ./datazips/imagenet32x32val.zip https://image-net.org/data/downsample/Imagenet32_val.zip

echo "解压 imagenet32x32..."
unzip ./datazips/imagenet32x32.zip -d ./data/DownsampledImageNet32/
unzip ./datazips/imagenet32x32val.zip -d ./data/DownsampledImageNet32/


# 4. 下载并解压 tinyimagenet 数据集
echo "下载 tinyimagenet 数据集..."
wget -O ./datazips/tinyimagenet.zip https://image-net.org/data/tiny-imagenet-200.zip

echo "解压 tinyimagenet..."
unzip ./datazips/tinyimagenet.zip -d ./data/TinyImageNet200/
#rm ./data/TinyImageNet200/tinyimagenet.zip  # 删除压缩包（可选）

echo "所有数据集下载和解压完成！"