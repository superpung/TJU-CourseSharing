#!/bin/bash

# 定义基础变量
DATASET_CHOICE="2"   # 1=CIFAR-10, 2=CIFAR-100, 3=TinyImageNet, 4=ImageNet64
EPOCHS="100"          # 训练轮数
SCRIPT="start.py"  # 替换为你的Python脚本路径

# 模型列表与对应的特定参数（这里以学习率为例）
#1=ResNet18, 2=SEResNet18, 3=ECAResNet18, 4=ResNet18_CoordAtt, 6=DoubleSEResNet18, 7=ResNet18_CBAM 8=ViT 
MODEL_CHOICES=("1" "2" "3" "4" "6" "7" "8")  # 模型列表
SPECIFIC_PARAMS=("0.001" "0.0007" "0.0004" "0.0004" "0.0004" "0.0004" "0.0002")  # 每个模型对应的特定参数

# 创建输出目录
OUTPUT_DIR="model_specific_experiments"
LOG_DIR="${OUTPUT_DIR}/logs"
mkdir -p "${LOG_DIR}"

# 获取当前时间戳
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")

# 检查模型和参数数量是否匹配
if [ ${#MODEL_CHOICES[@]} -ne ${#SPECIFIC_PARAMS[@]} ]; then
    echo "错误：模型列表与参数列表长度不一致！"
    exit 1
fi

# 循环执行不同模型的训练
for i in "${!MODEL_CHOICES[@]}"; do
    model="${MODEL_CHOICES[$i]}"
    param="${SPECIFIC_PARAMS[$i]}"
    
    
    
    # 构造日志文件名
    param_safe=$(echo "$param" | tr '.' '_')
    LOG_FILE="${LOG_DIR}/training_model_${model}_DS${DATASET_CHOICE}.log"
    
    
    
    echo "============================================================"
    echo "开始训练: 模型=${model}, 参数=${param}, 数据集=${DATASET_CHOICE}"
    echo "日志文件: ${LOG_FILE}"
    echo "============================================================"
    
    # 执行训练命令
    echo -e "${DATASET_CHOICE}\n${model}\n${EPOCHS}" | python "${SCRIPT}" "${param}" 2>&1 | tee "${LOG_FILE}"
    
    
    echo "完成模型 ${model} 的训练 (参数=${param})"
    echo "------------------------------------------------------------"
done

echo "所有训练任务已完成!"
echo "结果保存在: ${OUTPUT_DIR}"
echo "日志目录: ${LOG_DIR}"

