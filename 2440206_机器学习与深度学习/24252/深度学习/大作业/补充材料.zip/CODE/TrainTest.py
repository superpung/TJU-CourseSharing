
import torch
import torch.nn as nn



def train(model, device, train_loader, optimizer, epoch):
    model.train()
    loss_fn = nn.CrossEntropyLoss().to(device)
    total_loss = 0.0
    correct = 0
    for batch_idx, (data, target) in enumerate(train_loader):

        #print(2)
        
        #data, target = data.to(device), target.to(device)
        data, target = data.to(device, non_blocking=True), target.to(device, non_blocking=True)  
        
        optimizer.zero_grad()
        
        #print( 1)

        output = model(data)
        loss = loss_fn(output, target)
        loss.backward()
        optimizer.step()
        
        # 累计指标
        total_loss += loss.item() * data.size(0)
        pred = output.argmax(dim=1)
        correct += pred.eq(target).sum().item()
        
        if (batch_idx + 1) % 20 == 0:
            print(f'Train Epoch: {epoch} [{batch_idx * len(data)}/{len(train_loader.dataset)} '
                  f'({100. * batch_idx / len(train_loader):.0f}%)]\tLoss: {loss.item():.6f}')
    
    # 计算 epoch 指标
    epoch_loss = total_loss / len(train_loader.dataset)
    epoch_acc = correct / len(train_loader.dataset)
    
    return epoch_loss, epoch_acc


def test(model, device, test_loader):
    model.eval()
    test_loss = 0.0
    correct = 0
    correct_top5 = 0  
    total = len(test_loader.dataset)
    loss_fn = nn.CrossEntropyLoss(reduction='sum').to(device)
    
    with torch.no_grad():
        for data, target in test_loader:
            data, target = data.to(device), target.to(device)
            output = model(data)
            
            # 计算损失
            test_loss += loss_fn(output, target).item()
            
            # 计算Top-1准确率
            pred = output.argmax(dim=1)
            correct += pred.eq(target).sum().item()
            
            # 计算Top-5准确率
            _, pred_top5 = output.topk(5, dim=1)  
            correct_top5 += pred_top5.eq(target.view(-1, 1)).sum().item()
    
    # 计算平均损失
    test_loss /= total
    
    # 计算准确率
    test_acc = correct / total
    test_acc_top5 = correct_top5 / total  
    
    # 打印结果
    print(f'\nTest set: Average loss: {test_loss:.4f}, '
          f'Top1 Acc: {correct}/{total} ({100. * test_acc:.2f}%), '
          f'Top5 Acc: {correct_top5}/{total} ({100. * test_acc_top5:.2f}%)\n')

    return test_loss, test_acc, test_acc_top5  