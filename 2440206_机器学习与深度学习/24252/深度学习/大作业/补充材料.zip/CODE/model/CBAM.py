
import torch
import torch.nn as nn
from .base import ResNet, BasicBlock

class CBAM(nn.Module):
    def __init__(self, channels, reduction_ratio=16, kernel_size=7):
        super().__init__()
        # 通道注意力模块
        self.channel_att = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(channels, channels // reduction_ratio, 1),
            nn.ReLU(),
            nn.Conv2d(channels // reduction_ratio, channels, 1),
            nn.Sigmoid()
        )
        
        # 空间注意力模块
        self.spatial_att = nn.Sequential(
            nn.Conv2d(2, 1, kernel_size, padding=kernel_size//2, bias=False),
            nn.Sigmoid()
        )
    
    def forward(self, x):
        # 通道注意力
        channel_att = self.channel_att(x)
        x_channel = x * channel_att
        
        # 空间注意力
        max_pool = torch.max(x_channel, dim=1, keepdim=True)[0]
        avg_pool = torch.mean(x_channel, dim=1, keepdim=True)
        spatial_att = self.spatial_att(torch.cat([max_pool, avg_pool], dim=1))
        x_spatial = x_channel * spatial_att
        
        return x_spatial

class ResNetWithCBAM(ResNet):
    def __init__(self, block, num_blocks, num_classes=10, in_channels=3):
        super().__init__(block, num_blocks, num_classes, in_channels)
        
        # 在四个残差层之后添加CBAM模块
        self.cbam1 = CBAM(64 * block.expansion)
        self.cbam2 = CBAM(128 * block.expansion)
        self.cbam3 = CBAM(256 * block.expansion)
        self.cbam4 = CBAM(512 * block.expansion)
    
    def forward(self, x):
        out = torch.relu(self.bn1(self.conv1(x)))
        
        # 通过每个残差层后应用对应的CBAM模块
        out = self.layer1(out)
        out = self.cbam1(out)
        
        out = self.layer2(out)
        out = self.cbam2(out)
        
        out = self.layer3(out)
        out = self.cbam3(out)
        
        out = self.layer4(out)
        out = self.cbam4(out)
        
        out = self.avgpool(out)
        out = out.view(out.size(0), -1)
        out = self.linear(out)
        return out

def ResNet18_CBAM(num_classes=10, in_channels=3):
    return ResNetWithCBAM(BasicBlock, [2, 2, 2, 2], num_classes, in_channels)
