from .base import ResNet18
import torch
import torch.nn as nn


class CoordAtt(nn.Module):
    def __init__(self, in_channels, reduction=16):
        super().__init__()
        self.pool_h = nn.AdaptiveAvgPool2d((None, 1))
        self.pool_w = nn.AdaptiveAvgPool2d((1, None))
        
        mid_channels = max(8, in_channels // reduction)
        
        self.conv1 = nn.Conv2d(in_channels, mid_channels, 1, bias=False)
        self.bn1 = nn.BatchNorm2d(mid_channels)
        self.conv_h = nn.Conv2d(mid_channels, in_channels, 1, bias=False)
        self.conv_w = nn.Conv2d(mid_channels, in_channels, 1, bias=False)
        self.sigmoid = nn.Sigmoid()
    def forward(self, x):
        identity = x
        
        # 高度方向注意力
        h = self.pool_h(x)
        h = self.conv1(h)
        h = self.bn1(h)
        h = torch.relu(h)
        h = self.conv_h(h)
        h_att = self.sigmoid(h)
        
        # 宽度方向注意力
        w = self.pool_w(x)
        w = self.conv1(w)
        w = self.bn1(w)
        w = torch.relu(w)
        w = self.conv_w(w)
        w_att = self.sigmoid(w)
        
        # 结合注意力
        return identity * w_att * h_att



class ResNet18_CoordAtt(nn.Module):
    def __init__(self, num_classes=10, in_channels=3):
        super().__init__()
        # 原始 ResNet18
        self.resnet = ResNet18(num_classes, in_channels)
        
        # 在每个残差块组后添加 CoordAtt 模块
        self.att1 = CoordAtt(64)   # layer1 输出通道数
        self.att2 = CoordAtt(128)  # layer2 输出通道数
        self.att3 = CoordAtt(256)  # layer3 输出通道数
        self.att4 = CoordAtt(512)  # layer4 输出通道数

    def forward(self, x):
        # 初始卷积层
        x = torch.relu(self.resnet.bn1(self.resnet.conv1(x)))
        
        # 残差块组 + CoordAtt
        x = self.resnet.layer1(x)
        x = self.att1(x)  
        
        x = self.resnet.layer2(x)
        x = self.att2(x)  
        
        x = self.resnet.layer3(x)
        x = self.att3(x)  
        
        x = self.resnet.layer4(x)
        x = self.att4(x)  
        
        # 分类层
        x = self.resnet.avgpool(x)
        x = x.view(x.size(0), -1)
        x = self.resnet.linear(x)
        return x
