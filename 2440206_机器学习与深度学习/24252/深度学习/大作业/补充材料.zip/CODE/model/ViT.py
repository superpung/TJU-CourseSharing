import torch
import torch.nn as nn
import torch.nn.functional as F
from einops import rearrange

class PatchEmbedding(nn.Module):
    """将图像分割成patch并嵌入"""
    def __init__(self, img_size=32, patch_size=4, in_channels=3, embed_dim=512):
        super().__init__()
        self.img_size = (img_size, img_size)
        self.patch_size = (patch_size, patch_size)
        self.grid_size = (img_size // patch_size, img_size // patch_size)
        self.num_patches = self.grid_size[0] * self.grid_size[1]
        
        self.proj = nn.Conv2d(in_channels, embed_dim, 
                              kernel_size=patch_size, 
                              stride=patch_size)

    def forward(self, x):
        x = self.proj(x)  # [B, C, H, W] -> [B, D, H//P, W//P]
        x = x.flatten(2).transpose(1, 2)  # [B, D, N] -> [B, N, D]
        return x

class MultiHeadAttention(nn.Module):
    """多头自注意力机制"""
    def __init__(self, embed_dim, num_heads, dropout=0.1):
        super().__init__()
        self.embed_dim = embed_dim
        self.num_heads = num_heads
        self.head_dim = embed_dim // num_heads
        
        assert self.head_dim * num_heads == embed_dim, "Embed dim must be divisible by num_heads"
        
        self.qkv = nn.Linear(embed_dim, embed_dim * 3)
        self.attn_drop = nn.Dropout(dropout)
        self.proj = nn.Linear(embed_dim, embed_dim)
        self.proj_drop = nn.Dropout(dropout)

    def forward(self, x):
        B, N, C = x.shape
        qkv = self.qkv(x).reshape(B, N, 3, self.num_heads, self.head_dim).permute(2, 0, 3, 1, 4)
        q, k, v = qkv[0], qkv[1], qkv[2]
        
        attn = (q @ k.transpose(-2, -1)) * (self.head_dim ** -0.5)
        attn = attn.softmax(dim=-1)
        attn = self.attn_drop(attn)
        
        x = (attn @ v).transpose(1, 2).reshape(B, N, C)
        x = self.proj(x)
        x = self.proj_drop(x)
        return x

class MLP(nn.Module):
    """多层感知机"""
    def __init__(self, in_features, hidden_features, dropout=0.1):
        super().__init__()
        self.fc1 = nn.Linear(in_features, hidden_features)
        self.act = nn.GELU()
        self.fc2 = nn.Linear(hidden_features, in_features)
        self.drop = nn.Dropout(dropout)

    def forward(self, x):
        x = self.fc1(x)
        x = self.act(x)
        x = self.drop(x)
        x = self.fc2(x)
        x = self.drop(x)
        return x

class TransformerBlock(nn.Module):
    """Transformer模块"""
    def __init__(self, embed_dim, num_heads, mlp_ratio=4.0, dropout=0.1):
        super().__init__()
        self.norm1 = nn.LayerNorm(embed_dim)
        self.attn = MultiHeadAttention(embed_dim, num_heads, dropout)
        self.norm2 = nn.LayerNorm(embed_dim)
        
        mlp_hidden_dim = int(embed_dim * mlp_ratio)
        self.mlp = MLP(embed_dim, mlp_hidden_dim, dropout)

    def forward(self, x):
        x = x + self.attn(self.norm1(x))
        x = x + self.mlp(self.norm2(x))
        return x

class VisionTransformer(nn.Module):
    """完整的ViT模型"""
    def __init__(self, img_size=32, patch_size=4, in_channels=3, num_classes=10,
                 embed_dim=512, depth=6, num_heads=8, mlp_ratio=4.0, dropout=0.1):
        super().__init__()
        # Patch嵌入
        self.patch_embed = PatchEmbedding(img_size, patch_size, in_channels, embed_dim)
        num_patches = self.patch_embed.num_patches
        
        # 分类token和位置编码
        self.cls_token = nn.Parameter(torch.zeros(1, 1, embed_dim))
        self.pos_embed = nn.Parameter(torch.zeros(1, num_patches + 1, embed_dim))
        self.pos_drop = nn.Dropout(dropout)
        
        # Transformer模块
        self.blocks = nn.ModuleList([
            TransformerBlock(embed_dim, num_heads, mlp_ratio, dropout)
            for _ in range(depth)
        ])
        
        # 输出层
        self.norm = nn.LayerNorm(embed_dim)
        self.head = nn.Linear(embed_dim, num_classes)
        
        # 初始化
        nn.init.trunc_normal_(self.pos_embed, std=0.02)
        nn.init.trunc_normal_(self.cls_token, std=0.02)
        
        # 根据图像大小调整patch大小
        self._adjust_patch_size(img_size)

    def _adjust_patch_size(self, img_size):
        """自动调整patch大小以适应不同分辨率"""
        if img_size == 32:  # CIFAR
            self.patch_embed = PatchEmbedding(32, 4, 3, 512)
        elif img_size == 64:  # TinyImageNet
            self.patch_embed = PatchEmbedding(64, 8, 3, 512)
        
        num_patches = self.patch_embed.num_patches
        self.pos_embed = nn.Parameter(torch.zeros(1, num_patches + 1, 512))
        nn.init.trunc_normal_(self.pos_embed, std=0.02)

    def forward(self, x):
        # 嵌入patches
        x = self.patch_embed(x)  # [B, num_patches, embed_dim]
        B, N, D = x.shape
        
        # 添加分类token
        cls_tokens = self.cls_token.expand(B, -1, -1)
        x = torch.cat((cls_tokens, x), dim=1)  # [B, num_patches+1, D]
        
        # 添加位置编码
        x = x + self.pos_embed
        x = self.pos_drop(x)
        
        # 通过Transformer模块
        for block in self.blocks:
            x = block(x)
        
        # 分类
        x = self.norm(x)
        cls_token_final = x[:, 0]  # 取出分类token
        return self.head(cls_token_final)

# 创建对标ResNet18的模型
def create_vit_model(dataset='cifar10'):
    if dataset in ['cifar10', 'cifar100']:
        img_size = 32
        num_classes = 10 if dataset == 'cifar10' else 100
    elif dataset == 'tinyimagenet':
        img_size = 64
        num_classes = 200
    else:
        raise ValueError("Unsupported dataset")
    
    return VisionTransformer(
        img_size=img_size,
        patch_size=4 if img_size==32 else 8,  # 自动调整
        in_channels=3,
        num_classes=num_classes,
        embed_dim=512,        # 与ResNet18特征维度匹配
        depth=6,              # 6层Transformer
        num_heads=8,          # 8头注意力
        mlp_ratio=4.0,
        dropout=0.1
    )

# 测试代码
if __name__ == "__main__":
    # 创建CIFAR-10模型
    model_cifar = create_vit_model('cifar10')
    x = torch.randn(2, 3, 32, 32)
    out = model_cifar(x)
    print(f"CIFAR-10模型输出形状: {out.shape}, 参数量: {sum(p.numel() for p in model_cifar.parameters())/1e6:.2f}M")
    
    # 创建TinyImageNet模型
    model_tiny = create_vit_model('tinyimagenet')
    x = torch.randn(2, 3, 64, 64)
    out = model_tiny(x)
    print(f"TinyImageNet模型输出形状: {out.shape}, 参数量: {sum(p.numel() for p in model_tiny.parameters())/1e6:.2f}M")
