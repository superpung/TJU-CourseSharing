from load_data import create_cifar_loaders,create_tiny_imagenet_loaders,create_imagenet32_loaders
from model.SEnet import SEResNet18
from model.base import ResNet18
from model.CBAM import ResNet18_CBAM
from model.CorrdAtt import ResNet18_CoordAtt
from model.doubleSE import DoubleSEResNet18
from model.ECAnet import ECAResNet18
from model.ViT import VisionTransformer
from TrainTest import train,test
import torch
import torch.nn as nn
import platform
from PIL import Image
import torch.optim as optim
from torch.utils.tensorboard import SummaryWriter
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from torchinfo import summary
import os
import time
from torchprofile import profile_macs
import sys


def plot_training_metrics(save_dir):
    """
    绘制训练指标图表并保存
    
    参数:
    save_dir (str): 保存训练指标CSV文件和输出图片的目录
    
    功能:
    1. 读取训练指标CSV文件
    2. 绘制训练/测试损失和准确率曲线
    3. 自动调整y轴范围
    4. 保存图表为PNG文件
    """
    # 读取保存的指标数据
    metrics_path = os.path.join(save_dir, "training_metrics.csv")
    df = pd.read_csv(metrics_path)
    # 计算并打印最高测试准确率

    max_acc = df['test_acc'].max()
    max_top5_acc = df['test_acc_top5'].max()

    print(f"MAX_ACC={max_acc:.4f}")
    print(f"MAX_top5_acc={max_top5_acc:.4f}")
    # 创建画布和子图
    plt.figure(figsize=(12, 6))
    
    # ===== 绘制Loss曲线 =====
    plt.subplot(1, 2, 1)
    plt.plot(df['epoch'], df['train_loss'], label='Train Loss', marker='o')
    plt.plot(df['epoch'], df['test_loss'], label='Test Loss', marker='s')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.title('Training & Test Loss')
    
    # 动态设置Loss y轴范围
    all_loss = pd.concat([df['train_loss'], df['test_loss']])
    min_loss = np.floor(all_loss.min() * 10) / 10  # 向下取整到0.1
    max_loss = np.ceil(all_loss.max() * 10) / 10   # 向上取整到0.1
    
    # 确保范围有效且至少有0.3的间隔
    y_range = max_loss - min_loss
    if y_range < 0.3:
        mid = (min_loss + max_loss) / 2
        min_loss = mid - 0.15
        max_loss = mid + 0.15
    
    plt.ylim(min_loss, max_loss) 
    plt.yticks(np.arange(min_loss, max_loss + 0.01, 0.3))  # 添加微小偏移避免浮点误差
    plt.grid(True, linestyle='--', alpha=0.7)
    plt.legend()
    
    # ===== 绘制Accuracy曲线 =====
    plt.subplot(1, 2, 2)
    plt.plot(df['epoch'], df['train_acc'], label='Train Acc', marker='o')
    plt.plot(df['epoch'], df['test_acc'], label='Test Acc', marker='s')
    plt.xlabel('Epoch')
    plt.ylabel('Accuracy')
    plt.title('Training & Test Accuracy')
    
    # 标记最高准确率点
    max_acc_idx = df['test_acc'].idxmax()
    plt.scatter(df.loc[max_acc_idx, 'epoch'], max_acc, 
                color='red', zorder=5, label=f'Max Acc ({max_acc:.2%})')
    
    # 设置y轴范围和刻度
    plt.ylim(0.3, 1.0) 
    plt.yticks(np.arange(0.3, 1.01, 0.1))  # 包含1.0
    
    # 添加网格和图例
    plt.grid(True, linestyle='--', alpha=0.7)
    plt.legend(loc='lower right')
    
    # 调整布局并保存图片
    plt.tight_layout()
    output_path = os.path.join(save_dir, 'training_metrics.png')
    plt.savefig(output_path, dpi=300, bbox_inches='tight')
    print(f"训练指标图表已保存至: {output_path}")
    plt.show()


if __name__ == '__main__':
    default = 0.1
    LR = default
    if len(sys.argv) == 2:
        LR = float(sys.argv[1])
    
    print(platform.architecture()) 
    print(Image.__version__)
    
    # 数据集选择
    print("\n请选择要使用的数据集：")
    print("1. CIFAR-10")
    print("2. CIFAR-100")
    print("3. Tiny ImageNet")
    print("4. ImageNet-32")
    dataset_choice = input("请输入选项: ").strip()
    
    # 根据数据集选择设置类别数、数据加载器和保存目录
    if dataset_choice == '1':  # CIFAR-10
        num_classes = 10
        dataset_name = "CIFAR10"
        img_size = 32
        print(f"使用 {dataset_name} 数据集")
        # 创建CIFAR-10加载器
        train_loader, test_loader = create_cifar_loaders('cifar10', batch_size=512,num_workers=8)
        input_shape = (3, img_size, img_size)
        input_tensor_shape = (1, 3, img_size, img_size)
        base_save_dir = "cifar10_train_result"  # CIFAR-10专用目录
    elif dataset_choice == '2':  # CIFAR-100
        num_classes = 100
        dataset_name = "CIFAR100"
        img_size = 32
        print(f"使用 {dataset_name} 数据集")
        # 创建CIFAR-100加载器
        train_loader, test_loader = create_cifar_loaders('cifar100', batch_size=512,num_workers=8)
        input_shape = (3, img_size, img_size)
        input_tensor_shape = (1, 3, img_size, img_size)
        base_save_dir = "cifar100_train_result"  # CIFAR-100专用目录
    elif dataset_choice == '3':  # Tiny ImageNet
        num_classes = 200
        dataset_name = "TinyImageNet"
        img_size = 64
        print(f"使用 {dataset_name} 数据集")
        tiny_imagenet_dir = "./data/TinyImageNet200/tiny-imagenet-200"
        # 定义数据加载器
        train_loader, val_loader, ____ = create_tiny_imagenet_loaders(
            root_dir=tiny_imagenet_dir,
            batch_size=1024,
            num_workers=8
        )
        test_loader = val_loader
        input_shape = (3, img_size, img_size)  # Tiny ImageNet 是 64x64
        input_tensor_shape = (1, 3, img_size, img_size)
        base_save_dir = "tiny_imagenet_train_result"  # Tiny ImageNet专用目录
    elif dataset_choice == '4':  # ImageNet-32
        num_classes = 1000  # ImageNet有1000个类别
        dataset_name = "ImageNet32"
        img_size = 32
        print(f"使用 {dataset_name} 数据集")
        data_dir = "./data/DownsampledImageNet32"
        imagenet32_train, imagenet32_val = create_imagenet32_loaders(
            data_dir=data_dir,
            batch_size=2048,
            num_workers=8
        )
        train_loader = imagenet32_train
        test_loader = imagenet32_val
        input_shape = (3, img_size, img_size)
        input_tensor_shape = (1, 3, img_size, img_size)
        base_save_dir = "imagenet32_train_result"  # ImageNet专用目录
    else:
        print("输入无效")
        exit()
    
    # 确保基础保存目录存在
    os.makedirs(base_save_dir, exist_ok=True)
    
    # 模型选择
    print("\n请选择要使用的模型：")
    print("1. ResNet18：基准模型")
    print("2. SEResNet18")
    print("3. ECAResNet18")
    print("4. ResNet18_CoordAtt")
    print("6. scSEResNet18")
    print("7. ResNet18_CBAM")
    print("8. Vision Transformer (ViT)") 
    model_choice = input("请输入选项: ").strip()
    
    device = "cuda" if torch.cuda.is_available() else "cpu"
    
    # 处理ViT模型选择
    if model_choice == '8':  # Vision Transformer
        model_name = "ViT"
        # 创建ViT模型实例
        model = VisionTransformer(
            img_size=img_size,
            patch_size=4 if img_size == 32 else 8,  # 自动调整patch大小
            in_channels=3,
            num_classes=num_classes,
            embed_dim=512,        
            depth=6,              
            num_heads=8,          
            mlp_ratio=4.0,
            dropout=0.1
        ).to(device)
    else:
        # 其他ResNet模型
        model_classes = {
            '1': {'name': 'ResNet18', 'class': ResNet18},
            '2': {'name': 'SEResNet18', 'class': SEResNet18},
            '3': {'name': 'ECAResNet18', 'class': ECAResNet18},
            '4': {'name': 'ResNet18_CoordAtt', 'class': ResNet18_CoordAtt},
            '6': {'name': 'DoubleSEResNet18', 'class': DoubleSEResNet18},
            '7': {'name': 'ResNet18_CBAM', 'class': ResNet18_CBAM},
        }
        if model_choice in model_classes:
            model_info = model_classes[model_choice]
        else:
            print("输入无效，默认使用ResNet18")
            model_info = model_classes['1']
        model_name = model_info['name']
        model_class = model_info['class']
        # 创建模型实例，使用数据集对应的类别数
        model = model_class(num_classes=num_classes).to(device)
    
    # 创建模型保存目录（在数据集目录下）
    save_dir = os.path.join(base_save_dir, f"training_results_{model_name}")
    os.makedirs(save_dir, exist_ok=True)
    model_path = os.path.join(save_dir, "model.pth")
    csv_path = os.path.join(save_dir, "training_metrics.csv")
    
    # 恢复训练检查（现在只需要检查模型类型是否匹配）
    resume = False
    if os.path.exists(model_path) and os.path.exists(csv_path):
        checkpoint = torch.load(model_path, map_location=device)
        saved_model_type = checkpoint.get('model_type', '')
        
        # 只检查模型类型（数据集已经通过目录分离）
        if saved_model_type != model_name:
            print(f"\n发现已有训练结果，但模型类型不匹配（已保存模型：{saved_model_type}，当前模型：{model_name}）")
            print("无法继续训练，将开始新的训练！")
        else:
            choice = input("\n发现匹配的训练结果，是否继续训练？(y/n): ").lower()
            resume = (choice == 'y')
    
    epochs_app = int(input("输入轮数:"))

    # 优化器
    if model_name == "ViT":
        optimizer = optim.AdamW(model.parameters(), lr=LR, weight_decay=0.01)
    else:
        optimizer = optim.Adam(model.parameters(), lr=LR)
    
    # 学习率调度器
    if model_name == "ViT":
        # ViT建议使用余弦退火调度器
        scheduler = optim.lr_scheduler.CosineAnnealingLR(
            optimizer, 
            T_max=epochs_app,  # 总训练轮数作为周期
            eta_min=1e-6       # 最小学习率
        )
    else:
        # 其他模型使用ReduceLROnPlateau
        scheduler = optim.lr_scheduler.ReduceLROnPlateau(
            optimizer, mode='max', factor=0.8, patience=5
        )

    # 恢复训练时的状态加载
    if resume:
        checkpoint = torch.load(model_path, map_location=device)
        model.load_state_dict(checkpoint['model_state_dict'])
        optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
        scheduler.load_state_dict(checkpoint['scheduler_state_dict'])
        start_epoch = checkpoint['epoch'] + 1
        print(f"将从第 {start_epoch} 轮继续训练")
        # 加载历史指标
        df_hist = pd.read_csv(csv_path)
        metrics = {
            'epoch': df_hist['epoch'].tolist(),
            'train_loss': df_hist['train_loss'].tolist(),
            'train_acc': df_hist['train_acc'].tolist(),
            'test_loss': df_hist['test_loss'].tolist(),
            'test_acc': df_hist['test_acc'].tolist(),
            'test_acc_top5': df_hist['test_acc_top5'].tolist(),
            'epoch_time': df_hist['epoch_time'].tolist()
        }
    else:
        metrics = {'epoch': [], 'train_loss': [], 'train_acc': [], 'test_loss': [], 'test_acc': [], 'test_acc_top5': [], 'epoch_time': []}
        start_epoch = 1
        print("开始新的训练")
    print("\n模型结构概要：")
    summary(model, input_tensor_shape)  # 使用数据集对应的输入形状
    
    input = torch.randn(input_tensor_shape)  # 输入尺寸
    input = input.to(device)
    macs = profile_macs(model, input)
    flops = 2 * macs  # 1 MAC = 2 FLOPs
    print(f"FLOPs: {flops/1e9:.6f} GMac")
    # 初始化TensorBoard
    writer = SummaryWriter(log_dir=os.path.join(save_dir, "logs"))
    total_start_time = time.time()
    # 训练模型
    for epoch in range(start_epoch, start_epoch + epochs_app):
        epoch_start_time = time.time()
        # 训练阶段
        train_loss, train_acc = train(model, device, train_loader, optimizer, epoch)
        
        # 测试阶段
        test_loss, test_acc, test_acc_top5 = test(model, device, test_loader)
        
       # 更新学习率
        if model_name == "ViT":
            scheduler.step()
        else:
            scheduler.step(test_acc)
            
        epoch_time = time.time() - epoch_start_time
        # 记录指标
        metrics['epoch'].append(epoch)
        metrics['train_loss'].append(train_loss)
        metrics['train_acc'].append(train_acc)
        metrics['test_loss'].append(test_loss)
        metrics['test_acc'].append(test_acc)
        metrics['test_acc_top5'].append(test_acc_top5)
        metrics['epoch_time'].append(epoch_time)
        print(f"Epoch {epoch} 耗时: {epoch_time:.2f}秒")
        # 实时保存
        pd.DataFrame(metrics).to_csv(csv_path, index=False)
        torch.save({
            'epoch': epoch,
            'model_state_dict': model.state_dict(),
            'optimizer_state_dict': optimizer.state_dict(),
            'scheduler_state_dict': scheduler.state_dict(),
            'model_type': model_name,
            'dataset': dataset_name,  # 保存数据集信息（可选）
            'train_loss': train_loss,
            'train_acc': train_acc,
            'test_loss': test_loss,
            'test_acc': test_acc,
            'test_acc_top5': test_acc_top5,
        }, model_path)
        
        # TensorBoard记录
        writer.add_scalar('Loss/train', train_loss, epoch)
        writer.add_scalar('Accuracy/train', train_acc, epoch)
        writer.add_scalar('Loss/test', test_loss, epoch)
        writer.add_scalar('Accuracy/test', test_acc, epoch)
        writer.add_scalar('Time/epoch', epoch_time, epoch)
    
    # 关闭 TensorBoard writer
    writer.close()
    total_time = sum(metrics['epoch_time'])
    print(f"\n总训练时间: {total_time:.2f}秒 ({total_time/60:.2f}分钟)")
    
    print("训练完成！结果保存在", save_dir)
    
    plot_training_metrics(save_dir)
