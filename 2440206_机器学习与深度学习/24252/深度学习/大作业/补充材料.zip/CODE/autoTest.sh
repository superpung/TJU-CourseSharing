#!/bin/bash

# 定义基础变量
DATASET_CHOICE="3"   # 1=CIFAR-10, 2=CIFAR-100, 3=TinyImageNet,
MODEL_CHOICE="7"     # 1=ResNet18, 2=SEResNet18, 3=ECAResNet18, 4=ResNet18_CoordAtt, 6=DoubleSEResNet18, 7=ResNet18_CBAM 8=ViT 
EPOCHS="50"          # 训练轮数
SCRIPT="./start.py"  # 替换为你的Python脚本路径

# 学习率列表
LEARNING_RATES=(0.0007)

# 创建输出目录
OUTPUT_DIR="learning_rate_experiments"
PICTURE_DIR="${OUTPUT_DIR}/pictures"
LOG_DIR="${OUTPUT_DIR}/logs"
mkdir -p "${PICTURE_DIR}" "${LOG_DIR}"

# 获取当前时间戳
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")

# 循环执行不同学习率的训练
for lr in "${LEARNING_RATES[@]}"; do
    # 清理之前的训练结果
    rm -rf cifar*_train_result tiny*_train_result imagenet*_train_result
    
    # 构造日志文件名
    lr_safe=$(echo "$lr" | tr '.' '_')
    LOG_FILE="${LOG_DIR}/DS${DATASET_CHOICE}_MD${MODEL_CHOICE}_lr_${lr_safe}.log"
    
    # 构造图片文件名前缀
    PICTURE_PREFIX="${PICTURE_DIR}/lr_${lr_safe}_DS${DATASET_CHOICE}_MD${MODEL_CHOICE}.png"
    
    echo "============================================================"
    echo "开始训练: 学习率=${lr}, 数据集=${DATASET_CHOICE}, 模型=${MODEL_CHOICE}"
    echo "日志文件: ${LOG_FILE}"
    echo "============================================================"
    
    # 执行训练命令
    echo -e "${DATASET_CHOICE}\n${MODEL_CHOICE}\n${EPOCHS}" | python "${SCRIPT}" "${lr}" 2>&1 | tee "${LOG_FILE}"
    
    
    echo "完成学习率 ${lr} 的训练"
    echo "------------------------------------------------------------"
done

echo "所有训练任务已完成!"
echo "结果保存在: ${OUTPUT_DIR}"
echo "日志目录: ${LOG_DIR}"
echo "图片目录: ${PICTURE_DIR}"
