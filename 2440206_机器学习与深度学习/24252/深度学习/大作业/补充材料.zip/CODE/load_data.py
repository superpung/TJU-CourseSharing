import os
import pickle
import numpy as np
import torch
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms
from PIL import Image
import pandas as pd
import torchvision.datasets as datasets

class ImageNet64Dataset(Dataset):
    def __init__(self, data, labels, transform=None):
        """
        下采样ImageNet-64数据集加载器
        
        参数:
            data: 图像数据 (numpy数组)
            labels: 标签数据 (numpy数组)
            transform: 图像变换
        """
        self.data = data
        self.labels = labels
        self.transform = transform
        
    def __len__(self):
        return len(self.data)
    
    def __getitem__(self, idx):
        image = self.data[idx]
        label = self.labels[idx]
        
        # 重塑为 (3, 64, 64) 格式
        image = image.reshape(3, 64, 64).astype(np.float32)
        
        if self.transform:
            image = self.transform(image)
            
        return image, label

def load_imagenet64_batch(file_path):
    """加载单个ImageNet-64批次文件"""
    with open(file_path, 'rb') as f:
        batch = pickle.load(f, encoding='latin1')
    data = batch['data']
    labels = batch['labels']
    return data, np.array(labels)

def create_imagenet64_loaders(data_dir, batch_size=128, num_workers=4):
    """
    创建ImageNet-64数据加载器
    
    参数:
        data_dir: 数据集目录路径
        batch_size: 批处理大小
        num_workers: 数据加载线程数
        
    返回:
        train_loader, val_loader: 训练和验证数据加载器
    """
    # 1. 加载训练数据 (10个批次)
    train_data = []
    train_labels = []
    
    for i in range(1, 11):
        file_path = os.path.join(data_dir, f'train_data_batch_{i}')
        data, labels = load_imagenet64_batch(file_path)
        train_data.append(data)
        train_labels.append(labels)
    
    train_data = np.concatenate(train_data, axis=0)
    train_labels = np.concatenate(train_labels, axis=0)
    
    # 2. 加载验证数据
    val_file = os.path.join(data_dir, 'val_data')
    val_data, val_labels = load_imagenet64_batch(val_file)
    
    # 3. 数据增强
    train_transform = transforms.Compose([
        transforms.RandomResizedCrop(64, scale=(0.8, 1.0)),  # 尺度增强
        transforms.RandomHorizontalFlip(),
        transforms.ColorJitter(brightness=0.3, contrast=0.3, saturation=0.3),  # 颜色抖动
        transforms.RandomRotation(20),  # 增大旋转幅度
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
        transforms.RandomErasing(p=0.7, scale=(0.02, 0.2), value='random')  # 强遮挡
    ])
    
    val_transform = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406], 
                             std=[0.229, 0.224, 0.225])
    ])
    
    # 4. 创建数据集
    train_dataset = ImageNet64Dataset(train_data, train_labels, train_transform)
    val_dataset = ImageNet64Dataset(val_data, val_labels, val_transform)
    
    # 5. 创建数据加载器
    train_loader = DataLoader(
        train_dataset,
        batch_size=batch_size,
        shuffle=True,
        num_workers=num_workers,
        pin_memory=True,
        drop_last=True  # 丢弃最后不完整的批次
    )
    
    val_loader = DataLoader(
        val_dataset,
        batch_size=batch_size,
        shuffle=False,
        num_workers=num_workers,
        pin_memory=True
    )
    
    return train_loader, val_loader
class ImageNet32Dataset(Dataset):
    def __init__(self, data, labels, transform=None):
        """
        ImageNet-32数据集加载器
        
        参数:
            data: 图像数据 (numpy数组)
            labels: 标签数据 (numpy数组)
            transform: 图像变换
        """
        self.data = data
        self.labels = labels
        self.transform = transform
        
    def __len__(self):
        return len(self.data)
    
    def __getitem__(self, idx):
        image = self.data[idx]
        label = self.labels[idx]
        
        # 重塑为 (3, 32, 32) 格式 (32x32版本)
        image = image.reshape(3, 32, 32).astype(np.float32)
        
        # 转换为PIL图像以兼容torchvision变换
        image = np.transpose(image, (1, 2, 0))  # 转为HWC格式
        image = transforms.ToPILImage()(image)
        
        if self.transform:
            image = self.transform(image)
            
        return image, label
def load_imagenet32_batch(file_path):
    """加载单个ImageNet-32批次文件"""
    with open(file_path, 'rb') as f:
        batch = pickle.load(f, encoding='latin1')
    data = batch['data']
    labels = batch['labels']
    return data, np.array(labels)
def create_imagenet32_loaders(data_dir, batch_size=128, num_workers=4):
    """
    创建ImageNet-32数据加载器
    
    参数:
        data_dir: 数据集目录路径
        batch_size: 批处理大小
        num_workers: 数据加载线程数
        
    返回:
        train_loader, val_loader: 训练和验证数据加载器
    """
    # 1. 加载训练数据 (10个批次)
    train_data = []
    train_labels = []
    
    for i in range(1, 11):
        file_path = os.path.join(data_dir, f'train_data_batch_{i}')
        data, labels = load_imagenet32_batch(file_path)
        train_data.append(data)
        train_labels.append(labels)
    
    train_data = np.concatenate(train_data, axis=0)
    train_labels = np.concatenate(train_labels, axis=0)
    
    # 2. 加载验证数据
    val_file = os.path.join(data_dir, 'val_data')
    val_data, val_labels = load_imagenet32_batch(val_file)
    
    # 3. 数据增强 (针对32x32尺寸优化)
    train_transform = transforms.Compose([
        transforms.RandomResizedCrop(32, scale=(0.8, 1.0)),
        transforms.RandomHorizontalFlip(),
        transforms.ColorJitter(brightness=0.2, contrast=0.2, saturation=0.2),  # 减小抖动幅度
        transforms.RandomRotation(15),  # 减小旋转幅度
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
        transforms.RandomErasing(p=0.5, scale=(0.02, 0.1), value='random')  # 减小遮挡比例
    ])
    
    val_transform = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406], 
                             std=[0.229, 0.224, 0.225])
    ])
    
    # 4. 创建数据集
    train_dataset = ImageNet32Dataset(train_data, train_labels, train_transform)
    val_dataset = ImageNet32Dataset(val_data, val_labels, val_transform)
    
    # 5. 创建数据加载器
    train_loader = DataLoader(
        train_dataset,
        batch_size=batch_size,
        shuffle=True,
        num_workers=num_workers,
        pin_memory=True,
        drop_last=True
    )
    
    val_loader = DataLoader(
        val_dataset,
        batch_size=batch_size,
        shuffle=False,
        num_workers=num_workers,
        pin_memory=True
    )
    
    return train_loader, val_loader



def create_cifar_loaders(dataset_name='cifar10', batch_size=128, num_workers=2):
    """
    创建CIFAR-10或CIFAR-100数据加载器
    
    参数:
        dataset_name: 'cifar10' 或 'cifar100'
        batch_size: 批处理大小
        num_workers: 数据加载线程数
        
    返回:
        train_loader, test_loader: 训练和测试数据加载器
    """
    # 选择数据集
    dataset = datasets.CIFAR10 if dataset_name == 'cifar10' else datasets.CIFAR100
    
    # 数据增强
    train_transform = transforms.Compose([
        transforms.RandomHorizontalFlip(),    # 随机水平翻转
        transforms.RandomCrop(32, padding=4), # 随机裁剪
        transforms.RandomRotation(15),
        transforms.ColorJitter(brightness=0.2, contrast=0.2), # 颜色抖动
        transforms.ToTensor(),
        transforms.Normalize((0.4914, 0.4822, 0.4465), (0.2470, 0.2435, 0.2616)), # CIFAR-10均值方差
        transforms.RandomErasing(p=0.5)
    ])

    test_transform = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.4914, 0.4822, 0.4465],
                             std=[0.2023, 0.1994, 0.2010])
    ])
    
    # 创建数据集
    train_dataset = dataset(
        root='./data',
        train=True,
        download=True,
        transform=train_transform
    )
    
    test_dataset = dataset(
        root='./data',
        train=False,
        download=True,
        transform=test_transform
    )
    
    # 创建数据加载器
    train_loader = DataLoader(
        train_dataset,
        batch_size=batch_size,
        shuffle=True,
        num_workers=num_workers,
        pin_memory=True,
        drop_last=True
    )
    
    test_loader = DataLoader(
        test_dataset,
        batch_size=batch_size,
        shuffle=False,
        num_workers=num_workers,
        pin_memory=True
    )
    
    return train_loader, test_loader

class TinyImageNetDataset(Dataset):
    def __init__(self, root_dir, split='train', transform=None):
        """
        Tiny ImageNet数据集加载器
        
        参数:
            root_dir: 数据集根目录
            split: 数据集分割 ('train', 'val', 'test')
            transform: 图像变换
        """
        self.root_dir = root_dir
        self.split = split
        self.transform = transform
        self.class_dict = {}
        self.class_idx_to_wnid = {}
        self.images = []
        self.labels = []
        
        # 加载类别映射
        self._load_class_mapping()
        
        if split == 'train':
            self._load_train_data()
        elif split == 'val':
            self._load_val_data()
        elif split == 'test':
            self._load_test_data()
    
    def _load_class_mapping(self):
        """加载类别ID到WordNet ID的映射"""
        class_file = os.path.join(self.root_dir, 'wnids.txt')
        with open(class_file, 'r') as f:
            for idx, line in enumerate(f):
                wnid = line.strip()
                self.class_dict[wnid] = idx
                self.class_idx_to_wnid[idx] = wnid
    
    def _load_train_data(self):
        """加载训练数据"""
        train_dir = os.path.join(self.root_dir, 'train')
        for wnid in self.class_dict:
            class_idx = self.class_dict[wnid]
            class_dir = os.path.join(train_dir, wnid, 'images')
            
            for img_name in os.listdir(class_dir):
                if img_name.endswith('.JPEG'):
                    img_path = os.path.join(class_dir, img_name)
                    self.images.append(img_path)
                    self.labels.append(class_idx)
    
    def _load_val_data(self):
        """加载验证数据"""
        val_dir = os.path.join(self.root_dir, 'val')
        images_dir = os.path.join(val_dir, 'images')
        annotations_file = os.path.join(val_dir, 'val_annotations.txt')
        
        # 解析验证集注释文件
        annotations = pd.read_csv(annotations_file, sep='\t', header=None, 
                                 names=['filename', 'wnid', 'x', 'y', 'w', 'h'])
        
        for _, row in annotations.iterrows():
            img_path = os.path.join(images_dir, row['filename'])
            if os.path.exists(img_path):
                self.images.append(img_path)
                self.labels.append(self.class_dict[row['wnid']])
    
    def _load_test_data(self):
        """加载测试数据（无标签）"""
        test_dir = os.path.join(self.root_dir, 'test', 'images')
        for img_name in os.listdir(test_dir):
            if img_name.endswith('.JPEG'):
                img_path = os.path.join(test_dir, img_name)
                self.images.append(img_path)
                self.labels.append(-1)  # 测试集无标签
    
    def __len__(self):
        return len(self.images)
    
    def __getitem__(self, idx):
        img_path = self.images[idx]
        label = self.labels[idx]
        
        # 加载图像
        img = Image.open(img_path).convert('RGB')
        
        if self.transform:
            img = self.transform(img)
            
        return img, label
def create_tiny_imagenet_loaders(root_dir, batch_size=128, num_workers=4):
    """
    创建Tiny ImageNet数据加载器
    
    参数:
        root_dir: 数据集根目录
        batch_size: 批处理大小
        num_workers: 数据加载线程数
        
    返回:
        train_loader, val_loader, test_loader: 训练、验证和测试数据加载器
    """
    # 数据增强和标准化
    train_transform = transforms.Compose([
        transforms.RandomResizedCrop(64, scale=(0.8, 1.0)),  # 尺度增强
        transforms.RandomHorizontalFlip(),
        transforms.ColorJitter(brightness=0.3, contrast=0.3, saturation=0.3),  # 颜色抖动
        transforms.RandomRotation(20),  # 增大旋转幅度
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
        transforms.RandomErasing(p=0.7, scale=(0.02, 0.2), value='random')  # 强遮挡
    ])

    test_transform = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406], 
                             std=[0.229, 0.224, 0.225])
    ])
    
    # 创建数据集
    train_dataset = TinyImageNetDataset(root_dir, split='train', transform=train_transform)
    val_dataset = TinyImageNetDataset(root_dir, split='val', transform=test_transform)
    test_dataset = TinyImageNetDataset(root_dir, split='test', transform=test_transform)
    
    # 创建数据加载器
    train_loader = DataLoader(
        train_dataset,
        batch_size=batch_size,
        shuffle=True,
        num_workers=num_workers,
        pin_memory=True,
        drop_last=True
    )
    
    val_loader = DataLoader(
        val_dataset,
        batch_size=batch_size,
        shuffle=False,
        num_workers=num_workers,
        pin_memory=True
    )
    
    test_loader = DataLoader(
        test_dataset,
        batch_size=batch_size,
        shuffle=False,
        num_workers=num_workers,
        pin_memory=True
    )
    
    return train_loader, val_loader, test_loader





# 使用示例
if __name__ == "__main__":
    '''
    # 创建ImageNet-64加载器
    data_dir = "E:/conda_python/DL/bigwork/data/DownsampledImageNet"
    imagenet64_train, imagenet64_val = create_imagenet64_loaders(
        data_dir=data_dir,
        batch_size=256,
        num_workers=4
    )
    '''
    # 创建CIFAR加载器
    cifar10_train, cifar10_test = create_cifar_loaders('cifar10', batch_size=128)
    cifar100_train, cifar100_test = create_cifar_loaders('cifar100', batch_size=128)
    
    # 打印数据集信息
    #print(f"ImageNet-64 训练集: {len(imagenet64_train.dataset)}张图像, {len(imagenet64_train)}批次")
    #print(f"ImageNet-64 验证集: {len(imagenet64_val.dataset)}张图像, {len(imagenet64_val)}批次")
    print(f"CIFAR-10 训练集: {len(cifar10_train.dataset)}张图像, {len(cifar10_train)}批次")
    print(f"CIFAR-10 测试集: {len(cifar10_test.dataset)}张图像, {len(cifar10_test)}批次")
    
    # 获取一个ImageNet-64批次
    #images, labels = next(iter(imagenet64_train))
    #print(f"\nImageNet-64批次图像维度: {images.shape}")
    #print(f"ImageNet-64批次标签维度: {labels.shape}")
    
    # 获取一个CIFAR批次
    cifar_images, cifar_labels = next(iter(cifar10_train))
    print(f"\nCIFAR-10批次图像维度: {cifar_images.shape}")
    print(f"CIFAR-10批次标签维度: {cifar_labels.shape}")

    # 设置数据集路径
    tiny_imagenet_dir = "E:/conda_python/DL/bigwork/data/TinyImageNet200/tiny-imagenet-200"  # 替换为实际路径
    
    # 创建加载器
    train_loader, val_loader, test_loader = create_tiny_imagenet_loaders(
        root_dir=tiny_imagenet_dir,
        batch_size=128,
        num_workers=4
    )
    
    # 打印数据集信息
    print(f"Tiny ImageNet 训练集: {len(train_loader.dataset)}张图像, {len(train_loader)}批次")
    print(f"Tiny ImageNet 验证集: {len(val_loader.dataset)}张图像, {len(val_loader)}批次")
    print(f"Tiny ImageNet 测试集: {len(test_loader.dataset)}张图像, {len(test_loader)}批次")
    
    # 获取一个训练批次
    images, labels = next(iter(train_loader))
    print(f"\n训练批次图像维度: {images.shape}")
    print(f"训练批次标签维度: {labels.shape}")
    
    # 获取一个验证批次
    val_images, val_labels = next(iter(val_loader))
    print(f"\n验证批次图像维度: {val_images.shape}")
    print(f"验证批次标签维度: {val_labels.shape}")
    
    # 获取一个测试批次
    test_images, test_labels = next(iter(test_loader))
    print(f"\n测试批次图像维度: {test_images.shape}")
    print(f"测试批次标签: {test_labels[:10]} (测试集无标签)")
