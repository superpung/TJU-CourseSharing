# 注意力机制在图像识别中的应用研究

## 项目概述

本项目系统性地研究并比较了多种主流注意力机制在图像分类任务中的性能表现。通过在CIFAR-10、CIFAR-100和TinyImageNet数据集上，以ResNet18为基准模型进行嵌入实现和对比实验，分析了不同注意力机制（通道域、空间域、混合域及自注意力）在图像分类任务中的效果，并提出了改进模型scSE。

## 摘要

随着人工智能的快速发展，计算机视觉领域的算法发展尤为迅速。图像分类作为计算机视觉中的核心问题，其性能优化具有重要意义。本报告主要研究不同的主流注意力机制在图像分类问题中的应用，比较这些注意力机制的性能，并对现有注意力机制进行改进以提高性能。

**关键词**：计算机视觉，图像分类，注意力机制

## 主要贡献

1. 基于ResNet18实现了多种注意力模型（SENet、ECANet、坐标注意力、CBAM、ViT等）
2. 在CIFAR-10/100和TinyImageNet数据集上进行对比分析
3. 提出改进模型scSE，不显著增加计算量的同时提升性能
4. 系统分析不同注意力机制在参数量、计算开销及分类精度等指标的表现

## 项目结构

```
├── data/                    # 数据集存储目录
├── model/                   # 模型实现代码
│   ├── base.py              # ResNet18基准模型
│   ├── CBAM.py              # CBAM注意力实现
│   ├── CorrdAtt.py          # 坐标注意力实现
│   ├── doubleSE.py          # scSE注意力实现
│   ├── ECAnet.py            # ECANet实现
│   ├── SEnet.py             # SENet实现
│   └── ViT.py               # Vision Transformer实现
|
├── autoStart.sh             # 自动训练脚本，在1个数据集上训练不同模型和对应参数
├── autoTest.sh              # 自动测试脚本，在1个数据集，1个模型上以不同学习率训练
├── download.sh              # 数据集下载脚本
├── load_data.py             # 数据加载器
├── TrainTest.py             # 训练测试函数
├── results/                 # 实验结果存储
├── start.py                 # 主训练脚本
└── README.md                # 项目说明文档
```

## 环境依赖

```
conda create -n myenv python=3.11 -y
conda activate myenv
```

安装pytorch（windows/linux），CUDA=12.8

```bash
pip3 install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu128
```

安装pytorch（linux），CUDA=12.6

```bash
pip3 install torch torchvision torchaudio
```

安装其他依赖

```bash
pip install torchinfo torchprofile einops pandas tensorboard matplotlib
```

## 数据集准备

项目支持以下数据集：

| 数据集       | 类别数 | 图像尺寸 | 样本数量  |
| ------------ | ------ | -------- | --------- |
| CIFAR-10     | 10     | 32×32    | 60,000    |
| CIFAR-100    | 100    | 32×32    | 60,000    |
| TinyImageNet | 200    | 64×64    | 120,000   |
| ImageNet-32  | 1000   | 32×32    | 1,281,167 |

运行下载脚本：

```bash
./download.sh
```

## 使用方法

### 单次训练

```bash
python start.py
```

根据提示选择数据集和模型，设置训练参数

### 批量测试不同模型

```bash
./autoTest.sh
```

### 批量测试不同超参数

```bash
./autoStart.sh
```

## 实验结果

### CIFAR-10性能对比（Top1准确率）

| 模型     | 参数量(M) | FLOPs(G) | 准确率(%) |
| -------- | --------- | -------- | --------- |
| ResNet18 | 11.22     | 1.1122   | 92.74     |
| +SE      | 11.31     | 1.1128   | 93.10     |
| +ECA     | 11.22     | 1.1127   | 93.00     |
| +Coor    | 11.29     | 1.1137   | 93.29     |
| +scSE    | 11.31     | 1.1138   | **93.39** |
| +CBAM    | 11.27     | 1.1130   | 93.01     |
| ViT      | 18.98     | 2.5100   | 81.33     |

### TinyImageNet性能对比

| 模型     | 参数量(M) | FLOPs(G) | 准确率(%) |
| -------- | --------- | -------- | --------- |
| ResNet18 | 11.27     | 4.4485   | 53.55     |
| +SE      | 11.36     | 4.4506   | 54.04     |
| +ECA     | 11.27     | 4.4504   | 54.35     |
| +Coor    | 11.33     | 4.4526   | 54.06     |
| +scSE    | 11.36     | 4.4545   | **54.86** |
| +CBAM    | 11.32     | 4.4516   | 54.40     |
| ViT      | 19.15     | 2.5196   | 39.77     |

## 主要结论

1. **scSE模型表现最佳**：在小型和中等规模数据集上，scSE能显著提升CNN模型的性能
2. **ECA的表现**：以近乎零计算代价实现较稳定的增益，适合资源受限场景
3. **ViT的局限**：在小型数据集上表现大幅落后于CNN，需要大规模预训练数据
4. **注意力机制有效**：在CIFAR-10和TinyImageNet上，所有注意力变体都提升了基准模型性能
5. **数据规模影响**：在细粒度任务（CIFAR100）中，注意力机制效果受数据规模制约

## 未来方向

1. 针对细粒度分类任务设计专用注意力模块
2. 探索知识蒸馏技术提升小数据集上的ViT性能
3. 研究低分辨率图像专用的ViT变体架构
4. 优化训练策略和正则化方法缓解过拟合问题

## 参考文献

```text
1. 李玉洁 等. (2025). 视觉Transformer(ViT)发展综述. 计算机科学, 52(1): 194-209.  
2. 陈昶. (2024). 基于注意力机制的图像分类方法研究 [硕士论文]. 杭州电子科技大学.  
3. Guo, M. H. et al. (2022). Attention mechanisms in computer vision: A survey. Comput. Visual Media, 8(3): 331–368.  
4. Vaswani, A. et al. (2017). Attention is all you need. Adv. Neural Inf. Process. Syst., 30.  
5. He, K. et al. (2016). Deep residual learning for image recognition. IEEE CVPR, 770–778.  
6. Zhang, A. et al. (2023). Dive into deep learning. Cambridge Univ. Press.  
7. Hu, J. et al. (2018). Squeeze-and-excitation networks. IEEE CVPR, 7132–7141.  
8. Wang, Q. et al. (2020). ECA-Net: Efficient channel attention... IEEE/CVF CVPR, 11534–11542.  
9. Hou, Q. et al. (2021). Coordinate attention for... mobile network design. IEEE/CVF CVPR, 13713–13722.  
10. Woo, S. et al. (2018). Cbam: Convolutional block attention module. ECCV, 3–19.  
11. Dosovitskiy, A. et al. (2020). An image is worth 16x16 words... image recognition. arXiv:2010.11929.
```

