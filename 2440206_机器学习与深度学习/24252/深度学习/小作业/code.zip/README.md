该任务是改进LeNet5网络以适应Cifar-10数据集的项目，实现的网络包括原始的LeNet，加深层次，引入残差，引入密集连接，引入inception模块改进的版本。

运行之前，需要安装的包：

```bash
pip install numpy pandas matplotlib scikit-learn jupyter scipy
pip install transformers datasets
pip3 install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu128
pip install torchinfo
pip install tensorboard
```

在win中，使用

```bash
Python .\LeNetImp.py
```

启动程序

输入选项以训练不同模型，数据集会自动下载，同时每个Epoch的训练结果会保存到该.py文件所在的目录中

注意：在代码中会加载8个进程用于训练数据传输，4个进程用于测试数据传输，同时batch size设置为256，按需调整大小。

训练结束后，由于启动的进程数较多，因此程序占用的所有资源不会立刻回收完毕。
