import torch
import platform

from PIL import Image

import torch
import torch.nn as nn
import torch.optim as optim
import torchvision.datasets as datasets
import torchvision.transforms as transforms
import torch.nn.functional as F
from torch.utils.tensorboard import SummaryWriter
import os
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from torchinfo import summary

# 定义LeNet-5模型
class LeNet5(nn.Module):
    def __init__(self):
        super(LeNet5, self).__init__()
        self.conv1 = nn.Conv2d(in_channels=3, out_channels=6, kernel_size=5, stride=1)
        self.pool1 = nn.AvgPool2d(kernel_size=2, stride=2)
        self.conv2 = nn.Conv2d(in_channels=6, out_channels=16, kernel_size=5, stride=1)
        self.pool2 = nn.AvgPool2d(kernel_size=2, stride=2)

        #self.fc1 = nn.Linear(in_features=16 * 4 * 4, out_features=120)
        self.fc1 = nn.Linear(16 * 5 * 5, 120) 
        
        self.fc2 = nn.Linear(in_features=120, out_features=84)
        self.fc3 = nn.Linear(in_features=84, out_features=10)
        
    def forward(self, x):
        x = self.pool1(torch.relu(self.conv1(x)))
        x = self.pool2(torch.relu(self.conv2(x)))
        x = x.view(x.size(0), -1)  
        x = torch.relu(self.fc1(x))
        x = torch.relu(self.fc2(x))
        x = self.fc3(x)
        return x
    

class LeNet5_v1(nn.Module):
    def __init__(self):
        super().__init__()
        self.conv1 = nn.Conv2d(3, 32, 3, padding=1)  
        self.bn1 = nn.BatchNorm2d(32)
        self.pool1 = nn.MaxPool2d(2, 2)
        self.conv2 = nn.Conv2d(32, 64, 3, padding=1)
        self.bn2 = nn.BatchNorm2d(64)
        self.pool2 = nn.MaxPool2d(2, 2)
        self.conv3 = nn.Conv2d(64, 128, 3, padding=1)  
        self.bn3 = nn.BatchNorm2d(128)
        self.pool3 = nn.MaxPool2d(2, 2)
        self.fc1 = nn.Linear(128*4*4, 512)  # 全连接层
        self.dropout = nn.Dropout(0.5)
        self.fc2 = nn.Linear(512, 10)  # 输出层
    def forward(self, x):
        x = self.pool1(F.relu(self.bn1(self.conv1(x))))
        x = self.pool2(F.relu(self.bn2(self.conv2(x))))
        x = self.pool3(F.relu(self.bn3(self.conv3(x))))
        x = x.view(x.size(0), -1)
        x = self.dropout(F.relu(self.fc1(x)))
        return self.fc2(x)



class LeNet5_v2(nn.Module):
    def __init__(self, num_classes=10):
        super(LeNet5_v2, self).__init__()
        
        # 特征提取层
        self.features = nn.Sequential(
            # Block 1 (2x conv)
            nn.Conv2d(3, 64, kernel_size=3, padding=1),  # 32x32
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True),
            nn.Conv2d(64, 64, kernel_size=3, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2),  # 16x16
            # Block 2 (2x conv)
            nn.Conv2d(64, 128, kernel_size=3, padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU(inplace=True),
            nn.Conv2d(128, 128, kernel_size=3, padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2),  # 8x8
            # Block 3 (3x conv)
            nn.Conv2d(128, 256, kernel_size=3, padding=1),
            nn.BatchNorm2d(256),
            nn.ReLU(inplace=True),
            nn.Conv2d(256, 256, kernel_size=3, padding=1),
            nn.BatchNorm2d(256),
            nn.ReLU(inplace=True),
            nn.Conv2d(256, 256, kernel_size=3, padding=1),
            nn.BatchNorm2d(256),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2),  # 4x4
            # Block 4 (3x conv)
            nn.Conv2d(256, 512, kernel_size=3, padding=1),
            nn.BatchNorm2d(512),
            nn.ReLU(inplace=True),
            nn.Conv2d(512, 512, kernel_size=3, padding=1),
            nn.BatchNorm2d(512),
            nn.ReLU(inplace=True),
            nn.Conv2d(512, 512, kernel_size=3, padding=1),
            nn.BatchNorm2d(512),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2),  # 2x2
        )
        # 分类器
        self.classifier = nn.Sequential(
            nn.AdaptiveAvgPool2d((1, 1)),  # 512x1x1
            nn.Flatten(),
            nn.Dropout(0.5),
            nn.Linear(512, 256),
            nn.BatchNorm1d(256),
            nn.ReLU(inplace=True),
            nn.Dropout(0.3),
            nn.Linear(256, num_classes))
        
    def forward(self, x):
        x = self.features(x)
        x = self.classifier(x)
        return x

class LeNet5_v2_p1(nn.Module):
    def __init__(self, num_classes=10):
        super(LeNet5_v2_p1, self).__init__()
      
        # 特征提取层
        self.features = nn.Sequential(
            # Block 1 (2x conv)
            nn.Conv2d(3, 64, kernel_size=3, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True),
            nn.Conv2d(64, 64, kernel_size=3, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2),  # 16x16
            
            # Block 2 (2x conv)
            nn.Conv2d(64, 128, kernel_size=3, padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU(inplace=True),
            nn.Conv2d(128, 128, kernel_size=3, padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2),  # 8x8
            
            # Block 3 (3x conv)
            nn.Conv2d(128, 256, kernel_size=3, padding=1),
            nn.BatchNorm2d(256),
            nn.ReLU(inplace=True),
            nn.Conv2d(256, 256, kernel_size=3, padding=1),
            nn.BatchNorm2d(256),
            nn.ReLU(inplace=True),
            nn.Conv2d(256, 256, kernel_size=3, padding=1),
            nn.BatchNorm2d(256),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2),  # 4x4
            
            # Block 4 (3x conv)
            nn.Conv2d(256, 512, kernel_size=3, padding=1),
            nn.BatchNorm2d(512),
            nn.ReLU(inplace=True),
            nn.Conv2d(512, 512, kernel_size=3, padding=1),
            nn.BatchNorm2d(512),
            nn.ReLU(inplace=True),
            nn.Conv2d(512, 512, kernel_size=3, padding=1),
            nn.BatchNorm2d(512),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2),  # 2x2
            
            # Block 5 
            nn.Conv2d(512, 512, kernel_size=3, padding=1),
            nn.BatchNorm2d(512),
            nn.ReLU(inplace=True),
            nn.Conv2d(512, 512, kernel_size=3, padding=1),
            nn.BatchNorm2d(512),
            nn.ReLU(inplace=True),
            nn.Conv2d(512, 512, kernel_size=3, padding=1),
            nn.BatchNorm2d(512),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2),  # 1x1
        )
        # 分类器
        self.classifier = nn.Sequential(
            nn.AdaptiveAvgPool2d((1, 1)),  
            nn.Flatten(),
            nn.Dropout(0.6),  
            nn.Linear(512, 512),
            nn.BatchNorm1d(512),
            nn.LeakyReLU(0.1, inplace=True),  # LeakyReLU
            nn.Dropout(0.5),
            nn.Linear(512, 256),
            nn.BatchNorm1d(256),
            nn.LeakyReLU(0.1, inplace=True),
            nn.Dropout(0.3),
            nn.Linear(256, num_classes)
        )
    def forward(self, x):
        x = self.features(x)
        x = self.classifier(x)
        return x




class BasicBlock(nn.Module):
    expansion = 1
    def __init__(self, in_planes, planes, stride=1):
        super(BasicBlock, self).__init__()
        self.conv1 = nn.Conv2d(
            in_planes, planes, kernel_size=3, stride=stride, padding=1, bias=False)
        self.bn1 = nn.BatchNorm2d(planes)
        self.conv2 = nn.Conv2d(planes, planes, kernel_size=3,
                               stride=1, padding=1, bias=False)
        self.bn2 = nn.BatchNorm2d(planes)
        self.shortcut = nn.Sequential()
        if stride != 1 or in_planes != self.expansion*planes:
            self.shortcut = nn.Sequential(
                nn.Conv2d(in_planes, self.expansion*planes,
                          kernel_size=1, stride=stride, bias=False),
                nn.BatchNorm2d(self.expansion*planes)
            )
    def forward(self, x):
        out = F.relu(self.bn1(self.conv1(x)))
        out = self.bn2(self.conv2(out))
        out += self.shortcut(x)
        out = F.relu(out)
        return out
class ResNet(nn.Module):
    def __init__(self, block, num_blocks, num_classes=10):
        super(ResNet, self).__init__()
        self.in_planes = 64
        
        self.conv1 = nn.Conv2d(3, 64, kernel_size=3,
                               stride=1, padding=1, bias=False)
        self.bn1 = nn.BatchNorm2d(64)
        self.layer1 = self._make_layer(block, 64, num_blocks[0], stride=1)
        self.layer2 = self._make_layer(block, 128, num_blocks[1], stride=2)
        self.layer3 = self._make_layer(block, 256, num_blocks[2], stride=2)
        self.layer4 = self._make_layer(block, 512, num_blocks[3], stride=2)
        self.avg_pool = nn.AdaptiveAvgPool2d((1, 1))
        self.linear = nn.Linear(512 * block.expansion, num_classes)
        # 权重初始化
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)
    def _make_layer(self, block, planes, num_blocks, stride):
        strides = [stride] + [1]*(num_blocks-1)
        layers = []
        for stride in strides:
            layers.append(block(self.in_planes, planes, stride))
            self.in_planes = planes * block.expansion
        return nn.Sequential(*layers)
    def forward(self, x):
        out = F.relu(self.bn1(self.conv1(x)))  # [B, 64, 32, 32]
        out = self.layer1(out)                 # [B, 64, 32, 32]
        out = self.layer2(out)                 # [B, 128, 16, 16]
        out = self.layer3(out)                 # [B, 256, 8, 8]
        out = self.layer4(out)                 # [B, 512, 4, 4]
        out = self.avg_pool(out)               # [B, 512, 1, 1]
        out = out.view(out.size(0), -1)        # [B, 512]
        out = self.linear(out)                 # [B, 10]
        return out
def LeNet5_v3():
    return ResNet(BasicBlock, [2, 2, 2, 2])


class DenseLayer(nn.Module):
    def __init__(self, in_channels, growth_rate):
        super(DenseLayer, self).__init__()
        self.bn1 = nn.BatchNorm2d(in_channels)
        self.conv1 = nn.Conv2d(in_channels, 4*growth_rate, kernel_size=1, bias=False)
        self.bn2 = nn.BatchNorm2d(4*growth_rate)
        self.conv2 = nn.Conv2d(4*growth_rate, growth_rate, kernel_size=3, padding=1, bias=False)
    def forward(self, x):
        out = self.conv1(F.relu(self.bn1(x)))
        out = self.conv2(F.relu(self.bn2(out)))
        return torch.cat([x, out], 1)
class DenseBlock(nn.Module):
    def __init__(self, num_layers, in_channels, growth_rate):
        super(DenseBlock, self).__init__()
        self.layers = nn.ModuleList()
        for i in range(num_layers):
            self.layers.append(DenseLayer(in_channels + i*growth_rate, growth_rate))
    def forward(self, x):
        for layer in self.layers:
            x = layer(x)
        return x
class Transition(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(Transition, self).__init__()
        self.bn = nn.BatchNorm2d(in_channels)
        self.conv = nn.Conv2d(in_channels, out_channels, kernel_size=1, bias=False)
        self.pool = nn.AvgPool2d(2, stride=2)
    def forward(self, x):
        x = F.relu(self.bn(x))
        x = self.conv(x)
        x = self.pool(x)
        return x
class DenseNet(nn.Module):
    def __init__(self, growth_rate=12, block_config=(6,6,6), num_classes=10):
        super(DenseNet, self).__init__()
        # Initial convolution
        self.features = nn.Sequential(
            nn.Conv2d(3, 2*growth_rate, kernel_size=3, stride=1, padding=1, bias=False),
            nn.BatchNorm2d(2*growth_rate),
            nn.ReLU(inplace=True)
        )
        
        num_channels = 2*growth_rate
        # Dense blocks
        self.blocks = nn.ModuleList()
        for i, num_layers in enumerate(block_config):
            block = DenseBlock(num_layers, num_channels, growth_rate)
            self.blocks.append(block)
            num_channels += num_layers * growth_rate
            
            if i != len(block_config)-1:
                trans = Transition(num_channels, num_channels // 2)
                self.blocks.append(trans)
                num_channels = num_channels // 2
        # Final layers
        self.final_bn = nn.BatchNorm2d(num_channels)
        self.avgpool = nn.AdaptiveAvgPool2d((1, 1))
        self.classifier = nn.Linear(num_channels, num_classes)
        # Weight initialization
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)
    def forward(self, x):
        x = self.features(x)
        for block in self.blocks:
            x = block(x)
        x = F.relu(self.final_bn(x))
        x = self.avgpool(x)
        x = x.view(x.size(0), -1)
        x = self.classifier(x)
        return x
def LeNet5_v4():
    return DenseNet(growth_rate=24, block_config=(8,8,8,8), num_classes=10)


class InceptionResBlock(nn.Module):
    def __init__(self, in_channels, out_channels, stride=1):
        super().__init__()
        self.branch1 = nn.Sequential(
            nn.Conv2d(in_channels, out_channels//4, 1, stride=stride, padding=0),
            nn.BatchNorm2d(out_channels//4),
            nn.ReLU(inplace=True)
        )
        
        self.branch2 = nn.Sequential(
            nn.Conv2d(in_channels, out_channels//4, 1, padding=0),
            nn.BatchNorm2d(out_channels//4),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_channels//4, out_channels//4, 3, stride=stride, padding=1),
            nn.BatchNorm2d(out_channels//4),
            nn.ReLU(inplace=True)
        )
        
        self.branch3 = nn.Sequential(
            nn.Conv2d(in_channels, out_channels//4, 1, padding=0),
            nn.BatchNorm2d(out_channels//4),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_channels//4, out_channels//4, 3, padding=1),
            nn.BatchNorm2d(out_channels//4),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_channels//4, out_channels//4, 3, stride=stride, padding=1),
            nn.BatchNorm2d(out_channels//4),
            nn.ReLU(inplace=True)
        )
        
        self.branch4 = nn.Sequential(
            nn.AvgPool2d(3, stride=stride, padding=1),
            nn.Conv2d(in_channels, out_channels//4, 1, padding=0),
            nn.BatchNorm2d(out_channels//4),
            nn.ReLU(inplace=True)
        )
        
        self.shortcut = nn.Sequential()
        if stride != 1 or in_channels != out_channels:
            self.shortcut = nn.Sequential(
                nn.Conv2d(in_channels, out_channels, 1, stride=stride),
                nn.BatchNorm2d(out_channels)
            )
    def forward(self, x):
        identity = self.shortcut(x)
        b1 = self.branch1(x)
        b2 = self.branch2(x)
        b3 = self.branch3(x)
        b4 = self.branch4(x)
        out = torch.cat([b1, b2, b3, b4], 1)
        out += identity
        return F.relu(out)
class LeNet5_v5(nn.Module):
    def __init__(self, num_classes=10):
        super().__init__()
        self.conv1 = nn.Conv2d(3, 64, 3, padding=1)
        self.bn1 = nn.BatchNorm2d(64)
        self.relu = nn.ReLU(inplace=True)
        
        # Stage layers
        self.layer1 = self._make_layer(64, 64, 3, stride=1)
        self.layer2 = self._make_layer(64, 128, 3, stride=2)
        self.layer3 = self._make_layer(128, 256, 3, stride=2)
        self.layer4 = self._make_layer(256, 512, 3, stride=2)
        
        self.avgpool = nn.AdaptiveAvgPool2d((1,1))
        self.dropout = nn.Dropout(0.5)
        self.fc = nn.Linear(512, num_classes)
        
    def _make_layer(self, in_channels, out_channels, num_blocks, stride):
        layers = [InceptionResBlock(in_channels, out_channels, stride)]
        for _ in range(1, num_blocks):
            layers.append(InceptionResBlock(out_channels, out_channels, stride=1))
        return nn.Sequential(*layers)
    
    def forward(self, x):
        x = self.conv1(x)
        x = self.bn1(x)
        x = self.relu(x)
        
        x = self.layer1(x)
        x = self.layer2(x)
        x = self.layer3(x)
        x = self.layer4(x)
        
        x = self.avgpool(x)
        x = x.view(x.size(0), -1)
        x = self.dropout(x)
        x = self.fc(x)
        return x





def train(model, device, train_loader, optimizer, epoch):
    model.train()
    loss_fn = nn.CrossEntropyLoss().to(device)
    total_loss = 0.0
    correct = 0

    

    for batch_idx, (data, target) in enumerate(train_loader):

        #print(2)
        
        #data, target = data.to(device), target.to(device)
        data, target = data.to(device, non_blocking=True), target.to(device, non_blocking=True)  
        
        optimizer.zero_grad()
        
        #print( 1)

        output = model(data)
        loss = loss_fn(output, target)
        loss.backward()
        optimizer.step()
        
        # 累计指标
        total_loss += loss.item() * data.size(0)
        pred = output.argmax(dim=1)
        correct += pred.eq(target).sum().item()
        
        if (batch_idx + 1) % 20 == 0:
            print(f'Train Epoch: {epoch} [{batch_idx * len(data)}/{len(train_loader.dataset)} '
                  f'({100. * batch_idx / len(train_loader):.0f}%)]\tLoss: {loss.item():.6f}')
    
    # 计算 epoch 指标
    epoch_loss = total_loss / len(train_loader.dataset)
    epoch_acc = correct / len(train_loader.dataset)
    
    # 记录到 TensorBoard
    writer.add_scalar('Loss/train', epoch_loss, epoch)
    writer.add_scalar('Accuracy/train', epoch_acc, epoch)
    
    return epoch_loss, epoch_acc



def test(model, device, test_loader):
    model.eval()
    test_loss = 0.0
    correct = 0
    loss_fn = nn.CrossEntropyLoss(reduction='sum').to(device)
    
    with torch.no_grad():
        for data, target in test_loader:
            data, target = data.to(device), target.to(device)
            output = model(data)
            test_loss += loss_fn(output, target).item()
            pred = output.argmax(dim=1)
            correct += pred.eq(target).sum().item()
    
    test_loss /= len(test_loader.dataset)
    test_acc = correct / len(test_loader.dataset)
    
    print(f'\nTest set: Average loss: {test_loss:.4f}, Accuracy: {correct}/{len(test_loader.dataset)} '
          f'({100. * test_acc:.2f}%)\n')
    
    return test_loss, test_acc


if __name__ == '__main__':
    print(platform.architecture()) 
    print(Image.__version__)
    
    # 模型选择
    print("\n请选择要使用的模型：")
    print("1. LeNet5：原始的LeNet5模型")
    print("2. LeNet5_v1")
    print("3. LeNet5_v2：基于VGG改进")
    print("4. LeNet5_v2_p1：V2版本多加一层")
    print("5. LeNet5_v3：基于ResNet18改进")
    print("6. LeNet5_v4：基于DenseNet改进")
    print("7. LeNet5_v5：基于Inception的改进，带有残差模块")
    model_choice = input("请输入选项: ").strip()

    model_classes = {
        '1': {'name': 'LeNet5', 'class': LeNet5},
        '2': {'name': 'LeNet5_v1', 'class': LeNet5_v1},
        '3': {'name': 'LeNet5_v2', 'class': LeNet5_v2},
        '4': {'name': 'LeNet5_v2_p1', 'class': LeNet5_v2_p1},
        '5': {'name': 'LeNet5_v3', 'class': LeNet5_v3},
        '6': {'name': 'LeNet5_v4', 'class': LeNet5_v4},
        '7': {'name': 'LeNet5_v5', 'class': LeNet5_v5}
    }
    if model_choice in model_classes:
        model_info = model_classes[model_choice]
    else:
        print("输入无效，默认使用LeNet5")
        model_info = model_classes['1']
    model_name = model_info['name']
    model_class = model_info['class']
    
    # 创建模型实例
    device = "cuda" if torch.cuda.is_available() else "cpu"
    model = model_class().to(device)
    
    # 优化器选择
    print("\n请选择优化器：")
    print("1. Adam")
    print("2. SGD")
    optim_choice = input("请输入选项: ").strip()
    # 初始化优化器
    if optim_choice == '2':
        optimizer = optim.SGD(model.parameters(), lr=0.01, momentum=0.9, weight_decay=5e-4)
        print("使用SGD优化器")
    else:
        optimizer = optim.Adam(model.parameters(),lr=0.1)
        print("使用Adam优化器")


    # 创建保存目录
    save_dir = f"training_results_{model_name}"
    os.makedirs(save_dir, exist_ok=True)
    model_path = os.path.join(save_dir, "model.pth")
    csv_path = os.path.join(save_dir, "training_metrics.csv")

    # 恢复训练检查
    resume = False
    if os.path.exists(model_path) and os.path.exists(csv_path):
        checkpoint = torch.load(model_path, map_location=device)
        saved_model_type = checkpoint.get('model_type', '')
        saved_optim_type = checkpoint.get('optimizer_type', '1')  # 默认为Adam
        
        # 模型类型检查
        if saved_model_type != model_name:
            print(f"\n发现已有训练结果，但模型类型不匹配")
            print("无法继续训练，将开始新的训练！")
        # 优化器类型检查
        elif saved_optim_type != optim_choice:
            print(f"\n警告：保存的优化器类型为{'SGD' if saved_optim_type == '2' else 'Adam'}，当前选择为{'SGD' if optim_choice == '2' else 'Adam'}")
            print("优化器类型不匹配，将重新初始化优化器！")
        else:
            choice = input("\n发现匹配的训练结果，是否继续训练？(y/n): ").lower()
            resume = (choice == 'y')
    


    
    epochs_app = int(input("输入轮数:"))
    
    

    # 恢复训练时的状态加载
    if resume:
        checkpoint = torch.load(model_path, map_location=device)
        model.load_state_dict(checkpoint['model_state_dict'])
        optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
        
        start_epoch = checkpoint['epoch'] + 1
        print(f"将从第 {start_epoch} 轮继续训练")
        # 加载历史指标
        df_hist = pd.read_csv(csv_path)
        metrics = {
            'epoch': df_hist['epoch'].tolist(),
            'train_loss': df_hist['train_loss'].tolist(),
            'train_acc': df_hist['train_acc'].tolist(),
            'test_loss': df_hist['test_loss'].tolist(),
            'test_acc': df_hist['test_acc'].tolist()
        }
    else:
        metrics = {'epoch': [], 'train_loss': [], 'train_acc': [], 'test_loss': [], 'test_acc': []}
        start_epoch = 1
        print("开始新的训练")

        
    print("\n模型结构概要：")
    summary(model, (1, 3, 32, 32))

    # 初始化TensorBoard
    writer = SummaryWriter(log_dir=os.path.join(save_dir, "logs"))


    # 加载MNIST数据集
    #train_dataset = datasets.MNIST(root='./data', train=True, transform=transforms.Compose([transforms.ToTensor(),transforms.Normalize((0.1307,),(0.3081))])  , download=True)
    #test_dataset = datasets.MNIST(root='./data', train=False, transform=transforms.Compose([transforms.ToTensor(),transforms.Normalize((0.1307,),(0.3081))]))


    train_transform = transforms.Compose([
        transforms.RandomHorizontalFlip(),    # 随机水平翻转
        transforms.RandomCrop(32, padding=4), # 随机裁剪
        transforms.ColorJitter(brightness=0.2, contrast=0.2), # 颜色抖动
        transforms.RandomRotation(15),
        transforms.ToTensor(),
        transforms.Normalize((0.4914, 0.4822, 0.4465), (0.2470, 0.2435, 0.2616)), # CIFAR-10均值方差
        transforms.RandomErasing(p=0.5)
    ])
    test_transform = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize((0.4914, 0.4822, 0.4465), (0.2470, 0.2435, 0.2616))
    ])


    #加载cifar
    train_dataset = datasets.CIFAR10(root='./data/Cifar', train=True, transform=train_transform ,download=True)
    test_dataset = datasets.CIFAR10(root='./data/Cifar', train=False, transform=test_transform  )

    # 定义数据加载器
    train_loader = torch.utils.data.DataLoader(dataset=train_dataset, batch_size=256, shuffle=True ,num_workers=8, pin_memory=True,persistent_workers=True)
    test_loader = torch.utils.data.DataLoader(dataset=test_dataset, batch_size=256, shuffle=False  ,num_workers=4, pin_memory=True,persistent_workers=True)

    

    # 训练模型
    for epoch in range(start_epoch, start_epoch + epochs_app):
        # 训练阶段
        train_loss, train_acc = train(model, device, train_loader, optimizer, epoch)
        
        # 测试阶段
        test_loss, test_acc = test(model, device, test_loader)

        

        # 记录指标
        metrics['epoch'].append(epoch)
        metrics['train_loss'].append(train_loss)
        metrics['train_acc'].append(train_acc)
        metrics['test_loss'].append(test_loss)
        metrics['test_acc'].append(test_acc)
        # 实时保存
        pd.DataFrame(metrics).to_csv(csv_path, index=False)
        torch.save({
            'epoch': epoch,
            'model_state_dict': model.state_dict(),
            'optimizer_state_dict': optimizer.state_dict(),
            'model_type': model_name,
            'optimizer_type': optim_choice, 
            'train_loss': train_loss,
            'train_acc': train_acc,
            'test_loss': test_loss,
            'test_acc': test_acc
        }, model_path)
        # TensorBoard记录
        writer.add_scalar('Loss/train', train_loss, epoch)
        writer.add_scalar('Accuracy/train', train_acc, epoch)
        writer.add_scalar('Loss/test', test_loss, epoch)
        writer.add_scalar('Accuracy/test', test_acc, epoch)
    # 关闭 TensorBoard writer
    writer.close()

    model_path = os.path.join(save_dir, f"model.pth")
    torch.save({
        'epoch': epoch,
        'model_state_dict': model.state_dict(),
        'optimizer_state_dict': optimizer.state_dict(),
        'model_type': model_name,  
        'train_loss': train_loss,
        'train_acc': train_acc,
        'test_loss': test_loss,
        'test_acc': test_acc
    }, model_path)

    print("训练完成！结果保存在", save_dir)
    
    # 读取保存的指标数据
    df = pd.read_csv(os.path.join(save_dir, "training_metrics.csv"))

    max_acc = df['test_acc'].max()
    print(f"MAX_ACC={max_acc}")
    # 创建画布和子图
    plt.figure(figsize=(12, 6))
    # 绘制Loss曲线
    plt.subplot(1, 2, 1)
    plt.plot(df['epoch'], df['train_loss'], label='Train Loss', marker='o')
    plt.plot(df['epoch'], df['test_loss'], label='Test Loss', marker='s')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.title('Training & Test Loss')
    # 设置y轴范围和刻度

    all_loss = pd.concat([df['train_loss'], df['test_loss']])
    min_loss = np.floor(all_loss.min() * 10) / 10  # 向下取整到0.1
    max_loss = np.ceil(all_loss.max() * 10) / 10   # 向上取整到0.1

    plt.ylim(min_loss, max_loss) 
    plt.yticks(np.arange(min_loss, max_loss, 0.3))
    plt.grid(True, linestyle='--', alpha=0.7)
    plt.legend()
    # 绘制Accuracy曲线
    plt.subplot(1, 2, 2)
    plt.plot(df['epoch'], df['train_acc'], label='Train Acc', marker='o')
    plt.plot(df['epoch'], df['test_acc'], label='Test Acc', marker='s')
    plt.xlabel('Epoch')
    plt.ylabel('Accuracy')
    plt.title('Training & Test Accuracy')
    # 设置y轴范围和刻度
    plt.ylim(0.3, 1.0) 
    plt.yticks(np.arange(0.3, 1.1, 0.1))  
    
    # 设置网格和legend位置
    plt.grid(True, linestyle='--', alpha=0.7)
    plt.legend(loc='lower right')  # 图例放在右下角
    
    # 调整布局并保存图片
    plt.tight_layout()
    plt.savefig(os.path.join(save_dir, 'training_metrics.png'))
    plt.show()
    #sys.exit()
  