% 实验3.1(2) 谐波信号采样
figure;
A=[1, 0.5, 0.25];
fo=5;
n=0:0.7:30;
subplot(3,2,1);
x=0;
t=0:0.0005:0.5;
for m=1:3
    x=x+A(m)*sin(2*pi*fo*m*t);
end
plot(t,x);
title('连续信号');
xlabel('t (s)');
grid on;
%10倍fo采样
subplot(3,2,2);
x=0;
fs=10*fo; 
for m=1:3
    x=x+A(m)*sin(2*pi*fo*m*n/fs);
end
stem(n,x,'fill');
title('10倍频率采样');
xlabel('n ');
grid on;
%8倍fo采样
subplot(3,2,3);
x=0;
fs=8*fo; 
for m=1:3
    x=x+A(m)*sin(2*pi*fo*m*n/fs);
end
stem(n,x,'fill');
title('8倍频率采样');
xlabel('n ');
grid on;
%5倍fo采样
subplot(3,2,4);
x=0;
fs=5*fo; 
for m=1:3
    x=x+A(m)*sin(2*pi*fo*m*n/fs);
end
stem(n,x,'fill');
title('5倍频率采样');
xlabel('n ');
grid on;
%2fo采样
subplot(3,2,5);
x=0;
fs=2*fo; 
for m=1:3
    x=x+A(m)*sin(2*pi*fo*m*n/fs);
end
stem(n,x,'fill');
title('2倍频率采样');
xlabel('n ');
grid on;
%fo采样
subplot(3,2,6);
x=0;
fs=fo; 
for m=1:3
    x=x+A(m)*sin(2*pi*fo*m*n/fs);
end
stem(n,x,'fill');
title('1倍频率采样');
xlabel('n ');
grid on;