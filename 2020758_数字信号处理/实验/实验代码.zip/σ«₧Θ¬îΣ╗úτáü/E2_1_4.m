% 实验2 4
fp1=440;
fp2=560;
ap=0.1;   % dB
fs1=275;
fs2=900;
as=60;  % dB
f_N=20000;
wp1 = fp1 / (f_N / 2);
wp2 = fp2 / (f_N / 2);
ws1 = fs1 / (f_N / 2);
ws2 = fs2 / (f_N / 2);
% Chebyshev Filter Design
[N, Wn] = ellipord([wp1 wp2], [ws1 ws2], ap, as);
[b, a] = ellip(N, ap, as, Wn, 'bandpass');
figure;
freqz(b, a, 1024, f_N);
title('Elliptic Bandpass Filter');

N=1600;
Ts=1/f_N;
n=0:1:(N-1);
t=n*Ts;
% Modulating Freq
fc1=100;
fc2=500;
fc3=1000;
% Carrier Freq
carrier_f=cos(2*pi*500*t);
% Amplitude-modulation signal
x=(cos(2*pi*fc1*t)+cos(2*pi*fc2*t)+cos(2*pi*fc3*t)).*carrier_f;

% Ini fig(time)
figure;
subplot(2,2,1);
plot(t,x);
xlabel('t(s)');
ylabel('Amplitude');
title('Original-time figure');
% Ini fig(freq)
xf0 = fft(x);
subplot(2,2,2);
plot(n*f_N/N,abs(xf0));
title('Original-frequency figure');
xlabel('f(Hz)');
ylabel('Amplitude');

% Pass the filter
filtered_signal = filter(b, a, x);
% Pass fig(time)
subplot(2,2,3);
plot(t, filtered_signal, 'r');
title('Filtered-time figure');
xlabel('t (s)');
ylabel('Amplitude');
% Pass fig(freq)
xf = fft(filtered_signal);
subplot(2,2,4);
plot(n*f_N/N,abs(xf));
title('Filtered-frequency figure');
xlabel('f(Hz)');
ylabel('Amplitude');