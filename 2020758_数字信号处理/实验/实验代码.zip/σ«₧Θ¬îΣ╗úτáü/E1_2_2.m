% 3.2(2)
fs=64;
t=0:1/fs:1-1/fs;
signal=@(t) 2*cos(8*pi*t) + 4*cos(16*pi*t) + cos(20*pi*t);
N_values=[16, 32, 64];
figure;
for i=1:3
    N=N_values(i);
    t_sampled=0:1/fs:(N-1)/fs;
    x=signal(t_sampled);
    Y=fft(x, N); 
    f=fs*(0:(N-1))/N;
    subplot(3, 1, i);
    stem(f, abs(Y), 'fill');
    title(['N=' num2str(N)]);
    xlabel('频率');
    ylabel('幅值');
    grid on;
end