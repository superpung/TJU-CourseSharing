% 实验2 6 2
fs = 1024;
N = 1024;
fo = 10;
fc = 100;
fp = 115;
fs1 = 130;
ap = 0.1;   % dB
as = 60;    % dB
t = (0:N-1) / fs;
xa = cos(2 * pi * fo * t) .* cos(2 * pi * fc * t);
% Generate noise
noise = randn(1, N);
% Butterworth filter
Wp_norm = ap / (fs / 2);
Ws_norm = as / (fs / 2);
[n_butter, Wn_butter] = buttord(Wp_norm, Ws_norm + 50/(fs/2), ap, as);
[b_hp, a_hp] = butter(n_butter, Wn_butter, 'high');
filtered_noise = filter(b_hp, a_hp, noise);
combined_signal = xa + filtered_noise;
% FIR
beta = 4;
b_lp = fir1(100, fp / (fs/2), 'low', kaiser(101,beta));
filtered_signal = filter(b_lp, 1, combined_signal);
[H, w] = freqz(b_lp, 1, 1024, fs);
figure;
subplot(2, 1, 1);
plot(w, 20*log10(abs(H)));
title('FIR Lowpass Filter Frequency Response');
xlabel('Frequency(Hz)');
ylabel('Amplitude(dB)');
grid on;
subplot(2, 1, 2);
plot(w, angle(H) * 180 / pi);
title('FIR Lowpass Filter Phase Response');
xlabel('Frequency(Hz)');
ylabel('Phase(degree)');
grid on;

figure;
subplot(2, 1, 1);
plot(t, filtered_signal);
title('Output time figure');
xlabel('t(s)');
ylabel('Amplitude');

f = (0:N-1) * fs / N;
X_filtered = fft(filtered_signal);
X_filtered_mag = abs(X_filtered);
subplot(2, 1, 2);
plot(f, X_filtered_mag);
title('Output frequency figure');
xlabel('Frequency(Hz)');
ylabel('Amplitude');
xlim([0, fs/2]);
