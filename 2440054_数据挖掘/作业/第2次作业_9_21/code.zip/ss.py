from matplotlib import pyplot as plt
import numpy as np
from scipy import stats

data = [13,15,16,16,19,20,20,21,22,22,25,25,25,25,30,33,33,35,35,35,35,36,40,45,46,52,70]
data = np.array(data)
# data = (data - data.mean()) / data.std()
# 计算Q1,Q3 分位数
Q1 = np.percentile(data, 25) 
Q3 = np.percentile(data, 75)
from scipy import stats
# 使用K-S检验
ks_result = stats.kstest(data, 'norm')
print('K-S统计量:', ks_result[0])  
print('P值:', ks_result[1])
# 求IQR
IQR = Q3 - Q1
#箱线下限
low_limit = Q1 - 1.5*IQR
#箱线上限  
upper_limit = Q3 + 1.5*IQR

print('下限:',low_limit)
print('上限:',upper_limit)

#方法一:直接判断是否超过箱线
outliers = list(data[data < low_limit]) + list(data[data > upper_limit])
print('直接法离群点:',outliers) 

#方法二:根据Z值判断
zscore = stats.zscore(data)
outliers = data[np.abs(zscore) > 3]
print('Z值法离群点:',outliers)

# plt.boxplot(data)
# plt.hist(data)
plt.xlabel('Data')
plt.ylabel('Value')
plt.title('Boxplot')
plt.show()
