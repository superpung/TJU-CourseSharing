# import lightgbm as lgb
from sklearn.model_selection import train_test_split
import pandas as pd
from sklearn.preprocessing import StandardScaler, MinMaxScaler, minmax_scale
from lightgbm import LGBMClassifier
from xgboost import XGBRFClassifier, XGBClassifier
from catboost import CatBoostClassifier
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier, AdaBoostClassifier
from sklearn.neighbors import KNeighborsClassifier

# 数据加载和转换
datatrain = pd.read_csv('./trainraw.csv', header='infer', index_col=0)
datatest = pd.read_csv('./testraw.csv', header='infer', index_col=0)

X_t = datatest.drop('label', axis=1).to_numpy()
y_t = datatest['label'].to_numpy()

X = datatrain.drop('label', axis=1).to_numpy()
y = datatrain['label'].to_numpy()
# print(X.shape)

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.1)
import warnings
warnings.filterwarnings('ignore')
xgb = XGBClassifier(max_depth=5, n_estimators=140)
lgb = LGBMClassifier(boosting_type='dart', max_depth=5, n_estimators=140, 
                     num_leaves=256, max_bin=256, 
                     feature_fraction=0.8, verbosity=0)
cat = CatBoostClassifier(iterations=100)
rf = RandomForestClassifier(max_depth=5, n_estimators=140)

gbdt = GradientBoostingClassifier(max_depth=5, n_estimators=140)
ada = AdaBoostClassifier(n_estimators=100)

gbm = gbdt

gbm.fit(X_train, y_train)

# 预测
y_pred = gbm.predict(X_test)
# 评估
from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score
print('Accuracy: %.4f' % accuracy_score(y_test, y_pred))
print('f1_score: %.4f' % f1_score(y_test, y_pred))
print('precision_score: %.4f' % precision_score(y_test, y_pred))
print('recall_score: %.4f' % recall_score(y_test, y_pred))


import pandas as pd
import os
from scipy import interpolate
import numpy as np
import numpy as np
final = pd.DataFrame([], columns=['name', 'label', 'num'])

for path, dir, files in os.walk('./电动车充电识别-数据/test/'):
    # print(len(files))
    for file in files:
        realpath = os.path.join(path, file)
        with open(realpath, 'r', encoding='utf-8') as f:
            realpath = os.path.join(path, file)
            # print(file)
            raw_data = pd.read_csv(realpath, header=None, names=['data']).to_numpy()
            # print(raw_data)
            if len(raw_data) != 280:
                # print('aaa', len(raw_data), file)
                x = np.linspace(0, 1, len(raw_data))
                y = raw_data.flatten()
                f = interpolate.interp1d(x, y, kind="quadratic")
                xnew = np.linspace(0, 1, 280)
                ynew = f(xnew)
                # print(len(ynew))
                raw_data = ynew.reshape((-1, 1))
                # print(raw_data.shape)
                # continue
            raw_data = list(raw_data.flatten())
            label: np.ndarray = gbm.predict([raw_data])
            num = int(str(file).split('.')[0])

            final.loc[len(final)] = [str(file), label[0], num]

final.set_index('name', inplace=True)
final = final.sort_values(by='num')
final = final.drop('num', axis=1)
print(final['label'].to_numpy().flatten())

final.to_csv('./res.csv')
# [2 2 0 0 2 2 2 2 0 0 2 0 2 0 2 2 0 0 2 2 0 0 2 2 2 2 2 0 2 2 2 0 2 0 0 0 2
#  2 2 2 2 2 2 0 2 2 2 0 2 2 0 2 0 0 0 2 2 0 0 2 0 2 2 2 2 2 0 0 2 0 2 2 2 2
#  2 2 0 2 2 2 2 2 0 0 0 2 2 2 2 0 0 0 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2
#  2 2 0 2 2 2 0 0 0 2 2 0 2 0 0 2 0 0 2 0 2 2 2 0 0 0 2 2 0 0 2 2 0 0 2 0 2
#  2 2 2 2] (152, 281)
