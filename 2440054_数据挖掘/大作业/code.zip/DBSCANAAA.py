from sklearn.cluster import DBSCAN
from sklearn import metrics
from sklearn.datasets import make_blobs
from sklearn.preprocessing import StandardScaler

# 产生一些模拟数据
import pandas 

data = pandas.read_csv("trainraw.csv", index_col=0)
X = data.drop('label', axis=1)
y = data['label']

# 标准化特征,方便计算距离
X = StandardScaler().fit_transform(X) 

# 定义DBSCAN参数
eps = 0.3
min_samples = 5

# 得出预测结果
db = DBSCAN(eps=eps, min_samples=min_samples).fit(X)
labels = db.labels_

n_clusters_ = len(set(labels)) - (1 if -1 in labels else 0)
n_noise_ = list(labels).count(-1)

import matplotlib.pyplot as plt
plt.figure(figsize=(12, 5))
plt.scatter(X[:, 141], X[:, 1], c=labels)
print(labels)
plt.show()

print('Estimated number of clusters: %d' % n_clusters_)
print('Estimated number of noise points: %d' % n_noise_)

# 评估簇划分的质量
print('Homogeneity: %0.3f' % metrics.homogeneity_score(y, labels))
print('Completeness: %0.3f' % metrics.completeness_score(y, labels))
print('V-measure: %0.3f' % metrics.v_measure_score(y, labels))
print('Adjusted Rand Index: %0.3f' 
      % metrics.adjusted_rand_score(y, labels))
print('Adjusted Mutual Information: %0.3f'
      % metrics.adjusted_mutual_info_score(y, labels))