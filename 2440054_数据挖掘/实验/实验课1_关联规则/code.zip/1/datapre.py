from apyori import apriori
import numpy as np
# 事务数据集
dataset = [['牛奶', '洋葱', '肉豆蔻', '芸豆', '鸡蛋', '酸奶'],
           ['洋葱', '肉豆蔻', '芸豆', '鸡蛋', '酸奶'],
           ['牛奶', '芸豆', '鸡蛋'],
           ['牛奶', '洋葱', '肉豆蔻', '芸豆', '酸奶'],
           ['洋葱', '肉豆蔻', '芸豆', '酸奶']]

# 转换数据集格式
allitems = []
for transaction in dataset:
    allitems += [str(item) for item in transaction]
    
quantity = {}
for item in allitems:
    if not item in quantity.keys():
        quantity.update({
            item: 0
        })
    quantity[item]+=1
    
min_support = 2
for index, transaction in enumerate(dataset):
    for item in transaction:
        if quantity[item] < min_support:
            dataset[index].remove(item)
    
