from apyori import apriori
import numpy as np
# 事务数据集
import pandas as pd

dataset = pd.read_csv('./data.csv', header='infer').to_numpy()
dataset_processed = []
for index in range(len(dataset)):
    dataset_processed.append([])
    dataset_processed[index].append(dataset[index][1])
    dataset_processed[index] += [line.lower() for line in str(dataset[index][2]).split(sep='、')]
# print(dataset_processed)

# 转换数据集格式
transactions = []
for transaction in dataset_processed:
    transactions += [str(item) for item in transaction]
# print(transactions)

quantity = {}
for item in transactions:
    if item not in quantity.keys():
        quantity.update({
            item: 0
        })
    quantity[item]+=1
trans_len = len(dataset_processed)
# print(quantity)

for min_support in range(2, 5):
    dataset_supported = []
    for index, line in enumerate(dataset_processed):
        dataset_candidate = []
        for item in line:
            if quantity[item] >= min_support:
                dataset_candidate.append(item)
        dataset_supported.append(dataset_candidate)
    print(f"min_support: {min_support} \n", dataset_supported)
    
    # 使用Apriori算法查找频繁项集
    results = list(apriori(dataset_supported, min_support=min_support/trans_len))

    # 打印频繁项集和关联规则
    with open(f'./{min_support}.txt', 'w', encoding='utf-8') as f:
        for result in results:
            itemset: frozenset = result.items
            support = result.support
            print(f"频繁项集: {itemset}, 支持度: {support}")
            f.write(f"频繁项集: {itemset}, 支持度: {support}\n".replace('frozenset', ''))

        # for rule in result.ordered_statistics:
        #     antecedent = rule.items_base
        #     consequent = rule.items_add
        #     confidence = rule.confidence
        #     print(f"关联规则: {antecedent} -> {consequent}, 置信度: {confidence}")