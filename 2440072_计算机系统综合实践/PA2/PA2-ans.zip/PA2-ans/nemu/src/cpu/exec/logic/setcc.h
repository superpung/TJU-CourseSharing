#ifndef __SETCC_H__
#define __SETCC_H__

make_helper(setne);

#endif
