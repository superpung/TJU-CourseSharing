#ifndef __TEST_H__
#define __TEST_H__

make_helper(test_i2rm_b);
make_helper(test_r2rm_b);

make_helper(test_i2rm_v);
make_helper(test_r2rm_v);

#endif
