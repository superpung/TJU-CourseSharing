#undef SUFFIX
#undef DATA_TYPE
#undef DATA_TYPE_S

#undef REG
#undef REG_NAME

#undef MEM_R
#undef MEM_W

#undef OPERAND_W

#undef MSB
